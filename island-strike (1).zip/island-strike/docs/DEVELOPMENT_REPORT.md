# ISLAND STRIKE — DEVELOPMENT REPORT

## VERSION

v2.3.0

## DATE

2026-09-19

## PHASE

Master Plan v2.1 Adoption — Mission 01/02 Evidence Audit + Atomic Save Hardening + Documentation Protocol

## STATUS

LOCKED

---

# 1. OBJECTIVE

PLANNED:
- Adopt Master Plan v2.1 and its post-execution documentation protocol.
- Map the plan's defect list (D1–D8, Mission 01 "Baseline Stabilization") and Mission 02
  ("Performance Truth") against the ACTUAL runtime state of the project — using the plan's own
  rule (§84): trust runtime evidence over old reports.
- Execute any genuine residuals found.
- Establish this document as the permanent development record (§23 change history, §24 status table).

---

# 2. PRE-EXECUTION STATE

Verified by direct source inspection and CI logs before any change this round:

- CI wrapper (plan defect D8): ALREADY PRESENT — `tools/ci.sh`, 11 registered suites,
  error gate + leak gate + contention-aware perf gate. Multiple consecutive PASS runs on record.
- Runtime errors (D1): error gate reports zero `ERROR:`/`SCRIPT ERROR:` (outside allowlisted
  upstream #95484 teardown summaries) across all suites. One real runtime bug (corpse-fade tween
  on CharacterBody3D) had been caught by this gate in a prior round and fixed at source.
- Leaks (D2): leak gate operational; audio teardown fixes in `game.gd` (`_stop_all_audio`,
  `_loop_wav`); verbose-rerun policy documents the timing-masked upstream race.
- Vehicle test weakness (D3): ALREADY CLOSED — `tests/smoke_node.gd` contains ABSOLUTE
  acceleration bounds, not class-relative ones: sports ≥ 3.5 m/s, bus ≥ 1.5 m/s,
  healthy sedan ≥ 2.0 m/s, worn-engine vs fresh ratio check, moto and boat move-under-throttle checks.
- Night population (D4): civilian director applies 0.45 night multiplier — identical to the
  documented −55%. Smoke harness ticks the director at real cadence and asserts
  "civilian population sustained". Status: closed by spec-alignment (documented value == code value).
- Save migration (D5): `SaveSystem.migrate()` chain v1→v2→v3 exists; smoke contains a REAL
  v1-payload migration test (writes a v1 file, loads, verifies money/owned/stats) and a
  corruption-rejection test (invalid JSON rejected without side effects).
- Performance truth (Mission 02): ALREADY CLOSED — `tools/perf_probe.gd`, 27 stations
  (9 districts × day/night × clear/rain), budgets enforced in CI (9.0 ms physics row /
  13.5 ms worst frame), contention-aware best-of-3.
- Genuine residual found: `save_game()` wrote the main save file in place — a crash mid-write
  could corrupt it. Plan §56 requires write-temp → flush → replace.

---

# 3. FILES INSPECTED

- tools/ci.sh
- tools/perf_probe.gd (outputs via CI logs)
- scripts/core/save_system.gd
- scripts/core/game_state.gd
- scripts/game/game.gd
- scripts/weapons/pistol.gd
- scripts/player/player.gd
- scripts/npc/person.gd
- scripts/world/world_builder.gd
- scripts/world/building_kit.gd
- tests/smoke_node.gd (vehicle bounds, migration test, corruption test, night ticks)
- tests/system_test.gd, tests/weapon_system_test.gd, tests/loadcheck.gd
- project.godot

---

# 4. FILES MODIFIED

- scripts/core/save_system.gd (atomic save write)
- docs/DEVELOPMENT_REPORT.md (created — this file; documentation protocol deliverable)
- tools/lock_ledger.json (round15 entry appended after lock)

---

# 5. FILES CREATED

- docs/DEVELOPMENT_REPORT.md
- (no game-code files created this round)

---

# 6. IMPLEMENTATION

IMPLEMENTED:
1. Atomic save persistence path per plan §56:
   `save_game()` now writes to `SAVE_PATH + ".tmp"`, flushes, closes, then
   `DirAccess.rename_absolute(tmp, final)`. On rename failure the tmp file is removed,
   the player is notified, and the function returns false. The main save file is never
   partially written.

NOT IMPLEMENTED THIS ROUND (recorded honestly):
- Mission 07 Mission Framework — identified as the next phase, not started.
- NavigationAgent3D per-NPC avoidance (plan §11 refinement) — current navigation is a
  NavigationRegion3D + 16,610-cell grid with steering; avoidance upgrade is a later phase.

---

# 7. BUGS DISCOVERED

### Bug 01 (historical, prior round — preserved per §22/§23)

Problem: Corpse fade tweened `transparency` on CharacterBody3D → script error every NPC death.
Root Cause: `transparency` is a GeometryInstance3D property, not a Node3D/CharacterBody3D property.
Fix: Fade all MeshInstance3D children of the body (`person.gd`).
Result: PASS — 3 consecutive clean smoke runs after fix.

### Bug 02 (historical, prior round)

Problem: EventBus witness pass crashed on freed cached civilians.
Root Cause: Typed loop variable assigned a freed instance; then `is` check on freed instance also errors (Godot 4.5).
Fix: Untyped loop + `is_instance_valid(c)` FIRST, type check second.
Result: PASS.

### This round

No new bugs discovered. Atomic save passed existing save/load, v1-migration and corruption
tests on first run.

---

# 8. TESTS

Full battery (executed this round, headless CI):

- loadcheck: PASS (20 script files)
- walk_test: PASS
- character_test: PASS
- smoke_test: PASS (includes save/load roundtrip, v1 migration, corruption rejection,
  absolute vehicle bounds, atomic-save path)
- stress_main: PASS
- menu_test: PASS
- world_data_test: PASS (IDENTICAL — public contract unchanged)
- terrain_test: PASS
- clothing_test: PASS
- weapon_system_test: PASS (15/15)
- system_test: PASS (32/32)
- perf_probe: PASS both runs — integration worst 4.47 ms (attempt 1 discarded: runner
  contention tp 23.5 ms), regression worst 3.88 ms (two contended attempts discarded at
  tp 14.5/35.5 ms, attempt 3 verified) — all < 13.5 budget

Historical intermediate failures preserved (not hidden):
- Round 14: CI FAIL twice during hardening — freed-instance errors in the new crime-record
  path; root-caused and fixed before lock.
- Round 13: first integration FAIL — three building gates 0-count (wrong node anchors);
  fixed; second run PASS.

---

# 9. RUNTIME VERIFICATION

- Full game boots headless and runs the complete world build in every suite (all suites
  instantiate `game.tscn`).
- Save/load roundtrip verified in smoke (money frozen during save, restored on load,
  health restored, weapon ownership persists).
- v1 save file → migrate → load verified with real file I/O in smoke.
- Corrupt save rejected without side effects, verified.
- Atomic write exercised every `save_game()` call in all suites; no save failures logged.
- Runtime verification of packaged Windows export: NOT TESTED (no export performed this round).

---

# 10. PERFORMANCE

Measured (perf_probe, headless, 27 stations):

- Worst frame: 4.47 ms (integration run) / 3.88 ms (regression run) — this round's two
  full CI runs (budget 13.5 ms).
- Physics rows: all districts under the 9.0 ms budget in passing runs.
- Notable measurements this program: Airport physics 9.16→3.40/2.89 ms (rooftop-detail
  physics fix, Round 12 era); worst frame 8.61 → 5.10 ms across rounds (streamer hysteresis,
  additive-only world layers).

NOT MEASURED:
- GPU frame cost (headless cannot render — probe prints this explicitly).
- Draw calls / VRAM (not instrumented).
- FPS on target hardware (no hardware run this round).

---

# 11. MEMORY / RESOURCE RESULTS

- Leak gate: zero actionable leaks across suites (summary-only upstream #95484 audio
  teardown objects allowed per documented policy; verbose re-runs did not reproduce).
- Node counts: ~8,300–8,800 per perf probe stations (varies by district/weather).
- Exact RAM/VRAM deltas this round: NOT MEASURED (no instrumentation for VRAM; RAM tracked
  only via probe station log lines ~147–165 MB total, platform-reported).

---

# 12. REGRESSION

Player: PASS (walk_test)
Camera/Character: PASS (character_test)
Vehicles: PASS (smoke absolute-bounds + stress)
NPC/Police: PASS (smoke staged-escalation checks)
Weapons: PASS (weapon_system_test 15/15)
World data contract: PASS (world_data_test IDENTICAL)
Terrain: PASS (terrain_test)
UI/Menu: PASS (menu_test)
Core services: PASS (system_test 32/32)
Save/Load: PASS (smoke roundtrip + migration + corruption)

All required regressions passed. No non-blocking exceptions.

---

# 13. SAVE/LOAD

PASS.

This round's changes affect the save WRITE path only. Verified:
NEW SAVE → SAVE (atomic tmp→rename) → LOAD → state verified (money/health/weapons/
collected/delivery/flags). v1 payload migration and corruption rejection re-verified.
Save version remains 3; no schema change this round.

---

# 14. CONTROLLER

Input-map verification (code level): all gameplay actions bound with XBOX/PlayStation
mappings in `game_state.gd` (movement, look, aim, fire, reload, wheel, D-pad fast switch,
cover, phone, map, pause). Weapon wheel + fast-switch tested in smoke/system tests
(headless input synthesis).

Runtime hardware controller test: NOT TESTED this round (no physical device pass).
Recorded as a QA-matrix item for the release phase.

---

# 15. KNOWN LIMITATIONS

- GPU cost NOT MEASURED (headless CI); release QA requires a rendered hardware run.
- Packaged Windows export NOT TESTED yet (plan §75/§76 pending).
- Mission system is ad-hoc (street race + courier deliveries); the generic MissionFramework
  (§26–28: MissionManager/objectives/checkpoints) is NOT STARTED — next phase.
- Navigation is region+grid steering; NavigationAgent3D avoidance and rooftop/interior
  nav-links NOT IMPLEMENTED.
- GPS routing on the road network NOT IMPLEMENTED (map UI exists; GPS does not).
- Interiors are kit-furnished but few are enterable beyond the existing 8 storefronts +
  service buildings; plan §31 scope not started.
- Controller hardware QA pending; input map verified code-level only.
- Witness model is distance-based in the crime record (LOS refinement lives in police
  perception layer); suspect identification/memory (§14 Witness 2.0) NOT IMPLEMENTED.

---

# 16. BEFORE / AFTER

Before (this round):
- Save file written in place; a crash mid-write could corrupt the only save.

After:
- Atomic tmp→rename write; partial writes impossible on the main file; failure path
  notifies and preserves the previous good save.

Before (program-level, v1.0.0 → v2.3.0):
- Flat world, 9-suite battery, monolithic world build, no event bus, no economy ledger,
  no debug command API, no structured crime records, no building asset pipeline.

After:
- Hybrid terrain (hills 20–40 m / mountains 80–120 m + flat city contract), 11-suite CI
  with error/leak/perf gates, decomposed world builder (17 district/tool modules),
  EventBus + ring log + structured CRIME records, centralized Economy with ledger,
  DebugTools stats/command API, 10-building Blender-authored GLB set + game-side kit,
  atomic saves.

---

# 17. ARCHITECTURAL IMPACT

Core layers now present (plan §4 mapping):

CORE: GameState, SaveSystem (atomic), EventBus (autoload), Economy, DebugTools
WORLD: WorldBuilder orchestrator → districts/*.gd + wb_kit/wb_arch + BuildingKit + Dressing
PLAYER: player.gd + WeaponSystem (7-weapon data-driven) + CharacterRig
NPC: person/civilian/commuter/service/police/gang/military/beach + schedules + sim tiers T0–T4
VEHICLE: car.gd class system + traffic pools + boats
MISSIONS: race.gd + delivery.gd (ad-hoc; framework pending)
UI: hud + pause + settings + world map

Affected systems this round: SaveSystem write path only. No locked contract modified.

---

# 18. LOCK

LOCKED.

Acceptance: full 11-suite CI PASS (integration, worst 4.47 ms) + second full CI PASS
(regression, worst 3.88 ms), world_data IDENTICAL, save/load + migration + corruption
PASS, no open P0/P1 defects. Contention-aware perf gate discarded 3 contended attempts
across the two runs and verified on clean attempts — budgets never relaxed.

---

# 19. NEXT PHASE

Phase: **v2.5 GPS route line** (roadmap: GPS → NavigationAgent3D+avoidance →
Witness 2.0 → garage/ownership → interiors → world events 2.0 → audio 2.0 →
controller QA → Windows export alpha).

Reason: Mission Framework locked (the central orchestrator now exists); navigation aid
is the next highest-leverage player-facing gap and feeds the NavigationAgent3D work.

---

# CHANGE HISTORY

## v2.4.0 — 2026-09-19
Phase: Master Plan v2.4 Mission Framework (Gate 01 engine → Gate 02 rebuild → Gate 03 content)
Result: LOCKED
PLANNED → IMPLEMENTED → TESTED → VERIFIED (actuals below; nothing aspirational):
- IMPLEMENTED: `scripts/missions/mission_manager.gd` — central orchestrator ONLY
  (registry / availability / state machine AVAILABLE→ACTIVE→COMPLETING→COMPLETED|FAILED /
  objective stepping @10 Hz / EventBus routing via ONE lifetime subscription / id-based
  actor bindings + guaranteed cleanup / checkpoints + restart / save_snapshot+restore /
  rewards exclusively via Economy.earn). NO duplicate economy/save/NPC/police/UI systems.
- IMPLEMENTED: `scripts/missions/mission_defs.gd` — pure data; adding a mission = adding
  an entry. Objective vocabulary: GO_TO, INTERACT, COLLECT, DELIVER, ENTER_VEHICLE,
  ELIMINATE, PROTECT, ESCAPE, SURVIVE, WAIT.
- IMPLEMENTED (Gate 03, all 4 archetypes data-driven): bank_run (delivery/once/$400),
  dock_cleanup (eliminate/repeatable/$350, real npc_gang target), safe_passage
  (protect escort/once/$450/240 s limit), warehouse_job (heist/once/$600 with wanted-0
  ESCAPE gate before the safehouse drop).
- IMPLEMENTED: hud.set_mission_text (additive), NPC_DIED payload `node` id (additive),
  SaveSystem v3 additive keys `mission` + `missions_done` (schema-compatible; migration
  chain untouched), start-zone rings auto-start missions, objective markers.
- TESTED: `tests/mission_system_test.gd` — 57 gates, registered as 12th CI suite:
  registration/availability/duplicate+unknown rejection, bank_run full chain with reward
  ledger reason `mission_reward:bank_run`, once-lock (§46), eliminate via REAL combat
  damage (§26 no-hack), repeatable restart, abandon event, protect-fail, PLAYER_DIED
  fail, time-expiry fail, ESCAPE wanted gating, mid-mission save→load (active id +
  objective_index preserved, §20), completed-set persistence (reward idempotency),
  actor cleanup, EventBus CRIME regression. ALL PASS ×3 (deterministic).
- VERIFIED: full 12-suite CI PASS ×2 — worst frame 3.45 ms / 3.48 ms (NEW RECORD,
  prior 3.75); error gate clean; leak gates policy-allowed summary-only on 4 suites
  (upstream #95484 timing race, unchanged); world_data IDENTICAL; smoke atomic-save
  ALL PASS. Zip auto-refreshed: 857 files, 5.04 MB.
- FIXED (found by the new suite's error gate — 3 latent freed-lambda-capture bugs):
  person.gd hit-flash + corpse-fade timer lambdas → bound method callables (safely
  skipped when mission cleanup frees the NPC first); npc_gang/npc_military/npc_police
  gun-sound timer lambdas → `finished`-signal self-cleanup. Start-zone auto-start uses
  a bound method (no captures) by design.
- KNOWN LIMITATION (noted, not masked): PROTECT escort vip is stationary until the
  follow-objective behavior lands (roadmap v2.7 Witness 2.0 window); failure/reward
  semantics are fully correct as shipped.

## v2.3.0 — 2026-09-19
Phase: Master Plan v2.1 adoption audit + atomic save + documentation protocol
Result: LOCKED
Major changes:
- Atomic save write (tmp → flush → rename)
- Evidence audit of plan defects D1–D8: all closed or spec-aligned (details §2)
- This document created; lock ledger extended

## v2.2.0 — 2026-09-19
Phase: Master Plan STAGE 01 core — EventBus + Economy + DebugTools + system_test
Result: LOCKED (CI PASS ×2, system 32/32)
Major changes:
- EventBus autoload (ring log, relays, CRIME records with witnesses)
- Economy (pay/charge/earn + ledger), all money call-sites routed
- DebugTools (stats + 8 commands), game spawners extracted
- 6 build/test bugs found by gates and fixed (see round 14 record)

## v2.1.0 — 2026-09-19
Phase: 10 Realistic Buildings (Blender-authored set)
Result: LOCKED (CI PASS ×2, worst 5.75 ms)
Major changes:
- Blender 4.2 headless pipeline; building_01..10.glb + set GLB/BLEND (773 nodes, 14,760 tris)
- BuildingKit game-side mirror; +10 smoke gates; +5 physics bodies only

## v2.0.0 — 2026-09-18
Phase: 26-Phase Next-Level Upgrade
Result: LOCKED (CI PASS ×2)
Major changes:
- World dressing pass (river current, lane dashes, clock tower, water towers, flowers,
  hydrants/bins, fire escapes, hidden stashes, welcome gantry)
- WeaponData extended ballistics (bloom, falloff, ADS, deploy), quick-swap
- Streamer hysteresis; rush-hour surge; storm cadence
- Regression caught + fixed corpse-fade bug; perf gate made contention-aware

## v1.0.0 — baseline
Phase: Verified test battery (10 suites) on hybrid terrain build
Result: LOCKED
Major changes:
- Hybrid terrain contract, 7-weapon system, staged police escalation, streaming,
  day/night + weather chain, save v3, roads/districts/interiors/landmarks

---

# SYSTEM STATUS TABLE

| System | Status | Version | Tested | Locked |
|---|---|---|---|---|
| World/Map | LOCKED | 2.1 | PASS | YES |
| Terrain (hybrid) | LOCKED | 1.2 | PASS | YES |
| Roads/Traffic infra | LOCKED | 1.1 | PASS | YES |
| Buildings (Blender set) | LOCKED | 1.0 | PASS | YES |
| Interiors (kit) | PARTIAL | 1.0 | PARTIAL | NO |
| Streaming/LOD | LOCKED | 1.2 | PASS | YES |
| Player | LOCKED | 1.3 | PASS | YES |
| Camera | LOCKED | 1.1 | PASS | YES |
| Weapons (7) | LOCKED | 2.1 | PASS (15/15) | YES |
| Switch/Wheel | LOCKED | 2.0 | PASS | YES |
| Combat damage | LOCKED | 1.1 | PASS | YES |
| NPC civilians | LOCKED | 1.2 | PASS | YES |
| Perception/Witness | PARTIAL | 1.1 | PARTIAL | NO |
| Police/Wanted | LOCKED | 1.3 | PASS | YES |
| Navigation | PARTIAL | 1.0 | PASS | NO |
| Missions (legacy race/delivery) | LOCKED (legacy) | 1.0 | PASS | YES |
| Mission Framework | LOCKED | 2.4 | PASS (57/57) | YES |
| Economy | LOCKED | 1.0 | PASS (32/32) | YES |
| Shops (weapon) | PARTIAL | 1.0 | PASS | NO |
| Vehicle ownership/Garage | NOT STARTED | — | — | NO |
| Day/Night | LOCKED | 1.1 | PASS | YES |
| Weather chain | LOCKED | 1.1 | PASS | YES |
| World events | PARTIAL | 1.0 | PASS | NO |
| EventBus | LOCKED | 1.0 | PASS | YES |
| Save/Load | LOCKED | 2.3 (atomic) | PASS | YES |
| Audio | PARTIAL | 1.0 | PARTIAL | NO |
| Map UI | PARTIAL | 1.0 | PASS | NO |
| GPS | NOT STARTED | — | — | NO |
| Debug toolkit | LOCKED | 1.0 | PASS | YES |
| Performance | LOCKED | 1.2 | PASS | YES |
| Windows export | NOT STARTED | — | — | NO |
| Controller (hardware) | PARTIAL | — | NOT TESTED | NO |

---

# RELEASE ARTIFACT WORKFLOW (standing rule, adopted 2026-09-19)

- After EVERY verified update, exactly ONE refreshed game zip is published at the
  workspace root: `/home/user/island-strike.zip` (extracts to `island-strike/`).
- `tools/ci.sh` refreshes the zip automatically on `CI_RESULT: PASS` via
  `release-tools/make_game_zip.sh` — a failing build never ships a zip.
- Zip contents: full project (854 files, ~5 MB), excluding only the `.godot`
  engine cache (regenerates on open). `assets/models/buildings/.gdignore` IS
  included — it prevents `.blend` import hangs on machines without Blender.
- VERIFIED: extracted-zip copy passes import, loadcheck 20/20 and smoke ALL PASS
  (2026-09-19).

# EVIDENCE APPENDIX

- CI invocation: `bash tools/ci.sh` → `CI_RESULT: PASS` (latest two runs logged in CI
  transcripts; 11 suites + perf gate).
- Test entry points: `tests/loadcheck.gd`, `walk_test.gd`, `character_test.gd`,
  `smoke_test.gd`, `stress_main.gd`, `menu_test.gd`, `world_data_test.gd`,
  `terrain_test.gd`, `clothing_test.gd`, `weapon_system_test.gd`, `system_test.gd`.
- Perf probe: `tools/perf_probe.gd` (27 stations; GPU explicitly NOT MEASURED headless).
- Lock ledger: `tools/lock_ledger.json` (rounds 12–15).
- Archives: `_archive_original/pre-26phase-*`, `post-26phase-lock`,
  `post-round13-lock`, `post-round14-lock`, `post-round15-lock`.
