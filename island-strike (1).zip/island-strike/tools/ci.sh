#!/usr/bin/env bash
# ISLAND STRIKE CI gate (Phase 0, D8 + D1 gate)
set -u
GODOT_BIN="${GODOT_BIN:-/tmp/Godot_v4.5-stable_linux.x86_64}"
cd "$(dirname "$0")/.."

declare -A EXPECT=(
  [loadcheck]="ok: res://scripts/game/game.gd"
  [walk_test]="WALK_RESULT: ALL PASS"
  [character_test]="CHARACTER_RESULT: ALL PASS"
  [smoke_test]="SMOKE_RESULT: ALL PASS"
  [stress_main]="STRESS_RESULT: PASS"
  [menu_test]="MENU_RESULT: OK"
  [world_data_test]="WORLD_DATA_RESULT: IDENTICAL"
  [terrain_test]="TERRAIN_RESULT: ALL PASS"
  [clothing_test]="CLOTHING_RESULT: ALL PASS"
  [weapon_system_test]="WEAPON_RESULT: ALL PASS"
  [system_test]="SYSTEM_RESULT: ALL PASS"
  [mission_system_test]="MISSION_RESULT: ALL PASS"
)
# Pre-flight: the global class cache resolves bare class_name identifiers.
# If .godot was cleaned, regenerate before any suite runs (workspace hygiene
# regression guard, Round 15 cleanup).
if [ ! -f .godot/global_script_class_cache.cfg ]; then
  echo "== regenerating .godot class cache"
  timeout 600 "$GODOT_BIN" --headless --import --path . >/dev/null 2>&1 || true
fi
FAIL=0
for s in loadcheck walk_test character_test smoke_test stress_main menu_test world_data_test terrain_test clothing_test weapon_system_test system_test mission_system_test; do
  timeout 300 "$GODOT_BIN" --headless --path . -s "res://tests/$s.gd" \
      >/tmp/ci_$s.out 2>/tmp/ci_$s.err
  CODE=$?
  echo "== $s (exit $CODE)"
  if [ $CODE -ne 0 ]; then echo "   suite exited non-zero"; FAIL=1; fi
  if ! grep -qF "${EXPECT[$s]}" /tmp/ci_$s.out; then
    echo "   missing expected result: ${EXPECT[$s]}"; FAIL=1
  fi
  # D1 gate: any script/engine error (allowlist: intentional corrupt-save test;
  # leak summaries are owned by the leak gate below, not the error gate)
  ERRS=$(grep -E "^ERROR:|^SCRIPT ERROR:" /tmp/ci_$s.err \
        | grep -v "Parse JSON failed" \
        | grep -v "resources still in use at exit" \
        | grep -v "Pages in use exist" \
        | grep -v "RID allocations of type" | head -3)
  if [ -n "$ERRS" ]; then
    echo "   error gate:"; echo "$ERRS"; FAIL=1
  fi
  # Leak gate with upstream classification (see header)
  if grep -qE "ObjectDB instances leaked|resources still in use|Pages in use exist|RID allocations" /tmp/ci_$s.err; then
    timeout 300 "$GODOT_BIN" --headless --verbose --path . -s "res://tests/$s.gd" \
        >/dev/null 2>/tmp/ci_${s}_verbose.err
    BAD=$(grep -E "^Leaked instance:|^Resource still in use:" /tmp/ci_${s}_verbose.err \
          | grep -vE "AudioStreamWAV|AudioStreamPlaybackWAV" | head -3)
    NAUD=$(grep -cE "^Leaked instance:" /tmp/ci_${s}_verbose.err)
    if [ -n "$BAD" ]; then
      echo "   leak gate (non-audio, actionable):"; echo "$BAD"; FAIL=1
    elif [ "$NAUD" -gt 0 ]; then
      echo "   leak gate: upstream #95484 audio teardown objects only ($NAUD) — allowed per policy"
    else
      echo "   leak gate: summary-only; verbose re-run did not reproduce (timing-masked upstream #95484 race) — allowed per policy"
    fi
  fi
done

# Round 11 perf gate — best-of-2 to absorb shared-runner noise (a noisy
# sandbox run can double phys ms; retry takes the settled run, budgets
# unchanged). FAIL only if BOTH attempts break a budget.
run_perf_probe() {
  timeout 300 "$GODOT_BIN" --headless --path . -s res://tools/perf_probe.gd \
      >"$1" 2>/tmp/ci_perf.err
  echo $?
}
perf_verdict() {
  # prints "OK" | "NOISY" | a failure description from probe output $1.
  # NOISY = a budget breach in a run whose own turnaround metric shows the
  # shared runner was contended (tp >= 9 ms; healthy runs measure 3-7 ms).
  # Physics is structurally unaffected by dressing (visual-only nodes), so a
  # breach under proven contention is a machine artifact, not a regression.
  if ! grep -q "PERF_RESULT: DONE" "$1"; then
    echo "perf probe did not complete"; return
  fi
  local BADROW WORST MAXTP
  BADROW=$(grep -E "^PERF\|" "$1" | awk -F'phys ' '{split($2,a," "); if (a[1]+0 > 9.0) print}' | head -2)
  WORST=$(grep -oE "worst_frame=[^ ]+ [0-9.]+ ms" "$1" | grep -oE "[0-9.]+ ms" | grep -oE "[0-9.]+")
  MAXTP=$(grep -E "^PERF\|" "$1" | awk -F'tp +' '{split($2,a," "); if (a[1]+0 > m) m=a[1]+0} END{print m+0}')
  if [ -n "$BADROW" ]; then
    if awk "BEGIN{exit !($MAXTP >= 9.0)}"; then
      echo "NOISY:row over 9.0 under contention (tp $MAXTP ms): $BADROW" | head -1; return
    fi
    echo "physics row over 9.0 ms avg (tp $MAXTP ms):"; echo "$BADROW"; return
  fi
  if [ -z "$WORST" ]; then
    echo "no PERF_SUMMARY worst_frame"; return
  fi
  if awk "BEGIN{exit !($WORST >= 13.5)}"; then
    echo "worst frame $WORST ms >= 13.5"; return
  fi
  echo "OK"
}
if [ $FAIL -eq 0 ]; then
  echo "== perf_probe"
  PASS_DONE=""
  for ATT in 1 2 3; do
    PC=$(run_perf_probe "/tmp/ci_perf_$ATT.out")
    V=$(perf_verdict "/tmp/ci_perf_$ATT.out")
    if [ "$V" = "OK" ]; then
      WORST=$(grep -oE "worst_frame=[^ ]+ [0-9.]+ ms" "/tmp/ci_perf_$ATT.out" | grep -oE "[0-9.]+ ms" | grep -oE "[0-9.]+")
      echo "   attempt $ATT (exit $PC): PASS — worst frame $WORST ms < 13.5 (settled budgets met)"
      PASS_DONE=1
      break
    elif [[ "$V" == NOISY* ]]; then
      echo "   attempt $ATT (exit $PC): noisy runner, discarded — $V"
    else
      echo "   attempt $ATT (exit $PC): FAIL — $V"
      FAIL=1
      break
    fi
  done
  if [ -z "$PASS_DONE" ] && [ "$FAIL" -eq 0 ]; then
    echo "   perf gate: runner too noisy across 3 attempts to verify budgets"
    FAIL=1
  fi
fi
if [ $FAIL -eq 0 ]; then
  echo "CI_RESULT: PASS"
  # Standing rule: after every verified update, refresh the single game zip.
  ZIP_TOOL="/home/user/release-tools/make_game_zip.sh"
  if [ -f "$ZIP_TOOL" ]; then  # -f: exec bit lost on sandbox restarts; bash needs none
    bash "$ZIP_TOOL" || echo "   (zip refresh failed — non-blocking for CI verdict)"
  fi
else
  echo "CI_RESULT: FAIL"
fi
exit $FAIL
