class_name WorldTerrain
extends Object
## Terrain service — Hybrid Realistic Mode (Staged Lock)
## Implements: flat for city/downtown/airport (preserve), hills/mountains north zone only
## Per user choice: hybrid — flat city + mountain hills north
## Height field is single source of truth — every system must ask height_at()
## Deep fix: explicit typing for all vars — no `:=` inferring Variant (warning treated as error)

const SEED: int = 7717
const AMPLITUDE: float = 18.0
const FREQ: float = 1.0 / 130.0
const MOUNTAIN_AMPLITUDE: float = 85.0
const HILL_AMPLITUDE: float = 28.0

static var activate: bool = false
static var active_zone: Rect2 = Rect2()

const FLAT_DISTRICTS: Array[Rect2] = [
	Rect2(-410, -280, 260, 210),
	Rect2(-100, -260, 340, 170),
	Rect2(-70, -350, 330, 100),
	Rect2(240, -320, 210, 80),
	Rect2(140, 60, 310, 240),
	Rect2(-410, 140, 300, 160),
	Rect2(-95, -55, 150, 170),
]

static func _hash2(ix: int, iz: int, oct: int) -> float:
	var k: int = int(SEED + ix * 374761393 + iz * 668265263 + oct * 2654435761)
	k = (k ^ (k >> 13)) * 1274126177
	return float((k ^ (k >> 16)) & 0xFFFF) / 65535.0

static func _noise2(x: float, z: float) -> float:
	var h: float = 0.0
	var amp: float = 1.0
	var fr: float = FREQ
	for o: int in range(3):
		var xf: float = x * fr
		var zf: float = z * fr
		var xi: int = floori(xf)
		var zi: int = floori(zf)
		var tx: float = xf - float(xi)
		var tz: float = zf - float(zi)
		var sx: float = tx * tx * (3.0 - 2.0 * tx)
		var sz: float = tz * tz * (3.0 - 2.0 * tz)
		var v00: float = _hash2(xi, zi, o)
		var v10: float = _hash2(xi + 1, zi, o)
		var v01: float = _hash2(xi, zi + 1, o)
		var v11: float = _hash2(xi + 1, zi + 1, o)
		h += amp * lerpf(lerpf(v00, v10, sx), lerpf(v01, v11, sx), sz)
		amp *= 0.5
		fr *= 2.0
	return h - 0.875

static func _is_flat_zone(x: float, z: float) -> bool:
	var p: Vector2 = Vector2(x, z)
	for r: Rect2 in FLAT_DISTRICTS:
		if r.has_point(p):
			return true
	return false

static func _mountain_mask(x: float, z: float) -> float:
	var north_factor: float = 0.0
	if z < -350.0:
		north_factor = 1.0
	elif z < -300.0:
		north_factor = clampf((-300.0 - z) / 50.0, 0.0, 1.0) * 1.0
	elif z < -220.0:
		north_factor = clampf((-220.0 - z) / 80.0, 0.0, 1.0) * 0.35
	else:
		north_factor = 0.0
	var ridge: float = sin(x * 0.008) * 0.15 + cos(x * 0.003) * 0.1
	north_factor = clampf(north_factor + ridge * north_factor, 0.0, 1.2)
	return north_factor

static func _river_carve(x: float, z: float) -> float:
	var river_x: float = -50.0 + sin(z * 0.01) * 80.0
	# Deep fix: abs() returns Variant -> use absf() for float explicit
	var dist_to_river: float = absf(x - river_x)
	if dist_to_river > 25.0:
		return 0.0
	var depth_factor: float = clampf((-z + 350.0) / 700.0, 0.2, 1.0)
	# Deep fix: explicit float type, no Variant inference
	var carve: float = (1.0 - dist_to_river / 25.0) * 4.0 * depth_factor
	return carve

static func height_at(x: float, z: float) -> float:
	if not activate:
		return 0.0
	if _is_flat_zone(x, z):
		return 0.0
	if not active_zone.has_point(Vector2(x, z)):
		return 0.0
	var base_noise: float = _noise2(x, z)
	var mountain: float = _mountain_mask(x, z)
	var river: float = _river_carve(x, z)
	var edge: float = 30.0
	var dxl: float = clampf((x - active_zone.position.x) / edge, 0.0, 1.0)
	var dxr: float = clampf((active_zone.end.x - x) / edge, 0.0, 1.0)
	var dzl: float = clampf((z - active_zone.position.y) / edge, 0.0, 1.0)
	var dzr: float = clampf((active_zone.end.y - z) / edge, 0.0, 1.0)
	var mask: float = minf(minf(dxl, dxr), minf(dzl, dzr))
	var height: float = 0.0
	if mountain > 0.7:
		height = base_noise * MOUNTAIN_AMPLITUDE * mountain + mountain * 35.0
	elif mountain > 0.1:
		height = base_noise * HILL_AMPLITUDE * mountain + mountain * 12.0
	else:
		height = base_noise * 2.5 * mask
	height -= river
	height *= mask
	return clampf(height, -6.0, 120.0)

## Round 12 Phase 08: river current — gentle flow along the carved channel.
## Tangent of river_x(z) = -50 + sin(z*0.01)*80; strength fades to zero at
## 22 m from the channel centre. Zero outside the river band.
static func river_current_at(pos: Vector3) -> Vector3:
	var river_x: float = -50.0 + sin(pos.z * 0.01) * 80.0
	var dist: float = absf(pos.x - river_x)
	if dist > 22.0:
		return Vector3.ZERO
	var strength: float = (1.0 - dist / 22.0) * 0.9
	var tangent: Vector3 = Vector3(cos(pos.z * 0.01) * 0.8, 0.0, 1.0).normalized()
	return tangent * strength


static func build_patch(root: Node3D) -> Node:
	if not activate or active_zone.size == Rect2().size:
		return null
	var size: Vector2 = active_zone.size
	var steps: int = maxi(maxi(int(size.x / 6.0), int(size.y / 6.0)), 12)
	var verts: PackedVector3Array = PackedVector3Array()
	var uvs: PackedVector2Array = PackedVector2Array()
	for zz: int in range(steps + 1):
		for xx: int in range(steps + 1):
			var fx: float = float(xx) / float(steps)
			var fz: float = float(zz) / float(steps)
			var wx: float = active_zone.position.x + fx * size.x
			var wz: float = active_zone.position.y + fz * size.y
			verts.append(Vector3(fx * size.x - size.x * 0.5, height_at(wx, wz), fz * size.y - size.y * 0.5))
			uvs.append(Vector2(fx, fz))
	var st: SurfaceTool = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for zz: int in range(steps):
		for xx: int in range(steps):
			var a: int = zz * (steps + 1) + xx
			st.add_index(a)
			st.add_index(a + steps + 1)
			st.add_index(a + 1)
			st.add_index(a + 1)
			st.add_index(a + steps + 1)
			st.add_index(a + steps + 2)
	for i: int in range(verts.size()):
		st.set_uv(uvs[i])
		st.add_vertex(verts[i])
	var arr_mesh: ArrayMesh = st.commit()
	var mat: ShaderMaterial = ShaderMaterial.new()
	mat.shader = _grass_shader()
	var mi: MeshInstance3D = MeshInstance3D.new()
	mi.name = "TerrainPatch_Hybrid"
	mi.mesh = arr_mesh
	mi.material_override = mat
	mi.position = Vector3(active_zone.position.x + size.x * 0.5, 0.0, active_zone.position.y + size.y * 0.5)
	mi.visibility_range_end = 800.0
	var body: StaticBody3D = StaticBody3D.new()
	body.name = "TerrainBody"
	var cs: CollisionShape3D = CollisionShape3D.new()
	var shape: ConcavePolygonShape3D = ConcavePolygonShape3D.new()
	shape.set_faces(arr_mesh.get_faces())
	cs.shape = shape
	body.add_child(cs)
	mi.add_child(body)
	root.add_child(mi)
	print("TERRAIN_HYBRID: built patch %s steps %d verts %d maxH %.1f" % [str(active_zone), steps, verts.size(), _max_height_in_zone()])
	return mi

static func _max_height_in_zone() -> float:
	var max_h: float = 0.0
	for x: int in range(-400, 400, 50):
		for z: int in range(-500, -200, 50):
			var h: float = height_at(float(x), float(z))
			if h > max_h:
				max_h = h
	return max_h

static func _grass_shader() -> Shader:
	var shader: Shader = Shader.new()
	shader.code = """
shader_type spatial;
uniform vec2 world_offset;
void fragment() {
	vec2 world_uv = UV * 12.0 + world_offset;
	float n = fract(sin(dot(world_uv, vec2(12.9898, 78.233))) * 43758.5453);
	vec3 green1 = vec3(0.22, 0.48, 0.22);
	vec3 green2 = vec3(0.18, 0.42, 0.18);
	vec3 dry = vec3(0.55, 0.52, 0.38);
	vec3 col = mix(green1, green2, n);
	col = mix(col, dry, smoothstep(0.7, 0.85, n) * 0.35);
	ALBEDO = col;
	ROUGHNESS = 0.92;
}
"""
	return shader