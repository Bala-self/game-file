class_name DebugTools
extends Object
## Debug framework — stats + command API (master plan §41).
## stats(): one dictionary for HUD/debug panels and tests.
## cmd(): teleport / set_time / set_wanted / give_money / give_weapon /
##        spawn_car / spawn_npc / set_weather. Every command is logged on
##        the EventBus (DEBUG_CMD) and returns "OK: ..." or "ERR: ...".

const BUS := preload("res://scripts/core/event_bus.gd")
const EconomyRes := preload("res://scripts/core/economy.gd")


static func _tree() -> SceneTree:
	var ml: MainLoop = Engine.get_main_loop()
	return ml as SceneTree


static func _gs() -> Node:
	var t: SceneTree = _tree()
	if t == null:
		return null
	return t.root.get_node_or_null("GameState")


static func _player() -> Node:
	var t: SceneTree = _tree()
	if t == null:
		return null
	return t.get_first_node_in_group("player")


static func _game() -> Node:
	var t: SceneTree = _tree()
	if t == null:
		return null
	return t.get_first_node_in_group("game")


## Live world/system snapshot for overlays and tests.
static func stats() -> Dictionary:
	var t: SceneTree = _tree()
	var gs: Node = _gs()
	var out: Dictionary = {
		"day_time": 12.0, "wanted": 0, "money": 0, "raining": false,
		"fps": Engine.get_frames_per_second(),
	}
	if gs != null:
		out["day_time"] = gs.get("day_time")
		out["wanted"] = int(gs.get("wanted"))
		out["money"] = int(gs.get("money"))
		out["raining"] = bool(gs.get("raining"))
	if t == null:
		return out
	out["civilians"] = t.get_nodes_in_group("civilians").size()
	out["cars"] = t.get_nodes_in_group("cars").size()
	out["police"] = t.get_nodes_in_group("police").size()
	out["gangs"] = t.get_nodes_in_group("gangs").size()
	var p: Node = _player()
	if p is Node3D:
		out["player_pos"] = (p as Node3D).global_position
	var bus: Node = t.root.get_node_or_null("EventBus")
	if bus != null:
		out["events"] = bus.tail(8)
	return out


## Command API. arg types: teleport Vector3, set_time float, set_wanted int,
## give_money int, give_weapon String, spawn_car/spawn_npc null,
## set_weather bool.
static func cmd(name: String, arg: Variant = null) -> String:
	var result: String = _dispatch(name, arg)
	var bus: Node = null
	var t: SceneTree = _tree()
	if t != null:
		bus = t.root.get_node_or_null("EventBus")
	if bus != null:
		bus.record("DEBUG_CMD", {"cmd": name, "arg": str(arg), "result": result})
	return result


static func _dispatch(name: String, arg: Variant) -> String:
	var t: SceneTree = _tree()
	if t == null or _gs() == null:
		return "ERR: no scene tree"
	match name:
		"teleport":
			var p: Node = _player()
			if p == null or not (p is Node3D) or not (arg is Vector3):
				return "ERR: teleport needs player + Vector3"
			(p as Node3D).global_position = arg
			if p is CharacterBody3D:
				(p as CharacterBody3D).velocity = Vector3.ZERO
			return "OK: teleported to %s" % [arg]
		"set_time":
			var gs_t: Node = _gs()
			gs_t.set("day_time", clampf(float(arg), 0.0, 23.99))
			gs_t.time_changed.emit(float(gs_t.get("day_time")))
			return "OK: time %.2f" % float(gs_t.get("day_time"))
		"set_wanted":
			_gs().set_wanted(int(arg))
			return "OK: wanted %d" % int(_gs().get("wanted"))
		"give_money":
			EconomyRes.earn(int(arg), "debug")
			return "OK: money %d" % int(_gs().get("money"))
		"give_weapon":
			var p2: Node = _player()
			if p2 == null:
				return "ERR: no player"
			var wpn: Node = p2.get("pistol")
			if wpn == null:
				return "ERR: no weapon system"
			var wid: String = str(arg)
			if not WeaponData.is_valid(wid):
				return "ERR: unknown weapon %s" % wid
			var owned: Dictionary = wpn.get("owned_weapons")
			owned[wid] = true
			var ammo: Dictionary = wpn.get("ammo")
			if not ammo.has(wid):
				ammo[wid] = [int(WeaponData.get_cfg(wid)["mag"]),
						int(WeaponData.get_cfg(wid)["reserve_max"])]
			wpn.set("owned_weapons", owned)
			wpn.set("ammo", ammo)
			return "OK: granted %s" % wid
		"spawn_car":
			var g: Node = _game()
			if g == null or not g.has_method("debug_spawn_car"):
				return "ERR: game spawner unavailable"
			g.debug_spawn_car()
			return "OK: car spawned"
		"spawn_npc":
			var g2: Node = _game()
			if g2 == null or not g2.has_method("debug_spawn_npc"):
				return "ERR: game spawner unavailable"
			g2.debug_spawn_npc()
			return "OK: npc spawned"
		"set_weather":
			_gs().set_raining(bool(arg))
			return "OK: raining %s" % str(bool(_gs().get("raining")))
		_:
			return "ERR: unknown command %s" % name
