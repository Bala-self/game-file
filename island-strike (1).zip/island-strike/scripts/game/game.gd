extends Node3D
## Game director: builds the world, spawns actors, runs day/night, weather,
## civilian/police/traffic directors, respawn and busted logic.

const CIVILIAN_TARGET := 24
const TRAFFIC_TARGET := 9
const POLICE_TARGETS: Array = [0, 1, 2, 4, 6, 8]  # index = wanted level

var player: CharacterBody3D
var hud: CanvasLayer
var pause_menu: CanvasLayer
var world_data: Dictionary = {}
var rain_particles: GPUParticles3D
var env: Environment
var sun: DirectionalLight3D
var moon: DirectionalLight3D
var ocean_audio: AudioStreamPlayer
var rain_audio: AudioStreamPlayer
var bust_meter: float = 0.0
var _wanted_los_timer: float = 0.0  # time since last LOS from any cop
var _wanted_decay_timer: float = 0.0  # time since wanted started blinking
var _wanted_blink: bool = false
var _sky_mat: ProceduralSkyMaterial
var _civ_scene = preload("res://scripts/npc/npc_civilian.gd")
var _cop_scene = preload("res://scripts/npc/npc_police.gd")
var _car_scene = preload("res://scripts/vehicles/car.gd")
var _collectible_scene = preload("res://scripts/world/collectible.gd")
var _gang_scene = preload("res://scripts/npc/npc_gang.gd")
var _beach_scene = preload("res://scripts/npc/npc_beach.gd")
var _military_scene = preload("res://scripts/npc/npc_military.gd")
var race: Node3D
var delivery: Node3D  # Round 9 S3: courier missions (Phase 28 slice)
var _event_manager: EventManager
var _prev_day_time: float = 12.0
# Round 9 S6: emergency dispatch state (Phase 21 slice)
var _amb: CharacterBody3D = null
var _amb_dwell: float = 0.0
var _dispatch_cd: float = 0.0
# Round 9 S10 (Phase 38 slice): district ambient zone (waves/birds/hum)
var _ambience: AudioStreamPlayer = null
var _ambience_key: String = ""
var _wx_fog: float = 0.0008  # Round 11: clear-sky haze (0.0035 washed the mid-ground)
var _wx_sun: float = 1.2
# Round 10 E4: wet-road response (asphalt darkens + sheens when raining)
var _road_mats: Array = []
var _road_base: Array = []
var _wet: float = 0.0
var _hud_scene = preload("res://scripts/ui/hud.gd")
var _pause_scene = preload("res://scripts/ui/pause_menu.gd")
const EconomyRes := preload("res://scripts/core/economy.gd")


func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	world_data = WorldBuilder.build(self)
	GameState.world_data = world_data
	env = get_node("WorldEnv").environment
	_sky_mat = env.sky.sky_material
	sun = get_node("Sun")

	_spawn_player()
	_setup_moon()
	_setup_rain()
	_setup_audio()

	# Phase 6: tile streaming — static geometry beyond the NEAR ring parks
	# its collision; the 1-ring band guarantees collision at any speed.
	var streamer: Streamer = Streamer.create(player)
	add_child(streamer)
	streamer.scan(self)

	# audit #23: drivable boat moored off the harbor office (Phase 24 slice)
	var boat: CharacterBody3D = load("res://scripts/vehicles/boat.gd").new()
	boat.position = Vector3(-582, -0.85, 226)
	boat.rotation.y = PI / 2  # moored facing open water (west)
	add_child(boat)
	# Round 9 S2: speedboat at the second mooring (faster hull, no cabin)
	var speedboat: CharacterBody3D = load("res://scripts/vehicles/boat.gd").create("speedboat")
	speedboat.position = Vector3(-572, -0.85, 234)
	speedboat.rotation.y = PI / 2
	add_child(speedboat)
	# Round 9 S10: district ambience layer (non-positional, quiet)
	_ambience = AudioStreamPlayer.new()
	_ambience.volume_db = -16.0
	add_child(_ambience)
	# Round 9 S1: motorcycles — two parked on the airport apron (flat, open:
	# a test moto can throttle in a straight line), class also in traffic pools
	var apron: Rect2 = world_data["districts"].get("Airport", Rect2(240, -320, 210, 80))
	var ac: Vector2 = apron.get_center()
	for i in range(2):
		var moto: CharacterBody3D = _car_scene.create(Color(0.85, 0.15, 0.15), "moto")
		var gy: float = scripts_world_terrain_height(ac.x + 6.0 * i - 3.0, ac.y)
		moto.position = Vector3(ac.x + 6.0 * i - 3.0, gy + 0.4, ac.y)
		moto.name = "Moto%d" % (i + 1)
		add_child(moto)

	# Phase 10: navmesh + nav-driven NPC classes (commuter, service worker)
	NavGrid.build(self)
	for i in range(3):
		var c: CharacterBody3D = load("res://scripts/npc/npc_commuter.gd").new()
		c.position = world_data["player_spawn"] + Vector3(4.0 + i * 2.0, 0.4, 4.0)
		add_child(c)
	for i in range(3):
		var w: CharacterBody3D = load("res://scripts/npc/npc_service.gd").new()
		w.position = world_data["player_spawn"] + Vector3(-4.0 - i * 2.0, 0.4, 4.0)
		add_child(w)

	hud = _hud_scene.create(player)
	add_child(hud)
	pause_menu = _pause_scene.create()
	add_child(pause_menu)

	_register_service_points()
	world_data["property_spots"] = {
		"safehouse": Vector2(-165, -240),
		"gas_station": Vector2(-20, -140),
		"harbor_office": Vector2(-564, 226),
		"warehouse": Vector2(408, 270),
	}
	_register_properties()
	race = load("res://scripts/world/race.gd").new()
	# Round 9 S3: courier deliveries (Phase 28 slice) — mid-mission save below
	delivery = load("res://scripts/world/delivery.gd").new()
	add_child(delivery)
	add_child(race)
	add_to_group("game")
	var ws: WorldSim = WorldSim.create(self)
	add_child(ws)
	# Round 16 (v2.4): MissionManager — central mission orchestrator
	var mm: Node = preload("res://scripts/missions/mission_manager.gd").new()
	mm.name = "MissionManager"
	add_child(mm)
	var em: EventManager = EventManager.create(self)
	add_child(em)
	_event_manager = em
	apply_quality(GameState.settings.get("quality", "HIGH"))
	var event_timer = Timer.new()
	event_timer.wait_time = 22.0
	event_timer.timeout.connect(_event_director)
	add_child(event_timer)
	event_timer.start()
	_spawn_collectibles()
	_spawn_parked_cars()
	for i in range(CIVILIAN_TARGET):
		_spawn_civilian()
	for i in range(TRAFFIC_TARGET):
		_spawn_traffic_car()

	GameState.crime_committed.connect(_on_crime)
	GameState.wanted_changed.connect(func(_v: int) -> void: _police_director())
	if player.has_signal("died"):
		player.died.connect(_on_player_died)

	var civ_timer = Timer.new()
	civ_timer.wait_time = 3.0
	civ_timer.timeout.connect(_civilian_director)
	add_child(civ_timer)
	civ_timer.start()

	var cop_timer = Timer.new()
	cop_timer.wait_time = 0.8
	cop_timer.timeout.connect(_police_director)
	add_child(cop_timer)
	cop_timer.start()

	var gang_timer = Timer.new()
	gang_timer.wait_time = 3.0
	gang_timer.timeout.connect(_gang_director)
	add_child(gang_timer)
	gang_timer.start()

	var beach_timer = Timer.new()
	beach_timer.wait_time = 4.0
	beach_timer.timeout.connect(_beach_director)
	add_child(beach_timer)
	beach_timer.start()

	var military_timer = Timer.new()
	military_timer.wait_time = 5.0
	military_timer.timeout.connect(_military_director)
	add_child(military_timer)
	military_timer.start()

	var bust_timer = Timer.new()
	bust_timer.wait_time = 0.5
	bust_timer.timeout.connect(_busted_check)
	add_child(bust_timer)
	bust_timer.start()

	var weather_timer = Timer.new()
	weather_timer.wait_time = randf_range(150.0, 300.0)
	weather_timer.timeout.connect(func() -> void:
		var _ws = get_node_or_null("WorldSim")
		if _ws:
			_ws.cycle()
		else:
			GameState.set_raining(not GameState.raining))
	add_child(weather_timer)
	weather_timer.start()

	if GameState.pending_load:
		GameState.pending_load = false
		SaveSystem.load_game.call_deferred()
	GameState.notify("Welcome to Island Strike! Find the 20 hidden packages.")


# ---------------------------------------------------------------- spawning
func _spawn_player() -> void:
	var player_script = preload("res://scripts/player/player.gd")
	player = player_script.create()
	player.add_to_group("player")
	add_child(player)
	player.global_position = world_data["player_spawn"] + Vector3(0, 0.4, 0)
	# Deep fix: invalidate cached player so streamer + NPCs pick new ref
	if GameState.has_method("invalidate_player_cache"):
		GameState.invalidate_player_cache()


func _setup_moon() -> void:
	moon = DirectionalLight3D.new()
	moon.name = "Moon"
	moon.rotation_degrees = Vector3(-40, 140, 0)
	moon.light_energy = 0.0
	moon.light_color = Color(0.55, 0.65, 0.9)
	moon.shadow_enabled = false
	add_child(moon)


func _setup_rain() -> void:
	rain_particles = GPUParticles3D.new()
	rain_particles.name = "Rain"
	rain_particles.amount = 700
	rain_particles.lifetime = 1.1
	rain_particles.visibility_aabb = AABB(Vector3(-40, -30, -40), Vector3(80, 60, 80))
	var pmat = ParticleProcessMaterial.new()
	pmat.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	pmat.emission_box_extents = Vector3(24, 1, 24)
	pmat.gravity = Vector3(0, -30, 0)
	pmat.initial_velocity_min = 2.0
	pmat.initial_velocity_max = 5.0
	rain_particles.process_material = pmat
	var quad = QuadMesh.new()
	quad.size = Vector2(0.05, 0.45)
	var qm = StandardMaterial3D.new()
	qm.albedo_color = Color(0.6, 0.7, 0.85, 0.5)
	qm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	qm.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	qm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	quad.material = qm
	rain_particles.draw_pass_1 = quad
	rain_particles.emitting = false
	add_child(rain_particles)


func _setup_audio() -> void:
	ocean_audio = AudioStreamPlayer.new()
	ocean_audio.stream = load("res://assets/audio/ocean.wav")
	ocean_audio.volume_db = -14.0
	ocean_audio.autoplay = true
	add_child(ocean_audio)
	# D2 family fix: teardown-safe replay (see car.gd engine note)
	_loop_wav(ocean_audio)
	ocean_audio.play()

	rain_audio = AudioStreamPlayer.new()
	rain_audio.stream = load("res://assets/audio/rain.wav")
	rain_audio.volume_db = -10.0
	add_child(rain_audio)
	_loop_wav(rain_audio)
	GameState.weather_changed.connect(func(r: bool) -> void:
		if r and not GameState.audio_shutdown:
			rain_audio.play()
		else:
			rain_audio.stop())


func _spawn_collectibles() -> void:
	var spots: Array = world_data["collectible_spots"]
	for i in range(spots.size()):
		var id: String = "C%02d" % (i + 1)
		if GameState.collected.has(id):
			continue
		var c: Node = _collectible_scene.create(id, 250)
		c.position = spots[i]
		add_child(c)


func _spawn_parked_cars() -> void:
	var rng = RandomNumberGenerator.new()
	for i in range(world_data["parked_spots"].size()):
		var pos: Vector3 = world_data["parked_spots"][i]
		var car: CharacterBody3D = _car_scene.create_random(rng, _traffic_pool(pos))
		car.position = pos + Vector3(0, 0.4, 0)
		car.rotation_degrees.y = rng.randf_range(0, 360)
		add_child(car)


func _spawn_traffic_car() -> void:
	var loops: Array = world_data["traffic_loops"]
	var rng = RandomNumberGenerator.new()
	var loop: Array = loops[randi() % loops.size()]
	# audit #9: moving traffic honors district vehicle pools (as parked do)
	var car: CharacterBody3D = _car_scene.create_random(rng, _traffic_pool(loop[0]))
	if car.is_police_car:
		car = _car_scene.create(Color.from_hsv(rng.randf(), 0.5, 0.85), "sedan")
	car.traffic = true
	car.waypoints = loop
	car.position = car.waypoints[0] + Vector3(0, 0.4, 0)
	add_child(car)


## Police patrol car — world integration: drives from station parking, not magic spawn
func _spawn_police_car() -> void:
	# Police station parking at downtown (-348, -270) per downtown.gd reserved cell 5
	var station_parking: Vector3 = Vector3(-348, 0.4, -282)  # police station parking, road network connected
	var best: Vector3 = station_parking
	# If player far from station, use nearest COP_SPAWNS that is >60m away but closest to station→player route
	if player and player.global_position.distance_to(station_parking) > 200.0:
		var best_d: float = 9999.0
		for s: Vector3 in world_data["cop_spawns"]:
			var d_to_player: float = s.distance_to(player.global_position)
			if d_to_player > 60.0 and d_to_player < best_d:
				best_d = d_to_player
				best = s
	else:
		best = station_parking
	
	var car: CharacterBody3D = _car_scene.create(Color(0.9, 0.9, 0.95), "police")
	car.position = best + Vector3(0, 0.4, 0)
	car.traffic = false
	car.dispatch = true
	var target_pos: Vector3 = player.global_position + Vector3(randf_range(-5,5), 0, randf_range(-5,5)) if player else best + Vector3(20,0,0)
	car.dispatch_target = target_pos
	# Build dispatch waypoints along roads — use road network midpoints for realistic routing
	var wps: Array[Vector3] = []
	wps.append(best)
	# Add intermediate road points if far
	if player:
		var mid: Vector3 = (best + target_pos) * 0.5
		# Snap mid to nearest road
		var nearest_road_dist: float = 9999.0
		var nearest_road_point: Vector3 = mid
		for r in world_data["roads"]:
			var rc: Vector2 = r.get_center()
			var rp: Vector3 = Vector3(rc.x, 0.4, rc.y)
			var d: float = rp.distance_to(mid)
			if d < nearest_road_dist:
				nearest_road_dist = d
				nearest_road_point = rp
		if nearest_road_dist < 100.0:
			wps.append(nearest_road_point)
	wps.append(target_pos)
	car.waypoints = wps
	# Also set enhanced chase waypoints if car supports it
	if car.has_method("set_dispatch_waypoints"):
		car.set_dispatch_waypoints(wps)
	add_child(car)
	GameState.notify("Police cruiser dispatched from station!" if best == station_parking else "Police cruiser dispatched!")
	# Threat assessment — cruiser only if threat medium+
	var threat: int = ThreatAssessment.assess(player, best, GameState.wanted) if player else 0
	if threat == ThreatAssessment.ThreatLevel.NONE and GameState.wanted < 2:
		# No threat, no shoot, just observe — no_shoot meta enforced
		car.set_meta("no_shoot", true)
	else:
		car.set_meta("no_shoot", false)


func _spawn_civilian() -> void:
	# Deep fix: unified sidewalk via GameState + district-aware clothing
	var pos: Vector3 = GameState.get_random_sidewalk_point() if GameState.has_method("get_random_sidewalk_point") else _random_sidewalk_point()
	var districts: Dictionary = world_data.get("districts", {})
	var beach_rect: Rect2 = districts.get("Beachfront", Rect2())
	var is_beach: bool = beach_rect.size != Vector2.ZERO and beach_rect.has_point(Vector2(pos.x, pos.z))
	var civ: CharacterBody3D
	if is_beach and randf() < 0.6:
		civ = _beach_scene.create()
	else:
		civ = _civ_scene.create()
	civ.position = pos
	add_child(civ)
	# Deep fix: register in GameState group registry
	if GameState.has_method("register_spawn"):
		GameState.register_spawn("civilians", civ)


func _random_sidewalk_point() -> Vector3:
	# Deep fix: single source of truth — delegate to GameState utility
	if GameState.has_method("get_random_sidewalk_point"):
		return GameState.get_random_sidewalk_point()
	var roads: Array = world_data["roads"]
	var r: Rect2 = roads[randi() % roads.size()]
	var horizontal: bool = r.size.x > r.size.y
	var side = 1.0 if randf() < 0.5 else -1.0
	var p: Vector3 = Vector3.ZERO
	if horizontal:
		p = Vector3(randf_range(r.position.x, r.end.x), 0, r.position.y + 10.5 * side)
	else:
		p = Vector3(r.position.x + 10.5 * side, 0, randf_range(r.position.y, r.end.y))
	return p


# --------------------------------------------------------------- directors
func _civilian_director() -> void:
	# Deep fix: use cached group registry to avoid 32x group lookups per frame
	var civs: Array = GameState.get_cached_group("civilians") if GameState.has_method("get_cached_group") else get_tree().get_nodes_in_group("civilians")
	var alive: int = 0
	for c in civs:
		if is_instance_valid(c) and c.health > 0:
			alive += 1
		elif is_instance_valid(c):
			c.queue_free()
			if GameState.has_method("unregister_despawn"):
				GameState.unregister_despawn("civilians", c)
	# schedules: fewer civilians at night, shelter-seekers in rain,
	# rush-hour commuter surge (Round 12 Phase 18)
	var target: float = float(CIVILIAN_TARGET)
	if GameState.is_night():
		target *= 0.45
	if GameState.raining:
		target *= 0.7
	if GameState.is_rush_hour() and not GameState.raining:
		target *= 1.3
	if alive < int(target):
		_spawn_civilian()
	elif alive > int(target) + 2:
		# gradual surplus despawn (oldest first)
		for c in civs:
			if is_instance_valid(c) and c.health > 0:
				c.queue_free()
				break


func _police_director() -> void:
	# Deep fix: staged escalation with cached groups + cached player
	var target: int = POLICE_TARGETS[clampi(GameState.wanted, 0, 5)]
	var cops: Array = GameState.get_cached_group("police") if GameState.has_method("get_cached_group") else get_tree().get_nodes_in_group("police")
	var alive: int = 0
	for c in cops:
		if not is_instance_valid(c):
			continue
		if GameState.wanted == 0:
			c.dismiss()
		elif c.health > 0:
			alive += 1
	# Spawn from station parking if wanted >0, else off-screen ≥50m (world integration)
	if alive < target:
		var station_parking = Vector3(-348, 0.4, -282)  # police station
		var best: Vector3 = station_parking
		var best_d: float = -1.0
		if GameState.wanted == 0:
			# No wanted — no spawn
			best_d = -1.0
		elif GameState.wanted == 1:
			# Wanted 1 — foot cops from nearest spawn >50m, observe/arrest not shoot
			for s: Vector3 in world_data["cop_spawns"]:
				var d: float = s.distance_to(player.global_position) if player else 100.0
				if d > best_d and d > 50.0:
					best_d = d
					best = s
		else:
			# Wanted 2+ — prefer station parking (drive from station)
			best = station_parking
			best_d = 100.0
			# If player far, use COP_SPAWNS as backup
			if player and player.global_position.distance_to(station_parking) > 300.0:
				for s: Vector3 in world_data["cop_spawns"]:
					var d: float = s.distance_to(player.global_position) if player else 100.0
					if d > 50.0 and d < 250.0:
						best = s
						break
		if best_d > 0:
			var cop: CharacterBody3D = _cop_scene.create_at(best)
			cop.position = best + Vector3(0, 0.4, 0)
			# Threat assessment — set initial state based on threat
			var threat: int = ThreatAssessment.assess(player, best, GameState.wanted) if player else 0
			if threat == ThreatAssessment.ThreatLevel.NONE and GameState.wanted <= 1:
				cop.set("state", "observe")
			elif threat <= ThreatAssessment.ThreatLevel.LOW:
				cop.set("state", "identify")
			add_child(cop)
	# Deep fix: police cruisers — use cached cars group
	if GameState.wanted >= 2:
		var cruisers: int = 0
		var cars: Array = GameState.get_cached_group("cars") if GameState.has_method("get_cached_group") else get_tree().get_nodes_in_group("cars")
		for c in cars:
			if is_instance_valid(c) and c.is_police_car and not c.wrecked:
				cruisers += 1
		if cruisers < mini(2, GameState.wanted - 1):
			_spawn_police_car()
	# Wanted decay — break LOS + hide (staged)
	_busted_check()  # also handles bust meter


## Dockside Crew population: 5 while the player is near the Industrial zone.
func _gang_director() -> void:
	var territory: Rect2 = world_data["gang_territory"]
	var player = GameState.get_player() if GameState.has_method("get_player") else get_tree().get_first_node_in_group("player")
	if player == null:
		return
	var center: Vector2 = territory.get_center()
	if Vector2(player.global_position.x, player.global_position.z).distance_to(center) > 150.0:
		return
	var alive: int = 0
	var gangs: Array = GameState.get_cached_group("gangs") if GameState.has_method("get_cached_group") else get_tree().get_nodes_in_group("gangs")
	for m in gangs:
		if is_instance_valid(m) and m.health > 0:
			alive += 1
	if alive >= 5:
		return
	var pos: Vector3 = Vector3.ZERO
	for attempt in range(8):
		pos = Vector3(randf_range(territory.position.x, territory.end.x), 0.4,
				randf_range(territory.position.y, territory.end.y))
		if pos.distance_to(player.global_position) >= 18.0 and WorldBuilder.surface_at(pos) != "asphalt":
			break
	var gang: CharacterBody3D = _gang_scene.create_in(territory)
	gang.position = pos
	add_child(gang)

func _beach_director() -> void:
	var beach_rect: Rect2 = world_data["districts"].get("Beachfront", Rect2())
	if beach_rect.size == Vector2.ZERO:
		return
	var player = GameState.get_player() if GameState.has_method("get_player") else get_tree().get_first_node_in_group("player")
	if player == null:
		return
	var center: Vector2 = beach_rect.get_center()
	if Vector2(player.global_position.x, player.global_position.z).distance_to(center) > 180.0:
		return
	var alive: int = 0
	var beach_groups: Array = GameState.get_cached_group("beach_npcs") if GameState.has_method("get_cached_group") else get_tree().get_nodes_in_group("beach_npcs")
	for b in beach_groups:
		if is_instance_valid(b) and b.health > 0:
			alive += 1
	if alive >= 6:
		return
	var pos = Vector3(randf_range(beach_rect.position.x, beach_rect.end.x), 0.4, randf_range(beach_rect.position.y, beach_rect.end.y))
	if pos.distance_to(player.global_position) < 15.0:
		return
	var beach_npc: CharacterBody3D = _beach_scene.create()
	beach_npc.position = pos
	add_child(beach_npc)


func _military_director() -> void:
	var mil_rect: Rect2 = world_data["districts"].get("Military", Rect2())
	if mil_rect.size == Vector2.ZERO:
		mil_rect = Rect2(-70, -350, 330, 100)
	var player = GameState.get_player() if GameState.has_method("get_player") else get_tree().get_first_node_in_group("player")
	if player == null:
		return
	var center: Vector2 = mil_rect.get_center()
	if Vector2(player.global_position.x, player.global_position.z).distance_to(center) > 200.0:
		return
	var alive: int = 0
	var mil_groups: Array = GameState.get_cached_group("military") if GameState.has_method("get_cached_group") else get_tree().get_nodes_in_group("military")
	for b in mil_groups:
		if is_instance_valid(b) and b.health > 0:
			alive += 1
	if alive >= 4:
		return
	var pos = Vector3(randf_range(mil_rect.position.x, mil_rect.end.x), 0.4, randf_range(mil_rect.position.y, mil_rect.end.y))
	if pos.distance_to(player.global_position) < 18.0:
		return
	var mil: CharacterBody3D = _military_scene.create_at(pos)
	mil.position = pos
	add_child(mil)




## Random-event director: supply drops, alley ambushes, civilian panics.
## Never repeats the same event back-to-back; remembers first sightings.
func _event_director() -> void:
	if GameState.wanted >= 3:
		return  # never interrupt a manhunt
	if _event_manager:
		_event_manager.trigger_random()


func _event_supply_drop(first: bool) -> void:
	var player = get_tree().get_first_node_in_group("player")
	if player == null:
		return
	var island: Rect2 = world_data["island"]
	var ang = randf() * TAU
	var xz: Vector2 = Vector2(player.global_position.x, player.global_position.z) + Vector2(float(cos(ang)), float(sin(ang))) * randf_range(18.0, 26.0)
	xz = xz.clamp(island.position + Vector2(10, 10), island.end - Vector2(10, 10))
	var pickup: Area3D = load("res://scripts/world/pickup.gd").create("money", 150)
	pickup.position = Vector3(xz.x, 0.9, xz.y)
	add_child(pickup)
	var beam = MeshInstance3D.new()
	var bm = CylinderMesh.new()
	bm.top_radius = 0.4
	bm.bottom_radius = 0.4
	bm.height = 30.0
	var bmat = StandardMaterial3D.new()
	bmat.albedo_color = Color(0.3, 1.0, 0.5, 0.5)
	bmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	bmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	bm.material = bmat
	beam.mesh = bm
	beam.position = Vector3(xz.x, 15.0, xz.y)
	add_child(beam)
	GameState.notify(("NEW EVENT — " if first else "") + "AIRDROP! Green beacon, $150 inside. 60 s!")
	var t = get_tree().create_timer(60.0)
	t.timeout.connect(func() -> void:
		if is_instance_valid(pickup):
			pickup.queue_free()
		if is_instance_valid(beam):
			beam.queue_free())


func _event_ambush(first: bool) -> void:
	var player = get_tree().get_first_node_in_group("player")
	if player == null:
		return
	var territory: Rect2 = world_data["gang_territory"]
	var island: Rect2 = world_data["island"]
	var spawned: int = 0
	for i in range(2):
		var ang = randf() * TAU
		var pos: Vector3 = player.global_position + Vector3(float(cos(ang)), 0, float(sin(ang))) * 24.0
		var xz: Vector2 = Vector2(pos.x, pos.z).clamp(island.position + Vector2(6, 6),
				island.end - Vector2(6, 6))
		if WorldBuilder.surface_at(Vector3(xz.x, 0, xz.y)) == "asphalt" and i == 0:
			pass  # roads are fine ambush ground too
		var gang: CharacterBody3D = _gang_scene.create_in(territory)
		gang.position = Vector3(xz.x, 0.4, xz.y)
		gang.target = player.global_position
		gang.state = "investigate"
		add_child(gang)
		spawned += 1
	if spawned > 0:
		GameState.notify(("NEW EVENT — " if first else "") + "AMBUSHERS closing in on your position!")


func _event_panic(first: bool) -> void:
	var player = GameState.get_player() if GameState.has_method("get_player") else get_tree().get_first_node_in_group("player")
	if player == null:
		return
	var src: Vector3 = player.global_position + Vector3(randf_range(-8, 8), 0, randf_range(-8, 8))
	var scared: int = 0
	var civs_panic: Array = GameState.get_cached_group("civilians") if GameState.has_method("get_cached_group") else get_tree().get_nodes_in_group("civilians")
	for c in civs_panic:
		if is_instance_valid(c) and c.health > 0 \
				and c.global_position.distance_to(player.global_position) < 40.0:
			c.on_gunshot(src)
			scared += 1
	if scared > 0:
		GameState.notify(("NEW EVENT — " if first else "") + "Gunshots nearby! Crowd scattering...")


## Graphics presets. LOW stays readable (keeps buildings, roads, lamp lights);
## sheds vegetation, shadows, resolution scale. ULTRA adds MSAA + glow.
func apply_quality(q: String) -> void:
	GameState.settings["quality"] = q
	var veg_off: bool = q == "LOW"
	for v in get_tree().get_nodes_in_group("veg"):
		v.visible = not veg_off
	for l in get_tree().get_nodes_in_group("street_lamps"):
		l.visible = not veg_off
	var sun_node = get_node_or_null("Sun")
	if sun_node:
		(sun_node as DirectionalLight3D).shadow_enabled = q in ["HIGH", "ULTRA"]
	var vp: Viewport = get_viewport()
	match q:
		"LOW":
			vp.scaling_3d_scale = 0.75
			vp.msaa_3d = Viewport.MSAA_DISABLED
		"MEDIUM":
			vp.scaling_3d_scale = 0.85
			vp.msaa_3d = Viewport.MSAA_DISABLED
		"HIGH":
			vp.scaling_3d_scale = 1.0
			vp.msaa_3d = Viewport.MSAA_DISABLED
		"ULTRA":
			vp.scaling_3d_scale = 1.0
			vp.msaa_3d = Viewport.MSAA_2X
	var we = get_node_or_null("WorldEnv")
	if we:
		(we as WorldEnvironment).environment.glow_enabled = q == "ULTRA"


## Door interaction areas for buyable properties.
func _register_properties() -> void:
	for id: String in world_data.get("property_spots", {}):
		var spot: Vector2 = world_data["property_spots"][id]
		var area = Area3D.new()
		area.add_to_group("property")
		area.set_meta("property_id", id)
		var cs = CollisionShape3D.new()
		var ss = SphereShape3D.new()
		ss.radius = 4.0
		cs.shape = ss
		area.add_child(cs)
		area.position = Vector3(spot.x, 1.0, spot.y)
		add_child(area)


## Round 9 S6: emergency dispatch (Phase 21 slice) — a civilian death reports
## a scene; an ambulance van drives from the hospital depot. One at a time,
## 40 s cooldown so pileups don't flood the roads.
func on_civilian_died(scene: Vector3) -> void:
	if _amb != null or _dispatch_cd > 0.0:
		return
	_dispatch_cd = 40.0
	var van: CharacterBody3D = _car_scene.create(Color(0.92, 0.92, 0.95), "van")
	van.dispatch = true
	van.dispatch_target = scene + Vector3(6, 0, 4)
	van.traffic = false
	# spawn on the avenue beside the hospital grounds (the lot itself is
	# inside the building footprint — smoke-caught: embedded spawn never moves)
	van.position = Vector3(60, 0.4, WBKit.HOSPITAL_SPOT.y)
	van.name = "Ambulance"
	van.add_to_group("ambulances")
	add_child(van)
	van.look_at(Vector3(van.dispatch_target.x, 0.4, van.dispatch_target.z), Vector3.UP)
	_amb = van
	_amb_dwell = 0.0
	GameState.notify("Ambulance dispatched")


## District-appropriate traffic mix (vehicle ecosystem: spawn by district).
## Round 9 S1: ground height for vehicle placement (terrain is procedural).
func scripts_world_terrain_height(x: float, z: float) -> float:
	return WorldTerrain.height_at(x, z)


func _traffic_pool(at: Vector3) -> Array:
	for dname: String in ["Downtown", "Industrial", "Farmland", "Beachfront", "Suburbs"]:
		var r: Rect2 = world_data["districts"].get(dname, Rect2())
		if r.size != Vector2.ZERO and r.has_point(Vector2(at.x, at.z)):
			match dname:
				"Downtown":
					return ["sedan", "taxi", "taxi", "sports", "suv", "bus", "moto"]
				"Industrial":
					return ["van", "pickup", "van", "sedan"]
				"Farmland":
					return ["pickup", "pickup", "sedan"]
				"Beachfront":
					return ["suv", "sports", "sedan", "moto", "moto"]
				"Suburbs":
					return ["sedan", "suv", "pickup", "van"]
	return []


func _busted_check() -> void:
	# Busted + Wanted decay — staged escalation
	if not is_instance_valid(player):
		bust_meter = 0.0
		_wanted_los_timer = 0.0
		_wanted_decay_timer = 0.0
		return
	if GameState.wanted == 0:
		bust_meter = 0.0
		_wanted_los_timer = 0.0
		_wanted_decay_timer = 0.0
		_wanted_blink = false
		return
	# Safehouse clears wanted instantly (sleep = save+heal+morning)
	var safehouse = get_tree().get_first_node_in_group("safehouse")
	if safehouse and safehouse.global_position.distance_to(player.global_position) < 4.0:
		if GameState.wanted > 0:
			GameState.set_wanted(0)
			GameState.notify("Wanted cleared — safehouse")
			bust_meter = 0.0
			_wanted_los_timer = 0.0
		return
	if player.driving_car != null or player.health <= 0:
		bust_meter = 0.0
		# Still check LOS for decay even in car? No, car breaks LOS faster
		# Continue to decay logic below

	# Check if any cop has LOS
	var any_los: bool = false
	var cop_near: bool = false
	for c in get_tree().get_nodes_in_group("police"):
		if not is_instance_valid(c) or c.health <= 0:
			continue
		var d: float = c.global_position.distance_to(player.global_position)
		if d < 2.6:
			cop_near = true
		if d < 90.0 and c.has_method("_has_los_to") and c._has_los_to(player.global_position):
			any_los = true
			break

	if any_los:
		_wanted_los_timer = 0.0
		_wanted_decay_timer = 0.0
		_wanted_blink = false
	else:
		_wanted_los_timer += 0.5  # called every 0.5s

	# Busted meter
	if cop_near and player.velocity.length() < 2.0 and player.driving_car == null:
		bust_meter += 0.5
		if bust_meter >= 2.0:
			_busted()
	else:
		bust_meter = maxf(0.0, bust_meter - 0.5)

	# Wanted decay — per star timers: 1=15s, 2=25s, 3=45s, 4=60s, 5=90s to start blinking, then drop 1 star every 10s if hidden
	var decay_start: float
	match GameState.wanted:
		1: decay_start = 15.0
		2: decay_start = 25.0
		3: decay_start = 45.0
		4: decay_start = 60.0
		5: decay_start = 90.0
		_: decay_start = 15.0

	if _wanted_los_timer >= decay_start and not any_los:
		if not _wanted_blink:
			_wanted_blink = true
			_wanted_decay_timer = 0.0
			GameState.notify("Wanted blinking — stay hidden to lose heat")
		_wanted_decay_timer += 0.5
		if _wanted_decay_timer >= 10.0:
			_wanted_decay_timer = 0.0
			GameState.set_wanted(GameState.wanted - 1)
			if GameState.wanted > 0:
				GameState.notify("Wanted level dropped — %d stars remaining" % GameState.wanted)
			else:
				GameState.notify("Wanted cleared — you escaped!")
				_wanted_blink = false
				_wanted_los_timer = 0.0


func _busted() -> void:
	bust_meter = 0.0
	GameState.notify("BUSTED! Fine paid: $200")
	EconomyRes.charge(200, "busted_fine")
	GameState.set_wanted(0)
	_respawn_player()


func _on_player_died() -> void:
	GameState.notify("WRECKED! Hospital fee: $100")
	EconomyRes.charge(100, "hospital_fee")
	GameState.set_wanted(0)
	var t = get_tree().create_timer(2.5)
	t.timeout.connect(_respawn_player)


func _respawn_player() -> void:
	if not is_instance_valid(player):
		return
	player.respawn(world_data["player_spawn"] + Vector3(0, 0.4, 0))
	bust_meter = 0.0
	if GameState.has_method("invalidate_player_cache"):
		GameState.invalidate_player_cache()


# ------------------------------------------------------------------- crimes
func _on_crime(severity: int, pos: Vector3) -> void:
	if severity > 0:
		GameState.add_wanted(severity)
	get_tree().call_group("civilians", "on_gunshot", pos)
	get_tree().call_group("police", "on_gunshot", pos)


# -------------------------------------------------------------------- loop
var _thunder_cd: float = 0.0

## Exit teardown (D2 root-cause fix): actively-playing audio streams leak at
## engine shutdown. Stop every player so playbacks are released.
func _notification(what: int) -> void:
	if what == NOTIFICATION_EXIT_TREE:
		_stop_all_audio()


## D2 family fix: native WAV looping replaces finished->play replay lambdas.
## The replay pattern leaks AudioStreamPlaybackWAV at teardown (engine artifact,
## isolated-repro verified); a looped stream holds ONE playback that stop() ends.
func _loop_wav(p: Node) -> void:
	var s: AudioStreamWAV = p.stream as AudioStreamWAV
	if s:
		s.loop_mode = AudioStreamWAV.LOOP_FORWARD
		s.loop_begin = 0
		s.loop_end = int(s.get_length() * s.mix_rate)


func _stop_all_audio() -> void:
	# whole-tree sweep: test harnesses attach vehicles outside game's subtree,
	# and their audio must die with everything else at shutdown. The latch
	# keeps per-frame restart logic (rain, engines, sirens) from undoing it.
	GameState.audio_shutdown = true
	var tree = get_tree()
	if tree == null:
		return
	for p: AudioStreamPlayer in tree.root.find_children("*", "AudioStreamPlayer", true, false):
		p.stop()
	for p: AudioStreamPlayer3D in tree.root.find_children("*", "AudioStreamPlayer3D", true, false):
		p.stop()


func _process(delta: float) -> void:
	if _road_mats.is_empty():
		for r in get_tree().root.find_children("Road*", "MeshInstance3D", true, false):
			var mi: MeshInstance3D = r as MeshInstance3D
			var bm: Material = mi.get_active_material(0)
			if bm is StandardMaterial3D:
				_road_mats.append(bm)
				_road_base.append((bm as StandardMaterial3D).albedo_color)
	# new-day income for owned properties
	if GameState.day_time + 5.0 < _prev_day_time:
		var inc: int = GameState.daily_income()
		if inc > 0:
			EconomyRes.earn(inc, "property_income")
			GameState.notify("Daily income from properties: +$%d" % inc)
	_prev_day_time = GameState.day_time
	# Round 9 S6: ambulance arrival dwell -> despawn; cooldown tick
	_dispatch_cd = maxf(0.0, _dispatch_cd - delta)
	if _amb != null and is_instance_valid(_amb):
		if _amb.global_position.distance_to(_amb.dispatch_target) < 9.0:
			_amb_dwell += delta
			if _amb_dwell > 6.0:
				_amb.queue_free()
				_amb = null
				_amb_dwell = 0.0
	GameState.advance_time(delta * 24.0 / GameState.DAY_LENGTH_SEC)
	GameState.update_traffic_phase(delta)
	_update_day_night()
	_update_ambience()
	_update_rain(delta)
	_update_thunder(delta)
	var mill = get_node_or_null("WindmillBlades")
	if mill:
		mill.rotate_z(delta * 0.8)
	var t: float = Time.get_ticks_msec() / 1000.0
	for b in get_tree().get_nodes_in_group("beacons"):
		b.light_energy = 1.4 + float(sin(t * 3.0 + b.position.x)) * 1.0
	for tl: Node3D in get_tree().get_nodes_in_group("traffic_lights"):
		var lamps: Array = tl.get_children()
		var ns_green: bool = GameState.traffic_ns_green
		var lt_xz: Vector2 = tl.get_meta("xz")
		var ns_axis: bool = absf(lt_xz.x - roundf(lt_xz.x / 314.0) * 314.0) < 1.0 if false else _is_ns_road(lt_xz)
		for i in range(lamps.size()):
			var mesh_inst: MeshInstance3D = lamps[i]
			var mat: StandardMaterial3D = (mesh_inst.mesh as BoxMesh).material
			var is_red: bool = i == 0
			var is_yellow: bool = i == 1
			var is_green: bool = i == 2
			var lit: bool = false
			if ns_axis:
				lit = (is_green if ns_green else is_red) or (is_yellow and false)
			else:
				lit = (is_red if ns_green else is_green)
			mat.emission_energy_multiplier = 2.2 if lit else 0.05
	# Round 10 E6: ferris wheel spins (real-time, not day/night driven)
	for fw in get_tree().get_nodes_in_group("ferris"):
		fw.rotation.x += delta * 0.35
	# Round 10 E4: wet asphalt — darkens and sheens with rain (lerped)
	_wet = move_toward(_wet, 1.0 if GameState.raining else 0.0, 0.6 * delta)
	for i in range(_road_mats.size()):
		var rm: StandardMaterial3D = _road_mats[i]
		var base: Color = _road_base[i]
		rm.albedo_color = base.darkened(0.3 * _wet)
		rm.roughness = lerpf(0.95, 0.45, _wet)
		rm.metallic = 0.22 * _wet
	# weather visual easing
	var we = get_node_or_null("WorldEnv") as WorldEnvironment
	if we:
		we.environment.fog_density = lerpf(we.environment.fog_density, _wx_fog, 0.8 * delta)
		we.environment.fog_light_color = we.environment.fog_light_color
	var sun_node = get_node_or_null("Sun") as DirectionalLight3D
	if sun_node:
		sun_node.light_energy = lerpf(sun_node.light_energy, _wx_sun, 0.8 * delta)


## Weather 2.0 visual application — targets lerped in _process for smooth
## transitions. Particles/audio stay driven by GameState.raining (v1 path).
func apply_weather(state: String) -> void:
	match state:
		"CLEAR":
			_wx_fog = 0.0008
			_wx_sun = 1.2
		"CLOUDY":
			_wx_fog = 0.0045
			_wx_sun = 0.85
		"RAIN":
			_wx_fog = 0.006
			_wx_sun = 0.55
		"HEAVY_RAIN":
			_wx_fog = 0.009
			_wx_sun = 0.4
		"FOG":
			_wx_fog = 0.02
			_wx_sun = 0.7


func _is_ns_road(xz: Vector2) -> bool:
	# lights on N-S avenues (x = -267, 53, -410) control N-S flow
	return absf(xz.x + 267.0) < 1.0 or absf(xz.x - 53.0) < 1.0 or absf(xz.x + 410.0) < 1.0


func _register_service_points() -> void:
	var shop = Area3D.new()
	shop.add_to_group("gun_shop")
	var sc = CollisionShape3D.new()
	var ss = SphereShape3D.new()
	ss.radius = 3.2
	sc.shape = ss
	shop.add_child(sc)
	shop.position = world_data["shop_spot"]
	add_child(shop)
	var gas = Area3D.new()
	gas.add_to_group("gas_station")
	var gc = CollisionShape3D.new()
	var gs = SphereShape3D.new()
	gs.radius = 4.2
	gc.shape = gs
	gas.add_child(gc)
	gas.position = world_data["gas_spot"]
	add_child(gas)
	var sh = Area3D.new()
	sh.add_to_group("safehouse")
	var hc = CollisionShape3D.new()
	hs_shape = SphereShape3D.new()
	hs_shape.radius = 3.2
	hc.shape = hs_shape
	sh.add_child(hc)
	sh.position = world_data["safehouse_spot"]
	add_child(sh)


var hs_shape: SphereShape3D

func _update_thunder(delta: float) -> void:
	_thunder_cd -= delta
	if GameState.raining and _thunder_cd <= 0.0:
		# Round 12 Phase 20: storms crack more often (heavy rain 6-14 s)
		if GameState.heavy_rain:
			_thunder_cd = randf_range(6.0, 14.0)
		else:
			_thunder_cd = randf_range(18.0, 45.0)
		# lightning flash: brief sun spike
		var tw: Tween = create_tween()
		tw.tween_property(sun, "light_energy", 3.2, 0.08)
		tw.tween_property(sun, "light_energy", 0.4, 0.35)
		var snd = AudioStreamPlayer.new()
		snd.stream = load("res://assets/audio/thunder.wav")
		snd.volume_db = -6.0
		add_child(snd)
		snd.play()
		var t = get_tree().create_timer(2.4)
		t.timeout.connect(snd.queue_free)


## Round 9 S10: district ambient zone — stream switches by district and
## phase; only switches when the zone key changes (no per-frame restarts).
func _update_ambience() -> void:
	var p = GameState.get_player() if GameState.has_method("get_player") else get_tree().get_first_node_in_group("player")
	if p == null:
		return
	var dname: String = _district_at(p.global_position)
	var key: String = ""
	match dname:
		"Beachfront", "Marina", "Coast":
			key = "res://assets/audio/ocean.wav"
		"Park":
			key = "" if GameState.is_night() else "res://assets/audio/birds_day.wav"
		"Downtown":
			key = "res://assets/audio/city_hum.wav" if GameState.is_night() else ""
	if key == _ambience_key:
		return
	_ambience_key = key
	if key == "":
		_ambience.stop()
		return
	var stream = load(key)
	if stream is AudioStreamWAV:
		stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
		stream.loop_begin = 0
		stream.loop_end = stream.data.size() / 2  # 16-bit mono frames
	_ambience.stream = stream
	_ambience.volume_db = -16.0
	_ambience.play()


func _district_at(pos: Vector3) -> String:
	for dname: String in world_data["districts"].keys():
		var r: Rect2 = world_data["districts"][dname]
		if r.size != Vector2.ZERO and r.has_point(Vector2(pos.x, pos.z)):
			return dname
	return ""


func _update_day_night() -> void:
	var t: float = GameState.day_time
	var day_factor: float = clampf(float(sin((t - 6.0) / 12.0 * PI)), 0.0, 1.0)
	var night: float = 1.0 - day_factor
	sun.rotation_degrees = Vector3(-15.0 - 70.0 * day_factor, 30.0 + (t - 12.0) * 8.0, 0)
	var rain_dim: float = 0.55 if GameState.raining else 1.0
	# Round 11: Compatibility-renderer light balance — sun 1.3 + sky ambient 1.1
	# produced ~2.4x irradiance: bright albedos (sand/grass) clipped to pure
	# white (measured pixel 1.0,1.0,1.0 over albedo 0.64 in qa_marina). Sun 1.0
	# + ambient 0.75 keeps contrast without clipping.
	# Round 11: light budget is RENDERER-CONDITIONAL. Forward+ (the shipped
	# default) tonemaps filmic and keeps sun 1.3 / sky-ambient 1.1 without
	# clipping; the Compatibility path (CI software-GL, low-end fallback)
	# measured ~2x irradiance clip on bright albedos (pixel 1.0 over albedo
	# 0.64 — tools/qa_marina.png ladder), so it runs a grounded profile.
	var compat: bool = RenderingServer.get_current_rendering_method() == "gl_compatibility"
	sun.light_energy = (0.15 + (0.75 if compat else 1.15) * day_factor) * rain_dim
	moon.light_energy = 0.14 * night
	env.ambient_light_energy = ((0.20 + 0.15) if compat else (0.35 + 0.75)) * day_factor
	# Round 10 E3: stars fade in with the night factor
	_sky_mat.sky_cover_modulate = Color(0.85, 0.9, 1.0, night)
	# Round 11: fog color follows the sky — pale haze by day, dark by night
	# (was pinned near-white: midnight rendered like overcast noon). Deepened
	# + density lowered again: the bright default washed the whole mid-ground
	# into a near-white plain (rendered, bisection-measured pixel 0.86/0.95).
	env.fog_light_color = Color(0.55, 0.63, 0.72).lerp(Color(0.03, 0.05, 0.10), night)
	# Round 10 E6: radio beacon blinks (25 % duty); E8: cat-eye studs at night
	for bc in get_tree().get_nodes_in_group("beacon"):
		var bm: StandardMaterial3D = bc.get_meta("beacon_mat")
		bm.emission_energy_multiplier = 3.0 if fmod(t * 900.0, 1.0) < 0.25 else 0.15
	for ns in get_tree().get_nodes_in_group("night_studs"):
		(ns.get_meta("stud_mat") as StandardMaterial3D) \
				.emission_energy_multiplier = 2.4 * night
	# Sky palette: night <-> (sunset near horizon) <-> day
	var top_night: Color = Color(0.02, 0.03, 0.09)
	var top_day: Color = Color(0.24, 0.47, 0.75)
	var hor_night: Color = Color(0.08, 0.1, 0.18)
	var hor_day: Color = Color(0.68, 0.75, 0.82)
	var sunset: float = clampf(1.0 - absf(day_factor - 0.18) * 5.0, 0.0, 1.0)
	_sky_mat.sky_top_color = top_night.lerp(top_day, day_factor)
	_sky_mat.sky_horizon_color = hor_night.lerp(hor_day, day_factor).lerp(
			Color(0.95, 0.55, 0.3), sunset * 0.6)
	_sky_mat.ground_horizon_color = _sky_mat.sky_horizon_color
	env.fog_density = 0.008 if GameState.raining else 0.0035
	# Street lamps
	var lamp_energy: float = 1.15 if (GameState.is_night() or GameState.raining) else 0.0
	for l in get_tree().get_nodes_in_group("street_lamps"):
		l.light_energy = lamp_energy
	# Building windows glow at night
	var win: Material = WorldBuilder.WINDOW_MATERIAL
	if win:
		win.emission_energy_multiplier = 1.1 * night if night > 0.25 else 0.0


func _update_rain(_delta: float) -> void:
	rain_particles.emitting = GameState.raining
	if GameState.raining and player:
		var cam: Camera3D = get_viewport().get_camera_3d()
		var anchor: Vector3 = cam.global_position if cam else player.global_position
		rain_particles.global_position = anchor + Vector3(0, 16, 0)


## Debug spawners (master plan §41) — shared by input handlers + DebugTools.
func debug_spawn_car() -> void:
	var car: CharacterBody3D = _car_scene.create_random(RandomNumberGenerator.new())
	var pnode: Node = get_tree().get_first_node_in_group("player")
	if pnode is Node3D:
		car.position = (pnode as Node3D).global_position + Vector3(6, 0.6, 0)
	add_child(car)
	GameState.notify("DEBUG: vehicle spawned")


func debug_spawn_npc() -> void:
	var civ: CharacterBody3D = _civ_scene.create()
	var pnode2: Node = get_tree().get_first_node_in_group("player")
	if pnode2 is Node3D:
		civ.position = (pnode2 as Node3D).global_position + Vector3(-5, 0.4, 0)
	add_child(civ)
	GameState.notify("DEBUG: NPC spawned")


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		pause_menu.open()
	elif event.is_action_pressed("debug_toggle"):
		hud.toggle_debug()
	elif event.is_action_pressed("map"):
		hud.toggle_map()
	elif event.is_action_pressed("phone"):
		hud.toggle_phone()  # Round 9 S8
	elif hud._debug_on and event.is_action_pressed("debug_spawn_car"):
		debug_spawn_car()
	elif hud._debug_on and event.is_action_pressed("debug_spawn_npc"):
		debug_spawn_npc()
	elif event.is_action_pressed("save_game"):
		SaveSystem.save_game()
	elif event.is_action_pressed("load_game"):
		SaveSystem.load_game()
	elif event.is_action_pressed("weather_toggle"):
		var _ws = get_node_or_null("WorldSim")
		if _ws:
			_ws.cycle()
			GameState.notify("[debug] weather: " + _ws.state)
		else:
			GameState.set_raining(not GameState.raining)
			GameState.notify("[debug] weather toggled")