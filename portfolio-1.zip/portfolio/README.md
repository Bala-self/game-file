# Balakrishnan M — Portfolio

Single-page developer portfolio. Pure HTML5, CSS3, and vanilla JavaScript —
no frameworks, no build step, no dependencies to install.

## Run it

Open `index.html` directly in a browser, or serve the folder locally:

```bash
cd portfolio
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Structure

```
portfolio/
├── index.html                  # all content and structure
├── css/
│   └── style.css               # all styles + the motion layer
├── js/
│   └── script.js               # smooth scroll, reveals, progress, back-to-top
└── assets/
    ├── images/                 # project screenshots (natural ratio, fully visible)
    │   ├── billpro-screenshot.png
    │   ├── image.png                  # Kadai e-commerce screenshot
    │   ├── pizza-palace-screenshot.png
    │   └── tripadvisor-clone-screenshot.png
    ├── icons/                  # skill icons (sourced from github.com/Bala-self/game-file)
    │   ├── mysql.svg
    │   └── firebase.svg
    └── files/
        └── Balakrishnan_M_Resume.pdf   # resume download
```

## Design notes (v3)

- **Palette** (three colors + opacity variations, in `css/style.css` under `:root`):
  paper `#F4F1EA` · ink `#0F1E33` · cobalt `#1F44E0`.
- **Type**: Fraunces (display serif) · Instrument Sans (body) · IBM Plex Mono (labels/meta).
- **Alignment**: asymmetric hero with a quick-facts rail, section headers with a
  kicker + hairline rule, featured project body in a two-column grid, indexed
  project meta rows connected by a responsive project timeline, large footer
  wordmark.
- **Motion** (one signature animation per section, all progressive enhancements):
  hero entrance choreography with a masked name reveal · section rules that draw
  themselves · screenshot settle (scale 1.06 → 1) · staggered project cards ·
  pinned horizontal project timeline driven by vertical scroll, returning to
  vertical page scrolling after the fourth project ·
  cobalt border draw on experience entries · skills column cascade ·
  typographic letter-spacing settle on dates · springy pop on contact actions ·
  footer wordmark mask reveal · scroll-progress hairline · link-arrow nudges.
  Everything is disabled under `prefers-reduced-motion`, and all content is
  fully visible with JavaScript turned off.

## Navigation model

There is intentionally **no top navbar and no sidebar**. The footer is the
only site navigation (section links, social links, resume). The hero carries
its own copy of the social links and buttons because it is the first thing
seen. A "Skip to content" link is available on keyboard focus, and a
back-to-top button appears after scrolling past the hero.

## Editing content

- All text lives in `index.html` — edit it directly.
- Colors are defined once in `css/style.css` under `:root`
  (`--paper`, `--ink`, `--blue` + opacity variants).
- To replace a project screenshot, drop a new image into `assets/images/` and
  update the `src`, `width`, and `height` attributes on its `<img>` tag — the
  layout shows screenshots at their natural aspect ratio, fully visible.
- To update the resume, replace `assets/files/Balakrishnan_M_Resume.pdf`.

## Links used on the page

- GitHub: https://github.com/Bala-self
- LinkedIn: https://www.linkedin.com/in/balakrishnan-mariyappan-b43813294
- Email: balakrishnan.code@email.com
- BillPro repo: https://github.com/Bala-self/billing-software (not deployed publicly)
- Pizza Palace: demo https://pizza-palace-lake.vercel.app/ · repo https://github.com/Bala-self/pizza-palace
- TripAdvisor Clone: demo https://bala-self.github.io/tripadvisor.com/ · repo https://github.com/Bala-self/tripadvisor.com
- Kadai e-commerce website: repo https://github.com/Bala-self/ecommeres-website-using-firebase
