/*
  Portfolio interactions — intentionally minimal.
  The site has no persistent navigation, so the behaviors are:

  1. Smooth in-page scrolling for footer nav links and the hero
     "View Projects" button, honouring the visitor's reduced-motion
     preference.
  2. A "back to top" button that appears once the hero is scrolled past.
  3. A reveal-on-scroll system — one signature animation per section
     (masked name reveal, drawing rules, springy pops, screenshot
     settle). Progressive enhancement: content is fully visible without
     JavaScript, and all motion is skipped for reduced-motion users.
  4. A pinned horizontal project timeline driven by vertical scroll.

  The page remains fully readable and all links keep working even if
  this file fails to load.
*/

(function () {
  'use strict';

  // Shared reduced-motion check, read live so it also applies if the
  // visitor changes the OS setting mid-session.
  var reduceMotionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');

  function prefersReducedMotion() {
    return reduceMotionQuery.matches;
  }

  // 1. Smooth scrolling for in-page links (e.g. #projects, #contact)
  var inPageLinks = document.querySelectorAll('a[href^="#"]');

  inPageLinks.forEach(function (link) {
    link.addEventListener('click', function (event) {
      var hash = link.getAttribute('href');

      // Let the browser handle empty or non-matching targets
      if (!hash || hash.length < 2) {
        return;
      }

      var target = document.querySelector(hash);
      if (!target) {
        return;
      }

      // Visitors who prefer reduced motion get the default instant jump
      if (prefersReducedMotion()) {
        return;
      }

      event.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  });

  // 2. Back-to-top button
  var backToTopButton = document.getElementById('backToTop');
  var hero = document.getElementById('top');

  if (backToTopButton && hero) {
    function toggleBackToTop() {
      // Show the button only after the hero has been scrolled past
      if (window.scrollY > hero.offsetHeight) {
        backToTopButton.classList.add('is-visible');
      } else {
        backToTopButton.classList.remove('is-visible');
      }
    }

    window.addEventListener('scroll', toggleBackToTop, { passive: true });
    toggleBackToTop(); // Set the correct state on page load

    backToTopButton.addEventListener('click', function () {
      if (prefersReducedMotion()) {
        window.scrollTo(0, 0);
      } else {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    });
  }

  // 3. Reveal on scroll
  var revealElements = document.querySelectorAll('.reveal');

  if (
    revealElements.length > 0 &&
    'IntersectionObserver' in window &&
    !prefersReducedMotion()
  ) {
    // Flag that JS is running, so the hidden initial states only apply
    // when the reveal script is actually able to reveal elements.
    document.documentElement.classList.add('js');

    var observer = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add('in');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -48px 0px' }
    );

    revealElements.forEach(function (element) {
      observer.observe(element);
    });
  }

  // 4. Pin the projects section and map its vertical travel to horizontal
  // card movement. This is progressive enhancement: reduced-motion users,
  // unsupported browsers, and no-JavaScript users keep the normal grid.
  var projectSection = document.getElementById('projects');
  var projectScrollShell = projectSection && projectSection.querySelector('.project-scroll-shell');
  var projectScrollSticky = projectSection && projectSection.querySelector('.project-scroll-sticky');
  var projectScrollViewport = projectSection && projectSection.querySelector('.project-scroll-viewport');
  var projectTrack = projectSection && projectSection.querySelector('.project-grid');
  var projectCards = projectTrack ? projectTrack.querySelectorAll('.project') : [];
  var projectScrollStatus = projectSection && projectSection.querySelector('#projectScrollStatus');
  var projectWideScreenQuery = window.matchMedia('(min-width: 768px)');

  if (
    projectScrollShell &&
    projectScrollSticky &&
    projectScrollViewport &&
    projectTrack &&
    projectWideScreenQuery.matches &&
    !prefersReducedMotion()
  ) {
    var projectHorizontalDistance = 0;
    var projectStart = 0;
    var projectFrame = null;
    var projectResizeObserver = null;
    var lastProjectIndex = -1;
    var projectSnapTimer = null;
    var projectIsSnapping = false;

    document.documentElement.classList.add('horizontal-scroll-enabled');

    function updateProjectHorizontalScroll() {
      projectFrame = null;

      var projectTravel = projectScrollShell.offsetHeight - projectScrollSticky.offsetHeight;
      var projectProgress = projectTravel > 0
        ? (window.scrollY - projectStart) / projectTravel
        : 0;

      projectProgress = Math.max(0, Math.min(1, projectProgress));
      projectTrack.style.setProperty('--project-progress', (projectProgress * 100) + '%');
      projectTrack.style.transform = 'translate3d(' + (-projectHorizontalDistance * projectProgress) + 'px, 0, 0)';

      var currentProjectIndex = Math.min(
        projectCards.length - 1,
        Math.round(projectProgress * (projectCards.length - 1))
      );

      projectCards.forEach(function (card, index) {
        card.classList.toggle('is-current', index === currentProjectIndex);
      });

      if (projectScrollStatus && currentProjectIndex !== lastProjectIndex) {
        projectScrollStatus.textContent = String(currentProjectIndex + 1).padStart(2, '0') + ' / ' + String(projectCards.length).padStart(2, '0');
        lastProjectIndex = currentProjectIndex;
      }
    }

    function requestProjectHorizontalScroll() {
      if (projectFrame !== null) {
        return;
      }

      projectFrame = window.requestAnimationFrame(updateProjectHorizontalScroll);
      scheduleProjectSnap();
    }

    function clearProjectSnapTimer() {
      if (projectSnapTimer !== null) {
        window.clearTimeout(projectSnapTimer);
        projectSnapTimer = null;
      }
    }

    // Let the visitor scroll freely, then settle on the nearest full card.
    function scheduleProjectSnap() {
      if (projectIsSnapping) {
        return;
      }

      clearProjectSnapTimer();
      projectSnapTimer = window.setTimeout(function () {
        projectSnapTimer = null;

        var projectTravel = projectScrollShell.offsetHeight - projectScrollSticky.offsetHeight;
        var projectEnd = projectStart + projectTravel;

        if (
          projectCards.length < 2 ||
          projectTravel <= 0 ||
          window.scrollY < projectStart ||
          window.scrollY > projectEnd
        ) {
          return;
        }

        var projectProgress = (window.scrollY - projectStart) / projectTravel;
        var projectIndex = Math.round(projectProgress * (projectCards.length - 1));
        var targetScrollTop = projectStart + projectTravel * (projectIndex / (projectCards.length - 1));

        if (Math.abs(window.scrollY - targetScrollTop) < 2) {
          return;
        }

        projectIsSnapping = true;
        window.scrollTo({ top: targetScrollTop, behavior: 'smooth' });

        window.setTimeout(function () {
          projectIsSnapping = false;
        }, 800);
      }, 150);
    }

    function measureProjectHorizontalScroll() {
      projectScrollShell.style.height = 'auto';
      projectTrack.style.transform = 'translate3d(0, 0, 0)';
      var projectPanelInset = Math.min(
        32,
        Math.max(16, projectScrollViewport.clientWidth * 0.03)
      );
      projectTrack.style.setProperty(
        '--project-card-width',
        Math.max(projectScrollViewport.clientWidth - (projectPanelInset * 2), 0) + 'px'
      );

      projectHorizontalDistance = Math.max(
        projectTrack.scrollWidth - projectScrollViewport.clientWidth,
        0
      );

      projectStart = projectScrollShell.getBoundingClientRect().top + window.scrollY;
      projectScrollShell.style.height = (projectScrollSticky.offsetHeight + projectHorizontalDistance) + 'px';
      requestProjectHorizontalScroll();
    }

    function disableProjectHorizontalScroll() {
      document.documentElement.classList.remove('horizontal-scroll-enabled');
      projectScrollShell.style.height = '';
      projectTrack.style.transform = '';
      projectTrack.style.removeProperty('--project-progress');
      projectTrack.style.removeProperty('--project-card-width');
      clearProjectSnapTimer();
      projectIsSnapping = false;
      projectCards.forEach(function (card) {
        card.classList.remove('is-current');
      });

      if (projectScrollStatus) {
        projectScrollStatus.textContent = '01 / 04';
      }
      window.removeEventListener('scroll', requestProjectHorizontalScroll);
      window.removeEventListener('resize', measureProjectHorizontalScroll);

      if (projectFrame !== null) {
        window.cancelAnimationFrame(projectFrame);
        projectFrame = null;
      }

      if (projectResizeObserver) {
        projectResizeObserver.disconnect();
        projectResizeObserver = null;
      }
    }

    window.addEventListener('scroll', requestProjectHorizontalScroll, { passive: true });
    window.addEventListener('resize', measureProjectHorizontalScroll);

    if ('ResizeObserver' in window) {
      projectResizeObserver = new ResizeObserver(measureProjectHorizontalScroll);
      projectResizeObserver.observe(projectScrollSticky);
      projectResizeObserver.observe(projectScrollViewport);
    }

    measureProjectHorizontalScroll();

    if (typeof reduceMotionQuery.addEventListener === 'function') {
      reduceMotionQuery.addEventListener('change', function () {
        if (prefersReducedMotion()) {
          disableProjectHorizontalScroll();
        }
      });
    }
  }

})();
