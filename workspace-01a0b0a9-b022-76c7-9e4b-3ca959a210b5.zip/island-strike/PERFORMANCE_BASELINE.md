# PERFORMANCE_BASELINE — Phase 3 measured truth
Method: `tools/perf_probe.gd` — teleports the player to every registered district
center (9 stations from `world_data["districts"]` Rect2s), samples Performance
monitors under day/clear, night/clear, day/rain; 60 fps-capped pacing; per station
leg: teleport/settle window (spike metric) + sustained window (30+ frames after
teleport). Engine 4.5.stable.876b29033, headless, seed 19041604.
**GPU rows (draw calls, VRAM, render ms) are NOT MEASURED here — headless cannot
render.** Windowed run on target hardware fills them:
`godot --path . -s res://tools/perf_probe.gd` (same probe, windowed; draw-call and
VRAM monitors then report real values — extend the print block as needed).

## Sustained results (avg/max over sustained window, ms)
| Station | cond | proc avg/max | phys avg/max | tp spike | nodes | mem MB |
|---|---|---|---|---|---|---|
| Airport | day/clear | 1.24 / 1.28 | **19.38** / 22.44 | 22.4 | 5984 | 116 |
| Airport | night/clear | 0.98 / 1.28 | **11.59** / 22.44 | 22.4 | 5950 | 114 |
| Airport | day/rain | 1.71 / 3.20 | **9.07** / 22.44 | 22.4 | 5951 | 115 |
| Beachfront | day/clear | 0.93 / 1.53 | 2.74 / 3.63 | 2.6 | 5916 | 113 |
| Beachfront | night/clear | 0.86 / 1.53 | 2.81 / 3.63 | 3.6 | 5917 | 113 |
| Beachfront | day/rain | 0.88 / 1.53 | 3.37 / 5.82 | 3.6 | 5883 | 112 |
| Downtown | day/clear | 1.02 / 1.15 | 2.28 / 2.33 | 2.3 | 5883 | 111 |
| Downtown | night/clear | 1.06 / 1.34 | 2.72 / 3.54 | 3.5 | 5848 | 110 |
| Downtown | day/rain | 0.90 / 1.34 | 2.57 / 3.54 | 3.5 | 5815 | 109 |
| Farmland | day/clear | 1.14 / 1.28 | 2.35 / 2.42 | 2.3 | 5815 | 109 |
| Farmland | night/clear | 1.00 / 1.28 | 2.54 / 2.83 | 2.8 | 5780 | 107 |
| Farmland | day/rain | 0.99 / 1.28 | 2.39 / 2.83 | 2.8 | 5781 | 107 |
| Industrial | day/clear | 1.17 / 2.81 | 2.36 / 2.90 | 2.2 | 5815 | 109 |
| Industrial | night/clear | **3.77 / 7.53** | 2.50 / 2.90 | 2.9 | 5819 | 109 |
| Industrial | day/rain | 3.21 / 7.53 | 2.66 / 3.65 | 2.9 | 5854 | 110 |
| Marina | day/clear | 0.88 / 0.90 | 4.62 / 4.62 | 4.6 | 5853 | 110 |
| Marina | night/clear | 0.80 / 0.90 | 4.18 / 4.62 | 4.6 | 5852 | 110 |
| Marina | day/rain | 0.89 / 1.10 | 4.32 / 5.89 | 4.6 | 5853 | 110 |
| Military | day/clear | 0.79 / 0.86 | 3.23 / 3.36 | 3.4 | 5853 | 110 |
| Military | night/clear | 0.74 / 0.86 | 3.46 / 4.06 | 4.1 | 5818 | 109 |
| Military | day/rain | 0.87 / 1.40 | 3.39 / 4.06 | 4.1 | 5819 | 109 |
| Park | day/clear | 1.20 / 1.33 | 2.71 / 2.75 | 2.7 | 5819 | 108 |
| Park | night/clear | 0.91 / 1.33 | 3.11 / 3.83 | 3.8 | 5794 | 108 |
| Park | day/rain | 0.99 / 1.55 | 3.16 / 3.83 | 3.8 | 5795 | 108 |
| Suburbs | day/clear | 1.03 / 1.09 | 3.09 / 3.40 | 3.0 | 5795 | 108 |
| Suburbs | night/clear | 0.92 / 1.09 | 3.44 / 3.91 | 3.9 | 5794 | 108 |
| Suburbs | day/rain | 0.98 / 1.42 | 3.65 / 5.08 | 3.9 | 5795 | 108 |

Weather delta: rain costs ~0.1–0.6 ms phys (area effect + wet grip only) — negligible.
Night delta: +0.2–0.4 ms (lamp/light ownership logic), except Industrial (below).

## Findings (measured defects, phase-planned — not fixed in Phase 3)
1. **Airport: sustained physics 9–19 ms avg (22.4 ms spike)** — 3–6× the ≤6 ms CPU
   budget and eating most of the 16.6 ms frame. Every other district is 2–5 ms.
   Not a teleport artifact (sustained window is uniformly high). Candidates:
   broadphase density at the runway/facility footprint, contact churn between
   co-located static shapes. Investigate + fix in the streaming/physics phases
   (measure first: per-shape counts at airport rect vs downtown).
2. **Industrial night/rain: game-logic spikes to 7.5 ms** (vs 1.2 ms day) — night
   lamp ownership + NPC activity in that district. Under budget but the largest
   logic cost in the game; revisit when sim LOD (Phase 40) lands.

## Budget compliance (CPU-side, this machine, headless)
| Budget | Measured | Status |
|---|---|---|
| frame ≤16.6 ms (1080p HIGH) | proc+phys worst sustained ≈ 8.1 ms (Industrial night); Airport 21 ms phys EXCLUDED until fixed | PASS ex-Airport; GPU NOT MEASURED |
| CPU game logic ≤6.0 ms | worst 7.5 ms spike (Industrial night), typical ≤1.5 | MARGINAL |
| physics implicit ≤6 ms | 2–5 typical; Airport 9–19 | FAIL at Airport |
| static mem ≤350 MB | 107–116 MB | PASS |
| nodes ≤9000 | 5,780–5,985 | PASS |
| draw calls ≤1200 / VRAM ≤1.0 GB / build ≤250 ms | NOT MEASURED (headless) | pending windowed run |

Re-run after each optimization phase; any layout-output change re-baselines this file.

## Phase 6 re-measure (streaming active, 12x12 @ 75 m, 113 tiles / 536 always-on)
Same method, same machine. Sustained CPU totals stay within budget (worst
Industrial/night: 5.19 logic + 5.25 phys ≈ 10.4 ms of 16.6). Changes vs Phase 3:
- Downtown sustained phys 2.3 -> 4.9-6.8 ms: post-teleport broadphase re-entry of
  reactivated bodies lands in the sample window (band flip ≈ 7.6 ms once per tile
  crossing; real driving crosses a boundary every ~1.9 s at top speed — noted as
  a hitch source; spread-across-frames scheduled with the sim-tier phase).
- Airport physics unchanged (9-19 ms): its cost is NEAR-band statics that stay
  active by design — the Phase 3 finding stands and remains phase-planned.
- Streaming payoff scales with world growth (phases 9-16); today it trades a
  small accounting overhead for the collision-band guarantee and node headroom.
- proc numbers now include the streamer's per-frame band check (<0.3 ms).
