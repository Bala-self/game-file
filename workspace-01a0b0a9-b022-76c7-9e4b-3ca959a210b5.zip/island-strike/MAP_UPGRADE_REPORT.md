# MAP_UPGRADE_REPORT — ISLAND STRIKE
Audit-driven upgrade per master map directive. Every number below is measured from the
live project (Godot 4.5 headless runs) or from world_builder.gd source. No feature is
listed as complete without a passing regression check.

## PHASE 01 — EXISTING MAP AUDIT (completed before any modification)
**World structure**: single `world_builder.gd` (deterministic, seeded) builds everything;
`game.gd` owns lights/AI/directors; autoloads GameState + SaveSystem; 17 scripts total.
**Geometry**: flat-by-design plateau (ground y=0, sand ring to ±560/±450, water at −1.3),
900 × 700 m buildable island inside a 1 km sand square — matches original map identity.
**Roads**: 15 asphalt rects + 1 dirt — now formally classed L1 freeway(4) / L2 primary(5) /
L3 secondary(3) / L4 local(2) / L5 rural(1); dashes, edge lines, stop lines, crosswalks(96),
junction-broken sidewalks(90), freeway median with junction gaps (physics-verified).
**Buildings**: modular `_building()` + interior kit; 24 enterable interiors; downtown
height census 7/6/9 (LOW/MED/TALL); 22+ QA-registered footprints, 0 road overlaps.
**Districts (registry)**: Downtown, Park, Suburbs, Military, Airport, Industrial, Farmland,
Beachfront, Marina (+ Roads/Water fallback) — 9 named.
**Pre-existing gaps found by this audit** (not assumed): lighthouse ✗, offshore island ✗,
beach pier ✗, train yard ✗, outskirt transitions ✗, coast dressing ✗.
**Performance (headless-logic)**: 4,756 nodes / 2,945 MeshInstance3D at frame 60;
STRESS PASS; six-suite battery 0 script errors. GPU-frame metrics require on-GPU capture
(documented as limitation).

## UPGRADES SHIPPED (this report's rounds, v1.3 → v1.9)
| Layer | Content | Verification |
|---|---|---|
| Districts + registry | 9 named districts, DISTRICTS registry, map screen | smoke |
| Landmarks | parking structure (rooftop), gas station, school, hospital, construction site + crane, marina yachts | smoke counts |
| Downtown | height classes 7/6/9, Police Station, 55 m glass Hotel, enterable store + restaurant | smoke census |
| Roads L1–L5 | hierarchy registry + census; median; stop lines; broken sidewalks | smoke geometric + physics rays |
| Street furniture | 4 bus stops, 6 district signs, 9 street trees, 8 utility poles, 12 gutters | smoke counts |
| **NEW v1.9 — Coastline** | lighthouse islet (18 m tower, red bands, night lamp), marina breakwater(7), channel buoys(5), seawall, wet-line dressing, beach umbrellas(6) + lifeguard hut, driftwood | smoke counts |
| **NEW v1.9 — Pier** | walkable boardwalk (7 deck segs, piles, benches, crates, end platform), ray-verified solid | smoke physics ray |
| **NEW v1.9 — Offshore island** | swim-reachable island (46 m mound, palms, rocks, dock, cairn + flag), ray-verified walkable | smoke physics ray |
| **NEW v1.9 — Train yard** | 320 m rail corridor farmland→industrial: 40 sleepers, continuous rails, 3 freight cars on wheelsets, transshipment containers(5), depot, signals | smoke counts |
| **NEW v1.9 — Transitions** | 3 outskirt shops + 2 sheds bridging suburbs↔farmland (no hard borders) | smoke counts |
| Interiors | 24 enterable (kit system, 7 furniture styles) | count + stand-inside physics |
| Vehicles | 8-class catalog, district traffic pools, taxi/bus identity | measured handling deltas |
| NPCs | rig reuse, outfits (fixed never-applied colors), anim LOD 60/15/freeze | character suite 22/22 |
| Traffic AI | signalized loops, night thinning, rain shelter | smoke |
| Events/economy | director + world memory, 4 buyable properties, daily income | smoke math |
| Graphics | LOW/MED/HIGH/ULTRA live presets | smoke |
| Input | device detection, [E]/[Y] contextual prompts, driving camera (P0 fixed) | smoke synthetic events |

## PERFORMANCE
Headless logic (measured): loadcheck 17/17 · WALK 11/11 · CHARACTER 22/22 · SMOKE ALL PASS ·
STRESS PASS · MENU OK · 0 script errors. Scene ≈ 5.0k nodes / ≈ 3.1k meshes after coast batch.
All new far props use `visibility_range_end` (380–1600 m) and veg/night groups; nothing
new registers per-frame cost except 1 lighthouse light (night-gated).
GPU (FPS/VRAM/draw calls) requires an on-GPU run — headless cannot measure it; flagged,
not faked.

## KNOWN LIMITATIONS (honest)
1. **Terrain is flat by design.** The original map identity + every spawn/physics/AI
   assumption is built on the y=0 plateau; a heightfield pass (northern hills, cliffs)
   requires rebasing the whole placement stack — planned, not silently skipped.
2. Rolling stock is static; drivable train = later rail phase. Boats = water-physics
   phase (offshore island currently swim-reachable).
3. No tunnel/drawbridge yet (topology reserved).
4. Road-age decals (oil/cracks) present only as gutters; wear pass pending.
5. Visual (rendered) QA of new coast geometry needs your next on-GPU capture.

## FIXED BUGS (this upgrade program)
sidewalk stripes over junction asphalt (geometry proof now 0) · NPC shirt colors never
applied (setup order) · idle limb swing (movement gate) · camera frozen while driving
(root cause: look gated off) · duplicate-name mangling · HUD callable-ammo crash.

## MAP LOCK STATUS
**PHASE-LOCK v1.9** for shipped layers (districts, roads L1–L5, downtown, coast, pier,
offshore, rail corridor, interiors, landmarks): BUILD → RUN → TEST → FIX → REGRESSION(6/6)
→ LOCK, with per-layer smoke proofs that now guard against regression.
**Full-map lock intentionally deferred** until: terrain-height pass, drivable boats/train,
tunnel/drawbridge, wear pass, and an on-GPU profiling capture. Locked layers are the
source of truth; the remaining phases continue from here.
