# ISLAND STRIKE — Master Upgrade Progress Tracker
Tracks the 37-axis master quality/map/feature directive. Updated per verified batch.
**Every "DONE" below means: implemented + integrated + executed + regression-verified in the actual game (Godot 4.5 headless runs).**

## Baseline
- v1.2 `b84f8fa` — round-2 P0 walk-straight fix, verified: WALK 11/11, SMOKE 23/23, STRESS PASS, MENU OK.

## BATCH 1 — v1.3 `2dcc987` (this release)
| Axis | Target | Status | Verification |
|---|---|---|---|
| Map density/landmarks | density+verticality, landmarks | **DONE (partial)** — parking structure w/ 2 driveable ramps + rooftop collectible, gas station, school, hospital, construction site + 24 m crane, marina yachts + fuel dock, crosswalks at all 8 signals | SMOKE: ramps/pumps/crane/school/hospital/yachts/crosswalk-96 checks ALL PASS |
| District registry | named districts | **DONE (9/12)** — Downtown, Park, Suburbs, Military, Airport, Industrial, Farmland, Beachfront, Marina (+ implicit Highway/Roads). Remaining: Outskirts/Highway as formal entries | F1 debug shows live district; map renders tinted rects |
| Gangs | territories, relationships | **DONE (phase 1)** — Dockside Crew, territory Rect2, director population, LOS aggro, hostile pursuit + shootback, gunfire investigate, $80–150 loot | SMOKE: spawn 4 + goes-hostile-on-sight ALL PASS |
| Activities | at least one deep activity | **DONE** — street race: 8 checkpoints, drive-only, 110 s timer, $400, best time persisted in stats | SMOKE: start/gate-advance/$400/best-time ALL PASS |
| Weapons | variety + switching | **DONE (2/4)** — Pistol (semi) + SMG (auto), per-weapon ammo pools, Q/wheel switching, per-weapon reload/spread | SMOKE: switch/mag-size ALL PASS |
| Economy | sources/sinks | **PARTIAL** — new sink: $50 gas-station repair. Race adds source. Property purchases pending | SMOKE: repair -$50 & health 100 ALL PASS |
| NPC schedules | day/night behavior | **DONE (phase 1)** — night crowd −55 %, rain −30 %, gradual surplus despawn | SMOKE: night thinning ALL PASS |
| Map UI | full map screen | **DONE** — TAB toggles WorldMap: landmass, tinted districts+labels, roads, services, race route live-state, collectibles, player arrow | SMOKE: open/close ALL PASS |
| Debug overlay | F1, hidden in release | **DONE** (pre-existing) — now includes live district name | audit RELEASE-CLEAN |
| LOD | distance culling | **PARTIAL** — vegetation visibility_range (palm 320/pine 360/oak 340/bush 220/rock 240), cones 200 | loadcheck clean; visual range tuning pending |
| Bug fix | — | duplicate-name mangling (@Name@N) — world helpers now force readable names; HUD ammo label callable crash fixed | SMOKE counts prove it |

## Regression @ v1.3 (all machine-run headless, Godot 4.5.stable)
```
loadcheck 16/16 ok · WALK_RESULT: ALL PASS (11) · SMOKE_RESULT: ALL PASS (24 checks)
STRESS_RESULT: PASS · MENU_RESULT: OK · script errors: 0 across all five suites
```

## BATCH 2 — v1.4 `1a571ac`
| Axis | Target | Status | Verification |
|---|---|---|---|
| Interiors | >=20 enterable, modular kits | **DONE (22)** — kit system (floor/4 walls/doorway+lintel/roof/warm light), 7 furniture kits (shop/house/office/school/medical/warehouse/bar); converted GunShop, Safehouse, GasShop, ParkingOffice, School, Hospital, SiteOffice; NEW 6 downtown storefronts, HarborOffice, 24 m Warehouse, ~7 suburb houses | SMOKE: count 22 >= 20 + player physically lands & stands inside GunShop (y=0.28) |

## BATCH 3 — v1.5 `198bdc2`
| Axis | Target | Status | Verification |
|---|---|---|---|
| Events | random-event director + world memory | **DONE** — 22 s director (stands down during wanted>=3, no repeats): AIRDROP $150+beacon 60 s, AMBUSHERS x2, PANIC crowd scatter; first-sight flags + events_seen persisted | SMOKE: spawn, stat, memory flags ALL PASS |
| Economy | sources/sinks, property | **DONE** — 4 buyable properties ($1.5k–$3.5k), E-prompt purchase, daily income (+$40/+$90), ownership in save | SMOKE: buy math, no-rebuy, income 130, 4 door areas ALL PASS |
| Graphics presets | LOW/MED/HIGH/ULTRA, LOW not broken | **DONE** — live-apply from settings; LOW sheds veg+shadows+0.75 res scale, keeps lamps/buildings; ULTRA MSAA 2x + glow | SMOKE: veg tag count, hide/restore, scaling ALL PASS |
| Save | extends | **DONE** — owned properties + world_flags roundtrip | SMOKE save/load battery still green |

Regression @ v1.5: loadcheck 16/16 · WALK 11/11 · SMOKE ALL PASS (now 45 checks) · STRESS PASS · MENU OK · 0 script errors

## BATCH 4 — v1.6: character system (CHARACTER_REPORT.md has full detail)
| Axis | Target | Status | Verification |
|---|---|---|---|
| Player character | rigged humanoid, reference outfit | **DONE** — CharacterRig (11 pivots + WeaponMount), 1.80 m measured, reference look (white tee/trousers/sneakers/dark hair) | character_test 22/22 ALL PASS |
| Animations | idle/walk/run/jump/fall/crouch/turn/aim/shoot/reload/hit/death | **DONE (13 states, procedural)** | character_test: oscillation, lean, hips-drop, arm-raise, recoil, flinch, tuck, fall-over all asserted |
| NPC reuse | same skeleton/animation for NPCs | **DONE** — civilians/police/gangs built from same rig + outfits; **fixed latent bug: NPC shirt colors never applied (setup order)** | material checks per kind |
| Weapon attachment | hook | **DONE** — pistol in right-hand mount, raises on aim/fire | parent + pose checks |
| Animation LOD / optimization | distance-based NPC sim | **DONE (T-seed)** — 60/15/freeze Hz by distance; LOD group from v1.3; scene: 4,756 nodes / 2,945 meshes measured | stress PASS |
| Controller | KB+M primary, pad secondary | **carried over, unchanged** (v1.2-verified) | WALK 11/11 + MENU OK |
| Regression | full battery | **DONE** — loadcheck 17/17, WALK 11/11, CHARACTER 22/22, SMOKE ALL PASS, STRESS PASS, MENU OK, 0 script errors | six suites run |

## BATCH 5 — v1.7: driving camera fix (P0), input contexts, vehicle catalog, District 01
| Axis | Target | Status | Verification |
|---|---|---|---|
| **P0 driving camera** | camera angle while driving | **FIXED + VERIFIED** — root cause: `_unhandled_input` gated look off entirely while driving. Now: same rig, mouse+stick look always work, hands-off auto-trail behind car heading, speed dolly/FOV, cab-height pivot, clean on-foot re-anchor | SMOKE: pivot tracks car, trail dot>0.85, manual look dyaw>0.15, dolly/FOV, re-anchor |
| Input architecture | device detection, contextual prompts | **DONE** — last_device detection (kb/controller), `[E]`/`[Y]` contextual prompts on interact/repair/property, horn → B/Circle, D-pad-down → weapon select | SMOKE: synthetic joypad/key events flip device + prompt glyphs |
| Vehicle framework | data-driven classes | **DONE (8 classes)** — CLASSES catalog rows define handling; +SUV, +BUS (long body, sluggish steer), per-class steer multiplier, district-aware traffic pools (Downtown taxis+buses, Industrial vans, Farmland pickups, Beachfront SUVs), taxi roof sign + bus destination board | SMOKE: sports vs bus measured top-speed delta >35%, pooled spawn respected |
| Buildings PHASE 01 | modular architecture framework | **DONE** — `_building()` data-driven constructor: foundation, 4 material families, night-glow windows, shopfront+awning+sign, parapet, rooftop AC/antenna (culled), QA footprint registry | loadcheck + smoke |
| District 01 Downtown | heights, landmarks, services | **DONE** — LOW/MED/TALL height census (7/6/9 measured), PoliceStation, Hotel (55 m glass), enterable convenience store + restaurant (interiors 22→24), rooftop equipment | SMOKE: landmarks, census, **0 of 22 footprints overlap roads** |

Regression @ v1.7: loadcheck 17/17 · WALK 11/11 · CHARACTER 22/22 · SMOKE ALL PASS · STRESS PASS · MENU OK · 0 script errors

## BATCH 6 — v1.8: road hierarchy + complete streetscape layer
| Axis | Target | Status | Verification |
|---|---|---|---|
| Road hierarchy | L1-L5 formal | **DONE** — ROAD_CLASSES registry: freeway(4 perimeter) / primary(5) / secondary(3) / local(2) / rural dirt(1); census const | SMOKE census check |
| Sidewalks | junction-safe | **UPGRADED** — segments now BREAK at every perpendicular road crossing (90 segments); zero sidewalk-over-asphalt overlaps; proof: segment-rect x road-rect intersection == 0 | SMOKE geometric QA |
| Freeway | median + gaps | **DONE** — collidable concrete median along all 4 perimeter roads with junction gaps; physics-ray verified solid at span + open at gap | SMOKE ray queries |
| Markings | stop lines | **DONE** — 16 stop lines ahead of every signalized crosswalk (dashes/edge lines pre-existing) | SMOKE count |
| Street furniture | bus stops, signs, trees, poles, drains | **DONE** — 4 bus stops (shelter+bench+sign), 6 district boundary signs, 9 downtown street trees in planters, 8 suburban utility poles + crossarms, 12 drainage gutters | SMOKE counts |
| Pedestrian logic | sidewalk paths | carried over (civilians target sidewalk points) | civilian suite in SMOKE |

Regression @ v1.8: loadcheck 17/17 · WALK 11/11 · CHARACTER 22/22 · SMOKE ALL PASS · STRESS PASS · MENU OK · 0 script errors

## BATCH 7 — v1.9: coastline + offshore + pier + rail yard + transitions (MAP_UPGRADE_REPORT.md)
| Layer | Content | Verification |
|---|---|---|
| Coastline | lighthouse islet (18m, night lamp in group), breakwater(7), buoys(5), seawall, umbrellas(6), lifeguard hut, driftwood | SMOKE counts |
| Pier | 7-segment walkable boardwalk + end platform + crates | SMOKE physics ray (solid underfoot) |
| Offshore island | 46m island, palms, dock, cairn+flag — swim-reachable | SMOKE physics ray |
| Train yard | 320m corridor: sleepers(40), rails, 3 freight cars, containers(5), depot, signals | SMOKE counts |
| Transitions | 3 outskirt shops + 2 sheds between suburbs/farmland | SMOKE counts |
| Audit + report | MAP_UPGRADE_REPORT.md: audit findings, per-layer proofs, limitations (flat terrain documented, not hidden), phase-lock status | file |

Regression @ v1.9: loadcheck 17/17 · WALK 11/11 · CHARACTER 22/22 · SMOKE ALL PASS · STRESS PASS · MENU OK · 0 script errors

## v2.0 PROGRAM — BATCH 8: checkpoint v2.0.01 ARCHITECTURE
| Item | Content | Verification |
|---|---|---|
| V1_9_BASELINE_REPORT | full audit per directive section 01 (project/world/player/vehicles/NPC/systems/perf) | file |
| Architecture hardening | policy extracted from 696-line game.gd into `systems/world_sim.gd` (Weather 2.0: 5-state weighted chain, smooth visual easing, day phases) + `systems/event_manager.gd` (data-driven events: weights, district filters, no-repeat) | SMOKE: chain states, district-filtered picks, phases |
| Weather 2.0 | CLEAR/CLOUDY/RAIN/HEAVY_RAIN/FOG; drives raining/heavy_rain (car grip 0.72 heavy), eased fog/sun visuals; T cycles | SMOKE: flags + phase + visual targets |
| Component damage | engine/wheel health; power →45%, steering →50%, high-speed wobble; gas repair resets; functional delta measured | SMOKE: factors + worn-vs-fresh accel |
| Save 2.0 | VERSION 2 + v1 migration (owned/flags defaults) + corrupt-JSON rejection, state untouched | SMOKE: migrate 777¢, corrupt rejected |
| Debug toolkit | F2/F3 spawn car/NPC, gated behind F1 (release-hidden) | SMOKE: F2 spawn +1 |
| Docs | PERFORMANCE_BUDGET.md, REGRESSION_CHECKLIST.md (v2.0 ledger), V1_9_BASELINE_REPORT.md | files |

Regression @ v2.0.01: loadcheck 17/17 · WALK 11/11 · CHARACTER 22/22 · SMOKE ALL PASS (114 checks) · STRESS PASS · MENU OK · 0 script errors

## v2.0 PROGRAM — BATCH 9: PHASE 0 closure (stabilize) @ v2.0.02
| Item | Content | Verification |
|---|---|---|
| D1 `Parameter "m" is null` | NOT REPRODUCED on 4.5 + this tree (0 stderr hits across full battery; all 43 MeshInstance3D sites assign mesh). Per directive: gated, never blind-fixed | ci.sh error gate owns it |
| D2 exit leaks | ROOT CAUSE: finished->play replay lambdas (ocean/rain/engine/siren) + playing-at-teardown; upstream class godot#95484 (closed, not planned). FIXED: native WAV loops (_loop_wav), root-wide pre-quit sweep + GameState.audio_shutdown latch, car _exit_tree stops. Residual: rare 1-playback mix-thread race, verbose-masked | 6x smoke soak: 6/6 PASS; leak gate classifies |
| D3 lying vehicle assert | sports car never freed -> bus spawned inside it; relative-only assertion masked 0.0 m/s. FIXED: free between classes, distinct spawns, ABSOLUTE bounds (sports >= 3.5 @0.5s? measured 5.2; bus >= 1.5; sedan >= 2.0; wreck == 0) | SMOKE absolute-bound asserts |
| D4 schedule claim | measured 24 -> 12 (-50% steady, hysteresis target+2, ~6 ticks / 18 s); docs claimed -55% (wrong, corrected). Guard: 14 per-frame ticks converge 12 +/- 1, extra tick stable (queue_free deferral respected — same-frame ticks free nothing) | SMOKE night schedule asserts |
| D8 CI gate | tools/ci.sh: 6 suites, error gate (corrupt-save allowlist), leak gate with verbose re-run classification: AudioStream* = documented upstream, anything else = FAIL. CI_RESULT: PASS | two consecutive green runs |
| Determinism (directive) | `randomize()` in GameState._ready violated fixed-seed contract -> seed(19041604). Any layout change now deterministic + breaking-declarable | code; layout outputs stable across runs |
| Headless test pacing | uncapped headless frames starve physics (3-30 ticks per 60-frame window, run-dependent) -> speed bounds flaky. FIX: Engine.max_fps=60 in smoke; bounds now physics-true | 6/6 soak after fix |
| Save semantics | migrate() chain kept; owned/world_flags now REPLACE on load (payload defines full state — bought properties no longer survive a v1 load) | SMOKE v1-migrate 777¢ + owned empty |
| CURRENT_STATE_AUDIT.md | fresh measured inventory: ~3.4k GDScript ln / 17 scripts; 5,983 nodes; 3,538 meshes; 1,054 static bodies; 71 lights; open defects board | file |

Regression @ v2.0.02: CI_RESULT: PASS (twice) — loadcheck 17/17 · WALK ALL PASS · CHARACTER 22/22 · SMOKE ALL PASS · STRESS PASS · MENU OK

## v2.0 PROGRAM — BATCH 10: phases 3–10 continuous run @ v2.0.10
| Phase | Delivered | Verification |
|---|---|---|
| 3 perf truth | tools/perf_probe.gd (9 stations x day/night/rain, teleport-spike vs sustained) + PERFORMANCE_BASELINE.md; GPU rows NOT MEASURED (windowed command documented) | measured table; findings: Airport phys 9-19 ms (planned), Industrial-night 7.5 ms spikes |
| 4 decomposition | world_builder 1679 ln -> orchestrator 139 + wb_kit 308 + wb_arch 234 + 14 districts/*.gd (max 367); public API aliased | world_data IDENTICAL; cycle probe proved module->orchestrator refs must not exist (design honored) |
| 4 contract gate | tests/world_data_test.gd: canonical serializer + baseline (17 keys measured; directive claimed 16); TRES_DRIFT gate added in phase 5 | IDENTICAL + tres in sync, every CI run |
| 5 typed data | WorldDataRes Resource + assets/data/world.tres + tools/gen_world_tres.gd; from_dict uses assign() (typed-array pitfall) | drift gate PASS |
| 6 streaming | Streamer: 12x12 @ 75 m, ACTIVE(=NEAR)/FAR bands, AABB>=150 m + out-of-grid always-on; 113-115 tiles / ~538 always-on; nothing freed | smoke: NEAR/1-ring/FAR band asserts + band-flip + at-speed no-fall-through; QA rays made player-proximate (the contract); perf re-measured (band-flip hitch noted, phase-40 item) |
| 7 terrain | WorldTerrain.height_at(x,z): deterministic 3-octave value noise, flat-first (0.0 everywhere), 30 m border falloff, build_patch() mesh+concave collision | terrain_test (8th suite): flat/determinism/falloff/mesh-match (5041 verts); activation = declared breaking change later |
| 8 roads | 8-class hierarchy (freeway/arterial/collector/main_street/reserved-residential/industrial/service/dirt) + ROAD_RULES (phase 20 hook); census DERIVED from spec | smoke 8-class census PASS; world_data untouched (IDENTICAL) |
| 9 streetscape | districts/streetscape.gd KITS (9 districts, signature prop each); dressing builders kit-driven (colors synced to literals — zero visual drift); 38 props, deterministic | smoke kit-prop count PASS; exact-count asserts untouched |
| 10 navigation | NavGrid 6 m bake (above-rooftop ray fix documented), greedy-rect polygons (17,295 cells/21 rects); NavigationLink3D x2; person enable_nav() + re-path-on-change; NPC classes 4-5/5 (commuter loop, service rotation, own groups) | smoke: bake+carve, agent-driven, links, commuter motion 0.37 m/window |
| hygiene | 37 stray .uid files untracked + .gitignore *.uid | git ls-files grep == 0 |

Regression @ v2.0.10: CI_RESULT: PASS — 8 suites (loadcheck / WALK / CHARACTER / SMOKE / STRESS / MENU / WORLD_DATA / TERRAIN)

## v2.0 PROGRAM — BATCH 11: external deep-audit response (32/32 dispositioned) @ v2.0.11
| Disposition | Items |
|---|---|
| Fixed this batch (27) | #1 regen accumulator · #2 entry-stat single owner · #3 F4 · #4 shoulder horn · #5 rain off-road 0.88 · #6 set_raining routing (rain ambience follows natural weather) · #7 kill attribution via real source · #8 ghost centerline decals · #9 traffic district pools · #10 stats restore · #11 killed signal · #12 prev_weapon · #13 dead lookup · #14 PATROL_SPEED · #15 police proximity/LOS gate · #16 real accuracy falloff · #17 has_method guards · #18 world_data water level · #21 contact classification (frontal->engine, side->wheel) · #22 lake + footbridge (park pond upgraded; geometry only, contract IDENTICAL) · #23 drivable boat (Phase 24 slice: marina mooring, buoyancy, throttle/steer, enter/exit) · #24 xz-meta signal coverage assert · #26 save plainness documented deliberate · #28 LOS 5 Hz cache · #30 shotgun (3-weapon framework) · #31 physics ragdoll on death (character suite re-anchored) · #32 key-rebind UI + persistence |
| Already delivered (audit predates) | #20 navmesh+NavigationAgent3D (Phase 10) · #25 tile streaming (Phase 6) |
| Honest deferrals (verification class) | #19 NPC anim: call path + LOD tiers source-verified; visual pass is user-side · #27 audio playtest: needs ears — user-side windowed run · #29 controller hardware: human-only |

**CORRECTION (found during this batch):** the Phase 6 commit message over-claimed
its smoke coverage — the streaming band asserts and player-proximate QA rays
were not in the file (the suite passed via always-on geometry and NEAR-band
luck). Restored properly now; the restored tests immediately caught TWO real
streaming defects: a stale cached player reference (bands froze after a
respawn) and a _process re-band ordering that left a 1-tick fall-through
window (re-band moved to _physics_process, ahead of the physics step).

Regression @ v2.0.11: CI_RESULT: PASS — 8 suites; SMOKE now 131 checks incl.
streaming bands, lake bridge, boat drive, ragdoll, signal-meta coverage.

## ROUND 9: NEXT LEVEL PER SYSTEM @ v2.0.12 (plan: ROUND9_PLAN.md)
Ten systems, one next-level upgrade each, executed A/B/C with full CI PASS
per cluster. Every upgrade connects to an existing system (no orphans).

| # | System | Upgrade | Guard (smoke) |
|---|--------|---------|----------------|
| S1 | vehicles | motorcycle class (1.45x speed, lean physics, 2-wheel visuals; traffic pools) | throttle 8.2 m/s + lean −0.065 rad |
| S2 | boats | speedboat class (data-driven CLASSES, second mooring) | afloat y=−0.70, 15 > 9 config bound |
| S3 | missions | courier deliveries ×3 + MID-MISSION SAVE (v3 + migration) | pickup, save/load resumes route 0 + timer |
| S4 | economy | weapon counter: SMG $800 / shotgun $1200, ownership persists | exact money math, broke gate, save/load, cycle skip |
| S5 | NPC life | day-phase schedules (GameState.day_phase single owner) | day picks in Downtown/Industrial; night in Suburbs/Farmland |
| S6 | dispatch | ambulance: hospital-depot van drives to reported scenes | dispatched, en route, closes on scene |
| S7 | combat | gang cover-seek behind vehicles under fire | state=cover, closes 4.0→2.5 m |
| S8 | UI | phone panel (P): money/wanted/clock/weather/stats/arsenal | opens; live money row |
| S9 | sim LOD | formal T0–T4 table (logic+anim rates, single accessor) | table bounds; live 60 Hz near, parked far |
| S10 | world audio | district ambience zones (ocean/birds/hum) | park-day birds; marina ocean |

**Process lessons (recorded as guards):** test damage must use a neutral
source (player-sourced hits summon police that kill the fixture); smoke match
arms must be unique (duplicate 1006/1008 arms silently dead-armed S7);
headless _process can outpace physics — reads after teleports need frame gaps
AND living actors (dead NPCs early-return and freeze their rig state);
CollisionObject toggles inside physics callbacks must be call/set_deferred.

Regression @ v2.0.12: CI_RESULT: PASS — 8 suites; SMOKE now 150 checks.

## ROUND 10: ENVIRONMENT NEXT LEVEL PER SYSTEM @ v2.0.13 (plan: ROUND10_PLAN.md)
Eight environment systems upgraded, visual-first: world_data contract stayed
IDENTICAL throughout (no data change, terrain activation still deliberately
deferred as a declared breaking change).

| # | System | Upgrade | Guard (smoke) |
|---|--------|---------|----------------|
| E1 | ground | world-noise grass shader (two greens + dry patches) | GrassBase runs ShaderMaterial |
| E2 | ocean | wave shader (GPU bob + shore foam) + boat wake particles | shader applied; wake emitter on boats |
| E3 | sky | procedural star cover (150-dot texture), alpha = night | cover assigned; night alpha 1.0 |
| E4 | weather surfaces | wet asphalt: darkens, sheens (14 shared mats, rain-lerped) | wetness rises; roughness 0.95 -> 0.94; full-wet 0.46 |
| E5 | vegetation | 600-tuft MultiMesh grass fields (park+farmland) + sway shader | 2 fields, 600 tufts |
| E6 | landmarks | rotating ferris wheel + blinking radio beacon | rotation delta; ON 3.0 / OFF 0.15 phases |
| E7 | park water | creek ribbon + waterfall + foam feeding the lake | 6 segments; waterfall emitting |
| E8 | road dressing | perimeter guardrails + 72 night cat-eye studs (MultiMesh) | 4 rails; studs glow at night only |

**Process lessons (recorded as guards):** Godot renames duplicate sibling
nodes to @Name@2 — group-based counting, not name wildcards; beacon duty
cycles asserted by driving the updater at pinned day_times (cross-arm reads
drift because day_time accrues every frame); the interior smoke flake was
root-caused to a drop point straddling the avenue edge (passing traffic
could roof the player) — fixed at the source, not the assertion.

Regression @ v2.0.13: CI_RESULT: PASS — 8 suites; SMOKE now 169 checks.

## ROUND 11: AUDIT-FIRST EXECUTION (external protocol) @ v2.0.14
Format per protocol section 26. Source-of-truth discipline: source + live
tests authoritative; documentation corrected where they disagreed.

**SCAN** — full source pass, no modifications: zero TODO/FIXME/placeholder;
one contract violation (character_rig.npc_outfit called rng.randomize());
no duplicate/unused systems; perf risks from the audit taken as active.

**CURRENT STATE (measured, not claimed)** — Godot 4.5; 9 CI suites; SMOKE
181 checks; world_data 199 lines IDENTICAL (contract held every round);
save v3 + migrations; nodes ~6.5k (<8k), mem ~130 MB, meshes 3538 (<5k);
seeds 19041604 (world RNG), 20260915 (builder), 7717 (terrain), 19041604
(veg scatter) — all fixed.

**DEFECTS (real, found + fixed this round)** —
1. Streaming band flip = 25 ms solver burst (mass collision re-registration
   in one tick). FIXED: body-budgeted activation queue (300 bodies/tick),
   player tile instant; mid-game flip now 3.4-5.7 ms; permanent smoke bound.
2. CI-only (documented): Compatibility/llvmpipe light clip + white-plain at
   Marina — sky-ambient + fog over grazing lawn, no filmic rolloff in that
   path. Fixed for that path via renderer-conditional light budget + manual
   shader haze; Forward+ (shipped) never exhibited it.
3. Midnight fog was pale (looked like overcast noon) — fog color now follows
   the sky; clear density 0.0035 -> 0.0008.
4. npc_outfit randomize() -> counter-seeded RNG.
5. perf_probe sampled the engine's first-touch burst (whole-world physics
   registration ~28 ms, few ticks at load) as "Airport sustained 9-19 ms" —
   probe re-phased to settle 300 frames; the audit's Airport/Industrial
   numbers were this artifact. Settled truth below.

**UPGRADE (B1 perf + B2 draw + E-gap verification)** — streamer activation
queue; perf gates (ci.sh fails on any district row > 9.0 ms avg physics or
worst frame >= 13.5 ms); distance-LOD classification (2247 meshes, explicit
ranges never lowered); shadow distance 260 -> 140; ocean specular tamed;
fog overhaul; renderer-conditional light budget; determinism fix.

**FILES CHANGED** — scripts/systems/streamer.gd, scripts/game/game.gd,
scripts/world/world_builder.gd, scripts/world/districts/env.gd,
scripts/characters/character_rig.gd, tools/ci.sh, tools/perf_probe.gd,
tools/render_probe.gd (new), tests/smoke_node.gd, PROGRESS.md.

**TESTS** — full battery per cluster (F, G): loadcheck 17/17, WALK,
CHARACTER, SMOKE 181, STRESS, MENU, WORLD_DATA IDENTICAL, TERRAIN,
PERF gate — CI_RESULT: PASS x2 commits. New permanent guards: band-flip
spike < 15 ms (measures 3.8-5.7), perf probe in CI, draw-LOD print.

**PERFORMANCE (headless CPU truth; GPU on target hardware NOT MEASURED)** —
settled physics worst district row: 6.36 ms avg (Airport day) — was
reported 9-19; Industrial proc worst 3.79 avg (was reported ~7.5 spike);
global worst frame 9.07 ms vs 16.6 budget; band flip 25 -> 3.4 ms.
Draw calls (rendered, CI software-GL): Marina 1649 -> 962, Downtown
720 -> 526, Beachfront 928 -> 658, Industrial 985 -> 684, Park 1155 -> 799,
Airport 420 -> 462. VRAM ~54 MB (llvmpipe). All GPU *performance* numbers
on the RTX 3050 target remain explicitly UNMEASURED.

**VISUAL QA (rendered screenshots, CI software-GL — user-side windowed pass
still owed on target hardware)** — day/night/frames verified at 6 stations:
HUD/minimap/day-night correct; ferris wheel live with radiating shadows;
windows glow at night; lake/bridge/creek render; star cover night-visible.
Known CI-renderer artifact documented above (not chased further; shipped
Forward+ unaffected).

**REGRESSIONS** — none open. During the round: spike-guard arm collided
with an existing smoke key (caught by duplicate-key check, moved to free
frames); interior-check flake pre-dated this round (root-caused earlier:
drop point straddled the avenue).

**LOCKED** — streaming (activation queue + instant player tile), perf gate
(in CI), light budget (renderer-conditional), determinism (zero randomize),
world_data (untouched all round), save v3, input map, camera, vehicle 9-class
framework, NPC hierarchy, weather model, CI 9-suite battery.

**REMAINING (real)** — target-hardware windowed pass: GPU fps/draw/VRAM +
the protocol section 22 checklist (user-side; headless cannot render GPU
truth). Marina/Park draw calls sit at ~950-1050 on software-GL: measure on
real GPU before optimizing further (llvmpipe overstates). Beachfront
draw-call reduction (one shared palm-frond material) is the next lever.

**NEXT PHASE** — NPC anchors 2.0 (persistent home/work/leisure per NPC on
the existing schedule system) OR target-hardware QA pass if hardware is
available. Terrain activation remains a DECLARED BREAKING CHANGE for later.

## PENDING (planned, in dependency order — not silently skipped)
1. **Remaining building districts** (Beachfront, Marina, School/Hospital grounds, Industrial dressing, Train yard, Port, Farmland, Military, Airport, Hills, Outskirts) — same pipeline per district
2. **Boats + motorcycles + more vehicle classes** (framework ready; new physics for water)
3. **Weapon wheel (hold TAB), phone/quick menu, inventory screen** (input spec remaining UI surfaces)
4. **Roads/traffic refinement** (lane adherence audit, T1–T6 hierarchy formalization in world_data)
6. **Vehicle damage refinement** (staged damage, verify never instant-explode on minor hits — regression check)
7. **Sim tiers T0–T4** (AI/physics LOD by distance; profiling-gated)
8. **District registry completion** (Outskirts/Highway formal entries → 12)
9. **Perf profile pass** (profiler-driven, not guesswork)
10. **Audio pass** (ambient zones, rain/night loops)
11. **35-section final report** + release zip + push command (user pushes)
