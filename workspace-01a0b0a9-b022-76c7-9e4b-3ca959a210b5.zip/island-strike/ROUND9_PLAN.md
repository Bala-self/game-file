# ROUND 9 — NEXT LEVEL PER SYSTEM (plan)
One concrete next-level upgrade per system. Each: implement → in-engine smoke
assert → permanent guard → full CI PASS → commit. Order = dependency order.

| # | System | Current level | Next level (this round) |
|---|--------|---------------|--------------------------|
| S1 | Vehicles | 8 data-driven car classes | motorcycle class (2-wheel visuals, agile, fast) + traffic pool entry |
| S2 | Boats | 1 fishing boat, moored | data-driven 2nd class: speedboat (faster hull, 2nd mooring) |
| S3 | Missions | race + collectibles + pickups | delivery mission type (3 routes, timer, reward) + mid-mission save (SAVE_VERSION 3 + migration) |
| S4 | Economy | money from races/pickups | shop point: health $50 / ammo $100, broke-gate, HUD notify |
| S5 | NPC life sim | 5 NPC classes wander | day-phase schedules (work/evening/night districts) |
| S6 | Emergency dispatch | police pursuit only | ambulance dispatch to scenes (cooldown, service class) |
| S7 | Combat | gang NPCs direct chase | cover-seek under fire (nearest anchor between bursts) |
| S8 | UI | HUD + pause + settings | TAB phone panel (money/wanted/phase/stats + save/load) |
| S9 | Sim LOD | per-NPC lod_hz ad hoc | formal T0–T4 tier table, asserted across distances |
| S10 | World audio | global rain/night | district ambient zones (waves/birds/hum by district+phase) |

Every S# must answer "what does it connect to": S1→traffic pools+gas+enter flow,
S2→marina+water level, S3→save_system+HUD marker, S4→money+HUD, S5→world_sim
phases+nav, S6→service NPC class+roads, S7→gang AI+cover anchors, S8→GameState,
S9→person/police update rates, S10→district registry.
