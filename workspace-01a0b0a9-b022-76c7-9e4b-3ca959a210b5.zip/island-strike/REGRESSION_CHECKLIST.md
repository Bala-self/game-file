# REGRESSION CHECKLIST — run before ANY "done" claim or commit
Command template (Godot 4.5 headless, from repo root):
`/tmp/Godot_v4.5-stable_linux.x86_64 --headless --path . -s res://tests/<suite>.gd`
(re-import first if scripts were added: `--headless --import .`)

| Suite | Covers | Pass criterion |
|---|---|---|
| loadcheck | every script parses/compiles (17) | all "ok:", 0 LOADFAIL |
| walk_test | P0 walk-straight rig, spring mask/margin, facing | WALK_RESULT: ALL PASS (11) |
| character_test | rig pivots, 1.78 m, outfits, 13 anim states, weapon mount | CHARACTER_RESULT: ALL PASS (22) |
| smoke_test | 114 gameplay checks: world structures, interiors, districts QA, vehicles/handling, driving camera, gangs, race, economy, events, weather chain, component damage, save migration/corruption, device prompts, debug spawns | SMOKE_RESULT: ALL PASS |
| stress_main | max population soak | STRESS_RESULT: PASS |
| menu_test | menu build + buttons | MENU_RESULT: OK |

Gate: ALL SIX green + `audit_project.py` RELEASE-CLEAN + 0 script errors in stderr.
Additional manual gates for release: on-GPU video capture (visual QA + FPS), push +
remote verification via GitHub API.

## v2.0 checkpoint ledger
- [x] v2.0.01 ARCHITECTURE — WorldSim weather chain, EventManager policy, component
      damage, save v2 + migration + corruption rejection, debug F2/F3 (F1-gated)
- [ ] v2.0.02 WORLD — terrain heightfield evaluation, tunnel/drawbridge, road wear
- [ ] v2.0.03 NPC — life schedules (home/work anchors), faction matrix, memory decay
- [ ] v2.0.04 AI — perception/decision hardening, cover usage
- [ ] v2.0.05 VEHICLES — boats (buoyancy), motorcycle, garage storage
- [ ] v2.0.06 COMBAT — cover system, melee
- [ ] v2.0.07 POLICE — dispatch escalation by wanted, checkpoints
- [ ] v2.0.08 ECONOMY — garage services, vehicle ownership persistence
- [ ] v2.0.09 SIM — audio zones by district, ambient population by phase
- [ ] v2.0.10 UI — weapon wheel, inventory screen
- [ ] v2.0.11 SAVE — garage/vehicle state slots
- [ ] v2.0.12 OPTIMIZATION — sector streaming, profiler pass
- [ ] v2.0.13 QA — full matrix + worst-case perf capture

## Leak-gate policy (Phase 0 decision)
Upstream godotengine/godot#95484 (closed, not planned): a stream playing at engine
teardown is reported leaked — the audio server has no next mix iteration to release
it. All game-side paths fixed in Phase 0 (native WAV loops, pre-quit root sweep +
audio_shutdown latch, car _exit_tree stops). Residual: rare single-playback mix race,
timing-masked under --verbose. ci.sh policy: summary-only leaks trigger a verbose
re-run; AudioStreamWAV/AudioStreamPlaybackWAV identities = documented upstream
(allowed + logged); ANY other leaked identity fails the gate. Re-classify on any
engine upgrade.
