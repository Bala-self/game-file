# CURRENT_STATE_AUDIT — ISLAND STRIKE (Phase 0 re-audit, fresh measurements)
All numbers re-measured on THIS tree, Godot **4.5.stable.official.876b29033**, headless.
External-baseline numbers (4.3, 6,602 lines, 2,669 meshes, walk 13 / char 24 / smoke ~75)
did NOT match this tree and were not trusted; everything below is local ground truth.

## 1. Actual files / line counts (measured)
| File | Lines | Role |
|---|---|---|
| scripts/world/world_builder.gd | ~1,800 | world construction monolith (known scaling hazard) |
| scripts/game/game.gd | ~730 | world runtime: lights, directors, weather visuals, events impl |
| scripts/vehicles/car.gd | ~650 | 8-class catalog + physics + component damage |
| scripts/player/player.gd | ~430 | controller, drive context, interaction, damage |
| scripts/systems/world_sim.gd | ~110 | weather chain (v2.0.01) |
| scripts/systems/event_manager.gd | ~100 | data-driven event policy (v2.0.01) |
| scripts/npc/person.gd + 3 subclasses | ~470 | shared rig body + civ/police/gang AI |
| scripts/characters/character_rig.gd | ~300 | 11-pivot procedural humanoid |
| scripts/core/{game_state,save_system}.gd | ~400 | autoloads: input/economy/time + save v2+migrate |
| scripts/ui/{hud,pause,settings,main_menu}.gd | ~600 | HUD incl. world map, menus |
| tests/ (9 files) | ~1,100 | six suites + character suite |
17 gameplay scripts ≈ 3,400 lines GDScript. One scene (game.tscn, 6 lines, code-built world).

## 2. System inventory
- **Done + guarded**: movement/camera (WALK 11/11 guard), character rig + 13 anims
  (22-check guard), 8 vehicle classes + component damage (absolute-bounds guards),
  driving camera + contexts, weather 5-state chain, data-driven events, economy
  (properties/income/shop/race/repair), wanted 0–5 w/ search state, day/night,
  save v2 + migrate() + corruption rejection, 24 interiors, L1–L5 roads, coast pack,
  rail corridor, districts registry, map screen, debug F2/F3 (F1-gated), CI gate.
- **Measured world shape**: 5,983 nodes · 3,538 MeshInstance3D · 1,054 StaticBody3D
  (matches external probe exactly) · 71 lights · build ≈ one blocking call (ms-value
  re-measure pending; prior method was wrong — instantiate≠build).
- **Test battery**: 6 suites, all green pre-Phase-0; exit codes 0; harness CI-ready.

## 3. Current failures / defects (Phase 0 board)
- **D1** `Parameter "m" is null` — NOT REPRODUCED here (0 hits in all stderr; all 43
  MeshInstance3D sites assign mesh). Kept as CI error-gate; do not fix blind.
- **D2** exit leaks — REPRODUCED, root cause: playing audio streams at shutdown
  (`--verbose`: AudioStreamWAV ocean.wav + playback; stress adds engine+rain).
  FIXED this phase: `_notification(EXIT_TREE) → _stop_all_audio()` + guard test.
- **D3** lying vehicle assertion — reproduced; root cause: sports car never freed →
  bus spawned inside it (0.0 m/s) + relative-only assertion. FIXED: free between
  classes, distinct spawns, absolute bounds (sports ≥ 3.5, bus ≥ 1.5) + delta.
- **D4** schedule claim mismatch — measured: 24→12 (−50% steady state, hysteresis,
  converges ≈ 18 s), docs claimed −55 %. FIXED: convergence assertion 12 ± 1 +
  stability + doc corrected.
- **D5** save versioning — was already v2+migration in v2.0.01; now reshaped to
  `migrate(data, from_version)` chain API + guarded round-trip.
- **D8** no CI — FIXED: tools/ci.sh (6 suites, error/leak gates, CI_RESULT line).
- **Structural risks (open, phase-planned)**: world_builder monolith; no streaming;
  flat terrain; no navmesh; no missions; no water physics; 3,538 individual meshes
  (0 MultiMesh); GPU metrics unmeasured (headless cannot render).

## 4. Incomplete systems (honest)
boats/aircraft/motorcycle, missions, navmesh pathfinding, terrain heightfield,
streaming, weapon wheel/inventory UI, ambient audio zones, on-GPU profiling.

## 5. Dependency notes
world_data keys = public contract (16 keys) — streaming/decomposition must keep them
byte-stable (diff test planned in Phase 2 of the directive). Save schema changes must
append to migrate(). Input map keys are referenced by name across suites.

## Phase-progress addendum (v2.0.10)
Program phases LOCKED this run: 0 (stabilize: D2/D3/D4 + determinism seed 19041604
+ ci.sh), 3 (perf baseline + probe), 4 (district decomposition + world_data
contract gate), 5 (typed .tres + drift gate), 6 (tile streaming), 7 (terrain
service, flat-first), 8 (8-class road hierarchy), 9 (streetscape kits),
10 (navmesh + NavigationAgent3D + NPC classes 4-5/5 + off-mesh links).
Next in order: 11 district expansion, 12 building kit, 13 interiors depth,
14 rooftops, 15 InteractionComponent, 16 NPC life sim. Standing finds carried:
Airport sustained physics 9-19 ms (investigate at streaming/physics work),
Industrial-night logic 7.5 ms (sim-tier phase), band-flip hitch (phase 40),
build-ms still NOT MEASURED, GPU rows NOT MEASURED (windowed run pending).
