# PERFORMANCE BUDGET — ISLAND STRIKE v2.0
Target: RTX 3050 4 GB / 16 GB / 1080p / Medium-High.

## Headless-measurable (this repo's CI suites)
| Metric | Budget | Measured @ v2.0.01 | Status |
|---|---|---|---|
| Script errors across 6 suites | 0 | 0 | OK |
| STRESS (spawn everything, 40 s) | PASS | PASS | OK |
| Total scene nodes (frame 60) | < 8k | ≈5.1k | OK |
| MeshInstance3D | < 5k | ≈3.2k | OK |
| Rigged NPC anim rate | 60 Hz near / 15 mid / 0 far | enforced in person.gd | OK |
| Far prop culling | visibility_range on all far decor | enforced in builders | OK |
| Lights (non-night-gated) | sun only + gated lamps | 1 + gated | OK |
| Smoke suite wall time (headless) | < 10 s | ≈8 s | OK |

## GPU frame budget (requires on-GPU capture — NOT measured headless)
| Metric | Budget | How to capture |
|---|---|---|
| Frame time @ 1080p downtown | ≤ 16.6 ms | your video / F1 overlay |
| Draw calls | < 900 | Godot profiler |
| VRAM | < 3.0 GB | profiler / task manager |
| Worst case: downtown night + rain + heavy traffic | no collapse < 30 fps | stress scenario |
Rule: no optimization is "done" from intuition — a budget line above must move.
