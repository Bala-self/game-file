# ROUND 10 — ENVIRONMENT NEXT LEVEL PER SYSTEM (plan)
One concrete next-level upgrade per environment system. Visual-first:
world_data contract stays IDENTICAL (geometry/materials only, no data change,
no terrain activation — that stays a declared breaking change for later).
Each E#: implement -> smoke assert -> full CI PASS -> commit.

| # | System | Current level | Next level (this round) |
|---|--------|---------------|--------------------------|
| E1 | Ground | flat single-color grass slab | world-noise ShaderMaterial: two-tone grass + dry/dirt patches |
| E2 | Ocean | flat translucent plane | wave shader: GPU vertex bob, shore foam band, boat wake particles |
| E3 | Sky | palette lerp only | procedural star cover texture, alpha = night factor |
| E4 | Weather surfaces | fog/sun/lightning states | wet roads: asphalt darkens, roughness drops, sheen when raining |
| E5 | Vegetation | hand-placed oaks/rocks | MultiMesh grass fields (park+farmland, 600) + beach palms; sway shader |
| E6 | Landmarks | static set | rotating ferris wheel (Beachfront) + blinking radio beacon |
| E7 | Park water | static lake | creek ribbon + waterfall particles into the lake |
| E8 | Road dressing | markings/signals/lamps | perimeter guardrails + night cat-eye studs (shared emissive) |

Connections: E1->env.gd ground, E2->water level+boats, E3->day/night factor,
E4->GameState.raining + shared road materials, E5->streamer registration +
MultiMesh budget (<800 meshes), E6->Beachfront/Industrial dressing, E7->park
lake geometry, E8->perimeter ROADS + night lamp cycle.
