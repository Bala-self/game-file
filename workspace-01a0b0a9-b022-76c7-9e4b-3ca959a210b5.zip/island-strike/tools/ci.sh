#!/usr/bin/env bash
# ISLAND STRIKE CI gate (Phase 0, D8 + D1 gate)
# Runs the full battery; fails on: non-zero suite exit, any ERROR:/SCRIPT ERROR:
# line (single documented allowlist: the intentional corrupt-save JSON parse),
# any leak warning, or a missing expected RESULT line.
#
# Leak classification (upstream godotengine/godot#95484, closed as not planned):
# a stream playing at engine teardown is reported as leaked because the audio
# server has no next mix iteration to release it. All game-side contributors
# are fixed (native WAV loops replace finished->play replay lambdas; root-wide
# pre-quit sweep + GameState.audio_shutdown latch; car _exit_tree stops).
# A rare residual single-playback race remains upstream. Policy: if a suite's
# stderr shows a leak summary, the suite is re-run ONCE with --verbose and the
# leaked identities are classified:
#   - AudioStreamWAV / AudioStreamPlaybackWAV  -> documented upstream, allowed
#   - anything else (Node, other Resources)    -> FAIL
set -u
GODOT_BIN="${GODOT_BIN:-/tmp/Godot_v4.5-stable_linux.x86_64}"
cd "$(dirname "$0")/.."

declare -A EXPECT=(
  [loadcheck]="ok: res://scripts/game/game.gd"
  [walk_test]="WALK_RESULT: ALL PASS"
  [character_test]="CHARACTER_RESULT: ALL PASS"
  [smoke_test]="SMOKE_RESULT: ALL PASS"
  [stress_main]="STRESS_RESULT: PASS"
  [menu_test]="MENU_RESULT: OK"
  [world_data_test]="WORLD_DATA_RESULT: IDENTICAL"
  [terrain_test]="TERRAIN_RESULT: ALL PASS"
)
FAIL=0
for s in loadcheck walk_test character_test smoke_test stress_main menu_test world_data_test terrain_test; do
  timeout 300 "$GODOT_BIN" --headless --path . -s "res://tests/$s.gd" \
      >/tmp/ci_$s.out 2>/tmp/ci_$s.err
  CODE=$?
  echo "== $s (exit $CODE)"
  if [ $CODE -ne 0 ]; then echo "   suite exited non-zero"; FAIL=1; fi
  if ! grep -qF "${EXPECT[$s]}" /tmp/ci_$s.out; then
    echo "   missing expected result: ${EXPECT[$s]}"; FAIL=1
  fi
  # D1 gate: any script/engine error (allowlist: intentional corrupt-save test;
  # leak summaries are owned by the leak gate below, not the error gate)
  ERRS=$(grep -E "^ERROR:|^SCRIPT ERROR:" /tmp/ci_$s.err \
        | grep -v "Parse JSON failed" \
        | grep -v "resources still in use at exit" | head -3)
  if [ -n "$ERRS" ]; then
    echo "   error gate:"; echo "$ERRS"; FAIL=1
  fi
  # Leak gate with upstream classification (see header)
  if grep -qE "ObjectDB instances leaked|resources still in use" /tmp/ci_$s.err; then
    timeout 300 "$GODOT_BIN" --headless --verbose --path . -s "res://tests/$s.gd" \
        >/dev/null 2>/tmp/ci_${s}_verbose.err
    BAD=$(grep -E "^Leaked instance:|^Resource still in use:" /tmp/ci_${s}_verbose.err \
          | grep -vE "AudioStreamWAV|AudioStreamPlaybackWAV" | head -3)
    NAUD=$(grep -cE "^Leaked instance:" /tmp/ci_${s}_verbose.err)
    if [ -n "$BAD" ]; then
      echo "   leak gate (non-audio, actionable):"; echo "$BAD"; FAIL=1
    elif [ "$NAUD" -gt 0 ]; then
      echo "   leak gate: upstream #95484 audio teardown objects only ($NAUD) — allowed per policy"
    else
      echo "   leak gate: summary-only; verbose re-run did not reproduce (timing-masked upstream #95484 race) — allowed per policy"
    fi
  fi
done

# Round 11 perf gate (Phase-3 truth loop made permanent): the perf probe must
# run clean AND meet the settled budgets. Gates are absolute-bounds:
#   - no district row over 9.0 ms avg physics (measured worst settled: ~6.4)
#   - global worst frame under 13.5 ms (budget 16.6; known one-frame cost:
#     the event director's spawn frame measures ~12 ms and is timer-driven,
#     not district-driven — settled district worst is ~7 ms)
#   - probe completes (PERF_RESULT: DONE)
if [ $FAIL -eq 0 ]; then
  timeout 300 "$GODOT_BIN" --headless --path . -s res://tools/perf_probe.gd \
      >/tmp/ci_perf.out 2>/tmp/ci_perf.err
  PC=$?
  echo "== perf_probe (exit $PC)"
  if [ $PC -ne 0 ] || ! grep -q "PERF_RESULT: DONE" /tmp/ci_perf.out; then
    echo "   perf probe did not complete"; FAIL=1
  fi
  BADROW=$(grep -E "^PERF\|" /tmp/ci_perf.out | awk -F'phys ' '{split($2,a," "); if (a[1]+0 > 9.0) print}' | head -2)
  if [ -n "$BADROW" ]; then
    echo "   perf gate: physics row over 9.0 ms avg:"; echo "$BADROW"; FAIL=1
  fi
  WORST=$(grep -oE "worst_frame=[^ ]+ [0-9.]+ ms" /tmp/ci_perf.out | grep -oE "[0-9.]+ ms" | grep -oE "[0-9.]+")
  if [ -z "$WORST" ]; then
    echo "   perf gate: no PERF_SUMMARY worst_frame"; FAIL=1
  elif awk "BEGIN{exit !($WORST >= 13.5)}"; then
    echo "   perf gate: worst frame $WORST ms >= 13.5"; FAIL=1
  else
    echo "   perf gate: worst frame $WORST ms < 13.5 (settled budgets met)"
  fi
fi
if [ $FAIL -eq 0 ]; then echo "CI_RESULT: PASS"; else echo "CI_RESULT: FAIL"; fi
exit $FAIL
