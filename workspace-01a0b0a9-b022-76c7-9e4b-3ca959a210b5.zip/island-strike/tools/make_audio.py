#!/usr/bin/env python3
"""Generates all game audio as small WAV files (stdlib only, deterministic)."""
import math
import os
import random
import struct
import wave

SR = 22050
OUT = os.path.join(os.path.dirname(__file__), "..", "assets", "audio")


def write_wav(name, samples):
    os.makedirs(OUT, exist_ok=True)
    path = os.path.join(OUT, name)
    with wave.open(path, "w") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        frames = b"".join(
            struct.pack("<h", int(max(-1.0, min(1.0, s)) * 32767)) for s in samples)
        w.writeframes(frames)
    print(f"wrote {path} ({len(samples)/SR:.2f}s)")


def silence(dur):
    return [0.0] * int(SR * dur)


def shoot():
    n = int(SR * 0.16)
    out = []
    random.seed(7)
    for i in range(n):
        t = i / SR
        env = math.exp(-t * 28)
        noise = (random.random() * 2 - 1)
        thump = math.sin(2 * math.pi * 130 * t) * math.exp(-t * 35)
        out.append((noise * 0.7 + thump * 0.6) * env)
    return out


def pickup():
    out = []
    for i in range(int(SR * 0.2)):
        t = i / SR
        f = 660 + 500 * min(1.0, t / 0.12)
        out.append(math.sin(2 * math.pi * f * t) * math.exp(-t * 14) * 0.5)
    return out


def click():
    return [math.sin(2 * math.pi * 1150 * i / SR) * math.exp(-(i / SR) * 90) * 0.5
            for i in range(int(SR * 0.05))]


def reload():
    out = silence(0.05)
    out += [math.sin(2 * math.pi * 700 * i / SR) * math.exp(-(i / SR) * 80) * 0.5
            for i in range(int(SR * 0.06))]
    out += silence(0.16)
    out += [math.sin(2 * math.pi * 900 * i / SR) * math.exp(-(i / SR) * 80) * 0.5
            for i in range(int(SR * 0.06))]
    return out


def engine():
    # loopable hum: integer cycles per buffer so ends match
    n = SR  # 1.0s
    out = []
    for i in range(n):
        t = i / SR
        v = (math.sin(2 * math.pi * 72 * t) * 0.5
             + math.sin(2 * math.pi * 144 * t + 0.7) * 0.25
             + math.sin(2 * math.pi * 216 * t + 1.9) * 0.12)
        out.append(v * 0.55)
    return out


def ocean():
    n = SR * 2
    random.seed(3)
    prev = 0.0
    out = []
    for i in range(n):
        t = i / SR
        raw = random.random() * 2 - 1
        prev = prev * 0.97 + raw * 0.03  # low-pass
        swell = math.sin(math.pi * t / 2.0) ** 2  # zero at both ends => clean loop
        out.append(prev * 4.0 * swell * 0.8)
    return out


def rain():
    n = int(SR * 1.5)
    random.seed(11)
    prev = 0.0
    out = []
    for i in range(n):
        raw = random.random() * 2 - 1
        prev = prev * 0.9 + raw * 0.1
        out.append(prev * 1.6)
    return out


def explode():
    n = int(SR * 0.8)
    random.seed(5)
    prev = 0.0
    out = []
    for i in range(n):
        t = i / SR
        raw = random.random() * 2 - 1
        prev = prev * 0.94 + raw * 0.06
        env = math.exp(-t * 5.5)
        sub = math.sin(2 * math.pi * 55 * t) * math.exp(-t * 7)
        out.append((prev * 6.0 + sub * 0.9) * env)
    return out



def thunder():
    n = int(SR * 2.2)
    random.seed(23)
    prev = 0.0
    out = []
    for i in range(n):
        t = i / SR
        raw = random.random() * 2 - 1
        prev = prev * 0.985 + raw * 0.015
        rumble = math.sin(2 * math.pi * 48 * t) * math.exp(-t * 1.6)
        crack = (random.random() * 2 - 1) * math.exp(-t * 22) * 0.8
        out.append(prev * 5.0 + rumble * 0.6 + crack)
    return out


def horn():
    n = int(SR * 0.55)
    out = []
    for i in range(n):
        t = i / SR
        env = min(1.0, t * 30) * min(1.0, (0.55 - t) * 12)
        v = math.sin(2 * math.pi * 400 * t) + math.sin(2 * math.pi * 505 * t) * 0.7
        out.append(v * 0.32 * env)
    return out


def siren():
    n = int(SR * 1.6)
    out = []
    for i in range(n):
        t = i / SR
        f = 620 + 260 * math.sin(2 * math.pi * 0.9 * t)
        env = min(1.0, t * 8) * min(1.0, (1.6 - t) * 4)
        out.append(math.sin(2 * math.pi * f * t) * 0.30 * env)
    return out


if __name__ == "__main__":
    write_wav("shoot.wav", shoot())
    write_wav("pickup.wav", pickup())
    write_wav("click.wav", click())
    write_wav("reload.wav", reload())
    write_wav("engine.wav", engine())
    write_wav("ocean.wav", ocean())
    write_wav("rain.wav", rain())
    write_wav("explode.wav", explode())
    write_wav("thunder.wav", thunder())
    write_wav("horn.wav", horn())
    write_wav("siren.wav", siren())
    print("all audio generated")
