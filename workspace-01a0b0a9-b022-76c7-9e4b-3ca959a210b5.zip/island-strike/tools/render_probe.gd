extends SceneTree
## Round 11: rendered QA probe — real rendering pipeline (GL Compatibility,
## llvmpipe in CI): shader-compile verification, draw calls, VRAM, screenshots
## per district x day/night. Run under Xvfb with --rendering-method
## gl_compatibility. GPU *performance* on target hardware stays UNMEASURED.
var game: Node
var f := 0
var si := -1
var stations: Array = [
	["downtown", Vector3(-165, 0.9, -240), 12.0],
	["park_creek", Vector3(-30, 0.9, 20), 12.0],
	["airport", Vector3(345, 0.9, -280), 12.0],
	["beach_ferris", Vector3(-505, 0.9, -40), 12.0],
	["industrial_night", Vector3(295, 0.9, 180), 23.0],
	["marina", Vector3(-550, 0.9, 200), 12.0],
]


func _initialize() -> void:
	game = load("res://scenes/game/game.tscn").instantiate()
	root.add_child(game)
	current_scene = game
	Engine.max_fps = 60
	root.get_node("GameState").day_time = 12.0


func _process(_d: float) -> bool:
	f += 1
	if f == 150 and si == -1:
		si = 0
		f = 0
		game.player.global_position = stations[0][1]
		root.get_node("GameState").day_time = stations[0][2]
		return false
	if si >= 0 and f == 90:
		var img := root.get_viewport().get_texture().get_image()
		img.save_png("res://tools/qa_%s.png" % stations[si][0])
		var dc: int = Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME)
		var vram: float = Performance.get_monitor(Performance.RENDER_VIDEO_MEM_USED) / 1048576.0
		var fp: float = Performance.get_monitor(Performance.TIME_FPS)
		print("QA|%s|draw_calls=%d|vram_mb=%.0f|fps=%.0f" % [stations[si][0], dc, vram, fp])
		si += 1
		f = 0
		if si < stations.size():
			game.player.global_position = stations[si][1]
			root.get_node("GameState").day_time = stations[si][2]
		else:
			quit(0)
			return true
	return false
