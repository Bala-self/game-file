extends SceneTree
## Regenerates assets/data/world.tres from the kit constants.
## Run after ANY constant change; ci.sh + tests/world_data_test.gd fail if the
## committed .tres drifts from the constants.
## Run: godot --headless --path . -s res://tools/gen_world_tres.gd

var game: Node
var f := 0


func _initialize() -> void:
	game = load("res://scenes/game/game.tscn").instantiate()
	root.add_child(game)
	current_scene = game


func _process(_d: float) -> bool:
	f += 1
	if f != 40:
		return false
	var wd: Dictionary = root.get_node("GameState").world_data
	var res := WorldDataRes.new()
	res.from_dict(wd)
	var err := ResourceSaver.save(res, "res://assets/data/world.tres")
	if err != OK:
		print("GEN_RESULT: FAIL (save error %d)" % err)
		quit(1)
		return false
	print("GEN_RESULT: OK assets/data/world.tres (%d keys)" % wd.size())
	quit(0)
	return false
