extends SceneTree
## PERFORMANCE_BASELINE probe (Phase 3).
## Teleports the player to every registered district center and samples
## Performance monitors under day/night x clear/rain. Headless mode measures
## CPU-side truth (frame process time, physics time, counts, memory); GPU
## rows (draw calls, VRAM, render time) require a windowed run on target
## hardware and are reported NOT MEASURED here.
## Run: godot --headless --path . -s res://tools/perf_probe.gd

var game: Node
var gs: Node
var f := 0
var stations: Array = []
var si := -1
var cond := 0  # 0 day/clear, 1 night/clear, 2 day/rain
var samples: Array = []
var rows: Array = []


func _initialize() -> void:
	game = load("res://scenes/game/game.tscn").instantiate()
	root.add_child(game)
	current_scene = game
	Engine.max_fps = 60  # realistic pacing for wall-clock-adjacent sampling
	gs = root.get_node("GameState")


func _sample_now(spike := false) -> void:
	samples.append({
		"proc_us": Performance.get_monitor(Performance.TIME_PROCESS),
		"phys_us": Performance.get_monitor(Performance.TIME_PHYSICS_PROCESS),
		"nodes": Performance.get_monitor(Performance.OBJECT_NODE_COUNT),
		"mem": Performance.get_monitor(Performance.MEMORY_STATIC),
		"spike_us": Performance.get_monitor(Performance.TIME_PHYSICS_PROCESS) if spike else 0.0,
	})


func _finish_station() -> void:
	var st: Dictionary = stations[si]
	var n := samples.size()
	if n == 0:
		return
	var proc_max := 0.0
	var proc_sum := 0.0
	var phys_max := 0.0
	var phys_sum := 0.0
	var tp_spike := 0.0
	for s: Dictionary in samples:
		proc_max = maxf(proc_max, s.proc_us)
		proc_sum += s.proc_us
		phys_max = maxf(phys_max, s.phys_us)
		phys_sum += s.phys_us
		tp_spike = maxf(tp_spike, s.get("spike_us", 0.0))
	var conds := ["day/clear", "night/clear", "day/rain"]
	rows.append({
		"station": st.name, "cond": conds[cond],
		"proc_avg_ms": proc_sum / n * 1000.0, "proc_max_ms": proc_max * 1000.0,
		"phys_avg_ms": phys_sum / n * 1000.0, "phys_max_ms": phys_max * 1000.0,
		"nodes": samples[n - 1].nodes, "mem_mb": samples[n - 1].mem / 1048576.0,
		"tp_spike_ms": tp_spike * 1000.0,
	})
	print("PERF|%-14s|%10s|proc %5.2f/%5.2f ms|phys %5.2f/%5.2f ms|tp %5.1f ms|nodes %d|mem %.0f MB"
			% [st.name, conds[cond], proc_sum / n * 1000.0, proc_max * 1000.0,
			phys_sum / n * 1000.0, phys_max * 1000.0, tp_spike * 1000.0,
			samples[n - 1].nodes, samples[n - 1].mem / 1048576.0])


func _next() -> void:
	samples = []
	si += 1
	cond = 0
	if si >= stations.size():
		var worst := 0.0
		var wname := ""
		for r: Dictionary in rows:
			if r.proc_max_ms > worst:
				worst = r.proc_max_ms
				wname = "%s/%s" % [r.station, r.cond]
		print("PERF_SUMMARY: rows=%d worst_frame=%s %.2f ms (budget 16.6)" % [rows.size(), wname, worst])
		print("PERF_RESULT: DONE (GPU rows NOT MEASURED — headless cannot render)")
		quit(0)
		return
	var st: Dictionary = stations[si]
	game.player.global_position = st.pos
	game.player.velocity = Vector3.ZERO
	# Round 11: arrival settle — the flip frame + queue drain are not
	# district cost; sampling starts after in_phase == 30 anyway (below).


func _collect_stations() -> void:
	var wr: Dictionary = gs.world_data.get("districts", {})
	for k: String in wr.keys():
		var r: Rect2 = wr[k]
		stations.append({"name": k, "pos": Vector3(r.position.x + r.size.x * 0.5, 0.8,
				r.position.y + r.size.y * 0.5)})
	stations.sort_custom(func(a, b) -> bool: return a.name < b.name)
	print("PERF: %d district stations" % stations.size())


func _apply_cond() -> void:
	if cond == 1:
		gs.day_time = 23.0
	else:
		gs.day_time = 12.0
	if cond == 2:
		var ws: Node = game.get_node_or_null("WorldSim")
		if ws:
			ws.set_state("RAIN")
		else:
			gs.raining = true


func _process(_d: float) -> bool:
	f += 1
	# Round 11: settle 300 frames after load — the first-touch physics burst
	# (engine registers the whole world) must not pollute district rows.
	if f < 300:
		return false
	if si < 0:
		_collect_stations()
		_next()
		return false
	var in_phase := f % 100
	if in_phase == 30:
		_apply_cond()
	elif in_phase in range(31, 60):
		_sample_now(true)   # teleport/settle window — spike metric only
	elif in_phase >= 60:
		_sample_now()       # sustained window (30+ frames after teleport)
	if in_phase == 99:
		_finish_station()
		cond += 1
		if cond > 2:
			_next()
	return false
