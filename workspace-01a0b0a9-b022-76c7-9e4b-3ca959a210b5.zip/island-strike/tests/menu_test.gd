extends SceneTree
## Menu load test: instantiate main menu, let it run 180 frames, report.
func _initialize() -> void:
	var menu: Node = load("res://scenes/main/main_menu.tscn").instantiate()
	root.add_child(menu)
	current_scene = menu
	var tester := Node.new()
	tester.set_script(load("res://tests/menu_node.gd"))
	root.add_child(tester)
