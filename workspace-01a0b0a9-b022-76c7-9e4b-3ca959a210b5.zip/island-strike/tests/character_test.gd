extends SceneTree
func _initialize() -> void:
	var game: Node = load("res://scenes/game/game.tscn").instantiate()
	root.add_child(game)
	current_scene = game
	var n := Node.new()
	n.set_script(load("res://tests/character_node.gd"))
	root.add_child(n)
