extends SceneTree
## P0 CONTROLLER REGRESSION — Part 10/11 walk-straight + diagonal tests.
func _initialize() -> void:
	var game: Node = load("res://scenes/game/game.tscn").instantiate()
	root.add_child(game)
	current_scene = game
	var tester := Node.new()
	tester.set_script(load("res://tests/walk_node.gd"))
	root.add_child(tester)
