extends Node
## 20s uncapped-FPS stress: raises wanted to 4, forces rain, verifies actors.
var game: Node3D

## D2: stop every audio stream ~60 frames before teardown (mix-settle window;
## stop-at-teardown can race the audio thread and leak the playback object).
func _prequit_audio() -> void:
	var g := get_tree().current_scene
	if g and g.has_method("_stop_all_audio"):
		g._stop_all_audio()

func _ready() -> void:
	game = get_tree().current_scene
	var t := Timer.new()
	t.wait_time = 20.0
	t.one_shot = true
	t.timeout.connect(_phase2)
	add_child(t)
	t.start()
	print("STRESS: running 20s (uncapped fps)...")

func _phase2() -> void:
	GameState.set_wanted(4)
	GameState.set_raining(true)
	var t2 := Timer.new()
	t2.wait_time = 5.0
	t2.one_shot = true
	t2.timeout.connect(_finish)
	add_child(t2)
	t2.start()

func _finish() -> void:
	var cops := get_tree().get_nodes_in_group("police").size()
	var civs := get_tree().get_nodes_in_group("civilians").size()
	var cars := get_tree().get_nodes_in_group("cars").size()
	print("STRESS: done cops=%d civs=%d cars=%d nodes=%d wanted=%d rain=%s" %
			[cops, civs, cars, get_tree().get_node_count(), GameState.wanted, GameState.raining])
	if cops >= 4 and civs >= 10 and cars >= 18:
		print("STRESS_RESULT: PASS")
		_prequit_audio()
		get_tree().quit(0)
	else:
		print("STRESS_RESULT: FAIL")
		_prequit_audio()
		get_tree().quit(1)
