extends Node
var frames := 0
## D2: stop every audio stream ~60 frames before teardown (mix-settle window;
## stop-at-teardown can race the audio thread and leak the playback object).
func _prequit_audio() -> void:
	var g := get_tree().current_scene
	if g and g.has_method("_stop_all_audio"):
		g._stop_all_audio()

func _process(_d: float) -> void:
	frames += 1
	if frames == 180:
		var has_buttons := false
		for c in get_tree().current_scene.get_children():
			if c is VBoxContainer:
				has_buttons = true
		if has_buttons:
			print("MENU_RESULT: OK (menu built, buttons present)")
			_prequit_audio()
			get_tree().quit(0)
		else:
			print("MENU_RESULT: FAIL (no UI found)")
			_prequit_audio()
			get_tree().quit(1)
