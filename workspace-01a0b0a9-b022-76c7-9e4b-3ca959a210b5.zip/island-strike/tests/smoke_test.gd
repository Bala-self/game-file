extends SceneTree
## Headless smoke test entry point.
## Run:  godot --headless --path . -s res://tests/smoke_test.gd
## Instantiates the real game scene and hands control to smoke_node.gd.


func _initialize() -> void:
	var game: Node = load("res://scenes/game/game.tscn").instantiate()
	root.add_child(game)
	current_scene = game
	var tester := Node.new()
	tester.set_script(load("res://tests/smoke_node.gd"))
	root.add_child(tester)
	# Headless CI pacing: cap fps at 60 so process frames track physics ticks
	# (uncapped headless frames starve physics — speed assertions measured in
	# frame windows saw 3-30 physics ticks run-to-run). Real-time ~18 s.
	Engine.max_fps = 60
	print("SMOKE: initialized")
