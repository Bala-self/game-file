extends SceneTree
## Headless stress entry: adds game + tester node, runs 20s uncapped.
func _initialize() -> void:
	var game: Node = load("res://scenes/game/game.tscn").instantiate()
	root.add_child(game)
	current_scene = game
	var tester := Node.new()
	tester.set_script(load("res://tests/stress_node.gd"))
	root.add_child(tester)
