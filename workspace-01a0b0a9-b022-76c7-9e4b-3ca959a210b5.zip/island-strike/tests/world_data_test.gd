extends SceneTree
## world_data contract diff-test (Phase 4 gate).
## world_data is a PUBLIC CONTRACT: any key, type, count or value change is
## breaking and must be declared in the release report. This test serializes
## the post-build world_data canonically (sorted dict keys, order-significant
## arrays, floats at 1e-4) and compares against tests/world_data_baseline.txt.
## First run: godot --headless --path . -s res://tests/world_data_test.gd -- --generate
## Every run after: exit 0 + IDENTICAL, or exit 1 + DIFF.

var game: Node
var f := 0


func _initialize() -> void:
	game = load("res://scenes/game/game.tscn").instantiate()
	root.add_child(game)
	current_scene = game


func _canon(v: Variant, indent: String) -> String:
	if v is Dictionary:
		var lines := []
		var ks: Array = v.keys()
		ks.sort()
		for k: String in ks:
			lines.append("%s%s:\n" % [indent, k] + _canon(v[k], indent + "  "))
		return "".join(lines)
	elif v is Array:
		var lines := []
		for i in range(v.size()):
			lines.append("%s[%d]:\n" % [indent, i] + _canon(v[i], indent + "  "))
		return "".join(lines)
	elif v is float:
		return "%s%.4f\n" % [indent, v]
	elif v is Vector2:
		return "%sV2(%.4f, %.4f)\n" % [indent, v.x, v.y]
	elif v is Vector3:
		return "%sV3(%.4f, %.4f, %.4f)\n" % [indent, v.x, v.y, v.z]
	elif v is Rect2:
		return "%sR2(%.4f, %.4f, %.4f, %.4f)\n" % [indent, v.position.x, v.position.y,
				v.size.x, v.size.y]
	elif v is Color:
		return "%sC(%.4f, %.4f, %.4f, %.4f)\n" % [indent, v.r, v.g, v.b, v.a]
	return "%s%s\n" % [indent, str(v)]


func _process(_d: float) -> bool:
	f += 1
	if f != 40:
		return false
	var gs := root.get_node("GameState")
	var text := _canon(gs.world_data, "")
	var path := "res://tests/world_data_baseline.txt"
	var generate := "--generate" in OS.get_cmdline_user_args()
	if generate or not FileAccess.file_exists(path):
		var fw := FileAccess.open(path, FileAccess.WRITE)
		fw.store_string(text)
		fw.close()
		print("WORLD_DATA_RESULT: GENERATED baseline (%d bytes)" % text.length())
		quit(0)
		return false
	# Phase 5 gate: committed typed resource must match the procedural data
	var res := load("res://assets/data/world.tres") as WorldDataRes
	if res == null:
		print("WORLD_DATA_RESULT: TRES_MISSING — regen with tools/gen_world_tres.gd")
		quit(1)
		return false
	var tres_text := _canon(res.to_dict(), "")
	if tres_text != text:
		print("WORLD_DATA_RESULT: TRES_DRIFT — assets/data/world.tres differs from constants; regen")
		quit(1)
		return false
	var expected := FileAccess.open(path, FileAccess.READ).get_as_text()
	if expected == text:
		print("WORLD_DATA_RESULT: IDENTICAL (%d lines, tres in sync)" % text.count("\n"))
		quit(0)
		return false
	# diff report: first differing lines
	var el := expected.split("\n")
	var tl := text.split("\n")
	var shown := 0
	for i in range(maxi(el.size(), tl.size())):
		var a: String = el[i] if i < el.size() else "<eof>"
		var b: String = tl[i] if i < tl.size() else "<eof>"
		if a != b:
			print("WORLD_DATA_DIFF line %d:\n  was: %s\n  now: %s" % [i + 1, a, b])
			shown += 1
			if shown >= 12:
				break
	print("WORLD_DATA_RESULT: DIFF — world_data contract changed; declare breaking in release report")
	quit(1)
	return false
