extends Node
## Automated GTA-style movement QA:
##  1) camera rig is decoupled from body rotation
##  2) W walks straight along camera-forward (4 headings)
##  3) diagonals are normalized (no speed boost)
##  4) spring arm configured to never clip the player / cars

var frames := 0
var game: Node3D
var phase := 0
var start_pos := Vector3.ZERO
var fails := 0


## D2: stop every audio stream ~60 frames before teardown (mix-settle window;
## stop-at-teardown can race the audio thread and leak the playback object).
func _prequit_audio() -> void:
	var g := get_tree().current_scene
	if g and g.has_method("_stop_all_audio"):
		g._stop_all_audio()

func _ready() -> void:
	game = get_tree().current_scene


func _begin_phase(p: int) -> void:
	var pl: CharacterBody3D = game.player
	# flat open sand area, far from roads/buildings
	pl.global_position = Vector3(-480, 1.2, -40)
	pl.velocity = Vector3.ZERO
	pl.yaw = [0.0, -PI / 2.0, PI, PI / 2.0][p]  # north, east, south, west
	start_pos = pl.global_position
	Input.action_press("move_forward")


func _physics_process(_delta: float) -> void:
	frames += 1
	match frames:
		30:
			var pl: CharacterBody3D = game.player
			_check(pl.cam_yaw.top_level, "camera rig is top-level (decoupled from body)")
			_check(pl.spring.collision_mask == 9, "spring collides with world+vehicles")
			_check(pl.spring.margin > 0.3, "spring margin configured (0.35)")
			_begin_phase(0)
		150:
			_straight_check("north", Vector3(0, 0, -1))
			_begin_phase(1)
		270:
			_straight_check("east", Vector3(1, 0, 0))
			_begin_phase(2)
		390:
			_straight_check("south", Vector3(0, 0, 1))
			_begin_phase(3)
		510:
			_straight_check("west", Vector3(-1, 0, 0))
			Input.action_release("move_forward")
			# diagonal test: W+A
			start_pos = game.player.global_position
			Input.action_press("move_left")
		570:
			var pl: CharacterBody3D = game.player
			var moved: Vector3 = pl.global_position - start_pos
			var diag_speed := Vector2(moved.x, moved.z).length() / 1.0  # m over 1s
			# straight phase covered ~12m in 2s => ~6 m/s; diagonal must be within 20%
			_check(absf(diag_speed - 6.0) < 1.5,
					"diagonal speed normalized (%.1f m/s vs ~6.0 straight)" % diag_speed)
			Input.action_release("move_left")
		575:
			# body must face its movement direction while moving diagonally
			var pl: CharacterBody3D = game.player
			var vel := Vector3(pl.velocity.x, 0, pl.velocity.z)
			if vel.length() > 1.0:
				var fwd := -pl.global_basis.z
				_check(fwd.normalized().dot(vel.normalized()) > 0.9,
						"body faces movement direction (dot=%.2f)" % fwd.normalized().dot(vel.normalized()))
			else:
				_check(false, "body heading check: player not moving")
		590:
			if fails == 0:
				print("WALK_RESULT: ALL PASS")
				_prequit_audio()
				get_tree().quit(0)
			else:
				print("WALK_RESULT: FAIL (%d)" % fails)
				_prequit_audio()
				get_tree().quit(1)
	if frames > 700:
		print("WALK_RESULT: TIMEOUT")
		_prequit_audio()
		get_tree().quit(1)


func _straight_check(label: String, expected_dir: Vector3) -> void:
	var pl: CharacterBody3D = game.player
	var moved: Vector3 = pl.global_position - start_pos
	moved.y = 0
	var dist := moved.length()
	var straightness := 0.0
	if dist > 0.5:
		straightness = moved.normalized().dot(expected_dir)
	_check(dist > 5.0, "W moved player %s (%.1f m)" % [label, dist])
	_check(straightness > 0.985, "path straight %s (dot=%.3f)" % [label, straightness])


func _check(cond: bool, label: String) -> void:
	if cond:
		print("WALK PASS: " + label)
	else:
		fails += 1
		print("WALK FAIL: " + label)
