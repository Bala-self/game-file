extends Node
## Character system test: rig structure, proportions, outfits, weapon mount,
## procedural animations (walk/run/idle/crouch/aim/shoot/hit/jump), NPC reuse,
## outfit fix, death fall. CHARACTER_RESULT: ALL PASS | FAIL -> ...
## Runs on PHYSICS frames for determinism.
var f := 0
var game: Node
var fails: Array[String] = []

## D2: stop every audio stream ~60 frames before teardown (mix-settle window;
## stop-at-teardown can race the audio thread and leak the playback object).
func _prequit_audio() -> void:
	var g := get_tree().current_scene
	if g and g.has_method("_stop_all_audio"):
		g._stop_all_audio()

func _ready() -> void:
	game = get_tree().current_scene

func _check(ok: bool, label: String) -> void:
	if ok:
		print("CHAR PASS: " + label)
	else:
		fails.append(label)
		print("CHAR FAIL: " + label)

func _rig() -> Node3D:
	return game.player.rig

func _physics_process(_d: float) -> void:
	f += 1
	var p: CharacterBody3D = game.player
	# walk-cycle sampling window (every physics frame 71..99)
	if f >= 71 and f <= 99 and game.player.rig:
		var sw: float = game.player.rig.leg_l.rotation.x
		set_meta("sw_max", maxf(get_meta("sw_max", 0.0), absf(sw)))
		var sg := 1 if sw > 0.0 else -1
		if int(get_meta("sw_sign", 0)) == 0:
			set_meta("sw_sign", sg)
		elif sg != int(get_meta("sw_sign", 0)):
			set_meta("sw_sign", 2)
	match f:
		30:
			var rig := _rig()
			_check(rig != null, "player has CharacterRig")
			if rig:
				for pv in [rig.hips, rig.spine, rig.head_p, rig.arm_l, rig.arm_r,
						rig.leg_l, rig.leg_r, rig.fore_r, rig.weapon_mount]:
					_check(pv != null and is_instance_valid(pv), "rig pivot: " + pv.name)
				# proportions: head top ~1.78 m above feet
				var head_top: float = rig.head_p.global_position.y + 0.21
				_check(head_top > p.global_position.y + 1.68 and head_top < p.global_position.y + 1.9,
						"height ~1.78m (top %.2f)" % (head_top - p.global_position.y))
				# reference outfit: white tee
				var shirt: Color = rig.shirt_mat.albedo_color
				_check(shirt.r > 0.85 and shirt.g > 0.85, "white T-shirt material")
				_check(game.player.pistol.get_parent() == rig.weapon_mount,
						"pistol mounted in right hand")
			var civ: Node = null
			for c in get_tree().get_nodes_in_group("civilians"):
				if is_instance_valid(c) and c.health > 0:
					civ = c
					break
			_check(civ != null and civ.rig != null, "civilian reuses CharacterRig")
			# deterministic outfit checks: spawn gang + cop directly
			var gang: Node = load("res://scripts/npc/npc_gang.gd").create_in(
					Rect2(140, 60, 310, 240))
			gang.position = Vector3(-460, 0.4, 100)
			add_child(gang)
			set_meta("gang", gang)
			_check(gang.rig != null and gang.rig.shirt_mat.albedo_color.r > 0.3
					and gang.rig.shirt_mat.albedo_color.g < 0.25,
					"gang wears dark-red jacket (setup-order fix)")
			var cop: Node = load("res://scripts/npc/npc_police.gd").create_at(
					Vector3(-470, 0.4, 120))
			cop.position = Vector3(-470, 0.4, 120)
			add_child(cop)
			_check(cop.rig != null and cop.rig.shirt_mat.albedo_color.b > 0.35,
					"police wears navy uniform")
			# walk phase: flat sand, forward
			p.global_position = Vector3(-480, 1.2, -40)
			p.velocity = Vector3.ZERO
			Input.action_press("move_forward")
		70:
			set_meta("sw_max", 0.0)
			set_meta("sw_sign", 0)
		100:
			Input.action_release("move_forward")
			_check(get_meta("sw_max", 0.0) > 0.15 and int(get_meta("sw_sign", 0)) == 2,
					"walk cycle oscillates (max %.2f)" % get_meta("sw_max", 0.0))
			p.global_position = Vector3(-480, 1.2, -40)
			Input.action_press("move_forward")
			Input.action_press("sprint")
		150:
			Input.action_release("move_forward")
			Input.action_release("sprint")
			var lean: float = _rig().spine.rotation.x
			_check(lean < -0.08, "sprint forward lean (%.2f)" % lean)
		185:
			# idle: speed long since decayed, limbs settled to neutral
			_check(absf(_rig().leg_l.rotation.x) < 0.1,
					"idle settles limbs (%.2f)" % absf(_rig().leg_l.rotation.x))
			Input.action_press("crouch")
		230:
			Input.action_release("crouch")
			var hips: Node3D = _rig().hips
			_check(hips.position.y < 0.97 - 0.2, "crouch lowers hips (%.2f)" % hips.position.y)
			Input.action_press("aim")
		260:
			Input.action_release("aim")
			var arm_r: float = _rig().arm_r.rotation.x
			_check(arm_r > 1.2, "aim raises right arm forward (%.2f rad)" % arm_r)
			p.pistol.ammo["pistol"][0] = 12
			p.pistol.cooldown = 0.0
			p.pistol._fire()
		270:
			_check(p.pistol.vis_raise > 0.0 and _rig()._aim_w > 0.3,
					"firing raises arms (vis_raise %.2f)" % p.pistol.vis_raise)
			p.take_damage(5, Vector3(-999, 0, -999))
			_check(_rig().hit_t > 0.2, "hit-reaction pulse set")
			p.global_position = Vector3(-480, 1.2, -40)
			p.velocity = Vector3.ZERO
			Input.action_press("jump")
		272:
			Input.action_release("jump")
		282:
			_check(not p.is_on_floor() and _rig().leg_l.rotation.x > 0.3,
					"jump tuck pose airborne (leg %.2f)" % _rig().leg_l.rotation.x)
			# death fall (existing body-root tween + settled limbs)
			var victim: Node = null
			for c in get_tree().get_nodes_in_group("civilians"):
				if is_instance_valid(c) and c.health > 0:
					victim = c
					break
			if victim:
				set_meta("victim", victim)
				victim.take_damage(999, Vector3(-9999, 0, 0), null)
		330:
			var v: Node = get_meta("victim", null)
			# audit #31: death is a physics ragdoll now — rig hidden, rigid
			# limb parts spawned, body root left un-rotated
			var parts := 0
			if v != null:
				for r in v.find_children("Rag*", "RigidBody3D", true, false):
					parts += 1
			_check(v != null and v.state == "dead" and not v.rig.visible
					and parts >= 6, "death spawns physics ragdoll (%d parts)" % parts)
			if fails.is_empty():
				print("CHARACTER_RESULT: ALL PASS")
				_prequit_audio()
				get_tree().quit(0)
			else:
				print("CHARACTER_RESULT: FAIL -> " + "; ".join(fails))
				_prequit_audio()
				get_tree().quit(1)
	if f > 420:
		print("CHARACTER_RESULT: TIMEOUT")
		_prequit_audio()
		get_tree().quit(1)
