extends Node3D
## Player pistol: hitscan fire, recoil, reload, muzzle flash, tracer, audio.

## Weapon framework: per-weapon configs (feel), per-weapon ammo pools.
const WEAPONS := {
	"pistol": {
		"name": "Pistol", "damage": 26, "cooldown": 0.19, "mag": 12,
		"spread_hip": 0.03, "spread_aim": 0.012, "reload_time": 1.1, "auto": false,
		"price": 0,
	},
	"smg": {
		"name": "SMG", "damage": 14, "cooldown": 0.09, "mag": 30,
		"spread_hip": 0.045, "spread_aim": 0.02, "reload_time": 1.6, "auto": true,
		"price": 800,
	},
	"shotgun": {
		"name": "Shotgun", "damage": 60, "cooldown": 0.75, "mag": 6,
		"spread_hip": 0.11, "spread_aim": 0.07, "reload_time": 2.2, "auto": false,
		"price": 1200,
	},
}
const RANGE := 180.0

var weapon_id := "pistol"
var ammo := {"pistol": [12, 48], "smg": [30, 90], "shotgun": [6, 24]}
## Round 9 S4 weapon economy: the pistol is standard issue; SMG and shotgun
## are bought at the gun shop and persist through saves (SAVE_VERSION 3).
var owned_weapons := {"pistol": true}
var in_hand := false      # attached to the character rig's hand mount
var vis_raise := 0.0      # recent-fire arm-raise timer (visual only)
var cooldown := 0.0
var reloading := false
var _fire_prev := false
var player: CharacterBody3D
var muzzle: Node3D
var audio: AudioStreamPlayer3D


static func create(owner_player: CharacterBody3D) -> Node3D:
	var w := Node3D.new()
	w.name = "Pistol"
	w.set_script(load("res://scripts/weapons/pistol.gd"))
	w.set("player", owner_player)
	return w


func _cfg() -> Dictionary:
	return WEAPONS[weapon_id]


func mag_size() -> int:
	return int(_cfg()["mag"])


func mag() -> int:
	return ammo[weapon_id][0]


func reserve() -> int:
	return ammo[weapon_id][1]


func weapon_name() -> String:
	return str(_cfg()["name"])


## Switch weapons (audit #12/#30): dir +1 = next, -1 = previous (mouse wheel
## both directions). Wraps around the full framework list.
func cycle_weapon(dir := 1) -> void:
	if reloading:
		return
	var ids: Array = WEAPONS.keys()
	var i := ids.find(weapon_id)
	for step in range(1, ids.size() + 1):
		var cand: String = ids[wrapi(i + dir * step, 0, ids.size())]
		if owned_weapons.get(cand, false):
			weapon_id = cand
			_fire_prev = true  # require re-press after switch
			GameState.weapon_changed.emit(weapon_name())
			emit_ammo()
			GameState.notify("Equipped: " + weapon_name())
			return
	GameState.notify("No other weapons owned — visit the gun shop")


## Round 9 S4: first unowned weapon in framework order, or "" when all owned.
func next_unowned() -> String:
	for id: String in WEAPONS.keys():
		if not owned_weapons.get(id, false):
			return id
	return ""


## Round 9 S4: purchase at the gun shop. Refuses when broke or all owned.
func buy_next_weapon() -> bool:
	var id := next_unowned()
	if id == "":
		GameState.notify("You own every weapon")
		return false
	var price := int(WEAPONS[id]["price"])
	if not GameState.try_spend(price):
		GameState.notify("Not enough cash for the %s ($%d)" % [WEAPONS[id]["name"], price])
		return false
	owned_weapons[id] = true
	GameState.notify("%s purchased (-$%d)" % [WEAPONS[id]["name"], price])
	return true


func _ready() -> void:
	var body := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.08, 0.14, 0.34)
	bm.material = StandardMaterial3D.new()
	bm.material.albedo_color = Color(0.12, 0.12, 0.13)
	body.mesh = bm
	# hip position when free-floating; hand-relative when rig-mounted
	body.position = Vector3(0, -0.02, -0.09) if in_hand else Vector3(0.34, 1.25, -0.35)
	add_child(body)

	muzzle = Node3D.new()
	muzzle.position = Vector3(0, 0.03, -0.30) if in_hand else Vector3(0.34, 1.32, -0.55)
	add_child(muzzle)

	audio = AudioStreamPlayer3D.new()
	audio.stream = load("res://assets/audio/shoot.wav")
	audio.volume_db = -2.0
	audio.max_distance = 120.0
	add_child(audio)

	GameState.ammo_changed.emit(mag, reserve)


func _process(delta: float) -> void:
	cooldown -= delta
	vis_raise = maxf(0.0, vis_raise - delta)
	if reloading:
		return
	if player.driving_car != null or not player.input_enabled or player.health <= 0:
		_fire_prev = false
		return
	# Auto weapons fire while held; semi weapons on press edge.
	var fire_pressed := Input.is_action_pressed("fire")
	var trigger := fire_pressed if bool(_cfg()["auto"]) else (fire_pressed and not _fire_prev)
	if trigger and cooldown <= 0.0:
		if mag() <= 0:
			_start_reload()
		else:
			_fire()
	_fire_prev = fire_pressed
	if Input.is_action_just_pressed("reload") and mag() < mag_size() and reserve() > 0:
		_start_reload()


func _fire() -> void:
	ammo[weapon_id][0] -= 1
	cooldown = float(_cfg()["cooldown"])
	vis_raise = 0.35
	GameState.ammo_changed.emit(mag(), reserve())

	var cam := get_viewport().get_camera_3d()
	if cam == null:
		return
	var origin := cam.global_position
	var dir := -cam.global_basis.z
	# hip-fire spread, accurate when aiming
	var spread: float = float(_cfg()["spread_aim"] if player.aiming else _cfg()["spread_hip"])
	dir = (dir + Vector3(randf() - 0.5, randf() - 0.5, randf() - 0.5) * spread).normalized()

	var to := origin + dir * RANGE
	var q := PhysicsRayQueryParameters3D.create(origin, to, 1 | 4 | 8)
	q.exclude = [player.get_rid()]
	var hit := player.get_world_3d().direct_space_state.intersect_ray(q)

	var end := to
	if hit:
		end = hit["position"]
		var collider: Object = hit["collider"]
		if collider != null and collider.has_method("take_damage"):
			var dist := origin.distance_to(end)
			var falloff := clampf(1.0 - dist / RANGE, 0.4, 1.0)
			if weapon_id == "shotgun":
				falloff = clampf(1.0 - dist / 26.0, 0.15, 1.0)  # short-range weapon
			collider.take_damage(int(int(_cfg()["damage"]) * falloff),
					player.global_position, player)

	_spawn_tracer(muzzle.global_position, end)
	_spawn_flash()
	audio.pitch_scale = randf_range(0.92, 1.08)
	audio.play()
	GameState.vibrate(0.3, 0.5, 0.08)
	GameState.commit_crime(0, player.global_position)  # alert witnesses, no direct star
	# recoil
	player.pitch = clampf(player.pitch + 0.022, -1.1, 1.25)


func _spawn_tracer(from: Vector3, to: Vector3) -> void:
	var dist := from.distance_to(to)
	if dist < 0.5:
		return
	var tracer := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = 0.015
	mesh.bottom_radius = 0.015
	mesh.height = dist
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(1.0, 0.9, 0.4)
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mesh.material = m
	tracer.mesh = mesh
	get_tree().current_scene.add_child(tracer)
	tracer.global_position = (from + to) * 0.5
	tracer.look_at(to)
	tracer.rotate_object_local(Vector3(1, 0, 0), PI / 2)
	var tw := tracer.create_tween()
	tw.tween_property(tracer, "transparency", 1.0, 0.09)
	tw.tween_callback(tracer.queue_free)


func _spawn_flash() -> void:
	var flash := OmniLight3D.new()
	flash.light_color = Color(1.0, 0.8, 0.4)
	flash.omni_range = 7.0
	flash.light_energy = 3.5
	flash.position = muzzle.global_position
	get_tree().current_scene.add_child(flash)
	var tw := flash.create_tween()
	tw.tween_property(flash, "light_energy", 0.0, 0.06)
	tw.tween_callback(flash.queue_free)


func _start_reload() -> void:
	if reserve() <= 0:
		GameState.notify("Out of %s ammo — downed police drop ammo" % weapon_name())
		return
	reloading = true
	var snd := AudioStreamPlayer.new()
	snd.stream = load("res://assets/audio/reload.wav")
	add_child(snd)
	snd.play()
	var rt: float = float(_cfg()["reload_time"])
	var t := get_tree().create_timer(rt)
	t.timeout.connect(func() -> void:
		var need: int = mag_size() - mag()
		var take: int = mini(need, reserve())
		ammo[weapon_id][0] += take
		ammo[weapon_id][1] -= take
		reloading = false
		emit_ammo()
		snd.queue_free())


func add_ammo(n: int) -> void:
	ammo[weapon_id][1] += n
	emit_ammo()


func emit_ammo() -> void:
	GameState.ammo_changed.emit(mag(), reserve())
