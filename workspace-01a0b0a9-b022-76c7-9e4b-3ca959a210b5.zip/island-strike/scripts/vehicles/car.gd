extends CharacterBody3D
## Vehicle v2: class-based configs (sedan/sports/pickup/van/taxi/police),
## dynamic brake & reverse lights, body roll/pitch, horn, damage, smoke,
## explosion, traffic AI with traffic-light obedience and enter/exit.

const MAX_FWD := 26.0
const MAX_REV := 9.0
const ACCEL := 14.0
const BRAKE := 32.0
const COAST := 5.0

## Vehicle class configs: proportions + performance [top_speed_factor, accel_factor, size, color hint]
## Vehicle class configs: proportions + performance.
## steer: handling multiplier (sports agile, bus sluggish). Data-driven: add a
## row here and the class exists across spawning, handling, visuals.
const CLASSES := {
	"sedan": {"speed": 1.0, "accel": 1.0, "size": Vector3(2.0, 0.85, 4.4), "cab": 2.1, "steer": 1.0},
	"sports": {"speed": 1.25, "accel": 1.35, "size": Vector3(1.95, 0.7, 4.2), "cab": 1.8, "steer": 1.15},
	"pickup": {"speed": 0.9, "accel": 0.9, "size": Vector3(2.2, 1.0, 5.0), "cab": 1.7, "steer": 0.9},
	"van": {"speed": 0.85, "accel": 0.8, "size": Vector3(2.2, 1.5, 5.2), "cab": 3.2, "steer": 0.85},
	"taxi": {"speed": 1.0, "accel": 1.05, "size": Vector3(2.0, 0.85, 4.4), "cab": 2.1, "steer": 1.0},
	"suv": {"speed": 0.95, "accel": 0.9, "size": Vector3(2.15, 0.98, 4.9), "cab": 2.6, "steer": 0.9},
	"bus": {"speed": 0.7, "accel": 0.5, "size": Vector3(2.5, 1.05, 7.6), "cab": 3.4, "steer": 0.55},
	"police": {"speed": 1.2, "accel": 1.25, "size": Vector3(2.05, 0.9, 4.6), "cab": 2.2, "steer": 1.1},
	# motorcycle (Round 9 S1): narrow 2-wheel class — fast + agile, leans in turns
	"moto": {"speed": 1.45, "accel": 1.5, "size": Vector3(0.62, 0.7, 2.2), "cab": 0.0, "steer": 1.35},
}

var driver: CharacterBody3D = null
var traffic := false
var waypoints: Array = []
var wp_i := 0
var speed := 0.0
var steer := 0.0
var health := 100.0
var engine_health := 100.0   # component damage: power loss when worn
var wheel_health := 100.0    # component damage: steering degradation
var wrecked := false
var stuck_t := 0.0
## Round 9 S6: emergency dispatch — when set, the AI drives to this point
## (ambulance runs; game.gd owns spawn/despawn + cooldown).
var dispatch := false
var dispatch_target := Vector3.ZERO
var vehicle_class := "sedan"
var is_police_car := false
var _prev_throttle := 0.0
var _body_pitch := 0.0
var _body_roll := 0.0
var body_mat: StandardMaterial3D
var wheels: Array = []
var brake_lights: Array = []
var reverse_lights: Array = []
var lightbar: Array = []  # StandardMaterial3D (red/blue), flashed when wanted
var smoke: GPUParticles3D
var engine_audio: AudioStreamPlayer3D
var horn_audio: AudioStreamPlayer3D
var siren_audio: AudioStreamPlayer3D
var _collision_cd := 0.0
var _color := Color(0.7, 0.2, 0.2)


static func create(color: Color, v_class := "sedan") -> CharacterBody3D:
	var c := CharacterBody3D.new()
	c.name = "Car"
	c.collision_layer = 8
	c.collision_mask = 1 | 2 | 4 | 8
	c.set_script(load("res://scripts/vehicles/car.gd"))
	c.set("_color", color)
	c.set("vehicle_class", v_class)
	if v_class == "police":
		c.set("is_police_car", true)
	return c


static func create_random(rng: RandomNumberGenerator, pool: Array = []) -> CharacterBody3D:
	# police cruisers are dispatch-only, never random civilian traffic.
	# Optional district pool — the game side picks by spawn position.
	var classes: Array = pool if pool.size() > 0 \
			else ["sedan", "sports", "pickup", "van", "taxi", "suv"]
	var pick: String = classes[rng.randi() % classes.size()]
	var color := Color.from_hsv(rng.randf(), 0.55, rng.randf_range(0.5, 0.9))
	match pick:
		"taxi":
			color = Color(0.95, 0.8, 0.1)
		"van":
			color = Color(0.9, 0.9, 0.92)
		"police":
			color = Color(0.9, 0.9, 0.95)
	return create(color, pick)


func _ready() -> void:
	add_to_group("cars")
	var cfg: Dictionary = CLASSES.get(vehicle_class, CLASSES["sedan"])
	var size: Vector3 = cfg["size"]
	var cab_len: float = cfg["cab"]

	var col := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(size.x, size.y + 0.5, size.z)
	col.shape = box
	col.position.y = (size.y + 0.5) * 0.5
	add_child(col)

	if vehicle_class == "taxi":
		var sign := MeshInstance3D.new()
		var sm := BoxMesh.new()
		sm.size = Vector3(0.7, 0.22, 0.3)
		var smat := StandardMaterial3D.new()
		smat.albedo_color = Color(0.95, 0.8, 0.1)
		smat.emission_enabled = true
		smat.emission = Color(0.9, 0.7, 0.1)
		smat.emission_energy_multiplier = 0.8
		sm.material = smat
		sign.mesh = sm
		sign.position = Vector3(0, size.y + 0.55, 0.3)
		add_child(sign)
	elif vehicle_class == "bus":
		var board := MeshInstance3D.new()
		var bm2 := BoxMesh.new()
		bm2.size = Vector3(1.8, 0.35, 0.1)
		var bmat := StandardMaterial3D.new()
		bmat.albedo_color = Color(0.1, 0.1, 0.12)
		bmat.emission_enabled = true
		bmat.emission = Color(0.9, 0.5, 0.1)
		bmat.emission_energy_multiplier = 0.6
		bm2.material = bmat
		board.mesh = bm2
		board.position = Vector3(0, size.y + 0.45, -size.z / 2.0 + 0.1)
		add_child(board)

	body_mat = StandardMaterial3D.new()
	body_mat.albedo_color = _color
	body_mat.metallic = 0.4
	body_mat.roughness = 0.4

	if vehicle_class == "moto":
		# motorcycle silhouette (Round 9 S1): frame + tank + seat + handlebar
		var frame := MeshInstance3D.new()
		var fm := BoxMesh.new()
		fm.size = Vector3(0.3, 0.34, size.z * 0.78)
		fm.material = body_mat
		frame.mesh = fm
		frame.position.y = 0.62
		add_child(frame)
		var tank := MeshInstance3D.new()
		var tm := BoxMesh.new()
		tm.size = Vector3(0.34, 0.26, 0.55)
		tm.material = body_mat
		tank.mesh = tm
		tank.position = Vector3(0, 0.88, 0.28)
		add_child(tank)
		var seat := MeshInstance3D.new()
		var sm3 := BoxMesh.new()
		sm3.size = Vector3(0.3, 0.12, 0.7)
		sm3.material = StandardMaterial3D.new()
		sm3.material.albedo_color = Color(0.1, 0.1, 0.12)
		seat.mesh = sm3
		seat.position = Vector3(0, 0.86, -0.32)
		add_child(seat)
		var bar := MeshInstance3D.new()
		var bm3 := BoxMesh.new()
		bm3.size = Vector3(0.72, 0.06, 0.06)
		bm3.material = StandardMaterial3D.new()
		bm3.material.albedo_color = Color(0.75, 0.75, 0.78)
		bm3.material.metallic = 0.8
		bar.mesh = bm3
		bar.position = Vector3(0, 1.06, 0.72)
		add_child(bar)
	else:
		# chassis (lower body)
		var chassis := MeshInstance3D.new()
		var cm := BoxMesh.new()
		cm.size = size
		cm.material = body_mat
		chassis.mesh = cm
		chassis.position.y = size.y * 0.8 + 0.12
		add_child(chassis)

		# hood taper (front wedge) — reads as a car silhouette
		var hood := MeshInstance3D.new()
		var hm := BoxMesh.new()
		hm.size = Vector3(size.x * 0.92, size.y * 0.45, size.z * 0.22)
		hm.material = body_mat
		hood.mesh = hm
		hood.position = Vector3(0, size.y * 1.15 + 0.12, size.z * 0.40)
		add_child(hood)

		# cabin (glass)
		var cabin := MeshInstance3D.new()
		var cbm := BoxMesh.new()
		cbm.size = Vector3(size.x * 0.82, size.y * 0.72, cab_len)
		var glass := StandardMaterial3D.new()
		glass.albedo_color = Color(0.15, 0.2, 0.28, 0.85)
		glass.metallic = 0.6
		glass.roughness = 0.1
		cbm.material = glass
		cabin.mesh = cbm
		cabin.position = Vector3(0, size.y * 1.6 + 0.12, -size.z * 0.05)
		add_child(cabin)

	# pickup bed / van solid rear
	if vehicle_class == "pickup":
		var bed := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = Vector3(size.x * 0.9, 0.5, size.z * 0.32)
		var bed_mat := StandardMaterial3D.new()
		bed_mat.albedo_color = body_mat.albedo_color.darkened(0.2)
		bed_mat.metallic = 0.4
		bed_mat.roughness = 0.4
		bm.material = bed_mat
		bed.mesh = bm
		bed.position = Vector3(0, size.y * 1.4 + 0.12, -size.z * 0.3)
		add_child(bed)

	# police light bar
	if is_police_car:
		for side in [-0.45, 0.45]:
			var lamp := MeshInstance3D.new()
			var lm := BoxMesh.new()
			lm.size = Vector3(0.55, 0.16, 0.3)
			var lmat := StandardMaterial3D.new()
			lmat.albedo_color = Color(1, 0.1, 0.1) if side < 0 else Color(0.1, 0.15, 1)
			lmat.emission_enabled = true
			lmat.emission = lmat.albedo_color
			lmat.emission_energy_multiplier = 0.0
			lm.material = lmat
			lamp.mesh = lm
			lamp.position = Vector3(side, size.y * 2.0 + 0.2, -size.z * 0.05)
			add_child(lamp)
			lightbar.append(lamp)
		siren_audio = AudioStreamPlayer3D.new()
		siren_audio.stream = load("res://assets/audio/siren.wav")
		siren_audio.volume_db = -6.0
		siren_audio.max_distance = 90.0
		add_child(siren_audio)
		_loop_wav(siren_audio)

	# head/tail lights (dynamic emissive)
	for side in [-0.6, 0.6]:
		var head_l := MeshInstance3D.new()
		var hlm := BoxMesh.new()
		hlm.size = Vector3(0.35, 0.16, 0.06)
		var hmat := StandardMaterial3D.new()
		hmat.albedo_color = Color(1, 1, 0.85)
		hmat.emission_enabled = true
		hmat.emission = Color(1, 1, 0.85)
		hmat.emission_energy_multiplier = 1.6
		hlm.material = hmat
		head_l.mesh = hlm
		head_l.position = Vector3(side * size.x / 1.7, size.y * 0.8 + 0.12, size.z / 2.0 + 0.03)
		add_child(head_l)

		var tail := MeshInstance3D.new()
		var tlm := BoxMesh.new()
		tlm.size = Vector3(0.35, 0.16, 0.06)
		var tmat := StandardMaterial3D.new()
		tmat.albedo_color = Color(0.35, 0.05, 0.05)
		tmat.emission_enabled = true
		tmat.emission = Color(1, 0.15, 0.1)
		tmat.emission_energy_multiplier = 0.25
		tlm.material = tmat
		tail.mesh = tlm
		tail.position = Vector3(side * size.x / 1.7, size.y * 0.8 + 0.12, -size.z / 2.0 - 0.03)
		add_child(tail)
		brake_lights.append(tmat)

		var rev := MeshInstance3D.new()
		var rlm := BoxMesh.new()
		rlm.size = Vector3(0.22, 0.14, 0.06)
		var rmat := StandardMaterial3D.new()
		rmat.albedo_color = Color(0.9, 0.9, 0.9)
		rmat.emission_enabled = true
		rmat.emission = Color(0.95, 0.95, 0.9)
		rmat.emission_energy_multiplier = 0.0
		rlm.material = rmat
		rev.mesh = rlm
		rev.position = Vector3(side * size.x / 1.7, size.y * 0.5 + 0.12, -size.z / 2.0 - 0.03)
		add_child(rev)
		reverse_lights.append(rmat)

	# wheels with silver rims (motorcycle: 2 centered, larger radius)
	var wps: Array = [Vector3(-size.x / 2.0 - 0.02, 0.38, size.z * 0.34),
			Vector3(size.x / 2.0 + 0.02, 0.38, size.z * 0.34),
			Vector3(-size.x / 2.0 - 0.02, 0.38, -size.z * 0.34),
			Vector3(size.x / 2.0 + 0.02, 0.38, -size.z * 0.34)]
	var wheel_r := 0.38
	var wheel_z90 := 90.0
	if vehicle_class == "moto":
		wps = [Vector3(0, 0.34, size.z * 0.36), Vector3(0, 0.34, -size.z * 0.36)]
		wheel_r = 0.34
		wheel_z90 = 90.0
	for wp: Vector3 in wps:
		var w := MeshInstance3D.new()
		var wm := CylinderMesh.new()
		wm.top_radius = 0.38
		wm.bottom_radius = 0.38
		wm.height = 0.3
		wm.material = StandardMaterial3D.new()
		wm.material.albedo_color = Color(0.08, 0.08, 0.08)
		w.mesh = wm
		w.position = wp
		w.rotation_degrees = Vector3(0, 0, 90)
		var rim := MeshInstance3D.new()
		var rm := CylinderMesh.new()
		rm.top_radius = 0.16
		rm.bottom_radius = 0.16
		rm.height = 0.32
		var rimmat := StandardMaterial3D.new()
		rimmat.albedo_color = Color(0.75, 0.75, 0.78)
		rimmat.metallic = 0.8
		rimmat.roughness = 0.3
		rm.material = rimmat
		rim.mesh = rm
		w.add_child(rim)
		add_child(w)
		wheels.append(w)

	smoke = GPUParticles3D.new()
	smoke.amount = 22
	smoke.lifetime = 1.6
	smoke.emitting = false
	smoke.position = Vector3(0, 1.0, -size.z * 0.4)
	var pmat := ParticleProcessMaterial.new()
	pmat.direction = Vector3(0, 1, 0)
	pmat.initial_velocity_min = 1.0
	pmat.initial_velocity_max = 2.5
	pmat.scale_min = 0.4
	pmat.scale_max = 1.0
	var curve := Curve.new()
	curve.add_point(Vector2(0, 1))
	curve.add_point(Vector2(1, 0))
	var cs := CurveTexture.new()
	cs.curve = curve
	pmat.alpha_curve = cs
	pmat.color = Color(0.25, 0.25, 0.25, 0.6)
	smoke.process_material = pmat
	var boxm := BoxMesh.new()
	boxm.size = Vector3(0.3, 0.3, 0.3)
	smoke.draw_pass_1 = boxm
	add_child(smoke)

	engine_audio = AudioStreamPlayer3D.new()
	engine_audio.stream = load("res://assets/audio/engine.wav")
	engine_audio.volume_db = -8.0
	engine_audio.max_distance = 40.0
	add_child(engine_audio)
	_loop_wav(engine_audio)

	horn_audio = AudioStreamPlayer3D.new()
	horn_audio.stream = load("res://assets/audio/horn.wav")
	horn_audio.volume_db = -6.0
	horn_audio.max_distance = 60.0
	add_child(horn_audio)


func _physics_process(delta: float) -> void:
	if wrecked:
		velocity.x = move_toward(velocity.x, 0, BRAKE * delta)
		velocity.z = move_toward(velocity.z, 0, BRAKE * delta)
		if not is_on_floor():
			velocity.y -= 9.8 * delta
		move_and_slide()
		return
	_collision_cd -= delta

	var throttle := 0.0
	var steer_input := 0.0
	var horn_pressed := false
	if driver != null:
		throttle = Input.get_axis("move_back", "move_forward")
		steer_input = Input.get_axis("move_right", "move_left")
		horn_pressed = Input.is_action_just_pressed("horn")
		if Input.is_action_pressed("jump"):
			throttle = -1.0  # handbrake
	elif traffic and waypoints.size() >= 2:
		var ai := _traffic_ai()
		throttle = ai[0]
		steer_input = ai[1]
	elif dispatch:
		throttle = _dispatch_drive()
	elif is_police_car and GameState.wanted > 0:
		throttle = _police_chase(delta)

	if horn_pressed and not horn_audio.playing:
		horn_audio.play()

	# Surface grip
	var surface := WorldBuilder.surface_at(global_position)
	var grip := 1.0
	match surface:
		"dirt": grip = 0.75
		"grass": grip = 0.7
		"sand": grip = 0.55
	if GameState.raining:
		grip *= 0.72 if GameState.heavy_rain else 0.85
		if surface != "asphalt":
			grip *= 0.88  # audit #5: rain reduces off-road grip like every surface

	var cfg: Dictionary = CLASSES.get(vehicle_class, CLASSES["sedan"])
	var max_fwd: float = MAX_FWD * float(cfg["speed"])
	# component damage effects: worn engine = less power, worn wheels = less grip
	var accel: float = ACCEL * float(cfg["accel"]) * engine_factor()

	if throttle > 0.0:
		speed += accel * grip * throttle * delta
	elif throttle < 0.0:
		if speed > 0.5:
			speed += BRAKE * throttle * delta
		else:
			speed += accel * 0.6 * throttle * delta
	else:
		speed = move_toward(speed, 0.0, COAST * delta)
	speed = clampf(speed, -MAX_REV, max_fwd * grip)
	if absf(speed) < 0.05:
		speed = 0.0

	steer = lerpf(steer, steer_input, 8.0 * delta)
	var steer_mul: float = float(cfg.get("steer", 1.0)) * wheel_factor()
	var wobble := 0.0
	if wheel_health < 35.0 and absf(speed) > 6.0:
		wobble = sin(Time.get_ticks_msec() / 1000.0 * 9.0) * 0.25  # pulled alignment
	var yaw_rate := (steer + wobble) * 1.9 * steer_mul * clampf(absf(speed) / 7.0, 0.0, 1.0) \
			* (1.0 - 0.4 * clampf(absf(speed) / max_fwd, 0.0, 1.0)) * grip
	if speed < 0:
		yaw_rate = -yaw_rate
	rotate_y(yaw_rate * delta)

	var fwd := -global_basis.z
	velocity.x = fwd.x * speed
	velocity.z = fwd.z * speed
	if not is_on_floor():
		velocity.y -= 12.0 * delta
	else:
		velocity.y = -2.0
	move_and_slide()

	# body roll/pitch (visual suspension feel)
	var target_pitch := clampf((speed - _prev_throttle * speed) * 0.0 - throttle * 0.03
			* clampf(absf(speed) / 8.0, 0.0, 1.0), -0.06, 0.06)
	_body_pitch = lerpf(_body_pitch, target_pitch, 6.0 * delta)
	_body_roll = lerpf(_body_roll, steer * clampf(absf(speed) / max_fwd, 0.0, 1.0) * 0.05, 6.0 * delta)
	rotation.x = _body_pitch
	rotation.z = _body_roll
	if vehicle_class == "moto":
		# S1: motorcycles lean into steering far more than cars
		rotation.z -= steer * clampf(absf(speed) / maxf(max_fwd, 1.0), 0.0, 1.0) * 0.35
	_prev_throttle = throttle

	_handle_collisions()
	for w: MeshInstance3D in wheels:
		w.rotate_object_local(Vector3(0, 0, 1), speed * delta / 0.38)

	# dynamic lights
	var braking := throttle < 0.0 and speed > 1.0
	for m: StandardMaterial3D in brake_lights:
		m.emission_energy_multiplier = 2.2 if braking else 0.25
	var reversing := speed < -0.5
	for m: StandardMaterial3D in reverse_lights:
		m.emission_energy_multiplier = 1.8 if reversing else 0.0
	if is_police_car:
		var t := Time.get_ticks_msec() / 1000.0
		var on := GameState.wanted > 0
		for i in range(lightbar.size()):
			var flash := sin(t * 9.0 + PI * i) > 0.0
			(lightbar[i].mesh as BoxMesh).material.emission_energy_multiplier = \
					(2.5 if flash else 0.2) if on else 0.0
		if on and not siren_audio.playing and not GameState.audio_shutdown:
			siren_audio.play()

	if driver != null and not GameState.audio_shutdown:
		if not engine_audio.playing:
			engine_audio.play()
		engine_audio.pitch_scale = 0.7 + absf(speed) / max_fwd * 0.9
	smoke.emitting = health < 45.0 and not wrecked


func _traffic_ai() -> Array:
	if waypoints.size() < 2:
		return [0.0, 0.0]
	var target: Vector3 = waypoints[wp_i]
	var to_target := target - global_position
	to_target.y = 0
	if to_target.length() < 9.0:
		wp_i = (wp_i + 1) % waypoints.size()
		return _traffic_ai()
	var fwd := -global_basis.z
	fwd.y = 0
	var desired := to_target.normalized()
	var angle := clampf(fwd.signed_angle_to(desired, Vector3.UP), -1.0, 1.0)
	var throttle := 0.85 if absf(angle) < 0.5 else 0.35
	# brake for obstacles ahead
	var space := get_world_3d().direct_space_state
	var q := PhysicsRayQueryParameters3D.create(
			global_position + Vector3(0, 0.8, 0),
			global_position + Vector3(0, 0.8, 0) + fwd * 9.0, 1 | 2 | 4 | 8)
	q.exclude = [get_rid()]
	if not space.intersect_ray(q).is_empty():
		throttle = -1.0
		stuck_t += get_physics_process_delta_time()
	else:
		stuck_t = 0.0
	if stuck_t > 5.0:
		stuck_t = 0.0
		wp_i = (wp_i + 1) % waypoints.size()
	# obey traffic lights: red for our axis near a signal?
	if _red_for_axis(fwd):
		throttle = minf(throttle, -1.0)
	return [throttle, angle]


func _red_for_axis(fwd: Vector3) -> bool:
	# moving mostly along X -> E-W axis; mostly along Z -> N-S axis
	var horizontal := absf(fwd.x) > absf(fwd.z)
	for lt: Node3D in get_tree().get_nodes_in_group("traffic_lights"):
		var lt_xz: Vector2 = lt.get_meta("xz")
		var to_light := Vector2(lt_xz.x, lt_xz.y) - Vector2(global_position.x, global_position.z)
		if to_light.length() < 16.0:
			var green_ns: bool = GameState.traffic_ns_green
			if horizontal and not green_ns:
				return true
			if not horizontal and green_ns:
				return true
	return false


## Round 9 S6: steer + throttle toward dispatch_target; stop when there.
func _dispatch_drive() -> float:
	var to := dispatch_target - global_position
	to.y = 0
	if to.length() < 8.0:
		return 0.0  # arrived — dwell; game.gd despawns after the pause
	var fwd := -global_basis.z
	fwd.y = 0
	var desired := to.normalized()
	var angle := clampf(fwd.signed_angle_to(desired, Vector3.UP), -1.0, 1.0)
	steer = angle
	return 0.9 if absf(angle) < 0.6 else 0.4


func _police_chase(_delta: float) -> float:
	var player: Node3D = get_tree().get_first_node_in_group("player")
	if player == null:
		return 0.0
	var to_player := player.global_position - global_position
	to_player.y = 0
	if to_player.length() < 8.0:
		return 0.0
	var fwd := -global_basis.z
	fwd.y = 0
	var desired := to_player.normalized()
	var angle := clampf(fwd.signed_angle_to(desired, Vector3.UP), -1.0, 1.0)
	steer = angle
	return 0.9 if absf(angle) < 0.6 else 0.4


func _handle_collisions() -> void:
	if _collision_cd > 0.0:
		return
	for i in range(get_slide_collision_count()):
		var col := get_slide_collision(i)
		var other: Object = col.get_collider()
		if other == null:
			continue
		var impact := absf(speed)
		# audit #21: classify contact — corner clip vs head-on — from the
		# contact point in car-local space (front third vs rest)
		var lc: Vector3 = global_basis.inverse() * (col.get_position() - global_position)
		var frontal := lc.z < -1.1
		if other.is_in_group("civilians") or other.is_in_group("police"):
			if impact > 9.0 and other.has_method("take_damage"):  # audit #17
				other.take_damage(int(impact * 2.4), global_position, self)
				if driver != null:
					GameState.commit_crime(1, global_position)
				speed *= 0.55
				_collision_cd = 0.4
		elif other.is_in_group("cars"):
			if impact > 10.0:
				other.take_damage(impact * 1.4, global_position, self)
				take_damage(impact * 1.2, other.global_position)
				# frontal hits punish the engine; side/rear punish wheels
				if frontal:
					engine_health = maxf(0.0, engine_health - impact * 1.8)
				else:
					wheel_health = maxf(0.0, wheel_health - impact * 1.2)
				speed *= 0.35
				_collision_cd = 0.4
				if driver != null:
					GameState.player_damaged.emit()
		elif other is CharacterBody3D and other.is_in_group("player"):
			if impact > 8.0 and driver != null and other.has_method("take_damage"):
				other.take_damage(int(impact), global_position, self)
				GameState.commit_crime(1, global_position)
				speed *= 0.5
				_collision_cd = 0.4


func take_damage(dmg: float, _from: Vector3, source: Node = null) -> void:
	if wrecked:
		return
	health -= dmg
	# component damage: engine takes the brunt of front hits, wheels of any
	engine_health = maxf(0.0, engine_health - dmg * 0.3)
	wheel_health = maxf(0.0, wheel_health - dmg * 0.2)
	if health <= 0:
		_explode()


func _explode() -> void:
	wrecked = true
	health = 0
	speed = 0
	body_mat.albedo_color = Color(0.12, 0.1, 0.1)
	smoke.emitting = true
	var boom := AudioStreamPlayer3D.new()
	boom.stream = load("res://assets/audio/explode.wav")
	boom.max_distance = 200.0
	add_child(boom)
	boom.play()
	var fire := OmniLight3D.new()
	fire.light_color = Color(1.0, 0.5, 0.15)
	fire.omni_range = 14.0
	fire.light_energy = 4.0
	fire.position = Vector3(0, 2, 0)
	add_child(fire)
	var tw := create_tween()
	tw.tween_property(fire, "light_energy", 0.0, 1.2)
	tw.tween_callback(fire.queue_free)
	if driver != null:
		var p := driver
		exit_player()
		p.take_damage(65, global_position, self)
	for n in get_tree().get_nodes_in_group("civilians") + get_tree().get_nodes_in_group("police"):
		if is_instance_valid(n) and n.global_position.distance_to(global_position) < 6.0:
			n.take_damage(60, global_position, self)
	GameState.commit_crime(0, global_position)
	var t := get_tree().create_timer(30.0)
	t.timeout.connect(func() -> void:
		if is_instance_valid(self):
			var player := get_tree().get_first_node_in_group("player")
			if player == null or global_position.distance_to(player.global_position) > 40.0:
				queue_free())


func enter_player(p: CharacterBody3D) -> void:
	if wrecked:
		GameState.notify("This wreck is not going anywhere")
		return
	driver = p
	traffic = false
	p.start_driving(self)
	GameState.stats.cars_entered += 1
	GameState.notify("Vehicle acquired")


func exit_player() -> void:
	if driver == null:
		return
	var p := driver
	driver = null
	var side := global_basis.x * 2.4
	var out := global_position + side + Vector3(0, 0.6, 0)
	p.exit_driving(out)
	engine_audio.stop()


## Engine power scales down to 45 % when the engine is destroyed-ish.
func engine_factor() -> float:
	return 0.45 + 0.55 * engine_health / 100.0


## Steering scales down to 50 % with wrecked wheels.
func wheel_factor() -> float:
	return 0.5 + 0.5 * wheel_health / 100.0


## D2 family fix: a car freed while its audio plays leaks the playback.
func _exit_tree() -> void:
	if engine_audio:
		engine_audio.stop()
	if horn_audio:
		horn_audio.stop()
	if siren_audio:
		siren_audio.stop()


## D2 family fix: native WAV looping (see game.gd _loop_wav note).
func _loop_wav(p: Node) -> void:
	var s := p.stream as AudioStreamWAV
	if s:
		s.loop_mode = AudioStreamWAV.LOOP_FORWARD
		s.loop_begin = 0
		s.loop_end = int(s.get_length() * s.mix_rate)


func get_seat_position() -> Vector3:
	return global_position + Vector3(0, 0.9, 0)
