extends Node3D
## Courier Deliveries (Round 9 S3 — Phase 28 slice): data-driven pickup ->
## dropoff routes with a timer and cash reward. Walk (or drive) into the
## crate to take the job, carry it to the beacon before time runs out.
## Mid-mission save: the carry state round-trips through save_system
## (SAVE_VERSION 3), so a loaded game resumes the delivery, not just money.

signal delivery_started(route: int)
signal delivery_finished(route: int, won: bool)

## [pickup_pos, dropoff_pos, time_limit_s, reward_$]
const ROUTES: Array = [
	[Vector3(-330, 1.0, -140), Vector3(-556, 1.0, 216), 110.0, 150],
	[Vector3(250, 1.0, -290), Vector3(-260, 1.0, -90), 120.0, 200],
	[Vector3(-30, 1.0, 90), Vector3(-450, 1.0, -40), 90.0, 120],
]

var active := false          # a crate is being carried
var route := -1              # active route index (-1 = idle)
var time_left := 0.0
var _crate: Node3D = null
var _beacon: Node3D = null
var _pickup_areas: Array[Area3D] = []


func _ready() -> void:
	add_to_group("delivery")
	for i in range(ROUTES.size()):
		var pos: Vector3 = ROUTES[i][0]
		var crate := Node3D.new()
		crate.position = pos
		var box := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = Vector3(0.9, 0.9, 0.9)
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color(0.72, 0.5, 0.2)
		mat.emission_enabled = true
		mat.emission = Color(0.9, 0.6, 0.15)
		mat.emission_energy_multiplier = 0.5
		bm.material = mat
		box.mesh = bm
		box.position.y = 0.45
		crate.add_child(box)
		var area := Area3D.new()
		area.collision_layer = 0
		area.collision_mask = 2  # player only
		var cs := CollisionShape3D.new()
		var ss := SphereShape3D.new()
		ss.radius = 2.4
		cs.shape = ss
		cs.position.y = 0.8
		area.add_child(cs)
		crate.add_child(area)
		_pickup_areas.append(area)
		add_child(crate)
		var idx := i
		area.body_entered.connect(func(_b: Node3D) -> void: _on_pickup(idx))
	# one shared dropoff beacon, moved to the active route's target
	_beacon = Node3D.new()
	var pillar := MeshInstance3D.new()
	var pm := CylinderMesh.new()
	pm.top_radius = 1.2
	pm.bottom_radius = 1.6
	pm.height = 14.0
	var pmat := StandardMaterial3D.new()
	pmat.albedo_color = Color(0.2, 1.0, 0.4, 0.55)
	pmat.emission_enabled = true
	pmat.emission = Color(0.2, 1.0, 0.4)
	pmat.emission_energy_multiplier = 1.2
	pmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	pm.material = pmat
	pillar.mesh = pm
	pillar.position.y = 7.0
	_beacon.add_child(pillar)
	var area2 := Area3D.new()
	area2.collision_layer = 0
	area2.collision_mask = 2
	var cs2 := CollisionShape3D.new()
	var ss2 := SphereShape3D.new()
	ss2.radius = 3.0
	cs2.shape = ss2
	cs2.position.y = 1.0
	area2.add_child(cs2)
	_beacon.add_child(area2)
	area2.body_entered.connect(func(_b: Node3D) -> void: _on_deliver())
	_beacon.visible = false
	_beacon.process_mode = Node.PROCESS_MODE_DISABLED
	add_child(_beacon)


func _process(delta: float) -> void:
	if not active:
		return
	time_left -= delta
	GameState.set_prompt("Deliver the package: %ds  ->  beacon" % int(ceil(time_left)))
	if time_left <= 0.0:
		_fail()


func _on_pickup(i: int) -> void:
	if active or i >= _pickup_areas.size():
		return
	if not _pickup_areas[i].get_parent().visible:
		return  # crate already consumed this cycle
	route = i
	active = true
	time_left = ROUTES[i][2]
	# physics-callback safe: CollisionObject state changes must be deferred
	_pickup_areas[i].get_parent().visible = false
	_pickup_areas[i].get_parent().set_deferred("process_mode", Node.PROCESS_MODE_DISABLED)
	_beacon.position = ROUTES[i][1]
	_beacon.visible = true
	_beacon.set_deferred("process_mode", Node.PROCESS_MODE_INHERIT)
	GameState.notify("Package up! $%d on delivery — follow the beacon" % ROUTES[i][3])
	delivery_started.emit(i)


func _on_deliver() -> void:
	if not active:
		return
	var reward: int = ROUTES[route][3]
	GameState.add_money(reward)
	GameState.stats["deliveries"] = int(GameState.stats.get("deliveries", 0)) + 1
	GameState.notify("DELIVERED! +$%d" % reward)
	delivery_finished.emit(route, true)
	_reset()


func _fail() -> void:
	GameState.notify("Delivery failed — package expired")
	delivery_finished.emit(route, false)
	_reset()


func _reset() -> void:
	active = false
	route = -1
	time_left = 0.0
	_beacon.visible = false
	_beacon.set_deferred("process_mode", Node.PROCESS_MODE_DISABLED)
	for a in _pickup_areas:
		if a.get_parent() != null:
			a.get_parent().visible = true
			a.get_parent().set_deferred("process_mode", Node.PROCESS_MODE_INHERIT)


## Mid-mission save contract (Round 9 S3): carried package state.
func state() -> Dictionary:
	if not active:
		return {}
	return {"route": route, "time_left": time_left}


func restore(d: Dictionary) -> void:
	if d.is_empty():
		return
	var r := int(d.get("route", -1))
	if r < 0 or r >= ROUTES.size():
		return
	# resume mid-carry: same pickup consumption path as _on_pickup
	_on_pickup(r)
	if active:
		time_left = float(d.get("time_left", ROUTES[r][2]))
