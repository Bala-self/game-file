class_name WorldDataRes
extends Resource
## Typed world-data contract (Phase 5). Serializes the 17-key world_data
## dictionary that game.gd, the map screen, EventManager, directors and the
## save system all read. The committed assets/data/world.tres is generated
## from the kit constants (tools/gen_world_tres.gd) and is diff-tested
## against them every CI run — drift is a build failure.
## Inner typing notes: traffic_loops holds Array[Vector3] loops (nested typed
## arrays are not expressible in GDScript exports); districts maps
## String -> Rect2; property_spots maps String -> Vector2.

@export var roads: Array[Rect2] = []
@export var dirt_roads: Array[Rect2] = []
@export var island := Rect2()
@export var sand := Rect2()
@export var water_y := -1.3
@export var traffic_loops: Array = []
@export var cop_spawns: Array[Vector3] = []
@export var collectible_spots: Array[Vector3] = []
@export var parked_spots: Array[Vector3] = []
@export var player_spawn := Vector3.ZERO
@export var traffic_lights: Array[Vector2] = []
@export var shop_spot := Vector3.ZERO
@export var gas_spot := Vector3.ZERO
@export var districts: Dictionary = {}
@export var gang_territory := Rect2()
@export var safehouse_spot := Vector3.ZERO
@export var property_spots: Dictionary = {}


func to_dict() -> Dictionary:
	return {
		"roads": roads,
		"dirt_roads": dirt_roads,
		"island": island,
		"sand": sand,
		"water_y": water_y,
		"traffic_loops": traffic_loops,
		"cop_spawns": cop_spawns,
		"collectible_spots": collectible_spots,
		"parked_spots": parked_spots,
		"player_spawn": player_spawn,
		"traffic_lights": traffic_lights,
		"shop_spot": shop_spot,
		"gas_spot": gas_spot,
		"districts": districts,
		"gang_territory": gang_territory,
		"safehouse_spot": safehouse_spot,
		"property_spots": property_spots,
	}


func from_dict(d: Dictionary) -> void:
	# typed arrays need assign() (a plain = from an untyped Array aborts)
	roads.assign(d.get("roads", []))
	dirt_roads.assign(d.get("dirt_roads", []))
	island = d.get("island", Rect2())
	sand = d.get("sand", Rect2())
	water_y = d.get("water_y", -1.3)
	traffic_loops = d.get("traffic_loops", [])
	cop_spawns.assign(d.get("cop_spawns", []))
	collectible_spots.assign(d.get("collectible_spots", []))
	parked_spots.assign(d.get("parked_spots", []))
	player_spawn = d.get("player_spawn", Vector3.ZERO)
	traffic_lights.assign(d.get("traffic_lights", []))
	shop_spot = d.get("shop_spot", Vector3.ZERO)
	gas_spot = d.get("gas_spot", Vector3.ZERO)
	districts = d.get("districts", {})
	gang_territory = d.get("gang_territory", Rect2())
	safehouse_spot = d.get("safehouse_spot", Vector3.ZERO)
	property_spots = d.get("property_spots", {})
