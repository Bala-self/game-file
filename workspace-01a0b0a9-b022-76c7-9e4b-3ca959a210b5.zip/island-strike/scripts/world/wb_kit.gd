class_name WBKit
extends Object
## Shared world-construction kit: primitives, palettes, world_data
## constants and QA registries. Depends on nothing (bottom of the
## world-builder dependency graph).


const ISLAND := Rect2(-450, -350, 900, 700)
const SAND := Rect2(-560, -450, 1120, 900)
const WATER_Y := -1.3
const ROAD_W := 14.0

# Roads as XZ rects (asphalt)
const ROADS: Array = [
	Rect2(-410, -317, 820, 14),   # N perimeter
	Rect2(-410, 303, 820, 14),    # S perimeter
	Rect2(-417, -310, 14, 620),   # W perimeter
	Rect2(403, -310, 14, 620),    # E perimeter
	Rect2(-410, -67, 820, 14),    # main E-W
	Rect2(-410, 143, 530, 14),    # E-W south
	Rect2(-267, -310, 14, 620),   # main N-S
	Rect2(53, -310, 14, 620),     # N-S ave
	Rect2(173, -60, 14, 370),     # industrial access
	Rect2(-400, -187, 280, 14),   # downtown local E-W
	Rect2(-157, -280, 14, 220),   # downtown local N-S
	Rect2(303, -310, 14, 100),    # airport spur
	Rect2(243, -227, 194, 12),    # airport service
	Rect2(-387, -310, 14, 620),   # beach road
]
const DIRT_ROADS: Array = [
	Rect2(-410, 224, 290, 8),
]
# Signalized intersections: [x, z] at crossings of major roads
const TRAFFIC_LIGHTS: Array = [
	Vector2(-267, -67), Vector2(53, -67), Vector2(410, -67),
	Vector2(-267, 143), Vector2(53, 143), Vector2(-410, 143),
	Vector2(-267, -310), Vector2(53, -310),
]

const FARM := Rect2(-400, 140, 280, 160)
const TRAFFIC_LOOP_A: Array = [
	Vector3(-400, 0, -300), Vector3(0, 0, -300), Vector3(400, 0, -300),
	Vector3(400, 0, -60), Vector3(400, 0, 300), Vector3(0, 0, 300),
	Vector3(-400, 0, 300), Vector3(-400, 0, -60),
]
const TRAFFIC_LOOP_B: Array = [
	Vector3(-390, 0, -74), Vector3(46, 0, -74), Vector3(46, 0, -300),
	Vector3(-140, 0, -300), Vector3(-140, 0, -194), Vector3(-390, 0, -194),
]
const COP_SPAWNS: Array = [
	Vector3(-404, 0.5, 30), Vector3(396, 0.5, -40),
	Vector3(30, 0.5, -304), Vector3(-30, 0.5, 304),
]
const COLLECTIBLE_SPOTS: Array = [
	Vector3(-530, 0.6, -250), Vector3(-505, 0.6, 210),
	Vector3(-385, 0.6, -170), Vector3(-140, 0.6, -100),
	Vector3(-350, 11.2, -120), Vector3(-190, 0.6, 30),  # C05 on parking roof
	Vector3(-300, 0.6, 100),
	Vector3(-60, 0.6, 30), Vector3(20, 0.6, 90),
	Vector3(-20, 0.6, -200), Vector3(200, 0.6, -140),
	Vector3(330, 0.6, -300), Vector3(400, 0.6, -240),
	Vector3(90, 0.6, -300),
	Vector3(160, 0.6, 100), Vector3(390, 0.6, 180), Vector3(280, 0.6, 280),
	Vector3(-350, 0.6, 200), Vector3(-180, 0.6, 280),
	Vector3(-550, 0.6, 40),
]
const PARKED_SPOTS: Array = [
	Vector3(-386, 0.4, -120), Vector3(-386, 0.4, 40), Vector3(-334, 0.4, -310),
	Vector3(-200, 0.4, -310), Vector3(100, 0.4, -310), Vector3(404, 0.4, -160),
	Vector3(404, 0.4, 120), Vector3(240, 0.4, 304), Vector3(-100, 0.4, 304),
	Vector3(-260, 0.4, -74), Vector3(-74, 0.4, -260), Vector3(166, 0.4, 60),
]
const PLAYER_SPAWN := Vector3(-430, 0.6, -40)
## QA registries (regression-checked): building footprints vs roads,
## downtown height-class census.
static var qa_rects: Array[Rect2] = []
static var dt_heights: Array[float] = []
static var sidewalk_rects: Array[Rect2] = []
static var rng_global := RandomNumberGenerator.new()
static var WINDOW_MATERIAL: StandardMaterial3D = null

## Formal road hierarchy (Phase 8): 8 classes, road index -> class.
const ROAD_CLASSES := {
	"freeway": [0, 1, 2, 3],          # perimeter loop, divided, 90 km/h
	"arterial": [4, 5, 6, 7],         # island mains, signalized, 60 km/h
	"collector": [12, 13],            # beach road + airport service, 50 km/h
	"main_street": [9, 10],           # downtown storefront streets, 40 km/h
	"residential": [],                # reserved: suburb interior streets (phase 9)
	"industrial_road": [8],           # industrial access + heavy vehicles
	"service_lane": [11],             # airport spur, single service lane
	"rural_dirt": [-1],               # DIRT_ROADS[0], 30 km/h
}

## Per-class rules (Phase 20 traffic hook): speed limit m/s, lane width m.
const ROAD_RULES := {
	"freeway": {"limit": 25.0, "lane_w": 4.5},
	"arterial": {"limit": 16.7, "lane_w": 4.0},
	"collector": {"limit": 13.9, "lane_w": 3.75},
	"main_street": {"limit": 11.1, "lane_w": 3.5},
	"residential": {"limit": 8.3, "lane_w": 3.25},
	"industrial_road": {"limit": 12.5, "lane_w": 4.25},
	"service_lane": {"limit": 9.7, "lane_w": 3.5},
	"rural_dirt": {"limit": 8.3, "lane_w": 3.0},
}



static func _box(parent: Node3D, size: Vector3, xz: Vector2, top_y: float, color: Color,
		collide := true, name := "Box") -> StaticBody3D:
	var body := StaticBody3D.new()
	body.name = name
	var mesh_inst := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh.material = _mat(color)
	mesh_inst.mesh = mesh
	body.add_child(mesh_inst)
	if collide:
		var shape := CollisionShape3D.new()
		var box := BoxShape3D.new()
		box.size = size
		shape.shape = box
		body.add_child(shape)
		body.collision_layer = 1
		body.collision_mask = 0
	body.position = Vector3(xz.x, top_y - size.y * 0.5, xz.y)
	parent.add_child(body, true)
	return body

static func _decal_box(parent: Node3D, size: Vector3, xz: Vector2, top_y: float,
		color: Color, name := "Decal") -> MeshInstance3D:
	var inst := MeshInstance3D.new()
	inst.name = name
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh.material = _mat(color)
	inst.mesh = mesh
	inst.position = Vector3(xz.x, top_y - size.y * 0.5, xz.y)
	parent.add_child(inst, true)  # force_readable_name: keep label through duplicates
	return inst

static func _cyl(parent: Node3D, radius: float, height: float, xz: Vector2, top_y: float,
		color: Color, collide := true, segments := 16) -> StaticBody3D:
	var body := StaticBody3D.new()
	var mesh_inst := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = height
	mesh.radial_segments = segments
	mesh.material = _mat(color)
	mesh_inst.mesh = mesh
	body.add_child(mesh_inst)
	if collide:
		var shape := CollisionShape3D.new()
		var cshape := CylinderShape3D.new()
		cshape.radius = radius
		cshape.height = height
		shape.shape = cshape
		body.add_child(shape)
		body.collision_layer = 1
	body.position = Vector3(xz.x, top_y - height * 0.5, xz.y)
	parent.add_child(body)
	return body

static func _mat(color: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 0.9
	return m

static func _emissive(color: Color, energy := 1.4) -> StandardMaterial3D:
	var m := _mat(color)
	m.emission_enabled = true
	m.emission = color
	m.emission_energy_multiplier = energy
	return m

static func _road_point_free(xz: Vector2, margin := 10.0) -> bool:
	for r: Rect2 in ROADS:
		if r.grow(margin).has_point(xz):
			return false
	for r: Rect2 in DIRT_ROADS:
		if r.grow(margin).has_point(xz):
			return false
	return true


# ------------------------------------------------------------------- pieces

static func _palm(root: Node3D, xz: Vector2, rng: RandomNumberGenerator) -> void:
	var h := rng.randf_range(5.0, 7.5)
	var trunk := _cyl(root, 0.25, h, xz, h, Color(0.5, 0.38, 0.22), false, 8)
	trunk.add_to_group("veg")
	for i in range(5):
		var ang := TAU * i / 5.0 + rng.randf() * 0.4
		var leaf := MeshInstance3D.new()
		var lm := BoxMesh.new()
		lm.size = Vector3(3.4, 0.12, 0.9)
		lm.material = _mat(Color(0.2 + rng.randf() * 0.1, 0.55, 0.2))
		leaf.mesh = lm
		leaf.position = Vector3(xz.x, h, xz.y) + Vector3(cos(ang) * 1.5, -0.1, sin(ang) * 1.5)
		leaf.rotation_degrees = Vector3(0, rad_to_deg(-ang) + 90.0, -14.0)
		leaf.visibility_range_end = 320.0
		leaf.add_to_group("veg")
		root.add_child(leaf)

static func _pine(root: Node3D, xz: Vector2, rng: RandomNumberGenerator) -> void:
	var h := rng.randf_range(6.0, 9.0)
	var trunk := _cyl(root, 0.3, h * 0.45, xz, h * 0.45, Color(0.4, 0.3, 0.2), false, 8)
	trunk.add_to_group("veg")
	var cone := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.1
	cm.bottom_radius = 2.4
	cm.height = h * 0.75
	cm.material = _mat(Color(0.15, 0.38, 0.2))
	cone.mesh = cm
	cone.position = Vector3(xz.x, h * 0.45 + h * 0.375, xz.y)
	cone.visibility_range_end = 360.0
	cone.add_to_group("veg")
	root.add_child(cone)

static func _oak(root: Node3D, xz: Vector2, rng: RandomNumberGenerator) -> void:
	var h := rng.randf_range(3.5, 5.0)
	var trunk := _cyl(root, 0.35, h, xz, h, Color(0.45, 0.33, 0.2), false, 8)
	trunk.add_to_group("veg")
	var crown := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = rng.randf_range(2.2, 3.2)
	sm.height = sm.radius * 2.0
	sm.material = _mat(Color(0.22, 0.48, 0.22))
	crown.mesh = sm
	crown.position = Vector3(xz.x, h + sm.radius * 0.6, xz.y)
	crown.visibility_range_end = 340.0
	crown.add_to_group("veg")
	root.add_child(crown)

static func _bush(root: Node3D, xz: Vector2, rng: RandomNumberGenerator) -> void:
	var sm := MeshInstance3D.new()
	var sph := SphereMesh.new()
	sph.radius = rng.randf_range(0.6, 1.1)
	sph.height = sph.radius * 1.6
	sph.material = _mat(Color(0.2, 0.42, 0.2))
	sm.mesh = sph
	sm.position = Vector3(xz.x, sph.height * 0.35, xz.y)
	sm.visibility_range_end = 220.0
	sm.add_to_group("veg")
	root.add_child(sm)

static func _rock(root: Node3D, xz: Vector2, rng: RandomNumberGenerator) -> void:
	var sm := MeshInstance3D.new()
	var sph := SphereMesh.new()
	sph.radius = rng.randf_range(0.5, 1.4)
	sph.height = sph.radius * 1.2
	sph.material = _mat(Color(0.5, 0.5, 0.48))
	sm.mesh = sph
	sm.position = Vector3(xz.x, sph.height * 0.25, xz.y)
	sm.rotation_degrees = Vector3(rng.randf() * 20, rng.randf() * 360, rng.randf() * 20)
	sm.visibility_range_end = 240.0
	sm.add_to_group("veg")
	root.add_child(sm)


## Multi-storey parking structure: real verticality, driveable ramps,
## rooftop collectible + viewpoint. Landmark visible across downtown.

static func surface_at(pos: Vector3) -> String:
	var p := Vector2(pos.x, pos.z)
	for r: Rect2 in ROADS:
		if r.has_point(p):
			return "asphalt"
	for r: Rect2 in DIRT_ROADS:
		if r.has_point(p):
			return "dirt"
	if not ISLAND.has_point(p):
		return "sand"
	if FARM.has_point(p):
		return "dirt"
	return "grass"

static func road_census() -> Dictionary:
	# derived from ROAD_CLASSES so the census can never drift from the spec
	var counts := {}
	for cls: String in ROAD_CLASSES.keys():
		var idxs: Array = ROAD_CLASSES[cls]
		counts[cls] = idxs.size() if not cls in ["rural_dirt"] else DIRT_ROADS.size()
	counts["total"] = ROADS.size() + DIRT_ROADS.size()
	counts["classes"] = ROAD_CLASSES.size()
	return counts
## District registry: name -> XZ rect (map screen, debug, AI territories)
const DISTRICTS := {
	"Downtown": Rect2(-410, -280, 260, 210),
	"Park": Rect2(-95, -55, 150, 170),
	"Suburbs": Rect2(-100, -260, 340, 170),
	"Military": Rect2(-70, -350, 330, 100),
	"Airport": Rect2(240, -320, 210, 80),
	"Industrial": Rect2(140, 60, 310, 240),
	"Farmland": Rect2(-410, 140, 300, 160),
	"Beachfront": Rect2(-560, -440, 120, 880),
	"Marina": Rect2(-620, 150, 130, 140),
}
const GAS_SPOT := Vector3(-20, 0.5, -140)
const SCHOOL_SPOT := Vector2(0, -230)
const HOSPITAL_SPOT := Vector2(180, -120)
const PARKING_XZ := Vector2(-350, -120)
const GANG_TERRITORY := Rect2(140, 60, 310, 240)
const SHOP_SPOT := Vector3(-259, 0.5, -120)       # gun shop door (downtown edge)
const SAFEHOUSE_SPOT := Vector3(-165, 0.5, -240)  # safehouse door (downtown)

const BUILDING_PALETTE_DOWNTOWN: Array = [
	Color(0.55, 0.57, 0.62), Color(0.45, 0.5, 0.58), Color(0.62, 0.58, 0.52),
	Color(0.4, 0.45, 0.55), Color(0.66, 0.64, 0.6),
]
const HOUSE_PALETTE: Array = [
	Color(0.85, 0.78, 0.66), Color(0.78, 0.84, 0.78), Color(0.87, 0.8, 0.72),
	Color(0.8, 0.74, 0.82), Color(0.82, 0.86, 0.9),
]
const CONTAINER_COLORS: Array = [
	Color(0.75, 0.3, 0.25), Color(0.25, 0.45, 0.65), Color(0.8, 0.7, 0.3),
	Color(0.3, 0.55, 0.35), Color(0.6, 0.6, 0.62),
]
