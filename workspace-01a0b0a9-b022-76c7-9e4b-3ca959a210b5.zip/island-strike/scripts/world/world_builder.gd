class_name WorldBuilder
extends Object
## Procedurally constructs the ISLAND STRIKE world (v2) and returns nav/spawn data.
## ORCHESTRATOR since the Phase 4 decomposition: per-district construction lives
## in scripts/world/wb_kit.gd, wb_arch.gd and scripts/world/districts/*.gd; this
## file owns the public API (build/surface_at/road_census), build ORDER and
## world_data assembly. Build order is contract: identical sequence == identical
## island (seed 20260915 inside build()).
## Public constants below are aliases of the kit data (single source of truth).

const WBKit := preload("res://scripts/world/wb_kit.gd")
const WBArch := preload("res://scripts/world/wb_arch.gd")
const WBRoads := preload("res://scripts/world/districts/roads.gd")
const WBStreetscape := preload("res://scripts/world/districts/streetscape.gd")
const WBEnv := preload("res://scripts/world/districts/env.gd")
const WBDDowntown := preload("res://scripts/world/districts/downtown.gd")
const WBDSuburbs := preload("res://scripts/world/districts/suburbs.gd")
const WBDMilitary := preload("res://scripts/world/districts/military.gd")
const WBDAirport := preload("res://scripts/world/districts/airport.gd")
const WBDIndustrial := preload("res://scripts/world/districts/industrial.gd")
const WBDFarmland := preload("res://scripts/world/districts/farmland.gd")
const WBDPark := preload("res://scripts/world/districts/park.gd")
const WBDBeach := preload("res://scripts/world/districts/beach.gd")
const WBDOutskirts := preload("res://scripts/world/districts/outskirts.gd")
const WBDRail := preload("res://scripts/world/districts/rail.gd")
const WBCoast := preload("res://scripts/world/districts/coast.gd")
const WBDInteriors := preload("res://scripts/world/districts/interiors.gd")

const ISLAND := WBKit.ISLAND
const SAND := WBKit.SAND
const WATER_Y := WBKit.WATER_Y
const ROAD_W := WBKit.ROAD_W
const ROADS := WBKit.ROADS
const DIRT_ROADS := WBKit.DIRT_ROADS
const TRAFFIC_LIGHTS := WBKit.TRAFFIC_LIGHTS
const FARM := WBKit.FARM
const COP_SPAWNS := WBKit.COP_SPAWNS
const COLLECTIBLE_SPOTS := WBKit.COLLECTIBLE_SPOTS
const PARKED_SPOTS := WBKit.PARKED_SPOTS
const PLAYER_SPAWN := WBKit.PLAYER_SPAWN
const ROAD_CLASSES := WBKit.ROAD_CLASSES
const DISTRICTS := WBKit.DISTRICTS
const GAS_SPOT := WBKit.GAS_SPOT
const SCHOOL_SPOT := WBKit.SCHOOL_SPOT
const HOSPITAL_SPOT := WBKit.HOSPITAL_SPOT
const PARKING_XZ := WBKit.PARKING_XZ
const GANG_TERRITORY := WBKit.GANG_TERRITORY
const SHOP_SPOT := WBKit.SHOP_SPOT
const SAFEHOUSE_SPOT := WBKit.SAFEHOUSE_SPOT
const TRAFFIC_LOOP_A := WBKit.TRAFFIC_LOOP_A
const TRAFFIC_LOOP_B := WBKit.TRAFFIC_LOOP_B
const BUILDING_PALETTE_DOWNTOWN := WBKit.BUILDING_PALETTE_DOWNTOWN
const HOUSE_PALETTE := WBKit.HOUSE_PALETTE
const CONTAINER_COLORS := WBKit.CONTAINER_COLORS

## QA registries alias the kit arrays (reference types -> same instance).
static var qa_rects: Array[Rect2] = []
static var dt_heights: Array[float] = []
static var sidewalk_rects: Array[Rect2] = []
static var WINDOW_MATERIAL: StandardMaterial3D = null


static func surface_at(pos: Vector3) -> String:
	return WBKit.surface_at(pos)


static func road_census() -> Dictionary:
	return WBKit.road_census()


static func build(root: Node3D) -> Dictionary:
	var rng := RandomNumberGenerator.new()
	rng.seed = 20260915

	# alias kit registries BEFORE construction (same Array instances)
	qa_rects = WBKit.qa_rects
	dt_heights = WBKit.dt_heights
	sidewalk_rects = WBKit.sidewalk_rects

	WBEnv._setup_environment(root)
	WBEnv._build_ground(root)
	WBEnv._build_water(root)
	WBEnv._build_vegetation(root)  # Round 10 E5
	WBEnv._build_landmarks(root)   # Round 10 E6
	WBEnv._build_creek(root)       # Round 10 E7
	WBEnv._build_road_protection(root)  # Round 10 E8
	WBRoads._build_roads(root)
	WBRoads._build_sidewalks(root)
	WBRoads._build_freeway_medians(root)
	WBRoads._build_stop_lines(root)
	WBRoads._build_bus_stops(root)
	WBRoads._build_district_signs(root)
	WBRoads._build_street_trees(root)
	WBRoads._build_utility_poles(root)
	WBRoads._build_drains(root)
	WBCoast._build_lighthouse(root)
	WBCoast._build_offshore_island(root)
	WBCoast._build_beach_pier(root)
	WBCoast._build_coast_dressing(root)
	WBDRail._build_rail_yard(root)
	WBDOutskirts._build_outskirts(root)
	WBDDowntown._build_downtown(root, rng)
	WBDDowntown._build_stadium(root)
	WBDSuburbs._build_suburbs(root, rng)
	WBDMilitary._build_military(root, rng)
	WBDAirport._build_airport(root, rng)
	WBDIndustrial._build_industrial(root, rng)
	WBDFarmland._build_farmland(root, rng)
	WBDPark._build_park(root, rng)
	WBDBeach._build_beach(root, rng)
	WBRoads._build_traffic_lights(root)
	WBRoads._build_road_signs(root)
	WBRoads._build_guardrails(root)
	WBRoads._build_street_furniture(root, rng)
	# Phase 9: per-district streetscape kits (signature props)
	for d: String in WBStreetscape.KITS.keys():
		WBStreetscape.apply_for_district(root, d, WBStreetscape.KITS[d])
	WBEnv._build_service_points(root)
	WBDDowntown._build_parking_structure(root)
	WBDDowntown._build_gas_station(root)
	WBDDowntown._build_school_and_hospital(root)
	WBDDowntown._build_construction_site(root)
	WBRoads._build_crosswalks(root)
	WBDInteriors._build_interiors(root)
	WBRoads._build_lamps(root)

	# alias build-produced kit state for the public API
	WINDOW_MATERIAL = WBKit.WINDOW_MATERIAL

	apply_distance_lod(root)  # Round 11: distance-LOD classification
	return {
		"roads": ROADS,
		"dirt_roads": DIRT_ROADS,
		"island": ISLAND,
		"sand": SAND,
		"water_y": WATER_Y,
		"traffic_loops": [TRAFFIC_LOOP_A, TRAFFIC_LOOP_B],
		"cop_spawns": COP_SPAWNS,
		"collectible_spots": COLLECTIBLE_SPOTS,
		"parked_spots": PARKED_SPOTS,
		"player_spawn": PLAYER_SPAWN,
		"traffic_lights": TRAFFIC_LIGHTS,
		"shop_spot": SHOP_SPOT,
		"gas_spot": GAS_SPOT,
		"districts": DISTRICTS,
		"gang_territory": GANG_TERRITORY,
		"safehouse_spot": SAFEHOUSE_SPOT,
	}


## Round 11: distance-LOD classification — mesh instances without an explicit
## visibility range get one by world-space size class, so cross-map buildings
## stop drawing at ranges where they are sub-pixel silhouettes. Measured
## (render probe): Marina 1649 / Park 1155 draw calls, dominated by far
## structures that no system culled. Big = visible far, small = not.
## Existing explicit ranges (vegetation etc.) are never lowered.
static func apply_distance_lod(root: Node3D) -> void:
	var applied := 0
	for m in root.find_children("*", "MeshInstance3D", true, false):
		var mi := m as MeshInstance3D
		if mi.visibility_range_end > 0.0:
			continue  # explicit range wins (never weaken existing culling)
		var sx := mi.global_basis.x.length() if mi is Node3D else 1.0
		var aabb := mi.get_aabb()
		var span: float = maxf(aabb.size.x, maxf(aabb.size.y, aabb.size.z)) * sx
		if span >= 20.0:
			mi.visibility_range_end = 760.0
		elif span >= 10.0:
			mi.visibility_range_end = 480.0
		elif span >= 4.0:
			mi.visibility_range_end = 330.0
		else:
			mi.visibility_range_end = 280.0
		applied += 1
	print("DIST_LOD: %d meshes classified" % applied)
