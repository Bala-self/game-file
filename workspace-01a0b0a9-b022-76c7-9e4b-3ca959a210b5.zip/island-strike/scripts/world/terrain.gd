class_name WorldTerrain
extends Object
## Terrain service (Phase 7): deterministic height field with a flat-first
## contract. height_at(x, z) is the single source of truth for "how high is
## the ground here" — every future system (prop placement, vehicle spawn,
## navmesh, missions) must ask it instead of assuming y.
##
## ACTIVATION POLICY (directive: flat-first, then activate): the height field
## is identically 0 until `activate` is set with a zone Rect2. Activating is a
## DECLARED BREAKING CHANGE (it moves the ground under validated areas) and
## must ship with a re-baselined world_data diff + perf probe + regression
## battery. Today the island is flat: height_at() == 0.0 everywhere by design.

## Deterministic value noise, seeded — same output every run (fixed-seed
## contract). Amplitude/frequency chosen for driveable grades (< 12%).
const SEED := 7717
const AMPLITUDE := 9.0
const FREQ := 1.0 / 130.0

static var activate := false
static var active_zone := Rect2()  # world XZ rect where terrain rises


static func _hash2(ix: int, iz: int, oct: int) -> float:
	var k := int(SEED + ix * 374761393 + iz * 668265263 + oct * 2654435761)
	k = (k ^ (k >> 13)) * 1274126177
	return float((k ^ (k >> 16)) & 0xFFFF) / 65535.0


static func _noise2(x: float, z: float) -> float:
	# 3-octave value noise on an integer hash grid; deterministic, no RNG state
	var h := 0.0
	var amp := 1.0
	var fr := FREQ
	for o in range(3):
		var xf: float = x * fr
		var zf: float = z * fr
		var xi := floori(xf)
		var zi := floori(zf)
		var tx := xf - float(xi)
		var tz := zf - float(zi)
		var sx := tx * tx * (3.0 - 2.0 * tx)
		var sz := tz * tz * (3.0 - 2.0 * tz)
		var v00 := _hash2(xi, zi, o)
		var v10 := _hash2(xi + 1, zi, o)
		var v01 := _hash2(xi, zi + 1, o)
		var v11 := _hash2(xi + 1, zi + 1, o)
		h += amp * lerpf(lerpf(v00, v10, sx), lerpf(v01, v11, sx), sz)
		amp *= 0.5
		fr *= 2.0
	return h - 0.875  # center around 0


## Public ground-height API. Flat (0.0) unless activation is on AND the point
## is inside the active zone; ramps to 0 at the zone border (no cliffs).
static func height_at(x: float, z: float) -> float:
	if not activate or active_zone.size == Rect2().size:
		return 0.0
	if not active_zone.has_point(Vector2(x, z)):
		return 0.0
	var edge := 30.0
	var dxl: float = clampf((x - active_zone.position.x) / edge, 0.0, 1.0)
	var dxr: float = clampf((active_zone.end.x - x) / edge, 0.0, 1.0)
	var dzl: float = clampf((z - active_zone.position.y) / edge, 0.0, 1.0)
	var dzr: float = clampf((active_zone.end.y - z) / edge, 0.0, 1.0)
	var mask: float = minf(minf(dxl, dxr), minf(dzl, dzr))
	return _noise2(x, z) * AMPLITUDE * mask


## Build the visual/physical heightfield mesh for the active zone (no-op while
## flat). ~4 m cells; collision matches the visible mesh exactly.
static func build_patch(root: Node3D) -> Node:
	if not activate or active_zone.size == Rect2().size:
		return null
	var size := active_zone.size
	var steps := maxi(maxi(int(size.x / 4.0), int(size.y / 4.0)), 8)
	var verts := PackedVector3Array()
	var uvs := PackedVector2Array()
	for zz in range(steps + 1):
		for xx in range(steps + 1):
			var fx := float(xx) / steps
			var fz := float(zz) / steps
			var wx := active_zone.position.x + fx * size.x
			var wz := active_zone.position.y + fz * size.y
			verts.append(Vector3(fx * size.x - size.x * 0.5, height_at(wx, wz),
					fz * size.y - size.y * 0.5))
			uvs.append(Vector2(fx, fz))
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for zz in range(steps):
		for xx in range(steps):
			var a := zz * (steps + 1) + xx
			st.add_index(a)
			st.add_index(a + steps + 1)
			st.add_index(a + 1)
			st.add_index(a + 1)
			st.add_index(a + steps + 1)
			st.add_index(a + steps + 2)
	for i in range(verts.size()):
		st.set_uv(uvs[i])
		st.add_vertex(verts[i])
	var arr_mesh := st.commit()
	var mi := MeshInstance3D.new()
	mi.name = "TerrainPatch"
	mi.mesh = arr_mesh
	mi.position = Vector3(active_zone.position.x + size.x * 0.5, 0.0,
			active_zone.position.y + size.y * 0.5)
	var body := StaticBody3D.new()
	body.name = "TerrainBody"
	var cs := CollisionShape3D.new()
	var shape := ConcavePolygonShape3D.new()
	shape.set_faces(arr_mesh.get_faces())
	cs.shape = shape
	body.add_child(cs)
	mi.add_child(body)
	root.add_child(mi)
	return mi
