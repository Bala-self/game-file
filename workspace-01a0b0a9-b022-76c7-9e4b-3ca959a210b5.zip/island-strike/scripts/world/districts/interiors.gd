class_name WBDInteriors
extends Object
## Fixed enterable interiors: downtown storefronts, harbor office, warehouse.

const K := preload("res://scripts/world/wb_kit.gd")
const A := preload("res://scripts/world/wb_arch.gd")

static func _build_interiors(root: Node3D) -> void:
	var kits := ["shop", "bar", "shop", "office", "house", "bar"]
	var spots: Array = [
		[Vector2(-253, -160), 3], [Vector2(-253, -200), 3], [Vector2(-253, -240), 3],
		[Vector2(-281, -160), 1], [Vector2(-281, -200), 1], [Vector2(-281, -240), 1],
	]
	for i in range(spots.size()):
		var xz: Vector2 = spots[i][0]
		A._build_interior_building(root, xz, Vector2(10, 8), 4.5, Color(0.5, 0.42, 0.36),
				kits[i], "Store", spots[i][1])
		K._decal_box(root, Vector3(3.4, 0.8, 0.2), xz + (Vector2(-5.3, 0) if spots[i][1] == 3
				else Vector2(5.3, 0)), 4.0, Color(0.9, 0.6, 0.15), "StoreSign")
	A._build_interior_building(root, Vector2(-560, 230), Vector2(8, 6), 3.6,
			Color(0.55, 0.58, 0.62), "office", "HarborOffice", 3)
	A._build_interior_building(root, Vector2(420, 270), Vector2(24, 16), 8.0,
			Color(0.45, 0.42, 0.4), "warehouse", "Warehouse", 3)
