class_name WBDAirport
extends Object
## Airport: runway, taxiway, terminal, hangar, aprons.

const K := preload("res://scripts/world/wb_kit.gd")
const A := preload("res://scripts/world/wb_arch.gd")

static func _build_airport(root: Node3D, rng: RandomNumberGenerator) -> void:
	K._decal_box(root, Vector3(190, 0.05, 20), Vector2(330, -280), 0.05, Color(0.25, 0.25, 0.27), "Runway")
	for i in range(9):
		K._decal_box(root, Vector3(8, 0.06, 0.6), Vector2(250 + i * 20, -280), 0.06,
				Color(0.9, 0.9, 0.9), "RunwayMark")
	K._box(root, Vector3(44, 9, 16), Vector2(330, -245), 9.0, Color(0.55, 0.65, 0.75))
	A._building_detail(root, Vector3(44, 9, 16), Vector2(330, -245), 9.0, 2)
	K._cyl(root, 2.4, 26.0, Vector2(295, -245), 26.0, Color(0.7, 0.7, 0.72))
	K._box(root, Vector3(8, 4, 8), Vector2(295, -245), 30.0, Color(0.3, 0.4, 0.5), false)
	for hx: float in [260.0, 400.0]:
		K._box(root, Vector3(30, 11, 20), Vector2(hx, -250), 11.0, Color(0.58, 0.6, 0.62))
	var px := Vector2(360, -280)
	K._cyl(root, 1.6, 18.0, px, 3.4, Color(0.9, 0.9, 0.92)).rotation_degrees = Vector3(0, 0, 90)
	K._box(root, Vector3(16, 0.5, 2.6), px, 3.0, Color(0.85, 0.85, 0.88), false)
	K._box(root, Vector3(0.4, 4.0, 3.0), px + Vector2(-8.4, 0), 5.6, Color(0.85, 0.85, 0.88), false)
