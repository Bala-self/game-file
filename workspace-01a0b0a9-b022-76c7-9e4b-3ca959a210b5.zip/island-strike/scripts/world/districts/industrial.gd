class_name WBDIndustrial
extends Object
## Industrial zone: warehouses, tanks, containers, silos.

const K := preload("res://scripts/world/wb_kit.gd")
const A := preload("res://scripts/world/wb_arch.gd")

static func _build_industrial(root: Node3D, rng: RandomNumberGenerator) -> void:
	for wx: float in [160.0, 240.0, 320.0, 390.0]:
		K._box(root, Vector3(34, 13, 20), Vector2(wx, 110), 13.0, Color(0.5, 0.48, 0.45))
		K._box(root, Vector3(35, 1.5, 21), Vector2(wx, 110), 14.5, Color(0.4, 0.4, 0.42), false)
		A._building_detail(root, Vector3(34, 13, 20), Vector2(wx, 110), 13.0, 3)
	for i in range(9):
		var cxz := Vector2(rng.randf_range(140, 400), rng.randf_range(160, 290))
		if K._road_point_free(cxz, 9.0):
			var col: Color = K.CONTAINER_COLORS[i % K.CONTAINER_COLORS.size()]
			K._box(root, Vector3(6.1, 2.6, 2.5), cxz, 2.6, col)
	K._box(root, Vector3(2, 22, 2), Vector2(415, 150), 22.0, Color(0.8, 0.35, 0.2))
	K._box(root, Vector3(2, 22, 2), Vector2(415, 190), 22.0, Color(0.8, 0.35, 0.2))
	K._box(root, Vector3(2, 2, 60), Vector2(415, 170), 23.0, Color(0.8, 0.35, 0.2), false)
	for sx: float in [200.0, 230.0]:
		K._cyl(root, 5.0, 16.0, Vector2(sx, 250), 16.0, Color(0.75, 0.75, 0.72))
