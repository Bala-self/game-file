class_name WBDSuburbs
extends Object
## Suburban residential fabric (house palette, gardens, interiors).

const K := preload("res://scripts/world/wb_kit.gd")
const A := preload("res://scripts/world/wb_arch.gd")

static func _build_suburbs(root: Node3D, rng: RandomNumberGenerator) -> void:
	var placed := 0
	for i in range(40):
		if placed >= 15:
			break
		var xz := Vector2(rng.randf_range(-90, 235), rng.randf_range(-250, -95))
		if not K._road_point_free(xz, 12.0):
			continue
		var near_service := false
		for s: Vector2 in [Vector2(K.GAS_SPOT.x, K.GAS_SPOT.z), K.SCHOOL_SPOT, K.HOSPITAL_SPOT]:
			if xz.distance_to(s) < 20.0:
				near_service = true
		if near_service:
			continue
		var col: Color = K.HOUSE_PALETTE[placed % K.HOUSE_PALETTE.size()]
		if placed % 2 == 1:
			# enterable variant: hollow kit house, no solid shell / door decal
			var hbody := A._build_interior_building(root, xz, Vector2(9, 7), 5.5, col,
					"house", "House", 0)
			hbody.set_meta("kind", "house")
			A._building_detail(root, Vector3(9, 5.5, 7), xz, 5.5, 1)
		else:
			var body := K._box(root, Vector3(9, 5.5, 7), xz, 5.5, col)
			K._box(root, Vector3(10, 2.2, 8), xz, 7.7, Color(0.45, 0.28, 0.2), false)
			K._box(root, Vector3(1.4, 2.4, 0.2), xz + Vector2(0, 3.6), 2.4, Color(0.35, 0.25, 0.15), false)
			A._building_detail(root, Vector3(9, 5.5, 7), xz, 5.5, 1)
			body.set_meta("kind", "house")
		# front yard bush
		if rng.randf() < 0.5:
			K._bush(root, xz + Vector2(rng.randf_range(-6, 6), 7.0), rng)
		placed += 1
