class_name WBCoast
extends Object
## Coast pack: lighthouse islet, offshore island, beach pier, shore dressing.

const K := preload("res://scripts/world/wb_kit.gd")
const A := preload("res://scripts/world/wb_arch.gd")

static func _build_lighthouse(root: Node3D) -> void:
	var base := Vector2(-505, 380)
	# rock islet base (walkable)
	var rock := K._box(root, Vector3(26, 3.0, 22), base, 3.0, Color(0.35, 0.34, 0.32), true,
			"LighthouseRock")
	rock.get_child(0).visibility_range_end = 1200.0
	for i in range(5):
		var off := Vector2(cos(TAU * i / 5.0), sin(TAU * i / 5.0)) * 13.0
		var boulder := K._box(root, Vector3(3.5, 2.2, 3.5), base + off, 2.4,
				Color(0.32, 0.31, 0.3), true, "CoastRock")
		boulder.rotation = Vector3(0, TAU * i / 5.0, 0.12)
		boulder.get_child(0).visibility_range_end = 900.0
	# tower: white with red bands
	var tower_h := 18.0
	for seg in range(3):
		var col := Color(0.92, 0.92, 0.94) if seg % 2 == 0 else Color(0.78, 0.16, 0.14)
		var t := K._cyl(root, 1.7 - seg * 0.25, tower_h / 3.0, base, 3.0 + tower_h / 3.0 * (seg + 1),
				col, true, 12)
		t.get_child(0).visibility_range_end = 1500.0
	var lamp_room := K._cyl(root, 1.2, 1.6, base, 3.0 + tower_h + 1.6, Color(0.15, 0.15, 0.17),
			false, 10)
	lamp_room.get_child(0).visibility_range_end = 1500.0
	var lamp := OmniLight3D.new()
	lamp.light_color = Color(1.0, 0.85, 0.5)
	lamp.omni_range = 60.0
	lamp.light_energy = 0.0  # night system drives it
	lamp.position = Vector3(base.x, 3.0 + tower_h + 0.8, base.y)
	lamp.add_to_group("lighthouse_lights")
	root.add_child(lamp)
	var glow := MeshInstance3D.new()
	var gm := SphereMesh.new()
	gm.radius = 0.7
	gm.height = 1.4
	var gmat := StandardMaterial3D.new()
	gmat.albedo_color = Color(1.0, 0.9, 0.55)
	gmat.emission_enabled = true
	gmat.emission = Color(1.0, 0.85, 0.4)
	gmat.emission_energy_multiplier = 1.4
	gm.material = gmat
	glow.mesh = gm
	glow.position = lamp.position
	root.add_child(glow)


## Offshore island east of the mainland: swim/boat destination with palms,
## rocks, a small dock and a lookout cairn.

static func _build_offshore_island(root: Node3D) -> void:
	var base := Vector2(700, 0)
	var mound := K._box(root, Vector3(46, 2.2, 34), base, 2.2, Color(0.72, 0.66, 0.48), true,
			"OffshoreIsland")
	mound.get_child(0).visibility_range_end = 1600.0
	var grass := K._decal_box(root, Vector3(38, 0.08, 26), base, 2.3, Color(0.42, 0.6, 0.32),
			"OffshoreGrass")
	grass.visibility_range_end = 1200.0
	for i in range(4):
		var px := base + Vector2(-14 + (i % 2) * 26, -8 + (i / 2) * 17)
		var trunk := K._cyl(root, 0.22, 6.0, px, 8.2, Color(0.5, 0.38, 0.22), false, 8)
		trunk.add_to_group("veg")
		for l in range(5):
			var ang := TAU * l / 5.0
			var leaf := MeshInstance3D.new()
			var lm := BoxMesh.new()
			lm.size = Vector3(3.0, 0.1, 0.8)
			lm.material = K._mat(Color(0.2, 0.55, 0.2))
			leaf.mesh = lm
			leaf.position = Vector3(px.x, 8.2, px.y) + Vector3(cos(ang) * 1.3, -0.1, sin(ang) * 1.3)
			leaf.rotation_degrees = Vector3(0, rad_to_deg(-ang) + 90.0, -16.0)
			leaf.visibility_range_end = 700.0
			leaf.add_to_group("veg")
			root.add_child(leaf)
	for i in range(3):
		var rxz := base + Vector2(16 - i * 14, 12 - i * 11)
		var boulder := K._box(root, Vector3(2.6, 1.8, 2.6), rxz, 3.0, Color(0.36, 0.35, 0.34),
				true, "CoastRock")
		boulder.get_child(0).visibility_range_end = 900.0
	# west-facing dock (mooring for future boats)
	var dock := K._box(root, Vector3(14, 0.5, 4.0), base + Vector2(-27, 0), 1.6,
			Color(0.5, 0.38, 0.25), true, "OffshoreDock")
	dock.get_child(0).visibility_range_end = 1000.0
	for px in [-31.0, -23.0]:
		K._box(root, Vector3(0.4, 2.0, 0.4), base + Vector2(px, 1.6), 0.4,
				Color(0.42, 0.32, 0.2), false, "DockPile")
	# lookout cairn + flag = "you found it" silhouette
	K._box(root, Vector3(1.2, 2.6, 1.2), base + Vector2(0, -2), 4.8, Color(0.45, 0.44, 0.42),
			true, "Cairn")
	K._box(root, Vector3(0.1, 3.0, 0.1), base + Vector2(0, -2), 7.8, Color(0.6, 0.6, 0.62),
			false, "Flagpole")
	K._decal_box(root, Vector3(1.4, 0.9, 0.05), base + Vector2(0.7, -2), 7.3,
			Color(0.85, 0.25, 0.2), "Flag")


## Beach pier: walkable boardwalk into the ocean with piles, benches, crates.

static func _build_beach_pier(root: Node3D) -> void:
	var z := -40.0
	var deck_y := 0.9
	for i in range(6):
		var x := -455.0 - i * 11.0
		var seg := K._box(root, Vector3(11.4, 0.4, 6.0), Vector2(x, z), deck_y,
				Color(0.55, 0.42, 0.28), true, "PierDeck")
		seg.get_child(0).visibility_range_end = 700.0
		for pz in [-2.4, 2.4]:
			K._box(root, Vector3(0.5, 3.0, 0.5), Vector2(x, z + pz), -0.5,
					Color(0.42, 0.32, 0.2), false, "PierPile")
		if i % 2 == 0:
			K._box(root, Vector3(1.8, 0.45, 0.5), Vector2(x + 2.0, z - 2.2), deck_y + 0.7,
					Color(0.5, 0.38, 0.26), false, "PierBench")
	# end platform + rail + crates (fishing spot)
	var end_x := -521.0
	var end := K._box(root, Vector3(10, 0.4, 12), Vector2(end_x, z), deck_y,
			Color(0.55, 0.42, 0.28), true, "PierDeck")
	end.get_child(0).visibility_range_end = 700.0
	K._box(root, Vector3(10, 0.9, 0.25), Vector2(end_x, z - 5.8), deck_y + 1.3,
			Color(0.45, 0.34, 0.22), false, "PierRail")
	for c in range(3):
		K._box(root, Vector3(1.0, 0.7, 1.0), Vector2(end_x + 2.5 - c * 2.5, z + 3.5),
				deck_y + 0.8, Color(0.5, 0.42, 0.3), true, "PierCrate")
	# shore ramp up to deck height
	K._box(root, Vector3(6.0, 0.35, 6.0), Vector2(-448.0, z), 0.55, Color(0.6, 0.47, 0.32),
			true, "PierRamp")


## Marina breakwater + channel buoys + beach dressing (umbrellas, lifeguard
## hut, driftwood) + seawall segments on the north shore.

static func _build_coast_dressing(root: Node3D) -> void:
	# breakwater: big rocks shielding the marina mouth
	for i in range(7):
		var p := Vector2(-575 + i * 7.0, 262 + i * 1.5)
		var rock := K._box(root, Vector3(5.0, 2.6, 5.0), p, 1.6, Color(0.33, 0.32, 0.31),
				true, "BreakwaterRock")
		rock.rotation = Vector3(0.05, TAU * i / 7.0, 0.08)
		rock.get_child(0).visibility_range_end = 900.0
	# channel buoys: emissive, easy to spot at dusk
	for i in range(5):
		var p := Vector2(-520 + i * 45.0, 300 + (i % 2) * 18)
		var buoy := K._box(root, Vector3(1.0, 1.0, 1.0), p, 0.1, Color(0.9, 0.35, 0.2),
				false, "Buoy")
		var bm: MeshInstance3D = buoy.get_child(0)
		(bm.mesh as BoxMesh).material.emission_enabled = true
		(bm.mesh as BoxMesh).material.emission = Color(1.0, 0.3, 0.15)
		(bm.mesh as BoxMesh).material.emission_energy_multiplier = 1.2
		bm.visibility_range_end = 800.0
	# beach umbrellas + towels near the beach promenade
	for i in range(6):
		var p := Vector2(-470 + (i % 3) * 14.0, -150 + (i / 3) * 90.0)
		K._box(root, Vector3(0.12, 2.4, 0.12), p, 2.4, Color(0.85, 0.85, 0.88), false,
				"UmbrellaPole")
		var canopy := MeshInstance3D.new()
		var cm := CylinderMesh.new()
		cm.top_radius = 0.1
		cm.bottom_radius = 1.9
		cm.height = 0.7
		cm.material = K._mat([Color(0.9, 0.3, 0.25), Color(0.2, 0.5, 0.85),
				Color(0.95, 0.8, 0.2)][i % 3])
		canopy.mesh = cm
		canopy.position = Vector3(p.x, 2.6, p.y)
		canopy.visibility_range_end = 420.0
		canopy.add_to_group("veg")
		root.add_child(canopy)
		K._decal_box(root, Vector3(1.6, 0.04, 2.6), p + Vector2(1.8, 0), 0.05,
				[Color(0.85, 0.8, 0.6), Color(0.4, 0.65, 0.8)][i % 2], "BeachTowel")
	# lifeguard hut on stilts
	var lg := Vector2(-470, -60)
	for px in [-1.6, 1.6]:
		for pz in [-1.6, 1.6]:
			K._box(root, Vector3(0.35, 2.6, 0.35), lg + Vector2(px, pz), 2.6,
					Color(0.6, 0.45, 0.3), false, "LifeguardStilt")
	K._box(root, Vector3(4.4, 2.4, 4.4), lg, 5.0, Color(0.85, 0.3, 0.25), true, "LifeguardHut")
	K._box(root, Vector3(5.0, 0.3, 5.0), lg, 5.35, Color(0.7, 0.22, 0.18), false, "LifeguardRoof")
	# driftwood + seaweed clumps along the tide line
	for i in range(5):
		var p := Vector2(-500 + i * 12.0, 60 + i * 55.0)
		var log := K._box(root, Vector3(0.4, 0.35, 3.2), p, 0.18, Color(0.45, 0.36, 0.28),
				false, "Driftwood")
		log.rotation.y = K.rng_global.randf() * TAU
		log.get_child(0).visibility_range_end = 380.0
	# seawall: low wall on the north shore behind the guardrail line
	for x in range(-380, 381, 60):
		K._box(root, Vector3(56, 1.2, 0.8), Vector2(x, -355), 1.2, Color(0.58, 0.58, 0.6),
				true, "Seawall")


## Rail corridor farmland -> industrial -> port: sleepers, rails, freight
## cars, small depot, signals. Static (rolling stock comes with the train
## system phase).
