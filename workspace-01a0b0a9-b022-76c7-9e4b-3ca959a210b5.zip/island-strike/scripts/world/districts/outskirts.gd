class_name WBDOutskirts
extends Object
## Outskirt transition strips bridging suburbs/farmland/industrial edges.

const K := preload("res://scripts/world/wb_kit.gd")
const A := preload("res://scripts/world/wb_arch.gd")

static func _build_outskirts(root: Node3D) -> void:
	# workshops / small commerce along the south link road
	for i in range(3):
		var p := Vector2(90 + i * 26.0, 128.0)
		A._building(root, p, Vector3(12, 5, 9),
				{"style": "plaster", "ground": "shop", "name": "OutskirtShop", "ac": 1}, K.rng_global)
	# storage sheds at the farmland shoulder
	for i in range(2):
		var p := Vector2(-160 + i * 40.0, 120.0)
		K._box(root, Vector3(10, 4.5, 8), p, 4.5, Color(0.55, 0.5, 0.42), true, "OutskirtShed")
		K._box(root, Vector3(11, 1.0, 9), p, 5.2, Color(0.4, 0.3, 0.2), false)


## Facade helper: adds window bands (emissive at night) + rooftop machinery.
