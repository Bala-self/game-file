class_name WBDDowntown
extends Object
## Downtown core: tower blocks with height-class census, stadium,
## multi-storey parking, gas station, school + hospital, construction site.

const K := preload("res://scripts/world/wb_kit.gd")
const A := preload("res://scripts/world/wb_arch.gd")

static func _build_downtown(root: Node3D, rng: RandomNumberGenerator) -> void:
	var defs: Array = []
	for gx in range(7):
		for gz in range(5):
			var x := -390.0 + gx * 42.0
			var z := -270.0 + gz * 62.0
			var xz := Vector2(x, z)
			if not K._road_point_free(xz, 12.0):
				continue
			defs.append(xz)
	K.dt_heights.clear()
	var reserved := {"police": 5, "hotel": 7, "store": 11, "rest": 13}
	for i in range(defs.size()):
		var xz: Vector2 = defs[i]
		var w := rng.randf_range(15.0, 24.0)
		var d := rng.randf_range(15.0, 24.0)
		# civic + service landmarks occupy reserved grid cells (road-free by design)
		if i == reserved.get("police", -1) and defs.size() > 5:
			A._building(root, xz, Vector3(20, 14, 16), {"style": "concrete", "name": "PoliceStation",
					"sign": "POLICE", "sign_color": Color(0.25, 0.5, 0.95), "ac": 2}, rng)
			K.dt_heights.append(14.0)
			continue
		if i == reserved.get("hotel", -1) and defs.size() > 7:
			A._building(root, xz, Vector3(22, 55, 18), {"style": "glass", "ground": "shop",
					"name": "Hotel", "sign": "HOTEL", "ac": 3}, rng)
			K.dt_heights.append(55.0)
			continue
		if i == reserved.get("store", -1) and defs.size() > 11:
			# enterable convenience store (kit interior, faces the road)
			A._build_interior_building(root, xz, Vector2(12, 10), 5.0, Color(0.72, 0.66, 0.5),
					"shop", "Store", 0)
			K._decal_box(root, Vector3(6, 0.9, 0.2), xz + Vector2(0, 5.05), 4.6,
					Color(0.95, 0.45, 0.15), "StoreSign")
			K.qa_rects.append(Rect2(xz - Vector2(6, 5), Vector2(12, 10)))
			K.dt_heights.append(5.0)
			continue
		if i == reserved.get("rest", -1) and defs.size() > 13:
			A._build_interior_building(root, xz, Vector2(14, 11), 5.5, Color(0.6, 0.4, 0.34),
					"bar", "Restaurant", 0)
			K._decal_box(root, Vector3(7, 0.9, 0.2), xz + Vector2(0, 5.55), 5.0,
					Color(0.85, 0.2, 0.3), "RestaurantSign")
			K.qa_rects.append(Rect2(xz - Vector2(7, 5.5), Vector2(14, 11)))
			K.dt_heights.append(5.5)
			continue
		var h: float
		if i == 3:
			h = 95.0
			var tower := K._box(root, Vector3(24, h, 24), xz, h, Color(0.35, 0.4, 0.5), true, "IslandTower")
			tower.set_meta("landmark", true)
			K._box(root, Vector3(6, 10, 6), xz, h + 10.0, Color(0.3, 0.3, 0.35), false)
			A._building_detail(root, Vector3(24, h, 24), xz, h, 22)
			var beacon := OmniLight3D.new()
			beacon.light_color = Color(1, 0.2, 0.2)
			beacon.omni_range = 30.0
			beacon.light_energy = 2.0
			beacon.position = Vector3(xz.x, h + 14.0, xz.y)
			beacon.add_to_group("beacons")
			root.add_child(beacon)
			continue
		# height classes: LOW 1-2F / MEDIUM 3-6F / TALL 7-12F (district texture)
		var cls := rng.randf()
		if cls < 0.25:
			h = rng.randf_range(8.0, 14.0)
		elif cls < 0.8:
			h = rng.randf_range(16.0, 38.0)
		else:
			h = rng.randf_range(42.0, 75.0)
		K.dt_heights.append(h)
		var style: String = ["concrete", "brick", "plaster", "glass"][rng.randi() % 4]
		var ground := "shop" if (h < 15.0 and rng.randf() < 0.6) else "plain"
		A._building(root, xz, Vector3(w, h, d),
				{"style": style, "ground": ground, "ac": rng.randi_range(1, 3),
				"name": "DTower"}, rng)
	# stepped tower silhouette variation: 2 "twin" setbacks
	for bxz: Vector2 in [Vector2(-222, -228), Vector2(138, -102)]:
		if K._road_point_free(bxz, 12.0):
			A._building(root, bxz, Vector3(18, 52, 18), {"style": "concrete", "name": "Twin",
					"ac": 3}, rng)
			K._box(root, Vector3(12, 20, 12), bxz, 72.0, Color(0.48, 0.5, 0.56), false)
			K.dt_heights.append(52.0)

static func _build_stadium(root: Node3D) -> void:
	var xz := Vector2(-300, 100)
	K._cyl(root, 42.0, 17.0, xz, 17.0, Color(0.62, 0.62, 0.66), true, 28)
	K._cyl(root, 33.0, 0.6, xz, 0.4, Color(0.3, 0.6, 0.3), false, 28)
	for i in range(4):
		var ang := TAU * i / 4.0
		var lxz := xz + Vector2(cos(ang), sin(ang)) * 46.0
		K._box(root, Vector3(1.6, 26.0, 1.6), lxz, 26.0, Color(0.5, 0.5, 0.55))
		K._box(root, Vector3(6.0, 1.6, 1.6), lxz, 25.0, Color(0.9, 0.9, 0.7), false)

static func _build_parking_structure(root: Node3D) -> void:
	var xz := K.PARKING_XZ
	var col := Color(0.52, 0.53, 0.56)
	for px in range(-10, 11, 10):
		for pz in range(-13, 14, 13):
			K._box(root, Vector3(1.2, 9.0, 1.2), xz + Vector2(px, pz), 9.0, col.darkened(0.1), true, "Pillar")
	K._box(root, Vector3(22, 0.5, 26), xz + Vector2(-5.5, 0), 4.5, col, true, "ParkingL1")
	K._box(root, Vector3(22, 0.5, 26), xz + Vector2(5.5, 0), 9.0, col, true, "ParkingRoof")
	A._ramp(root, xz + Vector2(-16.0, 0), 16.0, 4.5, 12.0, col)
	A._ramp(root, xz + Vector2(0.0, 0), 16.0, 4.5, 12.0, col, 4.5)
	K._box(root, Vector3(22, 1.0, 0.6), xz + Vector2(5.5, -12.8), 10.0, col.darkened(0.2), true)
	K._box(root, Vector3(22, 1.0, 0.6), xz + Vector2(5.5, 12.8), 10.0, col.darkened(0.2), true)
	K._box(root, Vector3(0.6, 1.0, 26), xz + Vector2(16.2, 0), 10.0, col.darkened(0.2), true)
	A._build_interior_building(root, xz + Vector2(0, 16.0), Vector2(10, 8), 3.5, Color(0.42, 0.44, 0.5), "office", "ParkingOffice", 2)
	var sign := K._decal_box(root, Vector3(7, 1.0, 0.2), xz + Vector2(0, 12.0), 4.6,
			Color(0.2, 0.6, 0.9), "ParkingSign")
	sign.position.y = 4.1

static func _build_gas_station(root: Node3D) -> void:
	var xz := Vector2(K.GAS_SPOT.x, K.GAS_SPOT.z)
	for p in [Vector2(-5, -4), Vector2(5, -4), Vector2(-5, 4), Vector2(5, 4)]:
		K._box(root, Vector3(0.8, 4.5, 0.8), xz + p, 4.5, Color(0.8, 0.8, 0.82), true, "CanopyPillar")
	K._box(root, Vector3(16, 0.8, 12), xz, 5.3, Color(0.9, 0.35, 0.2), false, "Canopy")
	for px in [-3.0, 3.0]:
		K._box(root, Vector3(0.9, 1.6, 0.6), xz + Vector2(px, 0), 1.6, Color(0.85, 0.85, 0.88), true, "Pump")
	A._build_interior_building(root, xz + Vector2(0, 11.0), Vector2(9, 7), 3.6, Color(0.88, 0.86, 0.8), "shop", "GasShop", 2)
	K._decal_box(root, Vector3(6, 0.9, 0.2), xz + Vector2(0, 7.4), 4.4, Color(0.9, 0.3, 0.2), "GasSign")
	K._decal_box(root, Vector3(10, 0.05, 8), xz, 0.05, Color(0.35, 0.36, 0.38), "GasApron")

static func _build_school_and_hospital(root: Node3D) -> void:
	var s := K.SCHOOL_SPOT
	A._build_interior_building(root, s, Vector2(26, 14), 7.0, Color(0.75, 0.7, 0.55), "school", "School", 0)
	K._box(root, Vector3(27, 1.0, 15), s, 8.0, Color(0.5, 0.35, 0.25), false)
	A._building_detail(root, Vector3(26, 7, 14), s, 7.0, 2)
	K._decal_box(root, Vector3(5, 1.0, 0.2), s + Vector2(0, 7.2), 5.6, Color(0.2, 0.45, 0.75), "SchoolSign")
	for i in range(4):
		K._box(root, Vector3(2.2, 0.5, 0.7), s + Vector2(-8 + i * 5.2, 12), 0.55,
				Color(0.5, 0.36, 0.22), false, "SchoolBench")
	var h := K.HOSPITAL_SPOT
	A._build_interior_building(root, h, Vector2(20, 14), 16.0, Color(0.92, 0.93, 0.95), "medical", "Hospital", 2)
	A._building_detail(root, Vector3(20, 16, 14), h, 16.0, 4)
	var cross_v := K._decal_box(root, Vector3(1.2, 3.6, 0.25), h + Vector2(0, 7.2), 13.0,
			Color(0.85, 0.15, 0.15), "CrossV")
	cross_v.position.y = 11.2
	var cross_h := K._decal_box(root, Vector3(3.6, 1.2, 0.25), h + Vector2(0, 7.2), 12.2,
			Color(0.85, 0.15, 0.15), "CrossH")
	cross_h.position.y = 11.2

static func _build_construction_site(root: Node3D) -> void:
	var xz := Vector2(-120, -30)
	K._decal_box(root, Vector3(26, 0.06, 22), xz, 0.06, Color(0.55, 0.45, 0.3), "SiteDirt")
	K._box(root, Vector3(1.6, 24.0, 1.6), xz + Vector2(-8, -6), 24.0, Color(0.9, 0.6, 0.1), true, "CraneMast")
	K._box(root, Vector3(26, 1.4, 1.4), xz + Vector2(2, -6), 25.0, Color(0.9, 0.6, 0.1), false, "CraneJib")
	K._box(root, Vector3(1.0, 0.4, 22.0), xz + Vector2(-8, -6), 25.4, Color(0.9, 0.6, 0.1), false, "CraneCounter")
	for i in range(3):
		K._cyl(root, 0.9, 0.4, xz + Vector2(6 + i * 2.2, 5), 0.5, Color(0.65, 0.65, 0.62), true, 12)
	for i in range(5):
		K._box(root, Vector3(2.4, 0.9, 0.4), xz + Vector2(-4, 7), 0.9, Color(0.85, 0.6, 0.1), true, "Barrier")
	for i in range(6):
		var cone := MeshInstance3D.new()
		var cm := CylinderMesh.new()
		cm.top_radius = 0.05
		cm.bottom_radius = 0.3
		cm.height = 0.75
		cm.material = K._mat(Color(1.0, 0.45, 0.1))
		cone.mesh = cm
		var off := Vector2(cos(TAU * i / 6.0), sin(TAU * i / 6.0)) * 9.0
		cone.position = Vector3(xz.x + off.x, 0.38, xz.y + off.y)
		cone.visibility_range_end = 200.0
		root.add_child(cone)
	A._build_interior_building(root, xz + Vector2(3, -3), Vector2(12, 10), 5.0, Color(0.6, 0.6, 0.58), "office", "SiteOffice", 0)
	for px in range(-2, 3, 2):
		K._box(root, Vector3(0.5, 4.0, 0.5), xz + Vector2(3 + px * 2.0, 4.2), 9.0,
				Color(0.7, 0.45, 0.2), false, "Scaffold")


## ---------------- modular building constructor (PHASE 01 framework) ----------
## One data-driven entry point for district architecture: foundation slab,
## styled volume (concrete/brick/plaster/glass), night-glow window bands,
## ground-floor treatment (shopfront/awning/sign), parapet roof, rooftop
## equipment (AC + antenna, culled). Footprints feed the road-overlap QA.
