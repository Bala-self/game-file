class_name WBStreetscape
extends Object
## Streetscape kits (Phase 9): per-district street-appearance specifications,
## data-driven. The dressing builders in roads.gd read their colors/sizes from
## the district's kit instead of hardcoded literals; placement math is
## UNCHANGED (count-locked smoke assertions stay valid). Each kit also defines
## one signature prop per district, placed along the district's streets by
## apply_for_district() (new names StreetKit*, streamed with their tile).
## Adding a district = adding a KITS entry; nothing else.

const K := preload("res://scripts/world/wb_kit.gd")

## kit fields:
##   planter    Color   downtown street-tree planter concrete
##   trunk      Color   street-tree trunk
##   crown      Color   street-tree crown
##   gutter     Color   drainage gutter concrete
##   bench      Color   bus-stop bench wood
##   shelter    Color   bus-stop shelter metal
##   prop_name  String  signature prop node name (StreetKit<prefix>)
##   prop_color Color   signature prop color
##   prop_size  Vector3 signature prop size (h = height)
##   prop_top   float   top-y of the signature prop
const KITS := {
	"Downtown": {
		"planter": Color(0.45, 0.44, 0.42), "trunk": Color(0.4, 0.3, 0.2),
		"crown": Color(0.22, 0.48, 0.22), "gutter": Color(0.16, 0.16, 0.18),
		"bench": Color(0.6, 0.45, 0.3), "shelter": Color(0.3, 0.32, 0.35),
		"prop_name": "NewsStand", "prop_color": Color(0.7, 0.25, 0.2),
		"prop_size": Vector3(1.4, 2.0, 0.9), "prop_top": 1.0,
	},
	"Suburbs": {
		"planter": Color(0.5, 0.48, 0.44), "trunk": Color(0.42, 0.32, 0.22),
		"crown": Color(0.28, 0.5, 0.24), "gutter": Color(0.4, 0.4, 0.4),
		"bench": Color(0.45, 0.33, 0.2), "shelter": Color(0.42, 0.44, 0.4),
		"prop_name": "Mailbox", "prop_color": Color(0.25, 0.35, 0.6),
		"prop_size": Vector3(0.5, 1.1, 0.4), "prop_top": 0.55,
	},
	"Beachfront": {
		"planter": Color(0.55, 0.52, 0.46), "trunk": Color(0.5, 0.42, 0.28),
		"crown": Color(0.3, 0.55, 0.28), "gutter": Color(0.45, 0.43, 0.4),
		"bench": Color(0.55, 0.44, 0.3), "shelter": Color(0.5, 0.5, 0.46),
		"prop_name": "ShowerPost", "prop_color": Color(0.75, 0.75, 0.72),
		"prop_size": Vector3(0.3, 2.4, 0.3), "prop_top": 1.2,
	},
	"Industrial": {
		"planter": Color(0.42, 0.42, 0.42), "trunk": Color(0.36, 0.28, 0.2),
		"crown": Color(0.24, 0.42, 0.2), "gutter": Color(0.32, 0.32, 0.34),
		"bench": Color(0.4, 0.3, 0.2), "shelter": Color(0.35, 0.37, 0.4),
		"prop_name": "Bollard", "prop_color": Color(0.8, 0.55, 0.1),
		"prop_size": Vector3(0.35, 0.9, 0.35), "prop_top": 0.45,
	},
	"Airport": {
		"planter": Color(0.48, 0.48, 0.48), "trunk": Color(0.4, 0.32, 0.24),
		"crown": Color(0.26, 0.46, 0.22), "gutter": Color(0.36, 0.36, 0.38),
		"bench": Color(0.42, 0.34, 0.24), "shelter": Color(0.38, 0.4, 0.44),
		"prop_name": "Windsock", "prop_color": Color(0.9, 0.55, 0.15),
		"prop_size": Vector3(0.16, 3.2, 0.16), "prop_top": 1.6,
	},
	"Farmland": {
		"planter": Color(0.5, 0.46, 0.4), "trunk": Color(0.44, 0.34, 0.22),
		"crown": Color(0.3, 0.52, 0.26), "gutter": Color(0.42, 0.4, 0.36),
		"bench": Color(0.48, 0.36, 0.22), "shelter": Color(0.46, 0.4, 0.32),
		"prop_name": "HayPost", "prop_color": Color(0.78, 0.66, 0.3),
		"prop_size": Vector3(0.7, 1.4, 0.7), "prop_top": 0.7,
	},
	"Military": {
		"planter": Color(0.4, 0.42, 0.38), "trunk": Color(0.34, 0.28, 0.2),
		"crown": Color(0.22, 0.4, 0.2), "gutter": Color(0.3, 0.31, 0.3),
		"bench": Color(0.36, 0.3, 0.2), "shelter": Color(0.32, 0.34, 0.32),
		"prop_name": "SandbagPost", "prop_color": Color(0.6, 0.56, 0.44),
		"prop_size": Vector3(0.9, 0.8, 0.6), "prop_top": 0.4,
	},
	"Marina": {
		"planter": Color(0.52, 0.5, 0.46), "trunk": Color(0.46, 0.38, 0.26),
		"crown": Color(0.28, 0.52, 0.26), "gutter": Color(0.42, 0.42, 0.44),
		"bench": Color(0.5, 0.4, 0.26), "shelter": Color(0.44, 0.46, 0.48),
		"prop_name": "CleatPost", "prop_color": Color(0.2, 0.22, 0.26),
		"prop_size": Vector3(0.4, 0.9, 0.4), "prop_top": 0.45,
	},
	"Park": {
		"planter": Color(0.47, 0.45, 0.41), "trunk": Color(0.42, 0.32, 0.22),
		"crown": Color(0.26, 0.5, 0.24), "gutter": Color(0.38, 0.38, 0.38),
		"bench": Color(0.52, 0.38, 0.24), "shelter": Color(0.44, 0.42, 0.4),
		"prop_name": "WaterFountain", "prop_color": Color(0.62, 0.6, 0.56),
		"prop_size": Vector3(0.8, 1.0, 0.8), "prop_top": 0.5,
	},
}


## Signature props: a handful per district, on the arterial/main street edge
## inside that district's rect. Deterministic spacing, no RNG (layout stable).
static func apply_for_district(root: Node3D, district: String, spec: Dictionary) -> void:
	var rect: Rect2 = K.DISTRICTS.get(district, Rect2())
	if rect.size == Vector2.ZERO or not KITS.has(district):
		return
	# walk the two island mains (arterial: E-W z=-67..-60; N-S x=-267..-253)
	# and place at the curb line just outside the road+sidewalk envelope
	var spots: Array[Vector2] = []
	for x in range(int(rect.position.x) + 30, int(rect.end.x) - 20, 90):
		if absf(x - -267.0) < 14.0 or absf(x - 53.0) < 14.0:
			continue  # junctions stay clear
		spots.append(Vector2(float(x), -80.0))
	for z in range(int(rect.position.y) + 30, int(rect.end.y) - 20, 90):
		if absf(z - -67.0) < 14.0 or absf(z - 143.0) < 14.0:
			continue
		spots.append(Vector2(-279.0, float(z)))
	for i in range(spots.size()):
		var p := spots[i]
		if not K._road_point_free(p, 4.0):
			continue
		K._box(root, spec.prop_size, p, spec.prop_top, spec.prop_color,
				true, "StreetKit" + spec.prop_name)
