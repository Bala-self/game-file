class_name WBDMilitary
extends Object
## Military base: walls, barracks, watchtowers, pine screens.

const K := preload("res://scripts/world/wb_kit.gd")
const A := preload("res://scripts/world/wb_arch.gd")

static func _build_military(root: Node3D, rng: RandomNumberGenerator) -> void:
	var wall_col := Color(0.4, 0.42, 0.38)
	var bx := 90.0
	var bz := -300.0
	K._box(root, Vector3(160, 4, 2), Vector2(bx, bz - 35), 4.0, wall_col)
	K._box(root, Vector3(2, 4, 70), Vector2(bx - 80, bz), 4.0, wall_col)
	K._box(root, Vector3(2, 4, 70), Vector2(bx + 80, bz), 4.0, wall_col)
	K._box(root, Vector3(70, 4, 2), Vector2(bx - 45, bz + 35), 4.0, wall_col)
	K._box(root, Vector3(70, 4, 2), Vector2(bx + 45, bz + 35), 4.0, wall_col)
	K._box(root, Vector3(30, 7, 12), Vector2(bx - 40, bz - 10), 7.0, Color(0.45, 0.48, 0.4))
	K._box(root, Vector3(26, 9, 18), Vector2(bx + 40, bz - 10), 9.0, Color(0.42, 0.45, 0.4))
	for tx: float in [bx - 78.0, bx + 78.0]:
		K._box(root, Vector3(1.2, 12.0, 1.2), Vector2(tx, bz + 34), 12.0, Color(0.35, 0.3, 0.25))
		K._box(root, Vector3(4, 3, 4), Vector2(tx, bz + 34), 15.0, Color(0.4, 0.42, 0.38))
	K._cyl(root, 0.8, 20.0, Vector2(bx, bz - 30), 20.0, Color(0.6, 0.6, 0.65))
	var dish := MeshInstance3D.new()
	var dm := SphereMesh.new()
	dm.radius = 3.0
	dm.height = 3.0
	dm.material = K._mat(Color(0.75, 0.75, 0.78))
	dish.mesh = dm
	dish.position = Vector3(bx, 21.5, bz - 30)
	root.add_child(dish)
	for i in range(14):
		var pxz := Vector2(rng.randf_range(-70, 250), rng.randf_range(-345, -255))
		if K._road_point_free(pxz, 8.0):
			K._pine(root, pxz, rng)
