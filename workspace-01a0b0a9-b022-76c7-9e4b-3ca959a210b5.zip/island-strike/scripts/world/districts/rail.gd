class_name WBDRail
extends Object
## Rail corridor: sleepers, rails, freight cars, depot, signals.

const K := preload("res://scripts/world/wb_kit.gd")
const A := preload("res://scripts/world/wb_arch.gd")

static func _build_rail_yard(root: Node3D) -> void:
	var z := 250.0
	for i in range(40):
		var x := -140.0 + i * 8.0
		var sleeper := K._decal_box(root, Vector3(2.4, 0.08, 1.0), Vector2(x, z), 0.09,
				Color(0.36, 0.28, 0.2), "RailSleeper")
		sleeper.visibility_range_end = 420.0
	for rx in [-140.0, 180.0]:
		pass
	# continuous rails (two long thin boxes per side)
	for off in [-0.75, 0.75]:
		var rail := K._decal_box(root, Vector3(320, 0.12, 0.16), Vector2(20, z + off), 0.14,
				Color(0.55, 0.56, 0.58), "RailLine")
		rail.visibility_range_end = 900.0
	# freight cars (static rolling stock)
	var cols := [Color(0.5, 0.25, 0.2), Color(0.25, 0.4, 0.5), Color(0.45, 0.45, 0.3)]
	for i in range(3):
		var cx := -60.0 + i * 22.0
		var car := K._box(root, Vector3(4.4, 3.0, 18.0), Vector2(cx, z), 4.2, cols[i], true,
				"FreightCar")
		car.get_child(0).visibility_range_end = 800.0
		for wx in [-1.6, 1.6]:
			for wz in [-6.5, 6.5]:
				var wheel := K._cyl(root, 0.5, 0.3, Vector2(cx + wx, z + wz), 0.55,
						Color(0.15, 0.15, 0.16), false, 10)
				wheel.rotation = Vector3(PI / 2, 0, 0)
				wheel.get_child(0).visibility_range_end = 500.0
	# transshipment containers beside the yard
	for i in range(5):
		var p := Vector2(-130 + i * 24.0, z + 14.0)
		var cont := K._box(root, Vector3(2.6, 2.6, 7.0), p, 2.6,
				[Color(0.6, 0.3, 0.15), Color(0.15, 0.4, 0.5), Color(0.4, 0.5, 0.2)][i % 3],
				true, "YardContainer")
		cont.get_child(0).visibility_range_end = 650.0
	# small depot + signals
	A._building(root, Vector2(30, 268), Vector3(14, 6, 9),
			{"style": "metal", "roof": "flat", "name": "RailDepot", "ac": 1})
	for sx in [-100.0, 20.0, 140.0]:
		K._box(root, Vector3(0.14, 3.2, 0.14), Vector2(sx, z - 3.0), 3.2,
				Color(0.4, 0.42, 0.45), false, "RailSignalPost")
		K._decal_box(root, Vector3(0.5, 0.5, 0.1), Vector2(sx, z - 3.0), 3.5,
				Color(0.8, 0.15, 0.1), "RailSignal")


## Outskirt transition strips: small commercial sheds bridging suburbs ->
## farmland and downtown -> industrial edges (no hard zone borders).
