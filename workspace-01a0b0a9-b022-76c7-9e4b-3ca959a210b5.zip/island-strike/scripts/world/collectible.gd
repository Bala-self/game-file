extends Area3D
## Hidden collectible package: spins, glows, persists via GameState.collected.

var id := "C00"
var reward := 250
var _t := 0.0


static func create(p_id: String, p_reward: int) -> Area3D:
	var a := Area3D.new()
	a.set_script(load("res://scripts/world/collectible.gd"))
	a.set("id", p_id)
	a.set("reward", p_reward)
	return a


func _ready() -> void:
	add_to_group("collectibles")
	collision_layer = 16
	collision_mask = 2
	var col := CollisionShape3D.new()
	var s := SphereShape3D.new()
	s.radius = 1.1
	col.shape = s
	add_child(col)
	var mesh_inst := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.8, 0.8, 0.8)
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.95, 0.78, 0.15)
	m.metallic = 0.7
	m.roughness = 0.25
	m.emission_enabled = true
	m.emission = Color(0.5, 0.38, 0.05)
	m.emission_energy_multiplier = 0.8
	bm.material = m
	mesh_inst.mesh = bm
	mesh_inst.name = "Box"
	add_child(mesh_inst)
	var light := OmniLight3D.new()
	light.light_color = Color(1.0, 0.85, 0.3)
	light.omni_range = 5.0
	light.light_energy = 1.2
	add_child(light)
	body_entered.connect(_on_body)


func _process(delta: float) -> void:
	_t += delta
	var box := get_node_or_null("Box")
	if box:
		box.rotate_y(delta * 1.8)
		box.position.y = 0.9 + sin(_t * 2.0) * 0.15


func _on_body(body: Node3D) -> void:
	if not body.is_in_group("player"):
		return
	GameState.collect(id, reward)
	var snd := AudioStreamPlayer.new()
	snd.stream = load("res://assets/audio/pickup.wav")
	snd.volume_db = -3.0
	get_tree().current_scene.add_child(snd)
	snd.play()
	var t := get_tree().create_timer(0.5)
	t.timeout.connect(snd.queue_free)
	set_deferred("monitoring", false)
	queue_free()
