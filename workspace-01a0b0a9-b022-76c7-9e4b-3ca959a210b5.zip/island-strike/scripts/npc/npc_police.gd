extends "res://scripts/npc/person.gd"

const PATROL_SPEED := 3.0
## Police NPC: patrols near spawn, pursues and shoots at wanted >= 2,
## searches last known position, leaves when wanted reaches zero.

const SHOOT_RANGE := 30.0
const SHOOT_INTERVAL := 1.3

var spawn_point := Vector3.ZERO
var shoot_timer := 0.0
var last_known := Vector3.ZERO
var search_t := 0.0
var patrol_a := Vector3.ZERO
var patrol_b := Vector3.ZERO


static func create_at(spawn: Vector3) -> CharacterBody3D:
	var c := CharacterBody3D.new()
	c.set_script(load("res://scripts/npc/npc_police.gd"))
	c.set("spawn_point", spawn)
	return c


func _setup() -> void:
	kind = "cop"
	add_to_group("police")
	health = 70
	walk_speed = PATROL_SPEED  # audit #14: single source (was shadowed)
	shirt_color = Color(0.15, 0.2, 0.5)
	patrol_a = spawn_point
	patrol_b = spawn_point + Vector3(randf_range(-15, 15), 0, randf_range(-15, 15))
	state = "patrol"
	target = patrol_a


func _think(delta: float) -> void:
	var player := get_tree().get_first_node_in_group("player")
	match state:
		"patrol":
			walk_speed = PATROL_SPEED
			if global_position.distance_to(target) < 1.5:
				var tmp := patrol_a
				patrol_a = patrol_b
				patrol_b = tmp
				target = patrol_a
			# audit #15: no omniscience — pursue needs proximity or LOS
			if GameState.wanted > 0 and player and (
					global_position.distance_to(player.global_position) < 90.0
					or _has_los_to(player.global_position)):
				state = "pursue"
		"pursue":
			if GameState.wanted == 0:
				dismiss()
				return
			if player == null or not is_instance_valid(player) or player.health <= 0:
				state = "patrol"
				target = patrol_a
				return
			last_known = player.global_position
			var d := global_position.distance_to(player.global_position)
			walk_speed = 4.9
			target = player.global_position
			shoot_timer -= delta
			if d < SHOOT_RANGE and GameState.wanted >= 2 and _has_los_to(player.global_position):
				if shoot_timer <= 0.0:
					shoot_timer = SHOOT_INTERVAL
					_shoot(player)
			elif d < 55.0 and GameState.wanted >= 3:
				search_t = 8.0
		"search":
			walk_speed = 4.0
			target = last_known
			search_t -= delta
			if search_t <= 0.0:
				state = "pursue"
		"leave":
			walk_speed = 3.5
			target = spawn_point
			state_t -= delta
			if state_t <= 0.0 or global_position.distance_to(spawn_point) < 2.0:
				queue_free()


func on_gunshot(pos: Vector3) -> void:
	if state == "dead":
		return
	if GameState.wanted > 0:
		last_known = pos
		if state != "leave":
			state = "pursue"


func dismiss() -> void:
	if state != "dead" and state != "leave":
		state = "leave"
		state_t = 10.0


func _react_to_damage(_from: Vector3) -> void:
	if state != "dead" and state != "leave":
		state = "pursue"


func _shoot(player: Node3D) -> void:
	var snd := AudioStreamPlayer3D.new()
	snd.stream = load("res://assets/audio/shoot.wav")
	snd.volume_db = -8.0
	snd.max_distance = 100.0
	add_child(snd)
	snd.play()
	var t := get_tree().create_timer(0.5)
	t.timeout.connect(func() -> void:
		if is_instance_valid(snd):
			snd.queue_free())
	# tracer toward player
	var from := global_position + Vector3(0, 1.5, 0)
	var to := player.global_position + Vector3(0, 1.2, 0)
	var tracer := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = 0.012
	mesh.bottom_radius = 0.012
	mesh.height = from.distance_to(to)
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(1, 0.6, 0.3)
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mesh.material = m
	tracer.mesh = mesh
	get_tree().current_scene.add_child(tracer)
	tracer.global_position = (from + to) * 0.5
	tracer.look_at(to)
	tracer.rotate_object_local(Vector3(1, 0, 0), PI / 2)
	var tw := tracer.create_tween()
	tw.tween_property(tracer, "transparency", 1.0, 0.08)
	tw.tween_callback(tracer.queue_free)
	# audit #16: real accuracy falloff with range (was a flat 75 %)
	var d := from.distance_to(to)
	var hit_chance := clampf(0.9 - d * 0.012, 0.3, 0.85)
	if randf() < hit_chance:
		player.take_damage(randi_range(4, 8), global_position, self)
