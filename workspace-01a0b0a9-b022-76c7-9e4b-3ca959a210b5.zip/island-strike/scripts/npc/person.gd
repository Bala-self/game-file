extends CharacterBody3D
## Base person: shared body build, health, damage, death, walk movement.

signal killed(kind: String)

var health := 60
var kind := "civilian"
var walk_speed := 2.2
var state := "idle"
var state_t := 0.0
var target := Vector3.ZERO
var nav_agent: NavigationAgent3D = null
var _nav_last := Vector3(1e9, 0, 0)
var body_mat: StandardMaterial3D
var shirt_color := Color(0.7, 0.7, 0.7)
var report_cd := 0.0
var _last_hit_by: Node = null
var _los_t := 0.0
var _los_pos := Vector3.ZERO
var _los_cached := false
var _los_result := false
var rig: CharacterRig


static func create() -> CharacterBody3D:
	var p := CharacterBody3D.new()
	p.set_script(load("res://scripts/npc/person.gd"))
	return p


func _ready() -> void:
	add_to_group("npcs")
	collision_layer = 4
	collision_mask = 1 | 8
	var col := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.32
	cap.height = 1.6
	col.shape = cap
	col.position.y = 0.85
	add_child(col)

	# outfit colors are set by _setup, so run it BEFORE building the body
	_setup()
	rig = CharacterRig.create(CharacterRig.npc_outfit(shirt_color))
	add_child(rig)
	body_mat = rig.shirt_mat  # damage flash recolors the chest


## Overridden by subclasses
func _setup() -> void:
	pass


## Phase 10: opt-in navmesh pathing (NavigationAgent3D over the NavGrid map).
func enable_nav() -> void:
	nav_agent = NavigationAgent3D.new()
	nav_agent.radius = 0.35
	nav_agent.path_desired_distance = 0.8
	nav_agent.target_desired_distance = 1.2
	add_child(nav_agent)


func _steer_dir(to_target: Vector3) -> Vector3:
	if nav_agent and nav_agent.is_target_reachable():
		var next := nav_agent.get_next_path_position()
		var d := next - global_position
		d.y = 0
		if d.length() > 0.25:
			return d.normalized()
	return to_target.normalized()


func _physics_process(delta: float) -> void:
	report_cd -= delta
	_los_t = maxf(0.0, _los_t - delta)
	if state == "dead":
		if not is_on_floor():
			velocity.y -= 9.8 * delta
			move_and_slide()
		return
	# Round 9 S9: tiered think-rate (movement keeps the last directive)
	_logic_t += delta
	var hz := _logic_hz()
	if hz > 0.0 and _logic_t >= 1.0 / hz:
		_logic_t = fmod(_logic_t, 1.0 / hz)
		_think(delta)
	if not is_on_floor():
		velocity.y -= 9.8 * delta
	# re-path only when the target actually moves (map query is not free)
	if nav_agent and target != _nav_last:
		_nav_last = target
		nav_agent.target_position = target
	var to_target := target - global_position
	to_target.y = 0
	if to_target.length() > 1.0:
		var dir := _steer_dir(to_target)
		velocity.x = dir.x * walk_speed
		velocity.z = dir.z * walk_speed
		rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), 8.0 * delta)
	else:
		velocity.x = move_toward(velocity.x, 0, 10 * delta)
		velocity.z = move_toward(velocity.z, 0, 10 * delta)
	move_and_slide()

	# character rig animation: formal sim tier (Round 9 S9)
	var planar := Vector2(velocity.x, velocity.z).length()
	if rig:
		var pdist := 1e9
		var player := get_tree().get_first_node_in_group("player")
		if player:
			pdist = global_position.distance_to(player.global_position)
		rig.lod_hz = float(GameState.sim_tier(pdist)["anim_hz"]) \
				if not _holds_t0() else 60.0
		rig.animate(delta, {
			"speed": planar,
			"max_speed": 6.0,
			"on_floor": is_on_floor(),
			"vy": velocity.y,
		})


## Overridden by subclasses
func _think(_delta: float) -> void:
	pass


var _logic_t := 0.0


## Round 9 S9: route-critical classes hold full rate; combat-active gangs too
## (an NPC actively fighting must not think at 2 Hz).
func _holds_t0() -> bool:
	return kind in ["commuter", "cop", "service"] \
			or (kind == "gang" and state != "wander")


func _logic_hz() -> float:
	if _holds_t0():
		return 60.0
	var player := get_tree().get_first_node_in_group("player")
	if player == null:
		return 60.0
	var d := global_position.distance_to(player.global_position)
	return float(GameState.sim_tier(d)["logic_hz"])


func take_damage(dmg: int, from: Vector3, source: Node = null) -> void:
	if state == "dead":
		return
	health -= dmg
	body_mat.albedo_color = Color(0.8, 0.2, 0.2)
	if rig:
		rig.hit_t = 0.3
	var t := get_tree().create_timer(0.25)
	t.timeout.connect(func() -> void:
		if is_instance_valid(self) and state != "dead":
			body_mat.albedo_color = shirt_color)
	_last_hit_by = source  # audit #7: real damage source, not proximity guess
	if source != null and kind == "civilian":
		# Round 9 S6: reported scene — game.gd owns dispatch + cooldown
		get_tree().call_group("game", "on_civilian_died", global_position)
	_react_to_damage(from)
	if health <= 0:
		_die(from, source)


## Overridden by subclasses
func _react_to_damage(_from: Vector3) -> void:
	pass


func _die(from: Vector3, source: Node = null) -> void:
	state = "dead"
	collision_layer = 0
	collision_mask = 0
	killed.emit(kind)  # audit #11: signal is now part of the death flow
	GameState.stats.kills += 1
	# audit #7: attribute to the ACTUAL source (vehicles resolve to driver);
	# proximity fallback applies only to unattributed/environmental deaths
	var player := get_tree().get_first_node_in_group("player")
	var actor: Node = _last_hit_by
	if actor != null and "driver" in actor and actor.driver != null:
		actor = actor.driver
	if actor != null and actor == player:
		GameState.commit_crime(3 if kind == "cop" else 2, global_position)
	elif actor == null and player and from.distance_to(player.global_position) < 50.0:
		GameState.commit_crime(3 if kind == "cop" else 2, global_position)
	_last_hit_by = null
	# drop loot (subclasses can suppress via "no_loot" meta)
	if not has_meta("no_loot"):
		if kind == "cop":
			_drop("ammo", 12)
		elif randf() < 0.45:
			_drop("money", randi_range(30, 90))
	# audit #31: physics ragdoll replaces the topple tween
	if rig:
		rig.visible = false
		_spawn_ragdoll(from)
	var fade := get_tree().create_timer(6.0)
	fade.timeout.connect(func() -> void:
		if is_instance_valid(self):
			var t2 := create_tween()
			t2.tween_property(self, "transparency", 1.0, 1.5)
			t2.tween_callback(queue_free))


func _drop(kind_name: String, amount: int) -> void:
	var pickup: Area3D = load("res://scripts/world/pickup.gd").create(kind_name, amount)
	get_tree().current_scene.add_child(pickup)
	pickup.global_position = global_position + Vector3(randf_range(-0.5, 0.5), 0.6, randf_range(-0.5, 0.5))


## Round 9 S5: life-sim schedule — routine pedestrians favor districts by day
## phase (work downtown/industrial by day, leisure at dusk, home suburbs/
## farmland at night). Falls back to any sidewalk when a phase district has
## no road segment.
const SCHEDULE_DISTRICTS := {
	"dawn": ["Suburbs", "Farmland"],
	"day": ["Downtown", "Industrial"],
	"dusk": ["Park", "Beachfront"],
	"night": ["Suburbs", "Farmland"],
}


func _scheduled_sidewalk_point() -> Vector3:
	var districts: Dictionary = GameState.world_data.get("districts", {})
	var allowed: Array = SCHEDULE_DISTRICTS.get(GameState.day_phase(), [])
	# candidates: (road, clipped span along its long axis) — sampling only the
	# part of the road INSIDE the district keeps the pick honest when a road
	# extends past the district boundary (smoke-caught: full-span sample
	# returned out-of-district points).
	var cands: Array = []
	for road: Rect2 in GameState.world_data.get("roads", []):
		for dname: String in allowed:
			var r: Rect2 = districts.get(dname, Rect2())
			if r.size == Vector2.ZERO:
				continue
			# short-axis gate: the road must also sit inside the district
			# grown(24) on its perpendicular axis (the island perimeter roads
			# cross many districts' long-axis bands while being miles away)
			var cx := road.get_center().x
			var cz := road.get_center().y
			if road.size.x > road.size.y:
				if cz < r.position.y - 24.0 or cz > r.end.y + 24.0:
					continue
				var a := maxf(road.position.x, r.position.x)
				var b := minf(road.end.x, r.end.x)
				if b > a + 6.0:
					cands.append([road, a, b, dname])
			else:
				if cx < r.position.x - 24.0 or cx > r.end.x + 24.0:
					continue
				var a2 := maxf(road.position.y, r.position.y)
				var b2 := minf(road.end.y, r.end.y)
				if b2 > a2 + 6.0:
					cands.append([road, a2, b2, dname])
	if cands.is_empty():
		return _random_sidewalk_point()
	var pick: Array = cands[randi() % cands.size()]
	var r2: Rect2 = pick[0]
	# sidewalk side chosen TOWARD the district center so boundary-hugging
	# roads drop their walkers inside the district, not across the line
	var dcenter: Vector2 = (districts.get(pick[3], Rect2()) as Rect2).get_center()
	var side := 1.0 if randf() < 0.5 else -1.0
	if r2.size.x > r2.size.y:
		var zc: float = r2.position.y + 10.5 * side
		if absf(zc - dcenter.y) > absf(r2.position.y - 10.5 * side - dcenter.y):
			zc = r2.position.y - 10.5 * side
		return Vector3(randf_range(pick[1], pick[2]), 0, zc)
	var xc: float = r2.position.x + 10.5 * side
	if absf(xc - dcenter.x) > absf(r2.position.x - 10.5 * side - dcenter.x):
		xc = r2.position.x - 10.5 * side
	return Vector3(xc, 0, randf_range(pick[1], pick[2]))


func _random_sidewalk_point() -> Vector3:
	var roads: Array = GameState.world_data.get("roads", [])
	if roads.is_empty():
		return global_position + Vector3(5, 0, 0)
	var r: Rect2 = roads[randi() % roads.size()]
	var side := 1.0 if randf() < 0.5 else -1.0
	if r.size.x > r.size.y:
		return Vector3(randf_range(r.position.x, r.end.x), 0, r.position.y + 10.5 * side)
	return Vector3(r.position.x + 10.5 * side, 0, randf_range(r.position.y, r.end.y))


## audit #31: lightweight ragdoll — rigid limbs with an impulse along the
## kill direction; parts die with the body (the fade timer frees the node).
func _spawn_ragdoll(from: Vector3) -> void:
	var specs := [
		["head", Vector3(0, 1.55, 0), Vector3(0.24, 0.24, 0.24), 1.2],
		["torso", Vector3(0, 1.1, 0), Vector3(0.36, 0.5, 0.2), 5.0],
		["arm_l", Vector3(-0.28, 1.1, 0), Vector3(0.1, 0.5, 0.1), 1.0],
		["arm_r", Vector3(0.28, 1.1, 0), Vector3(0.1, 0.5, 0.1), 1.0],
		["leg_l", Vector3(-0.1, 0.4, 0), Vector3(0.14, 0.55, 0.14), 2.0],
		["leg_r", Vector3(0.1, 0.4, 0), Vector3(0.14, 0.55, 0.14), 2.0],
	]
	var impulse := global_position - from
	impulse.y = 0.0
	impulse = (impulse.normalized() if impulse.length() > 0.01 else Vector3.FORWARD) \
			* 2.6 + Vector3(0, 1.6, 0)
	for s: Array in specs:
		var rb := RigidBody3D.new()
		rb.name = "Rag" + str(s[0])
		var cs := CollisionShape3D.new()
		var sh := BoxShape3D.new()
		var sz: Vector3 = s[2]
		sh.size = sz
		cs.shape = sh
		rb.add_child(cs)
		var mi := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = sz
		var part: String = s[0]
		if part == "torso" or part == "arm_l" or part == "arm_r":
			bm.material = body_mat
		else:
			var pm := StandardMaterial3D.new()
			pm.albedo_color = Color(0.85, 0.68, 0.55) if part == "head" \
					else Color(0.25, 0.25, 0.3)
			bm.material = pm
		mi.mesh = bm
		rb.add_child(mi)
		rb.mass = s[3]
		rb.position = s[1]
		add_child(rb)
		rb.apply_impulse(impulse * rb.mass,
				Vector3(randf() - 0.5, randf() * 0.3, randf() - 0.5))


## audit #28: stagger raycasts — cached 0.2 s per target position instead of
## one raycast per NPC per physics frame.
func _has_los_to(pos: Vector3) -> bool:
	if _los_cached and _los_t > 0.0 and _los_pos.distance_to(pos) < 0.5:
		return _los_result
	var space := get_world_3d().direct_space_state
	var from := global_position + Vector3(0, 1.6, 0)
	var to := pos + Vector3(0, 1.4, 0)
	var q := PhysicsRayQueryParameters3D.create(from, to, 1)
	_los_result = space.intersect_ray(q).is_empty()
	_los_pos = pos
	_los_t = 0.2
	_los_cached = true
	return _los_result
