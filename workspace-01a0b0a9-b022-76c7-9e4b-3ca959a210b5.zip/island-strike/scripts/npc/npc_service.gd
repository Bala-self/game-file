extends "res://scripts/npc/person.gd"
## Nav-driven service worker (Phase 10 NPC class 5/5): hangs at a service
## point (shop / gas / safehouse / harbor office), periodically re-picks one
## via the navmesh. Distinct group so directors never touch them.

const K := preload("res://scripts/world/wb_kit.gd")

var _idle := 0.0


func _setup() -> void:
	shirt_color = Color(0.5, 0.4, 0.2)
	add_to_group("services")
	add_to_group("nav_npcs")
	health = 100.0
	walk_speed = 1.8
	enable_nav()
	target = _pick_spot()


func _pick_spot() -> Vector3:
	var spots := [K.SHOP_SPOT, K.GAS_SPOT, K.SAFEHOUSE_SPOT,
			Vector3(-564, 0.5, 226), Vector3(408, 0.5, 270)]
	var i := hash(int(global_position.x)) % spots.size()
	return spots[absi(i)]


func _think(delta: float) -> void:
	if global_position.distance_to(target) < 1.5:
		_idle += delta
		if _idle > 8.0:
			_idle = 0.0
			target = _pick_spot()
	else:
		_idle = 0.0
