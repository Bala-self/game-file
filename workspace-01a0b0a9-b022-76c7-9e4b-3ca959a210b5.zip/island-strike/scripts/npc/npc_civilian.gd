extends "res://scripts/npc/person.gd"
## Civilian NPC: wanders sidewalks, idles, flees from gunfire, may report
## crimes (raising the wanted level), cowers, then resumes routine.

var flee_from := Vector3.ZERO


static func create() -> CharacterBody3D:
	var c := CharacterBody3D.new()
	c.set_script(load("res://scripts/npc/npc_civilian.gd"))
	return c


func _setup() -> void:
	kind = "civilian"
	add_to_group("civilians")
	walk_speed = randf_range(1.8, 2.6)
	shirt_color = Color.from_hsv(randf(), 0.4, randf_range(0.55, 0.9))
	state = "walk"
	target = _scheduled_sidewalk_point()  # Round 9 S5: phase schedule


func _think(delta: float) -> void:
	state_t -= delta
	match state:
		"walk":
			walk_speed = 2.2
			if global_position.distance_to(target) < 1.5:
				state = "idle"
				state_t = randf_range(2.0, 6.0)
		"idle":
			if state_t <= 0.0:
				state = "walk"
				target = _scheduled_sidewalk_point()  # S5 schedule
		"flee":
			walk_speed = 4.6
			var away := (global_position - flee_from)
			away.y = 0
			target = global_position + away.normalized() * 20.0
			if state_t <= 0.0:
				state = "cower"
				state_t = randf_range(3.0, 6.0)
		"cower":
			if state_t <= 0.0:
				state = "walk"
				target = _scheduled_sidewalk_point()  # S5 schedule


func on_gunshot(pos: Vector3) -> void:
	if state == "dead":
		return
	var d := global_position.distance_to(pos)
	if d < 34.0:
		flee_from = pos
		state = "flee"
		state_t = randf_range(4.0, 7.0)
		if d < 24.0 and report_cd <= 0.0 and randf() < 0.5:
			report_cd = 45.0
			GameState.add_wanted(1)
			GameState.notify("A witness reported you!")
