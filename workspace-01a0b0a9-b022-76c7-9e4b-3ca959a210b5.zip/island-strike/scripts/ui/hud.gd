extends CanvasLayer
## In-game HUD: health, money, wanted stars, clock, ammo, minimap, prompts,
## notifications, damage vignette, crosshair, F3 debug overlay.

var player: CharacterBody3D
var health_bar: ProgressBar
var stamina_bar: ProgressBar
var speed_label: Label
var weapon_label: Label
var race_label: Label
var world_map: Control
var money_label: Label
var stars_label: Label
var clock_label: Label
var weather_label: Label
var ammo_label: Label
var prompt_label: Label
var crosshair: ColorRect
var vignette: ColorRect
var debug_label: Label
var notify_box: VBoxContainer
var minimap: Control
var _debug_on := false
var _ui_t := 0.0


static func create(p: CharacterBody3D) -> CanvasLayer:
	var h := CanvasLayer.new()
	h.name = "HUD"
	h.set_script(load("res://scripts/ui/hud.gd"))
	h.set("player", p)
	return h


func _ready() -> void:
	health_bar = ProgressBar.new()
	health_bar.position = Vector2(20, 20)
	health_bar.size = Vector2(260, 20)
	health_bar.min_value = 0
	health_bar.max_value = 100
	health_bar.value = 100
	health_bar.show_percentage = false
	var fill := StyleBoxFlat.new()
	fill.bg_color = Color(0.75, 0.15, 0.15)
	fill.set_corner_radius_all(4)
	health_bar.add_theme_stylebox_override("fill", fill)
	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(0, 0, 0, 0.55)
	bg.set_corner_radius_all(4)
	health_bar.add_theme_stylebox_override("background", bg)
	add_child(health_bar)

	stamina_bar = ProgressBar.new()
	stamina_bar.position = Vector2(20, 44)
	stamina_bar.size = Vector2(180, 10)
	stamina_bar.min_value = 0
	stamina_bar.max_value = 100
	stamina_bar.value = 100
	stamina_bar.show_percentage = false
	var sfill := StyleBoxFlat.new()
	sfill.bg_color = Color(0.2, 0.65, 0.25)
	sfill.set_corner_radius_all(3)
	stamina_bar.add_theme_stylebox_override("fill", sfill)
	var sbg := StyleBoxFlat.new()
	sbg.bg_color = Color(0, 0, 0, 0.45)
	sbg.set_corner_radius_all(3)
	stamina_bar.add_theme_stylebox_override("background", sbg)
	add_child(stamina_bar)

	speed_label = _label(Vector2(0, 0), 34, Color(1, 1, 1))
	money_label = _label(Vector2(20, 46), 26, Color(0.95, 0.85, 0.3))
	stars_label = _label(Vector2(20, 78), 24, Color(0.95, 0.75, 0.1))
	clock_label = _label(Vector2(0, 20), 26, Color.WHITE)
	weather_label = _label(Vector2(0, 52), 18, Color(0.85, 0.9, 1.0))
	ammo_label = _label(Vector2(0, 0), 30, Color.WHITE)
	ammo_label.position = Vector2(-20, -50)  # adjusted below in _process
	prompt_label = _label(Vector2(0, 0), 22, Color(1, 1, 1))
	prompt_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

	var shadow_theme := func(l: Label) -> void:
		l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
		l.add_theme_constant_override("outline_size", 6)
	shadow_theme.call(speed_label)
	shadow_theme.call(money_label)
	shadow_theme.call(stars_label)
	shadow_theme.call(clock_label)
	shadow_theme.call(weather_label)
	shadow_theme.call(ammo_label)
	shadow_theme.call(prompt_label)

	crosshair = ColorRect.new()
	crosshair.color = Color(1, 1, 1, 0.85)
	crosshair.size = Vector2(5, 5)
	add_child(crosshair)

	vignette = ColorRect.new()
	vignette.color = Color(0.8, 0.05, 0.05, 0.0)
	vignette.set_anchors_preset(Control.PRESET_FULL_RECT)
	vignette.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(vignette)

	debug_label = _label(Vector2(20, 110), 15, Color(0.7, 1.0, 0.7))
	debug_label.visible = false
	shadow_theme.call(debug_label)

	minimap = Minimap.new()
	minimap.player = player
	minimap.custom_minimum_size = Vector2(200, 200)
	minimap.size = Vector2(200, 200)
	minimap.clip_contents = true
	minimap.position = Vector2(20, 40)
	add_child(minimap)

	notify_box = VBoxContainer.new()
	notify_box.set_anchors_preset(Control.PRESET_CENTER_RIGHT)
	notify_box.position = Vector2(-260, 120)
	notify_box.custom_minimum_size = Vector2(240, 0)
	add_child(notify_box)

	weapon_label = _label(Vector2(0, 0), 20, Color(0.85, 0.9, 1.0))
	shadow_theme.call(weapon_label)
	if player and is_instance_valid(player) and player.pistol:
		weapon_label.text = player.pistol.weapon_name()
	GameState.weapon_changed.connect(func(wname: String) -> void:
		weapon_label.text = wname)

	race_label = _label(Vector2(0, 60), 26, Color(0.3, 0.95, 1.0))
	race_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	shadow_theme.call(race_label)
	race_label.text = ""

	world_map = WorldMap.new()
	world_map.player = player
	world_map.visible = false
	_build_phone()
	add_child(world_map)
	add_to_group("hud")

	GameState.money_changed.connect(func(v: int) -> void:
		money_label.text = "$%d" % v)
	GameState.wanted_changed.connect(_on_wanted)
	GameState.ammo_changed.connect(func(m: int, r: int) -> void:
		ammo_label.text = "%d / %d" % [m, r])
	GameState.prompt_changed.connect(func(t: String) -> void:
		prompt_label.text = t)
	GameState.notify_posted.connect(_on_notify)
	GameState.player_damaged.connect(_flash_damage)
	GameState.player_health_changed.connect(func(hp: int) -> void:
		health_bar.value = hp)
	money_label.position = Vector2(20, 60)
	shadow_theme.call(speed_label)
	money_label.text = "$%d" % GameState.money
	_on_wanted(GameState.wanted)
	# initial ammo readout (signal fires before HUD exists)
	if player and is_instance_valid(player) and player.pistol:
		ammo_label.text = "%d / %d" % [player.pistol.mag(), player.pistol.reserve()]


func _label(pos: Vector2, fsize: int, col: Color) -> Label:
	var l := Label.new()
	l.position = pos
	l.add_theme_font_size_override("font_size", fsize)
	l.add_theme_color_override("font_color", col)
	add_child(l)
	return l


func _process(delta: float) -> void:
	_ui_t += delta
	clock_label.text = GameState.clock_text()
	weather_label.text = "Rain" if GameState.raining else "Clear"
	var vp := get_viewport().get_visible_rect().size
	if player and is_instance_valid(player):
		stamina_bar.value = player.stamina
		if player.driving_car != null:
			var kmh: int = int(absf(player.driving_car.speed) * 3.6)
			speed_label.text = "%d km/h" % kmh
			speed_label.position = Vector2(vp.x - 220, vp.y - 130)
			speed_label.visible = true
		else:
			speed_label.visible = false
	clock_label.position = Vector2(vp.x - 130, 20)
	weather_label.position = Vector2(vp.x - 130, 54)
	ammo_label.position = Vector2(vp.x - 160, vp.y - 70)
	weapon_label.position = Vector2(vp.x - 160, vp.y - 102)
	race_label.position = Vector2(vp.x / 2.0 - 150, 40)
	race_label.custom_minimum_size = Vector2(300, 0)
	prompt_label.position = Vector2(vp.x / 2.0 - 150, vp.y - 130)
	prompt_label.custom_minimum_size = Vector2(300, 0)
	crosshair.position = vp / 2.0 - Vector2(2.5, 2.5)
	crosshair.visible = player != null and is_instance_valid(player) \
			and player.driving_car == null and player.health > 0 and not world_map.visible
	minimap.position = Vector2(20, vp.y - 220)
	if _debug_on and _ui_t > 0.25:
		_ui_t = 0.0
		_update_debug()


func _on_wanted(v: int) -> void:
	stars_label.text = "*".repeat(v) + "-".repeat(5 - v)


func _on_notify(text: String) -> void:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", 19)
	l.add_theme_color_override("font_color", Color(1, 1, 1))
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
	l.add_theme_constant_override("outline_size", 6)
	notify_box.add_child(l)
	if notify_box.get_child_count() > 5:
		notify_box.get_child(0).queue_free()
	var tw := l.create_tween()
	tw.tween_interval(3.0)
	tw.tween_property(l, "modulate:a", 0.0, 0.8)
	tw.tween_callback(l.queue_free)


func _flash_damage() -> void:
	vignette.color.a = 0.32
	var tw := vignette.create_tween()
	tw.tween_property(vignette, "color:a", 0.0, 0.4)


func toggle_debug() -> void:
	_debug_on = not _debug_on
	debug_label.visible = _debug_on


var _phone: PanelContainer = null
var _phone_rows := {}


## Round 9 S8 (Phase 34 slice): phone/quick panel — P toggles a compact
## status card: money, wanted, clock/phase, weather, career stats, arsenal.
func _build_phone() -> void:
	_phone = PanelContainer.new()
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.06, 0.07, 0.1, 0.92)
	style.set_corner_radius_all(10)
	style.set_content_margin_all(12)
	_phone.add_theme_stylebox_override("panel", style)
	_phone.custom_minimum_size = Vector2(240, 0)
	_phone.set_anchors_preset(Control.PRESET_CENTER_RIGHT)
	_phone.position = Vector2(-260, -120)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 4)
	_phone.add_child(box)
	var title := Label.new()
	title.text = "PHONE"
	title.add_theme_font_size_override("font_size", 14)
	box.add_child(title)
	for key: String in ["money", "wanted", "time", "weather", "deliveries",
			"races", "arsenal"]:
		var row := Label.new()
		row.add_theme_font_size_override("font_size", 12)
		box.add_child(row)
		_phone_rows[key] = row
	_phone.visible = false
	add_child(_phone)


func toggle_phone() -> void:
	_phone.visible = not _phone.visible
	if not _phone.visible:
		return
	var player := get_tree().get_first_node_in_group("player")
	var arsenal := "Pistol"
	if player != null and player.get("pistol") != null:
		var owned: Array = player.pistol.owned_weapons.keys()
		arsenal = ", ".join(owned)
	_phone_rows["money"].text = "Cash: $%d" % GameState.money
	_phone_rows["wanted"].text = "Wanted: %s" % ["-".repeat(GameState.wanted) if GameState.wanted > 0 else "clean"]
	_phone_rows["time"].text = "Time: %02d:%02d (%s)" % [GameState.day_time,
			int(fmod(GameState.day_time, 1.0) * 60.0), GameState.day_phase()]
	_phone_rows["weather"].text = "Weather: %s" % ("rain" if GameState.raining else "clear")
	_phone_rows["deliveries"].text = "Deliveries: %d" % int(GameState.stats.get("deliveries", 0))
	_phone_rows["races"].text = "Races won: %d" % int(GameState.stats.get("races_won", 0))
	_phone_rows["arsenal"].text = "Arsenal: %s" % arsenal


func toggle_map() -> void:
	world_map.visible = not world_map.visible
	world_map.set_process(world_map.visible)


## Called by the race activity via the "hud" group.
func set_race_text(text: String) -> void:
	race_label.text = text


func _district_name() -> String:
	if player == null or not is_instance_valid(player):
		return "-"
	var districts: Dictionary = GameState.world_data.get("districts", {})
	var pp := Vector2(player.global_position.x, player.global_position.z)
	for dname: String in districts:
		if (districts[dname] as Rect2).has_point(pp):
			return dname
	return "Roads/Water"


func _update_debug() -> void:
	var lines := [
		"FPS: %d  frame: %.1f ms" % [Engine.get_frames_per_second(), 1000.0 / maxf(Engine.get_frames_per_second(), 1)],
		"pos: %s" % player.global_position.snapped(Vector3(0.1, 0.1, 0.1)) if player else "pos: -",
		"nodes: %d" % get_tree().get_node_count(),
		"civilians: %d  cops: %d  cars: %d" % [
			get_tree().get_nodes_in_group("civilians").size(),
			get_tree().get_nodes_in_group("police").size(),
			get_tree().get_nodes_in_group("cars").size()],
		"wanted: %d  money: %d  time: %s" % [GameState.wanted, GameState.money, GameState.clock_text()],
		"collected: %d/20" % GameState.collected.size(),
		"district: %s" % _district_name(),
	]
	debug_label.text = "\n".join(lines)


class Minimap:
	extends Control
	var player: CharacterBody3D
	const PPM := 0.42

	func _process(_delta: float) -> void:
		queue_redraw()

	func _draw() -> void:
		if GameState.world_data.is_empty() or player == null or not is_instance_valid(player):
			return
		var wd: Dictionary = GameState.world_data
		var center := size / 2.0
		var pp: Vector3 = player.global_position
		var to_map := func(wp: Vector2) -> Vector2:
			return center + (wp - Vector2(pp.x, pp.z)) * PPM
		draw_rect(Rect2(Vector2.ZERO, size), Color(0.07, 0.22, 0.36))
		# sand + island
		var sand: Rect2 = wd["sand"]
		var sand_p: Vector2 = to_map.call(sand.position)
		draw_rect(Rect2(sand_p, sand.size * PPM), Color(0.78, 0.7, 0.5))
		var island: Rect2 = wd["island"]
		var isl_p: Vector2 = to_map.call(island.position)
		draw_rect(Rect2(isl_p, island.size * PPM), Color(0.3, 0.52, 0.3))
		# roads
		for r: Rect2 in wd["roads"]:
			var rp: Vector2 = to_map.call(r.position)
			draw_rect(Rect2(rp, r.size * PPM), Color(0.25, 0.25, 0.27))
		# collectibles
		for c in get_tree().get_nodes_in_group("collectibles"):
			var cp: Vector2 = to_map.call(Vector2(c.global_position.x, c.global_position.z))
			draw_circle(cp, 3.0, Color(0.95, 0.8, 0.2))
		# police
		for cop in get_tree().get_nodes_in_group("police"):
			if is_instance_valid(cop) and cop.health > 0:
				var kp: Vector2 = to_map.call(Vector2(cop.global_position.x, cop.global_position.z))
				draw_circle(kp, 3.0, Color(0.9, 0.25, 0.2))
		# cars
		for car in get_tree().get_nodes_in_group("cars"):
			if is_instance_valid(car) and not car.wrecked:
				var crp: Vector2 = to_map.call(Vector2(car.global_position.x, car.global_position.z))
				draw_rect(Rect2(crp - Vector2(1.5, 1.5), Vector2(3, 3)), Color(0.8, 0.8, 0.85))
		# player arrow
		var ang: float = player.yaw if "yaw" in player else 0.0
		var pts := PackedVector2Array([
			Vector2(0, -7).rotated(-ang), Vector2(5, 6).rotated(-ang), Vector2(-5, 6).rotated(-ang)])
		draw_colored_polygon(pts, Color(1, 1, 1))


class WorldMap:
	extends Control
	## Full-screen world map (TAB): districts, roads, landmarks, race, player.
	const SCALE := 0.52
	const WORLD_MIN := Vector2(-640, -460)
	var player: CharacterBody3D

	func _ready() -> void:
		var panel := ColorRect.new()
		panel.color = Color(0.02, 0.04, 0.08, 0.92)
		panel.set_anchors_preset(Control.PRESET_FULL_RECT)
		add_child(panel)

	func _process(_delta: float) -> void:
		queue_redraw()

	func _to_map(w: Vector2, vp: Vector2) -> Vector2:
		var origin := vp / 2.0 - Vector2(320, 300)
		return origin + (w - WORLD_MIN) * SCALE

	func _draw() -> void:
		var vp := get_viewport().get_visible_rect().size
		draw_rect(Rect2(Vector2.ZERO, vp), Color(0.01, 0.05, 0.1, 0.85))
		var wd: Dictionary = GameState.world_data
		if wd.is_empty():
			return
		# land masses
		var sand: Rect2 = wd["sand"]
		draw_rect(Rect2(_to_map(sand.position, vp), sand.size * SCALE), Color(0.72, 0.66, 0.48))
		var island: Rect2 = wd["island"]
		draw_rect(Rect2(_to_map(island.position, vp), island.size * SCALE), Color(0.3, 0.5, 0.3))
		# districts
		var districts: Dictionary = wd.get("districts", {})
		var tints := {"Downtown": Color(0.5, 0.5, 0.58, 0.4), "Suburbs": Color(0.4, 0.6, 0.4, 0.35),
			"Industrial": Color(0.6, 0.5, 0.35, 0.4), "Farmland": Color(0.65, 0.6, 0.3, 0.35),
			"Airport": Color(0.4, 0.45, 0.55, 0.45), "Military": Color(0.55, 0.35, 0.35, 0.45),
			"Marina": Color(0.3, 0.5, 0.65, 0.4), "Beachfront": Color(0.75, 0.7, 0.5, 0.3),
			"Park": Color(0.25, 0.55, 0.25, 0.4)}
		for dname: String in districts:
			var r: Rect2 = districts[dname]
			draw_rect(Rect2(_to_map(r.position, vp), r.size * SCALE), tints.get(dname, Color(1, 1, 1, 0.2)))
			draw_string(ThemeDB.fallback_font, _to_map(r.position, vp) + Vector2(4, 12),
					dname, HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color(1, 1, 1, 0.85))
		# roads
		for r: Rect2 in wd["roads"]:
			draw_rect(Rect2(_to_map(r.position, vp), r.size * SCALE), Color(0.16, 0.16, 0.18))
		# services
		for pair: Array in [[wd.get("shop_spot", Vector3.ZERO), Color(0.95, 0.8, 0.1)],
				[wd.get("safehouse_spot", Vector3.ZERO), Color(0.3, 0.9, 0.4)],
				[wd.get("gas_spot", Vector3.ZERO), Color(0.95, 0.4, 0.2)]]:
			var p3: Vector3 = pair[0]
			var mp := _to_map(Vector2(p3.x, p3.z), vp)
			draw_rect(Rect2(mp - Vector2(4, 4), Vector2(8, 8)), pair[1])
		# race checkpoints
		for race in get_tree().get_nodes_in_group("race"):
			for i in range(race.CP_POS.size()):
				var cp: Vector3 = race.CP_POS[i]
				var col := Color(0.3, 0.95, 1.0) if (not race.active and i == 0) \
						or (race.active and i == race.cp_index) else Color(0.3, 0.95, 1.0, 0.3)
				draw_circle(_to_map(Vector2(cp.x, cp.z), vp), 4.0, col)
		# collectibles
		for c in get_tree().get_nodes_in_group("collectibles"):
			draw_circle(_to_map(Vector2(c.global_position.x, c.global_position.z), vp), 2.5, Color(0.95, 0.8, 0.2))
		# player
		if player and is_instance_valid(player):
			var pp := _to_map(Vector2(player.global_position.x, player.global_position.z), vp)
			var ang: float = player.yaw if "yaw" in player else 0.0
			var pts := PackedVector2Array([Vector2(0, -8).rotated(-ang),
					Vector2(6, 7).rotated(-ang), Vector2(-6, 7).rotated(-ang)])
			draw_colored_polygon(pts, Color(1, 1, 1))
		draw_string(ThemeDB.fallback_font, Vector2(20, vp.y - 16),
				"TAB — close map", HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color(1, 1, 1, 0.6))
