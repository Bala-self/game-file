extends VBoxContainer
## Shared settings panel: audio volume, mouse sensitivity, invert Y, fullscreen.

var on_close: Callable


static func create(close_cb: Callable) -> Control:
	var s := VBoxContainer.new()
	s.custom_minimum_size = Vector2(300, 0)
	s.add_theme_constant_override("separation", 8)
	s.set_script(load("res://scripts/ui/settings_panel.gd"))
	s.set("on_close", close_cb)
	return s


func _ready() -> void:
	var title := Label.new()
	title.text = "SETTINGS"
	title.add_theme_font_size_override("font_size", 26)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	add_child(title)

	_slider("Master Volume", 0.0, 1.0, 0.05, GameState.settings.volume,
			func(v: float) -> void:
				GameState.settings.volume = v
				GameState.apply_settings())
	_slider("Mouse Sensitivity", 0.3, 2.0, 0.05, GameState.settings.sensitivity,
			func(v: float) -> void:
				GameState.settings.sensitivity = v)

	var invert := CheckButton.new()
	invert.text = "Invert Y axis"
	invert.button_pressed = GameState.settings.invert_y
	invert.toggled.connect(func(on: bool) -> void:
		GameState.settings.invert_y = on)
	add_child(invert)

	var quality := OptionButton.new()
	for q: String in ["LOW", "MEDIUM", "HIGH", "ULTRA"]:
		quality.add_item(q)
	quality.select(["LOW", "MEDIUM", "HIGH", "ULTRA"].find(
			GameState.settings.get("quality", "HIGH")))
	quality.item_selected.connect(func(idx: int) -> void:
		var q: String = ["LOW", "MEDIUM", "HIGH", "ULTRA"][idx]
		var game := get_tree().get_first_node_in_group("game")
		if game:
			game.apply_quality(q))
	var qlabel := Label.new()
	qlabel.text = "Graphics quality"
	var qrow := HBoxContainer.new()
	qrow.add_child(qlabel)
	qrow.add_child(quality)
	add_child(qrow)

	var invert_x := CheckButton.new()
	invert_x.text = "Invert X axis (controller)"
	invert_x.button_pressed = GameState.settings.invert_x
	invert_x.toggled.connect(func(on: bool) -> void:
		GameState.settings.invert_x = on)
	add_child(invert_x)

	_slider("Controller Vibration", 0.0, 1.0, 0.05, GameState.settings.vibration,
			func(v: float) -> void:
				GameState.settings.vibration = v
				GameState.vibrate(0.5, 0.5, 0.15))
	_slider("Controller Deadzone", 0.05, 0.5, 0.05, GameState.settings.deadzone,
			func(v: float) -> void:
				GameState.settings.deadzone = v
				GameState.apply_settings())

	# audit #32: key rebinding — click a row, press a key; additive + persisted
	var bt := Label.new()
	bt.text = "KEY BINDINGS (click, press a key; Esc cancels)"
	bt.add_theme_font_size_override("font_size", 13)
	add_child(bt)
	for action: String in ["move_forward", "move_back", "move_left", "move_right",
			"jump", "sprint", "crouch", "interact", "reload", "next_weapon", "phone"]:
		add_child(_bind_row(action))

	var fullscreen := CheckButton.new()
	fullscreen.text = "Fullscreen"
	fullscreen.button_pressed = GameState.settings.fullscreen
	fullscreen.toggled.connect(func(on: bool) -> void:
		GameState.settings.fullscreen = on
		GameState.apply_settings())
	add_child(fullscreen)

	var back := Button.new()
	back.text = "Back"
	back.custom_minimum_size = Vector2(0, 40)
	back.pressed.connect(func() -> void:
		_click()
		on_close.call())
	add_child(back)


var _bind_buttons := {}
var _capturing := ""


func _current_key_text(action: String) -> String:
	# show the LAST key event (user rebinds are appended after defaults)
	var txt := "?"
	for e: InputEvent in InputMap.action_get_events(action):
		if e is InputEventKey:
			txt = OS.get_keycode_string((e as InputEventKey).keycode)
	return txt


func _bind_row(action: String) -> HBoxContainer:
	var row := HBoxContainer.new()
	var lab := Label.new()
	lab.text = action.replace("_", " ")
	lab.custom_minimum_size = Vector2(150, 0)
	row.add_child(lab)
	var btn := Button.new()
	btn.text = _current_key_text(action)
	btn.pressed.connect(func() -> void:
		_capturing = action
		btn.text = "press a key...")
	row.add_child(btn)
	_bind_buttons[action] = btn
	return row


func _input(event: InputEvent) -> void:
	if _capturing == "" or not event is InputEventKey or not event.pressed:
		return
	var kc: Key = (event as InputEventKey).keycode
	var action := _capturing
	_capturing = ""
	if kc != KEY_ESCAPE:
		GameState.bind_key(action, kc)
	for a: String in _bind_buttons.keys():
		(_bind_buttons[a] as Button).text = _current_key_text(a)
	get_viewport().set_input_as_handled()


func _slider(label_text: String, mn: float, mx: float, step: float, value: float,
		on_change: Callable) -> void:
	var l := Label.new()
	l.text = "%s: %.2f" % [label_text, value]
	add_child(l)
	var s := HSlider.new()
	s.min_value = mn
	s.max_value = mx
	s.step = step
	s.value = value
	s.custom_minimum_size = Vector2(0, 24)
	s.value_changed.connect(func(v: float) -> void:
		l.text = "%s: %.2f" % [label_text, v]
		on_change.call(v))
	add_child(s)


func _click() -> void:
	var snd := AudioStreamPlayer.new()
	snd.stream = load("res://assets/audio/click.wav")
	snd.volume_db = -8.0
	add_child(snd)
	snd.play()
	var t := get_tree().create_timer(0.25)
	t.timeout.connect(snd.queue_free)
