extends Node
class_name WorldSim
## Weather 2.0 + day-phase simulation. Additive system node: the world keeps
## living on its own — weather evolves on a weighted chain, gameplay systems
## (car grip, NPC shelter, traffic) react via GameState.raining / heavy_rain,
## visuals centralized in game.apply_weather().

signal weather_changed(state: String)

const STATES := ["CLEAR", "CLOUDY", "RAIN", "HEAVY_RAIN", "FOG"]
## Weighted weather chain: believable evolution, no instant deserts↔storms.
const CHAIN := {
	"CLEAR": [["CLEAR", 5], ["CLOUDY", 4], ["RAIN", 1], ["FOG", 1]],
	"CLOUDY": [["CLEAR", 3], ["CLOUDY", 2], ["RAIN", 3], ["FOG", 1]],
	"RAIN": [["CLOUDY", 4], ["RAIN", 3], ["HEAVY_RAIN", 2], ["CLEAR", 1]],
	"HEAVY_RAIN": [["RAIN", 5], ["CLOUDY", 2]],
	"FOG": [["CLEAR", 3], ["CLOUDY", 3], ["FOG", 1]],
}

var state := "CLEAR"
var state_t := 90.0
var _game: Node


static func create(game: Node) -> WorldSim:
	var ws := WorldSim.new()
	ws.name = "WorldSim"
	ws._game = game
	return ws


func _ready() -> void:
	var initial := "CLEAR"
	if GameState.raining:
		initial = "HEAVY_RAIN" if GameState.heavy_rain else "RAIN"
	set_state(initial, true)


func _process(delta: float) -> void:
	state_t -= delta
	if state_t <= 0.0:
		_evolve()


## Weighted random evolution along the chain; repeats are allowed but the
## heavy states cool down faster than they ramp up.
func _evolve() -> void:
	var options: Array = CHAIN[state]
	var total := 0
	for o: Array in options:
		total += int(o[1])
	var roll := randi() % total
	for o: Array in options:
		roll -= int(o[1])
		if roll < 0:
			set_state(String(o[0]))
			return
	set_state("CLEAR")


func cycle() -> void:
	var i := STATES.find(state)
	set_state(STATES[(i + 1) % STATES.size()])


func set_state(s: String, silent := false) -> void:
	if not STATES.has(s):
		return
	state = s
	state_t = randf_range(75.0, 140.0)
	# audit #6: route through set_raining so weather_changed fires —
	# rain ambience is wired to that signal and must follow natural transitions.
	GameState.set_raining(s in ["RAIN", "HEAVY_RAIN"])
	GameState.heavy_rain = s == "HEAVY_RAIN"
	if _game and _game.has_method("apply_weather"):
		_game.apply_weather(s)
	if not silent:
		var labels := {
			"CLEAR": "Skies clearing.", "CLOUDY": "Clouds rolling in.",
			"RAIN": "Rain moving in.", "HEAVY_RAIN": "HEAVY RAIN — roads are slick!",
			"FOG": "Fog bank rolling over the island.",
		}
		GameState.notify(labels.get(s, s))
	weather_changed.emit(s)


## Day phase for schedules/patrols/audio (6:00-18:00 day, edges are golden hours).
func day_phase() -> String:
	# Round 9 S5: single owner — GameState.day_phase (was duplicated here)
	return GameState.day_phase()
