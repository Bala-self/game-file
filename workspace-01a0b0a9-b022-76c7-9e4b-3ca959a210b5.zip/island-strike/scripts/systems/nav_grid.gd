class_name NavGrid
extends Object
## Navigation (Phase 10): bakes a flat-world navigation mesh over the island
## by sampling a 6 m grid — a cell is walkable when a downward ray from chest
## height hits ground below step height (roads/sidewalks pass, buildings/
## walls/fences block). Free cells are greedy-merged into rectangles, each
## rectangle becomes one NavigationMesh polygon. Deterministic (no RNG).
## Off-mesh links connect the pier span and the parking-structure levels so
## agents can traverse them despite the gap in ground polygons.

const K := preload("res://scripts/world/wb_kit.gd")
const CELL := 6.0
const STEP_H := 0.35  # anything taller than this blocks walking


static func _cell_blocked(x: float, z: float, space: PhysicsDirectSpaceState3D) -> bool:
	# cast from above rooftop height: a ray starting inside a collider skips
	# that shape (hit_from_inside off) and would report the ground below
	var q := PhysicsRayQueryParameters3D.create(Vector3(x, 60.0, z), Vector3(x, -0.5, z))
	var hit := space.intersect_ray(q)
	if hit.is_empty():
		return true  # no floor at all
	return hit["position"].y > STEP_H


static func build(root: Node3D) -> NavigationRegion3D:
	var island: Rect2 = K.ISLAND
	var space := root.get_viewport().world_3d.direct_space_state
	var cols := int(island.size.x / CELL)
	var rows := int(island.size.y / CELL)
	var free := {}
	for cz in range(rows):
		for cx in range(cols):
			var wx := island.position.x + (cx + 0.5) * CELL
			var wz := island.position.y + (cz + 0.5) * CELL
			if not _cell_blocked(wx, wz, space):
				free[Vector2i(cx, cz)] = true
	# greedy rectangle merge (deterministic scan order)
	var used := {}
	var rects: Array[Rect2i] = []
	for cz in range(rows):
		for cx in range(cols):
			var key := Vector2i(cx, cz)
			if not free.has(key) or used.has(key):
				continue
			var w := 1
			while cx + w < cols and free.has(Vector2i(cx + w, cz)) \
					and not used.has(Vector2i(cx + w, cz)):
				w += 1
			var h := 1
			var grow := true
			while grow and cz + h < rows:
				for xx in range(w):
					var k2 := Vector2i(cx + xx, cz + h)
					if not free.has(k2) or used.has(k2):
						grow = false
						break
				if grow:
					h += 1
			for zz in range(h):
				for xx in range(w):
					used[Vector2i(cx + xx, cz + zz)] = true
			rects.append(Rect2i(cx, cz, w, h))
	var nm := NavigationMesh.new()
	nm.agent_radius = 0.4
	nm.agent_height = 1.7
	var verts := PackedVector3Array()
	for r: Rect2i in rects:
		var x0 := island.position.x + r.position.x * CELL
		var z0 := island.position.y + r.position.y * CELL
		var x1 := x0 + r.size.x * CELL
		var z1 := z0 + r.size.y * CELL
		var base := verts.size()
		verts.append(Vector3(x0, 0.12, z0))
		verts.append(Vector3(x1, 0.12, z0))
		verts.append(Vector3(x1, 0.12, z1))
		verts.append(Vector3(x0, 0.12, z1))
		nm.add_polygon(PackedInt32Array([base, base + 1, base + 2, base + 3]))
	nm.vertices = verts
	var region := NavigationRegion3D.new()
	region.name = "NavRegion"
	region.navigation_mesh = nm
	root.add_child(region)
	root.add_child(_off_mesh_links())
	print("NAVMESH: %d cells walkable in %d rects" % [free.size(), rects.size()])
	return region


## Off-mesh links: pier span + parking structure ground<->deck.
static func _off_mesh_links() -> Node3D:
	var holder := Node3D.new()
	holder.name = "NavLinks"
	var pier := NavigationLink3D.new()
	pier.name = "PierLink"
	pier.start_position = Vector3(-455, 0.3, -40)
	pier.end_position = Vector3(-521, 0.3, -40)
	holder.add_child(pier)
	var park := NavigationLink3D.new()
	park.name = "ParkingDeckLink"
	park.start_position = Vector3(-350, 0.3, -120)
	park.end_position = Vector3(-350, 7.4, -120)
	park.bidirectional = false  # ramp up only; drive down, walk down the stair side
	holder.add_child(park)
	return holder
