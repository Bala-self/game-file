class_name Streamer
extends Node
## World streaming (Phase 6): 12x12 grid of ~75 m tiles over the island rect.
## Static world geometry is bucketed by tile at registration; tiles around the
## player are ACTIVE (visible + collidable), the 1-ring neighborhood is NEAR
## (identical to ACTIVE — pre-activated so collision can never be missing at
## speed), everything farther is FAR (hidden, collision layer 0, processing
## off). Nothing is freed (memory is cheap at this scale; LOD culling comes
## with the sim-tier phase).
## Correctness contract: a tile can only lose collision when the player is
## >= 2 tiles (150 m) away; re-activation is instantaneous and applied before
## the next physics step (process_priority default runs _process first).

const TILE := 75.0
const GRID := 12
## Never streamed: environment-scale nodes (ground, water, sky-lit slabs).
const MIN_AABB := 150.0
## Groups excluded (dynamic sims own their lifecycle).
const EXCLUDE_GROUPS := ["player", "cars", "civilians", "police", "gangs",
		"pickups", "street_lamps", "lighthouse_lights"]

var _tiles := {}  # Vector2i -> {bodies: Array[Node], visuals: Array[Node]}
var _always: Array[Node] = []
var _player: Node3D
var _last_tile := Vector2i(9999, 9999)
## Round 11: activation budget — collision toggles are queued and drained at
## OPS_PER_FRAME per physics tick. The player's own tile applies instantly
## (correctness contract: never a live step without the floor underfoot);
## the rest spreads across frames so a band flip costs one small pair-burst
## instead of one 25 ms solver spike (measured, tools/perf_probe.gd).
var _pending: Array = []  # [{tile: Vector2i, on: bool}]
var _pending_tiles := {}
const OPS_PER_FRAME := 300  # bodies per physics tick


static func create(player: Node3D) -> Streamer:
	var s := Streamer.new()
	s.name = "Streamer"
	s.add_to_group("streamer")
	s._player = player  # initial reference; _process re-resolves per frame
	return s


func _register(n: Node, aabb_size: float) -> void:
	for g: String in EXCLUDE_GROUPS:
		if n.is_in_group(g):
			return
	if aabb_size >= MIN_AABB:
		_always.append(n)
		return
	var p := (n as Node3D).global_position
	var t := Vector2i(floori(p.x / TILE) + GRID / 2, floori(p.z / TILE) + GRID / 2)
	if absi(t.x - GRID / 2) > GRID / 2 or absi(t.y - GRID / 2) > GRID / 2:
		_always.append(n)  # outside the island grid (offshore islet etc.)
		return
	if not _tiles.has(t):
		_tiles[t] = {"bodies": [], "visuals": []}
	if n is CollisionObject3D:
		_tiles[t].bodies.append(n)
	else:
		_tiles[t].visuals.append(n)


## Walk the built world once and bucket static geometry by tile.
func scan(world_root: Node3D) -> void:
	for b: Node in world_root.find_children("*", "StaticBody3D", true, false):
		var cs := (b as CollisionObject3D).get_child_count()
		var size := 0.0
		for i in range(cs):
			var c: Node = b.get_child(i)
			if c is CollisionShape3D and c.shape != null \
					and c.shape is BoxShape3D:
				size = maxf(size, maxf((c.shape as BoxShape3D).size.x,
						(c.shape as BoxShape3D).size.z))
		_register(b, size)
	# visual-only world nodes: meshes not under a streamed static body
	for m: Node in world_root.find_children("*", "MeshInstance3D", true, false):
		var top := m
		var under_body := false
		var walk: Node = m.get_parent()
		while walk != null and walk != m.get_tree().current_scene:
			if walk is StaticBody3D:
				under_body = true
				break
			walk = walk.get_parent()
		if under_body:
			continue  # toggled with its body
		if not (m.get_parent() is Node3D):
			continue
		var aabb: AABB = (m as MeshInstance3D).get_aabb()
		if maxf(aabb.size.x, aabb.size.z) >= MIN_AABB:
			continue
		# skip meshes that are children of an already-registered visual parent
		if m.get_parent() is MeshInstance3D:
			continue
		_register(m, maxf(aabb.size.x, aabb.size.z))
	_apply(_tile_of(_player.global_position), _last_tile)
	print("STREAMER: %d tiles registered, %d always-on" % [_tiles.size(), _always.size()])


## Apply collision + visibility for one tile (instant path and queue both
## land here, so a queued tile's meshes toggle the same tick it resolves).
func _set_tile_collision(t: Vector2i, set_on: bool) -> void:
	if not _tiles.has(t):
		return
	for b: Node in _tiles[t].bodies:
		if not is_instance_valid(b):
			continue
		var body := b as CollisionObject3D
		if not body.has_meta("orig_layer"):
			body.set_meta("orig_layer", body.collision_layer)
		body.collision_layer = (body.get_meta("orig_layer") as int) if set_on else 0
		if b is Node3D:
			(b as Node3D).visible = set_on


## Drain the activation queue: budget is counted in BODIES (the solver cost
## is per re-registered body, not per tile). Each tile's desired band is
## re-checked at pop time — a fast double-flip never applies a stale direction.
func _drain_activation_queue() -> void:
	var budget := OPS_PER_FRAME
	while budget > 0 and not _pending.is_empty():
		var op: Dictionary = _pending.pop_front()
		var t: Vector2i = op["tile"]
		var want_on: bool = _band(t, _last_tile) == "ACTIVE"
		_set_tile_collision(t, want_on)
		if _tiles.has(t):
			budget -= (_tiles[t].bodies as Array).size()


func _tile_of(p: Vector3) -> Vector2i:
	return Vector2i(floori(p.x / TILE) + GRID / 2, floori(p.z / TILE) + GRID / 2)


## Re-band in _physics_process: it runs BEFORE the physics server step, so a
## teleport/vehicle that crosses into a new tile gets collision applied in the
## same tick — never a live physics step with parked collision (smoke-caught:
## a _process re-band left a 1-tick fall-through window).
func _physics_process(_d: float) -> void:
	# per-frame group lookup: the player node can be REPLACED (respawn/load);
	# a cached reference went stale and froze the bands (smoke-caught)
	var p := get_tree().get_first_node_in_group("player") as Node3D
	if p == null:
		return
	var t := _tile_of(p.global_position)
	if t != _last_tile:
		var old := _last_tile
		_last_tile = t
		_apply(t, old)
	_drain_activation_queue()


func _band(t: Vector2i, center: Vector2i) -> String:
	var dx: int = absi(t.x - center.x)
	var dy: int = absi(t.y - center.y)
	var ring := maxi(dx, dy)
	if ring <= 1:
		return "ACTIVE"   # player tile + 1-ring neighborhood: NEAR == ACTIVE
	return "FAR"


func _apply(new_c: Vector2i, old_c: Vector2i) -> void:
	for t: Vector2i in _tiles.keys():
		var was := "" if old_c == Vector2i(9999, 9999) else _band(t, old_c)
		var now := _band(t, new_c)
		if was == now:
			continue
		var set_on := now == "ACTIVE"
		var bucket: Dictionary = _tiles[t]
		# Round 11: player tile collision NOW (contract); everything else —
		# including the initial world activation — queues (budgeted drain)
		if t == new_c:
			_set_tile_collision(t, set_on)
		elif not _pending_tiles.has(t) or _pending_tiles[t] != set_on:
			_pending_tiles[t] = set_on
			_pending.append({"tile": t, "on": set_on})
		for v: Node in bucket.visuals:
			if is_instance_valid(v) and v is Node3D:
				(v as Node3D).visible = set_on


## Test/QA hook: is world collision enabled at a world position right now?
func collision_enabled_at(p: Vector3) -> bool:
	return _band(_tile_of(p), _last_tile) == "ACTIVE"
