extends CharacterBody3D
## Third-person player: movement, sprint/crouch/jump/swim, camera, interaction,
## vehicle enter/exit, health/regen/death.

signal died
signal health_updated(hp: int)

const WALK_SPEED := 5.0
const SPRINT_SPEED := 8.6
const CROUCH_SPEED := 2.6
const SWIM_SPEED := 3.4
const JUMP_VELOCITY := 7.2
const GRAVITY := 18.0
const ACCEL := 32.0
## Audit #18: swim threshold derives from world_data water level (contract),
## not a frozen constant — follows any future water-level change.
func _water_level() -> float:
	return float(GameState.world_data.get("water_y", -1.3)) + 0.78

var health: int = 100
var stamina: float = 100.0
var rig: CharacterRig
var _manual_look := 0.0  # seconds of camera auto-trail suppression
var yaw := 0.0
var pitch := 0.2
var swimming := false
var crouching := false
var aiming := false
var driving_car: CharacterBody3D = null
var pistol: Node3D = null
var last_damage := -100.0
var input_enabled := true

var cam_yaw: Node3D
var spring: SpringArm3D
var cam: Camera3D
var visual: Node3D
var interact_target: Node = null


static func create() -> CharacterBody3D:
	var body := CharacterBody3D.new()
	body.name = "Player"
	body.collision_layer = 2
	body.collision_mask = 1 | 4 | 8
	body.set_script(load("res://scripts/player/player.gd"))
	return body


func _ready() -> void:
	var col := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.35
	capsule.height = 1.75
	col.shape = capsule
	col.position.y = 0.9
	add_child(col)

	visual = Node3D.new()
	visual.name = "Visual"
	add_child(visual)
	# articulated character rig (shared architecture with NPCs)
	rig = CharacterRig.create(CharacterRig.player_outfit())
	visual.add_child(rig)

	cam_yaw = Node3D.new()
	cam_yaw.name = "CamYaw"
	cam_yaw.position.y = 1.55
	add_child(cam_yaw)
	# GTA-style rig: the camera pivot must NOT inherit the body's rotation,
	# otherwise turning the body swings the camera and curves W-input (P0 bug).
	cam_yaw.top_level = true
	spring = SpringArm3D.new()
	spring.spring_length = 4.6
	spring.collision_mask = 1 | 8  # world + vehicles (was world-only: clipped through cars)
	spring.margin = 0.35
	spring.rotation.x = pitch
	cam_yaw.add_child(spring)
	cam = Camera3D.new()
	cam.fov = 72.0
	cam.near = 0.1
	spring.add_child(cam)
	cam.current = true

	pistol = load("res://scripts/weapons/pistol.gd").create(self)
	pistol.set("in_hand", true)
	rig.attach_weapon(pistol)
	# never let the spring arm collide with the player's own capsule
	spring.add_excluded_object(get_rid())


func _unhandled_input(event: InputEvent) -> void:
	if not input_enabled:
		return
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		_manual_look = 1.6  # manual look pauses the vehicle camera auto-trail
		var sens: float = GameState.settings.sensitivity * 0.0022
		yaw -= event.relative.x * sens
		var dy: float = event.relative.y * sens
		if GameState.settings.invert_y:
			dy = -dy
		pitch = clampf(pitch - dy, -1.1, 1.25)


func _physics_process(delta: float) -> void:
	# camera rig follows the body position only; rotation is mouse/stick-owned
	if cam_yaw:
		cam_yaw.global_position = global_position + Vector3(0, 1.55, 0)
	if not input_enabled:
		return
	if driving_car != null:
		_driving_update(delta)
		return

	var look := Input.get_vector("look_left", "look_right", "look_up", "look_down")
	if GameState.settings.invert_x:
		look.x = -look.x
	if look.length() > 0.05:
		yaw -= look.x * 2.6 * delta * GameState.settings.sensitivity
		var dy: float = look.y * 1.8 * delta * GameState.settings.sensitivity
		if GameState.settings.invert_y:
			dy = -dy
		pitch = clampf(pitch - dy, -1.1, 1.25)
	cam_yaw.rotation.y = yaw
	spring.rotation.x = pitch

	aiming = Input.is_action_pressed("aim")
	var target_fov := 48.0 if aiming else 72.0
	cam.fov = lerpf(cam.fov, target_fov, 10.0 * delta)
	spring.spring_length = lerpf(spring.spring_length, 2.3 if aiming else 4.6, 8.0 * delta)

	swimming = global_position.y < _water_level()
	crouching = Input.is_action_pressed("crouch") and not swimming

	var input_vec := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var dir := (cam_yaw.global_basis * Vector3(input_vec.x, 0, input_vec.y))
	dir.y = 0
	dir = dir.normalized() * input_vec.length()

	var sprinting := Input.is_action_pressed("sprint") and dir.length() > 0.1 \
			and not crouching and not aiming and stamina > 5.0
	var speed := SWIM_SPEED if swimming else CROUCH_SPEED if crouching \
			else SPRINT_SPEED if sprinting else WALK_SPEED
	if sprinting:
		stamina = maxf(0.0, stamina - 12.0 * delta)
	else:
		stamina = minf(100.0, stamina + 15.0 * delta)

	if swimming:
		# Buoyancy toward the surface + climb back onto land
		var target_y := -1.0
		velocity.y = lerpf(velocity.y, (target_y - global_position.y) * 2.2, 4.0 * delta)
		if dir.length() > 0.1 and _ground_ahead_below():
			velocity.y = 5.5  # climb out of water
	else:
		if is_on_floor():
			if Input.is_action_just_pressed("jump"):
				velocity.y = JUMP_VELOCITY
		else:
			velocity.y -= GRAVITY * delta

	velocity.x = move_toward(velocity.x, dir.x * speed, ACCEL * delta)
	velocity.z = move_toward(velocity.z, dir.z * speed, ACCEL * delta)
	move_and_slide()

	# Face movement direction (or camera direction when aiming)
	if aiming:
		rotation.y = lerp_angle(rotation.y, yaw, 12.0 * delta)
	elif dir.length() > 0.2:
		rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), 10.0 * delta)

	if not is_on_floor() and not swimming:
		velocity.y -= GRAVITY * delta * 0.5  # extra fall weight

	# character rig animation (walk/run/jump/fall/crouch/aim/shoot/hit)
	var planar_speed := Vector2(velocity.x, velocity.z).length()
	var vis_raise: float = pistol.vis_raise if pistol else 0.0
	if rig:
		rig.animate(delta, {
			"speed": planar_speed,
			"max_speed": SPRINT_SPEED,
			"on_floor": is_on_floor(),
			"vy": velocity.y,
			"crouch": crouching,
			"swim": swimming,
			"aim": 1.0 if (aiming or vis_raise > 0.0) else 0.0,
			"reloading": pistol.reloading if pistol else false,
		})

	_regen(delta)
	_update_interact()
	if Input.is_action_just_pressed("next_weapon") and pistol:
		pistol.cycle_weapon()
	elif Input.is_action_just_pressed("prev_weapon") and pistol:
		pistol.cycle_weapon(-1)


func _ground_ahead_below() -> bool:
	var space := get_world_3d().direct_space_state
	var fwd := -cam_yaw.global_basis.z
	fwd.y = 0
	fwd = fwd.normalized()
	var from := global_position + Vector3(0, 1.0, 0) + fwd * 1.2
	var q := PhysicsRayQueryParameters3D.create(from, from + Vector3(0, -3.5, 0), 1)
	return not space.intersect_ray(q).is_empty()


func _update_interact() -> void:
	interact_target = null
	var best := 3.8
	for c in get_tree().get_nodes_in_group("cars"):
		if is_instance_valid(c) and not c.wrecked:
			var d: float = c.global_position.distance_to(global_position)
			if d < best:
				best = d
				interact_target = c
	var shop := get_tree().get_first_node_in_group("gun_shop")
	var safehouse := get_tree().get_first_node_in_group("safehouse")
	var prop := get_tree().get_first_node_in_group("property")
	if prop and prop.global_position.distance_to(global_position) < 4.5:
		var pid: String = prop.get_meta("property_id")
		var info: Dictionary = GameState.PROPERTIES[pid]
		if GameState.owned.has(pid):
			GameState.set_prompt("%s — OWNED" % info["name"])
		else:
			GameState.set_prompt(GameState.ctx_prompt("interact", "Buy %s ($%d)" % [info["name"], info["price"]]))
			if Input.is_action_just_pressed("interact"):
				GameState.buy_property(pid)
		return
	var gas := get_tree().get_first_node_in_group("gas_station")
	if gas and gas.global_position.distance_to(global_position) < 4.5:
		var nearest_car: Node = null
		var best_d := 9.0
		for c in get_tree().get_nodes_in_group("cars"):
			var cd: float = c.global_position.distance_to(global_position)
			if cd < best_d:
				best_d = cd
				nearest_car = c
		if nearest_car != null:
			GameState.set_prompt(GameState.ctx_prompt("interact", "Repair nearest car $50"))
			if Input.is_action_just_pressed("interact"):
				try_gas_station(nearest_car)
		else:
			GameState.set_prompt("Gas station — park a car nearby to repair")
		return
	if shop and shop.global_position.distance_to(global_position) < 3.5:
		# Round 9 S4: weapon counter first — unowned guns before consumables
		var next_gun: String = pistol.next_unowned()
		if next_gun != "":
			GameState.set_prompt(GameState.ctx_prompt("interact", "Buy %s ($%d)" % [
					pistol.WEAPONS[next_gun]["name"], pistol.WEAPONS[next_gun]["price"]]))
			if Input.is_action_just_pressed("interact"):
				pistol.buy_next_weapon()
			if Input.is_action_just_pressed("reload") and health < 100:
				if GameState.try_spend(100):
					heal_full()
					GameState.notify("Health restored")
			return
		GameState.set_prompt("E — Buy ammo $50  /  R — Buy health $100")
		if Input.is_action_just_pressed("interact"):
			if GameState.try_spend(50):
				pistol.add_ammo(24)
				GameState.notify("+24 ammo")
		elif Input.is_action_just_pressed("reload") and health < 100:
			if GameState.try_spend(100):
				heal_full()
				GameState.notify("Health restored")
		return
	if safehouse and safehouse.global_position.distance_to(global_position) < 3.5:
		GameState.set_prompt("E — Sleep (save + heal, next morning)")
		if Input.is_action_just_pressed("interact"):
			GameState.day_time = 7.0
			heal_full()
			SaveSystem.save_game()
			GameState.notify("You slept. Saved & healed.")
		return
	if interact_target != null:
		GameState.set_prompt("E / X — Enter vehicle")
		if Input.is_action_just_pressed("interact"):
			interact_target.enter_player(self)
	else:
		GameState.set_prompt("")


## Driving context: SAME camera rig (one camera, no modes). Stick/mouse look
## always works; with hands off, the camera gently trails behind the car.
## Speed subtly dollies the camera out and widens FOV.
func _driving_update(delta: float) -> void:
	global_position = driving_car.get_seat_position()
	velocity = Vector3.ZERO
	GameState.set_prompt(GameState.ctx_prompt("interact", "Exit vehicle"))
	if Input.is_action_just_pressed("interact"):
		driving_car.exit_player()
		return
	# right-stick look while driving (mouse look arrives via _unhandled_input)
	var look := Input.get_vector("look_left", "look_right", "look_up", "look_down")
	if GameState.settings.invert_x:
		look.x = -look.x
	if look.length() > 0.05:
		_manual_look = 1.6
		yaw -= look.x * 2.6 * delta * GameState.settings.sensitivity
		var dy: float = look.y * 1.8 * delta * GameState.settings.sensitivity
		if GameState.settings.invert_y:
			dy = -dy
		pitch = clampf(pitch - dy, -1.1, 0.6)
	cam_yaw.rotation.y = yaw
	spring.rotation.x = pitch
	# vehicle framing: pivot above the cab (on-foot path re-anchors to the body)
	cam_yaw.global_position = driving_car.global_position + Vector3(0, 2.3, 0)
	_manual_look = maxf(0.0, _manual_look - delta)
	var car_speed: float = driving_car.velocity.length()
	if _manual_look <= 0.0 and car_speed > 2.0:
		var fwd: Vector3 = -driving_car.global_basis.z
		yaw = lerp_angle(yaw, atan2(-fwd.x, -fwd.z), 2.4 * delta)
	# speed-based camera dolly + FOV
	var t := clampf(car_speed / 30.0, 0.0, 1.0)
	spring.spring_length = lerpf(spring.spring_length, 5.4 + 2.0 * t, 3.0 * delta)
	cam.fov = lerpf(cam.fov, 72.0 + 9.0 * t, 3.0 * delta)


## Repair the given car at the gas station for $50.
func try_gas_station(car: Node3D) -> bool:
	if car == null or not is_instance_valid(car) or car.wrecked:
		GameState.notify("That car is beyond repair")
		return false
	if car.health >= 99.0:
		GameState.notify("This car is already in good shape")
		return false
	if GameState.try_spend(50):
		car.health = 100.0
		car.engine_health = 100.0
		car.wheel_health = 100.0
		car.smoke.emitting = false
		GameState.notify("Vehicle repaired (-$50)")
		GameState.vibrate(0.2, 0.2, 0.1)
		return true
	return false


func start_driving(car: CharacterBody3D) -> void:
	# audit #2: entry stat + notify owned by car.enter_player() alone
	driving_car = car
	collision_layer = 0
	collision_mask = 0
	visible = false
	pistol.visible = false


func exit_driving(world_pos: Vector3) -> void:
	driving_car = null
	global_position = world_pos
	collision_layer = 2
	collision_mask = 1 | 4 | 8
	visible = true
	pistol.visible = true
	velocity = Vector3.ZERO


# ------------------------------------------------------------------ health
func take_damage(dmg: int, _from: Vector3, source: Node = null) -> void:
	if health <= 0:
		return
	health = maxi(0, health - dmg)
	last_damage = Time.get_ticks_msec() / 1000.0
	GameState.player_health_changed.emit(health)
	GameState.player_damaged.emit()
	GameState.vibrate(0.4, 0.8, 0.18)
	if rig:
		rig.hit_t = 0.3  # hit-reaction flinch
	if health == 0:
		died.emit()


func heal_full() -> void:
	health = 100
	GameState.player_health_changed.emit(health)


var _regen_acc := 0.0


## Bug fix (audit #1): int(8.0*delta) truncates to 0 at 60 fps, so the legacy
## +1 fired EVERY tick (~60 HP/s). Accumulate fractionally, apply whole HP.
func _regen(delta: float) -> void:
	if health > 0 and health < 100 and Time.get_ticks_msec() / 1000.0 - last_damage > 8.0:
		_regen_acc += 8.0 * delta
		if _regen_acc >= 1.0:
			var add := int(_regen_acc)
			_regen_acc -= float(add)
			health = mini(100, health + add)
			GameState.player_health_changed.emit(health)
	else:
		_regen_acc = 0.0


func die() -> void:
	input_enabled = false
	visible = false
	collision_layer = 0
	died.emit()


func respawn(pos: Vector3) -> void:
	global_position = pos
	velocity = Vector3.ZERO
	health = 100
	input_enabled = true
	visible = true
	collision_layer = 2
	collision_mask = 1 | 4 | 8
	GameState.player_health_changed.emit(health)


func restore_from_save(pos: Vector3, hp: float, p_yaw: float, mag: int, reserve: int) -> void:
	global_position = pos
	health = int(hp)
	yaw = p_yaw
	GameState.player_health_changed.emit(health)
	if pistol:
		pistol.ammo["pistol"][0] = mag
		pistol.ammo["pistol"][1] = reserve
		pistol.emit_ammo()


func get_seat_position() -> Vector3:
	if driving_car:
		return driving_car.global_position + Vector3(0, 0.8, 0)
	return global_position
