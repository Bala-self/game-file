# V1.9 BASELINE REPORT (v2.0 program, PHASE 01 audit)
Measured from the live project @ v1.9 `44c3d2a` (Godot 4.5.stable.876b29033).

## PROJECT
Godot 4.5 headless-verified; compatibility renderer assumptions documented. Autoloads:
GameState (input map, economy, day clock, wanted, settings, properties) + SaveSystem.
17 scripts ≈ 3,000 lines; 1 scene (game.tscn builds world at runtime, deterministic
seeded builder). Input: 40+ actions, KB+M primary / pad secondary, device-aware prompts.

## WORLD
Flat plateau island (y=0) in 1 km sand square, water −1.3. 15 asphalt + 1 dirt roads
classed L1–L5, signals, crosswalks, stop lines, 90 junction-safe sidewalk segments,
freeway median. 9-district registry + coast pack (lighthouse, pier, offshore islet,
breakwater, buoys), rail corridor, 22+ QA-registered building footprints (0 road
overlaps), 24 enterable interiors, downtown height census 7/6/9, vegetation groups,
night lighting groups, weather visuals in game.gd.

## PLAYER
CharacterBody3D + CharacterRig (11 pivots, 13 procedural states, weapon-in-hand),
one third-person camera (top-level rig + spring, verified straight-walk 11/11),
drive context with look + auto-trail. Health/stamina/regen, interaction prompts
(device-aware), 2-weapon framework, swim/crouch/jump, save/restore hooks.

## VEHICLES
`car.gd` 8-class data catalog (sedan/sports/pickup/van/taxi/suv/bus/police), shared
physics (arcade cruise model, surface grip, rain grip), traffic AI loops + district
pools, police chase AI, component damage: **GAP at v1.9 (scalar health only) → fixed
in v2.0.01** (engine/wheel components with functional effects). Boats/aircraft: absent
(physics phases pending). Enter/exit contextual, gas-station repair ($50).

## NPC
person.gd + CharacterRig reuse; civilians (sidewalk wander, flee, report), police
(pursue + last-known search), gangs (territory, LOS aggro). Anim LOD 60/15/freeze.
**v2.0 gaps → roadmap:** full life schedules, faction matrix, generalized memory.

## SYSTEMS
Economy (money, 4 properties, daily income, shop, race, repairs), wanted 0–5 with
witness/report/dispatch, day/night 240 s cycle, weather v1 binary rain → **upgraded
in v2.0.01** to 5-state chain (CLEAR/CLOUDY/RAIN/HEAVY_RAIN/FOG), events v1 random
→ **v2.0.01 data-driven district-aware EventManager**, save v1 → **v2.0.01 version 2
+ migration + corruption rejection**, F1 debug overlay (release-hidden), map screen.

## PERFORMANCE (headless-logic)
≈5.0k nodes / ≈3.1k meshes with ~24 rigged NPCs; STRESS PASS; six suites, 0 script
errors; all distant props range-culled; 1 sun + night-gated lamps. GPU metrics need
on-GPU capture (see PERFORMANCE_BUDGET.md).

## v2.0.01 ARCHITECTURE DECISIONS
Extracted policy from the 696-line game.gd into purpose-built nodes (no big-bang
rewrite): `systems/world_sim.gd` (weather chain + day phases), `systems/
event_manager.gd` (data-driven selection: weights, districts, no-repeat). Component
damage + save migration added in place. Managers only where they earn their node.
