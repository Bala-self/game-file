# ISLAND STRIKE

An open-world island action sandbox built with **Godot 4**. Explore a procedurally
constructed island city on foot and by car, evade a reactive police force, hunt
20 hidden collectible packages, and live through a full day/night cycle with
dynamic weather — all offline, no external dependencies.

> This is release **v1.0** of the project: a complete, tested, playable core
> sandbox. The long-term master design (interiors, boats, rail, missions) is
> documented in the repository design notes; see *Known Limitations* below for
> exactly what is and is not in this release.

---

## Description

ISLAND STRIKE drops you on a ~1 km² island with eight distinct districts:
a high-rise **Downtown** (with the 95 m Island Tower and a stadium), a palm-lined
**Beachfront** with a lighthouse and marina piers, **Suburbs**, a restricted
**Military** zone with watchtowers and radar, a northeast **Airport**, a
**Industrial** docklands with container yards and a harbor crane, **Farmland**
with a working windmill, and a central **Park**.

Walk, sprint, swim, and commandeer any vehicle on the island. Civilians go about
their routines — until you cause trouble. Gunfire panics witnesses, witnesses
report crimes, and police escalate from local patrols to a full tactical
response as your wanted level rises. Evade to lose heat, or get **BUSTED**.

## Features

- **Open world** — deterministic procedural island: 8 districts, 14 road
  segments with lane/edge markings, sidewalks, guardrails, speed signs,
  **signalized intersections**, landmarks (Island Tower, stadium, lighthouse,
  airport with parked airliner, radar mast, harbor crane, windmill)
- **Third-person player controller** — walk / sprint / crouch / jump / swim,
  camera-relative movement, spring-arm collision camera, shoulder aiming
- **Vehicles** — **6 classes** (sedan / sports / pickup / van / taxi / police
  cruiser) with dynamic brake & reverse lights, body roll/pitch, horns, and
  explosions with radial damage; traffic obeys **traffic lights**; surface grip
  (asphalt/dirt/grass/sand) with wet-road modifiers
- **Police cruisers** — at 2+ stars, dispatch-only cruisers with flashing
  lightbars and sirens join foot cops in the pursuit
- **Wanted system (0–5 stars)** — witness reports, police pursuit and gunfire,
  search behavior, heat decay when you break line of sight, and a BUSTED
  arrest state
- **Civilian AI** — sidewalk routines with idle/walk states, panic fleeing,
  crime reporting; police AI with patrol / pursue / shoot / search / dismiss
  states and line-of-sight checks
- **Combat** — hitscan pistol with spread, recoil, reload, tracers, muzzle
  flash, damage falloff; downed police drop ammo; loot drops from NPCs
- **Economy** — money from collectibles and loot; hospital and busted fines
- **Collectibles** — 20 persistent hidden packages ($250 each), saved by ID
- **Day/night cycle** (20-minute full day) — moving sun, moon, sunset skies,
  street lamps, beacons and **building windows** that light at night
- **Thunderstorms** — rain cycles now include lightning flashes and thunder
- **Dynamic weather** — rain cycles with reduced grip, fog, and ambience
- **Save/load** — versioned JSON saves (position, health, ammo, money,
  wanted, time, weather, collectibles); manual save/load + Continue
- **Player systems** — sprint stamina, procedural walk animation, contextual
  services: **gun shop** (buy ammo/health) and **safehouse** (sleep = save +
  heal + morning)
- **Full UI** — main menu, pause menu, settings (volume, sensitivity,
  invert-Y/X, **controller vibration & deadzone**, fullscreen), HUD with
  health, stamina, money, wanted stars, clock, ammo, **speedometer**,
  contextual prompts, notifications, and a live **minimap**
- **Audio** — procedurally generated SFX (gunfire, engine, explosion,
  pickups, UI, ocean and rain ambience)
- **QA tooling** — F3 debug overlay (FPS, entity counts, position), headless
  smoke-test suite (`tests/smoke_test.gd`), audio generator (`tools/`)

## Controls

### Keyboard + Mouse

| Action | Key |
|---|---|
| Move | `W A S D` / Arrow keys |
| Look | Mouse |
| Sprint | `Shift` |
| Crouch | `Ctrl` or `C` |
| Jump / Handbrake | `Space` |
| Enter / Exit vehicle | `E` or `F` |
| Fire | Left mouse |
| Aim | Right mouse |
| Reload | `R` |
| Horn | `H` |
| Pause | `Esc` |
| Save / Load (quick) | `F5` / `F9` |
| Debug overlay | `F3` |
| Toggle weather (debug) | `T` |

### Controller (Xbox/PlayStation layout)

| Action | Button |
|---|---|
| Move | Left stick |
| Look | Right stick |
| Sprint | L3 (stick click) |
| Crouch | B / Circle |
| Jump / Handbrake | A / Cross |
| Interact (enter/exit) | X / Square |
| Reload | Y / Triangle |
| Fire | Right trigger |
| Aim | Left trigger |
| Pause | Start / Options |

Input is fully action-based and rebindable via `scripts/core/game_state.gd`.

## System Requirements

- **OS:** Windows 7+ / Linux / macOS (any OS Godot 4.3 supports)
- **GPU:** Any DirectX 11 / Vulkan / OpenGL 3.3-class GPU; the scene is
  lightweight (no external textures, primitive-based geometry)
- **RAM:** 4 GB minimum
- **Input:** Keyboard + mouse, or XInput/DirectInput controller
- **Internet:** Not required — fully offline

## Godot Version

- Built and validated on **Godot 4.5-stable** (headless test suite)
- Project feature tag: **4.3** — opens in Godot **4.3 or newer**
- Renderer: Forward+ (default), works with Mobile/Compatibility too

## Build / Run

### Run from source

1. Install [Godot 4.3+](https://godotengine.org/download) (standard build, not .NET)
2. Open Godot → **Import** → select this folder's `project.godot`
3. Press **F5** (Run Project) — or open `scenes/main/main_menu.tscn` and press F6

### Export a Windows build

1. In the Godot editor: **Editor → Manage Export Templates** → download the
   template pack for your Godot version (one-time)
2. **Project → Export…** — the included `export_presets.cfg` defines a
   **Windows Desktop** preset (`IslandStrike.exe`, PCK embedded)
3. Click **Export Project** → ship the resulting `.exe`

### Run the automated smoke test (headless, no display needed)

```bash
godot --headless --path . -s res://tests/smoke_test.gd
# expected final line: SMOKE_RESULT: ALL PASS
```

## Project Structure

```
island-strike/
├── project.godot            # Godot project (autoloads, layers, window)
├── export_presets.cfg       # Windows Desktop export preset
├── icon.svg
├── scenes/
│   ├── main/main_menu.tscn  # title screen
│   └── game/game.tscn       # gameplay root (world is built procedurally)
├── scripts/
│   ├── core/                # game_state.gd, save_system.gd (autoloads)
│   ├── game/                # game.gd — director: spawning, day/night, police
│   ├── world/               # world_builder.gd, collectible.gd, pickup.gd
│   ├── player/              # player.gd — movement, camera, interaction
│   ├── weapons/             # pistol.gd — hitscan combat
│   ├── vehicles/            # car.gd — driving + traffic AI + damage
│   ├── npc/                 # person.gd, npc_civilian.gd, npc_police.gd
│   ├── ui/                  # hud.gd (+minimap), pause_menu.gd,
│   │                        #   settings_panel.gd, main_menu.gd
│   └── main/                # main_menu.gd
├── assets/audio/            # generated WAV sound effects (tools/make_audio.py)
├── tools/make_audio.py      # deterministic audio generator (stdlib Python)
└── tests/                   # smoke_test.gd, smoke_node.gd, loadcheck.gd
```

## Known Limitations

Honest list of what v1.0 does **not** include (roadmap items from the master
design doc):

- No enterable interiors, doors, or saveable owned property
- No boats or aircraft (the docklands, piers and airport are landmarks)
- No rail system; no river/drawbridge/tunnel (single landmass island)
- Police are on foot only — no police cruisers or helicopter escalation
- No missions/gangs — the sandbox is collectibles + wanted-system driven
- No melee weapons or thrown weapons; pistol only
- Vehicle physics are arcade-style (no per-wheel suspension simulation)
- NPCs navigate point-to-point (no navmesh pathfinding around buildings)
- No music track (SFX and ambience only)
- Trees/props have no collision; buildings and cars do
- Windows build must be exported by you (see *Build/Run*) — export templates
  are a per-user download from Godot

## Version History

- **v1.1** — extreme-audit pass: vehicle classes, police cruisers, traffic
  signals AI obedience, lit windows at night, sidewalks/signs/guardrails,
  street furniture, stamina, walk animation, thunderstorms, shop & safehouse,
  controller vibration/deadzone/invert-X, speedometer. 23-check automated
  smoke suite + 20 s stress run, zero script errors.
- **v1.0** — initial playable sandbox.

## License

Code and generated assets: MIT License (c) 2026 Bala-self. Godot Engine is
licensed under MIT by its contributors.
