#!/usr/bin/env bash
# ============================================================
# ISLAND STRIKE — GitHub release pipeline (Godot 4.x)
# ============================================================
# Performs, in order:
#   1. Audit the project (audit_project.py) — aborts if not release-clean
#   2. Clean junk (.godot cache, logs, editor backups, OS junk)
#   3. Install proper .gitignore
#   4. git init (branch: main) + initial commit "Initial release - Island Strike"
#   5. Create GitHub repo ISLAND-STRIKE via API
#   6. Push (source project + Windows build, <= GitHub size limits)
#   7. VERIFY via API: repo exists, project.godot + README + key paths visible
#   8. Print final report (URL / commit hash / branch / status)
#
# Required environment:
#   GITHUB_TOKEN     fine-grained PAT with "Administration: read+write"
#                    and "Contents: read+write" on the target account
#   GITHUB_USER      your GitHub username (owner of the new repo)
# Optional:
#   PROJECT_DIR      default /home/user/island-strike
#   PRIVATE_REPO     1 = private repo (default), 0 = public
#   DRY_RUN          1 = do everything except network write operations
# ============================================================
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/home/user/island-strike}"
REPO_NAME="${REPO_NAME:-ISLAND-STRIKE}"
GITHUB_USER="${GITHUB_USER:-}"
GITHUB_TOKEN="${GITHUB_TOKEN:-}"
PRIVATE_REPO="${PRIVATE_REPO:-1}"
DRY_RUN="${DRY_RUN:-0}"
BRANCH="main"
COMMIT_MSG="Initial release - Island Strike"
API="https://api.github.com"

fail() { echo "❌ BLOCKER: $*" >&2; exit 1; }
step() { echo -e "\n=== $* ==="; }

[[ -d "$PROJECT_DIR" ]] || fail "project dir $PROJECT_DIR does not exist — nothing to release"
[[ -f "$PROJECT_DIR/project.godot" ]] || fail "no project.godot in $PROJECT_DIR — not a Godot project"
[[ -n "$GITHUB_USER" ]] || fail "GITHUB_USER not set"
[[ -n "$GITHUB_TOKEN" ]] || fail "GITHUB_TOKEN not set (GitHub auth is a human-only step)"
command -v git >/dev/null || fail "git not installed"

step "1/7 AUDIT"
python3 "$(dirname "$0")/audit_project.py" "$PROJECT_DIR" || fail "audit failed — fix problems before release"

step "2/7 CLEAN junk"
if [[ "$DRY_RUN" != "1" ]]; then
  find "$PROJECT_DIR" -type d \( -name ".godot" -o -name "__pycache__" \) -prune -exec rm -rf {} +
  find "$PROJECT_DIR" -type f \( -name "*.tmp" -o -name "*.log" -o -name "*.bak" -o \
      -name "*.orig" -o -name ".DS_Store" -o -name "Thumbs.db" -o -name "crash-handler.log" \) -delete
fi
echo "cleaned cache/log/editor-junk files"

step "3/7 .gitignore"
if [[ "$DRY_RUN" != "1" ]]; then
  cp "$(dirname "$0")/gitignore.godot4" "$PROJECT_DIR/.gitignore"
fi
echo "installed Godot 4 .gitignore"

step "4/7 git init + commit"
cd "$PROJECT_DIR"
if [[ ! -d .git ]]; then
  [[ "$DRY_RUN" == "1" ]] || git init -q -b "$BRANCH"
fi
git config user.name  "${GIT_AUTHOR_NAME:-$GITHUB_USER}"
git config user.email "${GIT_AUTHOR_EMAIL:-$GITHUB_USER@users.noreply.github.com}"
[[ "$DRY_RUN" == "1" ]] || { git add -A && git commit -q -m "$COMMIT_MSG" || echo "(nothing new to commit)"; }
COMMIT_HASH="$(git rev-parse HEAD 2>/dev/null || echo 'n/a(dry-run)')"
echo "commit: $COMMIT_HASH"

step "5/7 create GitHub repo"
if [[ "$DRY_RUN" != "1" ]]; then
  HTTP=$(curl -s -o /tmp/repo.json -w "%{http_code}" -X POST "$API/user/repos" \
    -H "Authorization: Bearer $GITHUB_TOKEN" -H "Accept: application/vnd.github+json" \
    -d "{\"name\":\"$REPO_NAME\",\"private\":$PRIVATE_REPO,\"description\":\"Island Strike - open-world action sandbox built in Godot 4\"}")
  [[ "$HTTP" == "201" || "$HTTP" == "422" ]] || { cat /tmp/repo.json; fail "repo creation failed (HTTP $HTTP)"; }
  [[ "$HTTP" == "422" ]] && echo "(repo already existed — continuing)"
fi
REPO_URL="https://github.com/$GITHUB_USER/$REPO_NAME"
echo "repo: $REPO_URL"

step "6/7 push"
if [[ "$DRY_RUN" != "1" ]]; then
  git remote remove origin 2>/dev/null || true
  git remote add origin "https://x-access-token:$GITHUB_TOKEN@github.com/$GITHUB_USER/$REPO_NAME.git"
  GIT_TERMINAL_PROMPT=0 git push -q -u origin "$BRANCH" || fail "push failed — check token scope / repo size"
  git remote set-url origin "$REPO_URL"   # strip token from remote config
fi
echo "pushed $BRANCH"

step "7/7 VERIFY remote repository"
verify() { # path -> prints ok/missing
  local p="$1" code
  code=$(curl -s -o /dev/null -w "%{http_code}" -H "Authorization: Bearer $GITHUB_TOKEN" \
         "$API/repos/$GITHUB_USER/$REPO_NAME/contents/$p?ref=$BRANCH")
  [[ "$code" == "200" ]] && echo "  ✅ $p" || { echo "  ❌ $p (HTTP $code)"; return 1; }
}
if [[ "$DRY_RUN" != "1" ]]; then
  OK=1
  code=$(curl -s -o /dev/null -w "%{http_code}" "$REPO_URL")
  [[ "$code" == "200" || "$code" == "404" ]] || fail "repo unreachable"
  verify "project.godot"  || OK=0
  verify "README.md"      || OK=0
  verify ".gitignore"     || OK=0
  verify "scenes"         || OK=0
  verify "scripts"        || OK=0
  [[ "$OK" == "1" ]] || fail "remote verification failed — repository incomplete"
fi

step "FINAL REPORT"
{
  echo "repo_url     : $REPO_URL"
  echo "commit_hash  : $COMMIT_HASH"
  echo "branch       : $BRANCH"
  echo "upload_status: SUCCESS (verified via GitHub API)"
} | tee /tmp/island-strike-release-report.txt
