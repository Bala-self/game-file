#!/usr/bin/env python3
"""
ISLAND STRIKE — pre-release project auditor (Godot 4.x)
=======================================================
Verifies a Godot project is release-clean BEFORE it is committed/pushed:

  1. project.godot present + parses (name, version, main scene)
  2. Every res:// path referenced by scenes/scripts/resources exists
     (ext_resource paths, load()/preload() strings, uid:// via .uid sidecars)
  3. Secret scan (API keys, tokens, private keys, passwords)
  4. Junk/cache inventory that should be cleaned before commit
  5. Packaging inventory (scenes / scripts / resources / build artifacts)

Exit code 0 = release-clean, 1 = problems found, 2 = no project found.

Usage:  python3 audit_project.py /path/to/project [--json out.json]
"""
import json
import os
import re
import sys
from collections import Counter

TEXT_EXT = {".gd", ".tscn", ".tres", ".godot", ".cfg", ".import", ".md",
            ".txt", ".csv", ".json", ".escn", ".gdns", ".godot", ".shader",
            ".gdshader", ".uid", ".cs", ".gitignore"}

SECRET_PATTERNS = [
    (r"ghp_[A-Za-z0-9]{36,}", "GitHub personal access token"),
    (r"gho_[A-Za-z0-9]{36,}", "GitHub OAuth token"),
    (r"github_pat_[A-Za-z0-9_]{20,}", "GitHub fine-grained PAT"),
    (r"AKIA[0-9A-Z]{16}", "AWS access key"),
    (r"sk-[A-Za-z0-9]{20,}", "OpenAI-style API key"),
    (r"xox[baprs]-[A-Za-z0-9-]{10,}", "Slack token"),
    (r"-----BEGIN (RSA|EC|OPENSSH|PGP|DSA) PRIVATE KEY-----", "Private key block"),
    (r"(?i)(api[_-]?key|secret|passwd|password)\s*[=:]\s*[\"'][^\"']{8,}[\"']", "Hard-coded credential assignment"),
    (r"(?i)authorization\s*:\s*bearer\s+[A-Za-z0-9._-]{16,}", "Bearer token in code"),
]

RES_PATH = re.compile(r"res://[^\"'\s\)\]]+")
UID_PATH = re.compile(r"uid://[a-z0-9]+")


def is_text(path):
    return os.path.splitext(path)[1].lower() in TEXT_EXT


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    root = os.path.abspath(sys.argv[1])
    json_out = None
    if "--json" in sys.argv:
        json_out = sys.argv[sys.argv.index("--json") + 1]

    pg = os.path.join(root, "project.godot")
    problems, warnings = [], []

    if not os.path.isfile(pg):
        print(f"[FAIL] No project.godot at {root} — this is not a Godot project.")
        return 2

    # ---- 1. project.godot -------------------------------------------------
    pg_text = open(pg, encoding="utf-8", errors="replace").read()
    name = re.search(r'name="([^"]*)"', pg_text)
    main_scene = re.search(r'run/main_scene\s*=\s*"([^"]+)"', pg_text)
    feat = re.findall(r'"4\.(\d+)"', pg_text)
    print(f"[OK]   project.godot found")
    print(f"       name       : {name.group(1) if name else '?'}")
    print(f"       main_scene : {main_scene.group(1) if main_scene else 'NOT SET'}")
    print(f"       godot 4.{feat[0] if feat else '?'} feature tag")
    if not main_scene:
        problems.append("project.godot has no run/main_scene")

    # ---- gather files ------------------------------------------------------
    all_files, junk = [], []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in (".git", ".godot")]
        for f in filenames:
            p = os.path.join(dirpath, f)
            all_files.append(os.path.relpath(p, root))
    for d in (".godot",):
        if os.path.isdir(os.path.join(root, d)):
            junk.append(d + "/ (regenerable cache — must be gitignored)")

    exists_cache = set(all_files)

    # uid:// resolution via .uid sidecars (Godot 4.4+)
    uid_map = {}
    for rel in all_files:
        if rel.endswith(".uid"):
            try:
                u = open(os.path.join(root, rel), encoding="utf-8").read().strip()
                if u.startswith("uid://"):
                    uid_map[u] = rel[:-4]
            except OSError:
                pass

    # ---- 2. res:// reference check -----------------------------------------
    refs = Counter()
    missing, uid_missing = [], []
    for rel in all_files:
        if not is_text(rel):
            continue
        full = os.path.join(root, rel)
        try:
            text = open(full, encoding="utf-8", errors="replace").read()
        except OSError:
            continue
        for m in RES_PATH.findall(text):
            path = m.rstrip(".,;:!?")
            if path.startswith("res://.godot/"):
                continue  # engine import cache — regenerated, never committed
            refs[path] += 1
            candidate = path.removeprefix("res://")
            if candidate.startswith("./"):
                candidate = candidate[2:]
            if not any(x == candidate or x.startswith(candidate + ".")
                       for x in exists_cache):
                # .import sources: the source file must exist, not the .import
                if candidate + ".import" in exists_cache:
                    continue
                missing.append((rel, path))
        for u in UID_PATH.findall(text):
            if u not in uid_map and u not in text:
                uid_missing.append((rel, u))

    n_scenes = sum(1 for f in all_files if f.endswith(".tscn"))
    n_scripts = sum(1 for f in all_files if f.endswith((".gd", ".cs")))
    n_res = sum(1 for f in all_files if f.endswith((".tres", ".res")))

    print(f"[OK]   {len(all_files)} files | {n_scenes} scenes | {n_scripts} scripts | {n_res} resources")
    print(f"[OK]   {sum(refs.values())} res:// references scanned")

    for src, p in missing[:40]:
        problems.append(f"missing res:// target {p} (referenced in {src})")
    if len(missing) > 40:
        print(f"       … and {len(missing) - 40} more missing references")
    for src, u in uid_missing[:20]:
        warnings.append(f"unresolvable {u} in {src}")

    # ---- 3. secret scan ----------------------------------------------------
    secrets = []
    for rel in all_files:
        if not is_text(rel) or rel == "project.godot":
            continue
        try:
            text = open(os.path.join(root, rel), encoding="utf-8", errors="replace").read()
        except OSError:
            continue
        for pat, label in SECRET_PATTERNS:
            if re.search(pat, text):
                secrets.append(f"{label} -> {rel}")
                problems.append(f"SECRET ({label}) found in {rel}")

    # ---- 4/5. junk + packaging inventory -----------------------------------
    exe = [f for f in all_files if f.lower().endswith(".exe")]
    pck = [f for f in all_files if f.lower().endswith(".pck")]
    zip_ = [f for f in all_files if f.lower().endswith((".zip", ".7z"))]
    big = [(f, os.path.getsize(os.path.join(root, f)))
           for f in all_files
           if os.path.getsize(os.path.join(root, f)) > 90 * 1024 * 1024]
    for f, s in big:
        warnings.append(f"{f} is {s/1e6:.0f} MB (>90 MB — GitHub blocks files >100 MB)")

    if junk:
        warnings.append("clean before commit: " + ", ".join(junk))
    if not exe:
        warnings.append("no Windows build (.exe) present in project tree")

    # ---- report -------------------------------------------------------------
    print()
    for w in warnings:
        print(f"[WARN] {w}")
    for p in problems:
        print(f"[FAIL] {p}")
    print()
    if problems:
        print(f"RESULT: NOT RELEASE-CLEAN — {len(problems)} problem(s).")
        rc = 1
    else:
        print("RESULT: RELEASE-CLEAN ✓ (no missing refs, no secrets, no critical gaps)")
        rc = 0

    if json_out:
        json.dump({"problems": problems, "warnings": warnings,
                   "files": len(all_files), "scenes": n_scenes,
                   "scripts": n_scripts, "secrets": secrets,
                   "missing_refs": missing},
                  open(json_out, "w"), indent=2)
    return rc


if __name__ == "__main__":
    sys.exit(main())
