/*
  Portfolio interactions — intentionally minimal.
  The site has no persistent navigation, so the behaviors are:

  1. Smooth in-page scrolling for footer nav links and the hero
     "View Projects" button, honouring the visitor's reduced-motion
     preference.
  2. A "back to top" button that appears once the hero is scrolled past.
  3. A reveal-on-scroll system — one signature animation per section
     (masked name reveal, drawing rules, springy pops, screenshot
     settle). Progressive enhancement: content is fully visible without
     JavaScript, and all motion is skipped for reduced-motion users.
  4. A scroll-spy rail in the "Selected Work" masthead that fills with reading
     progress through the vertical project list and jumps to a project on click.

  The page remains fully readable and all links keep working even if
  this file fails to load.
*/

(function () {
  'use strict';

  // Flag that JS is running (set early in <head> too) so the overlay states
  // only apply when the script can actually drive them.
  document.documentElement.classList.add('js');

  // Shared reduced-motion check, read live so it also applies if the
  // visitor changes the OS setting mid-session.
  var reduceMotionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');

  function prefersReducedMotion() {
    return reduceMotionQuery.matches;
  }

  // 1. Smooth scrolling for in-page links (e.g. #projects, #contact)
  var inPageLinks = document.querySelectorAll('a[href^="#"]');

  inPageLinks.forEach(function (link) {
    link.addEventListener('click', function (event) {
      var hash = link.getAttribute('href');

      // Let the browser handle empty or non-matching targets
      if (!hash || hash.length < 2) {
        return;
      }

      var target = document.querySelector(hash);
      if (!target) {
        return;
      }

      // Visitors who prefer reduced motion get the default instant jump
      if (prefersReducedMotion()) {
        return;
      }

      event.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  });

  // 2. Back-to-top button
  //    The page content runs to within 32px of the viewport edge, so a fixed
  //    bottom-right button unavoidably sits on top of the carousel arrows, the
  //    read-more button, and the close button in the project cards. Rather than
  //    inset those controls (which would need ~78px at 1440px and ~94px at
  //    390px and would visibly break their alignment), the button steps aside
  //    whenever it would cover something interactive.
  var backToTopButton = document.getElementById('backToTop');
  var hero = document.getElementById('top');

  if (backToTopButton && hero) {
    var pageEnd = document.querySelectorAll('#contact, .footer');
    var nearPageEnd = false;
    var backToTopFrame = null;

    // Cached once: the set of controls on the page never changes at runtime.
    var backToTopControls = null;

    function getBackToTopControls() {
      if (backToTopControls === null) {
        backToTopControls = Array.prototype.filter.call(
          document.querySelectorAll('a[href], button'),
          function (el) { return el !== backToTopButton; }
        );
      }

      return backToTopControls;
    }

    // True when a visible control is sitting underneath the button. Compared
    // rectangle-to-rectangle rather than by hit-testing points, so rounded
    // corners and overlapping siblings can never cause a miss.
    // The resting box, independent of the current visual state. The entrance
    // state is offset by a translateY, and measuring the offset box instead of
    // the resting one creates a feedback loop: the check would clear a gap the
    // button then overshoots into.
    function backToTopRestingRect() {
      var rect = backToTopButton.getBoundingClientRect();
      var transform = window.getComputedStyle(backToTopButton).transform;

      if (transform && transform !== 'none' && typeof DOMMatrixReadOnly === 'function') {
        var matrix = new DOMMatrixReadOnly(transform);

        return {
          left: rect.left - matrix.m41,
          right: rect.right - matrix.m41,
          top: rect.top - matrix.m42,
          bottom: rect.bottom - matrix.m42,
          width: rect.width,
          height: rect.height
        };
      }

      return rect;
    }

    function backToTopIsObstructed() {
      var rect = backToTopRestingRect();

      if (!rect.width || !rect.height) {
        return false;
      }

      var controls = getBackToTopControls();

      for (var i = 0; i < controls.length; i++) {
        var el = controls[i];
        var box = el.getBoundingClientRect();

        if (!box.width || !box.height) {
          continue;
        }

        // Cheap reject before touching computed style.
        if (box.bottom < 0 || box.top > window.innerHeight) {
          continue;
        }

        if (Math.min(rect.right, box.right) - Math.max(rect.left, box.left) < 4 ||
            Math.min(rect.bottom, box.bottom) - Math.max(rect.top, box.top) < 4) {
          continue;
        }

        var cs = window.getComputedStyle(el);

        if (cs.visibility === 'hidden' || cs.display === 'none' || parseFloat(cs.opacity) === 0) {
          continue;
        }

        return true;
      }

      return false;
    }

    function toggleBackToTop() {
      backToTopFrame = null;

      // Show only after the hero has been scrolled past, and only where the
      // button has clear space of its own.
      var shouldShow = window.scrollY > hero.offsetHeight &&
                       !nearPageEnd &&
                       !backToTopIsObstructed();

      backToTopButton.classList.toggle('is-visible', shouldShow);
    }

    function requestBackToTopUpdate() {
      if (backToTopFrame !== null) {
        return;
      }

      backToTopFrame = window.requestAnimationFrame(toggleBackToTop);
    }

    if (pageEnd.length && 'IntersectionObserver' in window) {
      var endObserver = new IntersectionObserver(
        function (entries) {
          entries.forEach(function (entry) {
            entry.target.dataset.nearEnd = entry.isIntersecting ? '1' : '0';
          });

          nearPageEnd = Array.prototype.some.call(pageEnd, function (el) {
            return el.dataset.nearEnd === '1';
          });

          requestBackToTopUpdate();
        },
        { rootMargin: '0px 0px -40% 0px' }
      );

      pageEnd.forEach(function (el) { endObserver.observe(el); });
    }

    window.addEventListener('scroll', requestBackToTopUpdate, { passive: true });
    window.addEventListener('resize', requestBackToTopUpdate);
    toggleBackToTop(); // Set the correct state on page load

    backToTopButton.addEventListener('click', function () {
      if (prefersReducedMotion()) {
        window.scrollTo(0, 0);
      } else {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    });
  }

  // 3. Reveal on scroll
  var revealElements = document.querySelectorAll('.reveal');

  if (
    revealElements.length > 0 &&
    'IntersectionObserver' in window &&
    !prefersReducedMotion()
  ) {
    // Flag that JS is running, so the hidden initial states only apply
    // when the reveal script is actually able to reveal elements.
    document.documentElement.classList.add('js');

    // A masked line starts translated fully outside its `overflow: hidden`
    // parent, so its own intersection ratio is 0 forever — observing the line
    // itself would deadlock and it would never be revealed. Observe the
    // clipping wrapper instead, then reveal the line inside it.
    function revealTargetFor(element) {
      return element.parentElement && element.parentElement.classList.contains('mask')
        ? element.parentElement
        : element;
    }

    var observer = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (!entry.isIntersecting) {
            return;
          }

          var target = entry.target;
          var line = target.classList.contains('mask')
            ? target.querySelector('.reveal-mask')
            : null;

          (line || target).classList.add('in');
          observer.unobserve(target);
        });
      },
      // threshold 0 so any sliver of the element triggers the reveal; the
      // bottom inset keeps the timing intentional.
      { threshold: 0, rootMargin: '0px 0px -48px 0px' }
    );

    revealElements.forEach(function (element) {
      observer.observe(revealTargetFor(element));
    });
  }

  // 4. Horizontal engine removed — projects are now a plain vertical list.
  //    The masthead rail is a scroll-spy over that list: each segment fills as
  //    you scroll through its project, and clicking one jumps to it.
  var projectSection = document.getElementById('projects');
  var projectList = projectSection && projectSection.querySelector('.project-list');
  var projectCards = projectList ? projectList.querySelectorAll('.project') : [];
  var projectSegs = projectSection ? projectSection.querySelectorAll('.work-seg') : [];
  var projectReadoutName = projectSection && projectSection.querySelector('[data-rail-name]');
  var projectRailLive = projectSection && projectSection.querySelector('[data-rail-live]');

  // "BillPro — GST Billing System" -> "BillPro", for the masthead readout.
  var projectShortNames = [];

  projectCards.forEach(function (card) {
    var nameEl = card.querySelector('.project-name');
    var full = nameEl ? nameEl.textContent.trim() : '';
    projectShortNames.push(full.split('\u2014')[0].trim() || full);
  });

  if (projectCards.length && projectSegs.length) {
    var railFrame = null;
    var lastAnnouncedIndex = -1;

    function clamp01(value) {
      return Math.max(0, Math.min(1, value));
    }

    // Which project is under the reading line — a touch below the top so a
    // card counts as "current" once its header has settled into view.
    function currentProjectIndex(focusLine) {
      var best = 0;

      for (var i = 0; i < projectCards.length; i++) {
        if (projectCards[i].getBoundingClientRect().top <= focusLine) {
          best = i;
        }
      }

      return best;
    }

    function updateRail() {
      railFrame = null;

      var viewportHeight = window.innerHeight;
      var focusLine = viewportHeight * 0.34;

      for (var i = 0; i < projectCards.length; i++) {
        var rect = projectCards[i].getBoundingClientRect();

        // Each segment fills as its project travels past the reading line,
        // so the rail doubles as a progress readout for the whole section.
        var fill = clamp01((focusLine - rect.top) / Math.max(rect.height, 1));

        if (projectSegs[i]) {
          projectSegs[i].style.setProperty('--f', fill.toFixed(4));
        }
      }

      var index = currentProjectIndex(focusLine);

      if (index !== lastAnnouncedIndex) {
        projectSegs.forEach(function (seg, i) {
          var isActive = i === index;
          seg.classList.toggle('is-active', isActive);

          if (isActive) {
            seg.setAttribute('aria-current', 'true');
          } else {
            seg.removeAttribute('aria-current');
          }
        });

        if (projectReadoutName) {
          projectReadoutName.textContent = projectShortNames[index] || '';
        }

        if (projectRailLive) {
          projectRailLive.textContent = 'Project ' + (index + 1) + ' of ' +
            projectCards.length + ': ' + (projectShortNames[index] || '');
        }

        lastAnnouncedIndex = index;
      }
    }

    function requestRailUpdate() {
      if (railFrame !== null) {
        return;
      }

      railFrame = window.requestAnimationFrame(updateRail);
    }

    // Clicking a segment scrolls straight to that project.
    projectSegs.forEach(function (seg, segIndex) {
      seg.addEventListener('click', function () {
        var card = projectCards[segIndex];

        if (!card) {
          return;
        }

        var top = card.getBoundingClientRect().top + window.scrollY -
                  (window.innerWidth >= 768 ? 24 : 16);

        window.scrollTo({
          top: top,
          behavior: prefersReducedMotion() ? 'auto' : 'smooth'
        });
      });
    });

    window.addEventListener('scroll', requestRailUpdate, { passive: true });
    window.addEventListener('resize', requestRailUpdate);

    if ('ResizeObserver' in window) {
      var railResizeObserver = new ResizeObserver(requestRailUpdate);
      projectCards.forEach(function (card) { railResizeObserver.observe(card); });
    }

    updateRail();
  }


  // 5. Project screenshots — carousel with side arrows, a "Read more" panel
  // that opens over the image, and a per-project like button.
  // Everything degrades to the first screenshot plus plain links with no JS.
  (function () {
    var carousels = document.querySelectorAll('[data-carousel]');

    if (!carousels.length) {
      return;
    }

    // One overlay at a time: opening a card closes any other open card.
    var openPanels = [];

    function closeAllExcept(panel) {
      openPanels.forEach(function (entry) {
        if (entry.panel !== panel) {
          entry.close();
        }
      });
    }

    carousels.forEach(function (root) {
      var article = root.closest('.project');
      var track = root.querySelector('.shot-track');
      var slides = root.querySelectorAll('.shot-slide');
      var dots = root.querySelectorAll('.shot-dot');
      var current = root.querySelector('[data-count]');
      var prevBtn = root.querySelector('.shot-nav--prev');
      var nextBtn = root.querySelector('.shot-nav--next');
      var details = root.querySelector('[data-details]');
      var closeBtn = root.querySelector('[data-details-close]');
      var toggleBtn = article && article.querySelector('[data-details-toggle]');
      var toggleLabel = toggleBtn && toggleBtn.querySelector('[data-toggle-label]');
      var likeBtn = root.querySelector('[data-like]');
      var likeCount = root.querySelector('[data-like-count]');
      var total = slides.length;
      var index = 0;

      // ---- carousel -------------------------------------------------------
      function show(nextIndex) {
        if (!total) {
          return;
        }

        index = ((nextIndex % total) + total) % total;   // wraps both ways
        track.style.transform = 'translate3d(' + (-index * 100) + '%, 0, 0)';

        dots.forEach(function (dot, i) {
          var active = i === index;
          dot.classList.toggle('is-active', active);
          if (active) {
            dot.setAttribute('aria-current', 'true');
          } else {
            dot.removeAttribute('aria-current');
          }
        });

        if (current) {
          current.textContent = String(index + 1);
        }
      }

      if (prevBtn) {
        prevBtn.addEventListener('click', function () { show(index - 1); });
      }

      if (nextBtn) {
        nextBtn.addEventListener('click', function () { show(index + 1); });
      }

      dots.forEach(function (dot) {
        dot.addEventListener('click', function () {
          show(parseInt(dot.getAttribute('data-go'), 10) || 0);
        });
      });

      // Arrow keys while focus is inside the carousel
      root.addEventListener('keydown', function (event) {
        if (event.key === 'ArrowLeft') { show(index - 1); }
        if (event.key === 'ArrowRight') { show(index + 1); }
      });

      // Touch swipe
      var touchStartX = null;

      root.addEventListener('touchstart', function (event) {
        touchStartX = event.changedTouches[0].clientX;
      }, { passive: true });

      root.addEventListener('touchend', function (event) {
        if (touchStartX === null) {
          return;
        }

        var delta = event.changedTouches[0].clientX - touchStartX;
        touchStartX = null;

        if (Math.abs(delta) > 40) {
          show(delta < 0 ? index + 1 : index - 1);
        }
      }, { passive: true });

      // ---- read more panel ------------------------------------------------
      if (details && toggleBtn) {
        var hideTimer = null;

        function open() {
          closeAllExcept(entry);
          window.clearTimeout(hideTimer);
          details.hidden = false;

          window.requestAnimationFrame(function () {
            details.classList.add('is-open');
          });

          toggleBtn.setAttribute('aria-expanded', 'true');
          if (toggleLabel) { toggleLabel.textContent = 'Read less'; }

          if (closeBtn) { closeBtn.focus(); }
        }

        function close(returnFocus) {
          details.classList.remove('is-open');
          toggleBtn.setAttribute('aria-expanded', 'false');
          if (toggleLabel) { toggleLabel.textContent = 'Read more'; }

          hideTimer = window.setTimeout(function () {
            if (!details.classList.contains('is-open')) {
              details.hidden = true;
            }
          }, 320);

          if (returnFocus) { toggleBtn.focus(); }
        }

        var entry = { panel: details, close: close };
        openPanels.push(entry);

        toggleBtn.addEventListener('click', function () {
          if (details.classList.contains('is-open')) {
            close(false);
          } else {
            open();
          }
        });

        if (closeBtn) {
          closeBtn.addEventListener('click', function () { close(true); });
        }

        // Click anywhere on the backdrop (but not the text) closes it
        details.addEventListener('click', function (event) {
          if (event.target === details || event.target === details.querySelector('.shot-details-inner')) {
            close(true);
          }
        });

        // Reset the panel if it is closed by other means
        details.addEventListener('transitionend', function () {
          if (!details.classList.contains('is-open')) {
            details.hidden = true;
          }
        });
      }

      // ---- like button ----------------------------------------------------
      if (likeBtn) {
        var key = 'bkm-like-' + (article && article.querySelector('.project-index')
          ? article.querySelector('.project-index').textContent.trim()
          : 'x');
        var liked = false;
        var count = 0;

        try {
          var stored = window.localStorage.getItem(key);
          if (stored) {
            var parsed = JSON.parse(stored);
            liked = !!parsed.liked;
            count = parseInt(parsed.count, 10) || 0;
          }
        } catch (error) {
          /* storage unavailable (private mode / sandboxed frame) — stay in memory */
        }

        function paint() {
          likeBtn.classList.toggle('is-liked', liked);
          likeBtn.setAttribute('aria-pressed', liked ? 'true' : 'false');
          if (likeCount) { likeCount.textContent = String(count); }
        }

        function persist() {
          try {
            window.localStorage.setItem(key, JSON.stringify({ liked: liked, count: count }));
          } catch (error) {
            /* ignore */
          }
        }

        paint();

        likeBtn.addEventListener('click', function () {
          liked = !liked;
          count = Math.max(0, count + (liked ? 1 : -1));
          paint();
          persist();

          likeBtn.classList.remove('is-pop');
          void likeBtn.offsetWidth;   // restart the pop animation
          likeBtn.classList.add('is-pop');
        });
      }

      // The panel is visible by default so no-JS visitors can read it;
      // now that the script is running, it becomes an on-demand overlay.
      if (details) {
        details.hidden = true;
      }

      show(0);
    });

    // Escape closes whichever panel is open
    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') {
        openPanels.forEach(function (entry) { entry.close(true); });
      }
    });
  })();

})();
