# Balakrishnan M — Portfolio

Single-page developer portfolio. Pure HTML5, CSS3, and vanilla JavaScript —
no frameworks, no build step, no dependencies to install.

## Run it

Open `index.html` directly in a browser, or serve the folder locally:

```bash
cd portfolio
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Structure

```
portfolio/
├── index.html                  # all content and structure
├── css/
│   └── style.css               # all styles + the motion layer
├── js/
│   └── script.js               # smooth scroll, reveals, progress, back-to-top
└── assets/
    ├── images/                 # 3 carousel frames per project (1440x900)
    │   ├── billpro/01.jpg 02.jpg 03.jpg
    │   ├── pizza-palace/01.jpg 02.jpg 03.jpg
    │   ├── tripadvisor/01.jpg 02.jpg 03.jpg
    │   ├── kadai/01.jpg 02.jpg 03.jpg
    │   └── *-screenshot.png           # original full-page captures (source)
    ├── icons/                  # skill icons (sourced from github.com/Bala-self/game-file)
    │   ├── mysql.svg
    │   └── firebase.svg
    └── files/
        └── Balakrishnan_M_Resume.pdf   # resume download
```

## Design notes (v3)

- **Palette** (three colors + opacity variations, in `css/style.css` under `:root`):
  paper `#F4F1EA` · ink `#0F1E33` · cobalt `#1F44E0`.
- **Type**: Fraunces (display serif) · Instrument Sans (body) · IBM Plex Mono (labels/meta).
- **Alignment**: asymmetric hero with a quick-facts rail, section headers with a
  kicker + hairline rule, a vertical project card (meta + title, big screenshot,
  small intro, links + read more), indexed project meta rows connected by a
  responsive project timeline, large footer wordmark.
- **"Selected Work" masthead**: its own treatment, aligned to the section grid.
  A section-index chip sits next to the eyebrow — deliberately a chip, so it reads
  as a section number and not a second "01 / 04" counter. The old decorative
  hairline is replaced by a **segmented rail**: each segment fills as you scroll
  through its project, the active one is highlighted in cobalt, and clicking a
  segment scrolls to that project. It is hidden without JavaScript, since the spy
  and the jump both need scripting.
- **Project cards**: a single vertical stack, one card per project, each sized by
  its own content so the 16:10 screenshot can run the full column width without
  any viewport-fitting tricks. Arrows sit on the sides of the image, with dots, a
  counter, and a like button along the bottom. "Read more" opens the full detail
  panel *inside the image area* as an overlay, so the page itself never scrolls to
  reveal text. Long panels scroll within the frame (`overscroll-behavior: contain`),
  and Escape closes them.
- **Motion** (one signature animation per section, all progressive enhancements):
  hero entrance choreography with a masked name reveal · section rules that draw
  themselves · screenshot settle (scale 1.06 → 1) · staggered project cards ·
  a segmented rail in the section header that scroll-spies the project list and
  doubles as navigation · screenshot carousel with slide transitions ·
  like-button pop ·
  cobalt border draw on experience entries · skills column cascade ·
  typographic letter-spacing settle on dates · springy pop on contact actions ·
  footer wordmark mask reveal · scroll-progress hairline · link-arrow nudges.
  Everything is disabled under `prefers-reduced-motion`. With JavaScript
  turned off every project shows its first screenshot and the full detail text
  inline — nothing is hidden behind the read-more button.

## Navigation model

There is intentionally **no top navbar and no sidebar**. The footer is the
only site navigation (section links, social links, resume). The hero carries
its own copy of the social links and buttons because it is the first thing
seen. A "Skip to content" link is available on keyboard focus, and a
back-to-top button appears after scrolling past the hero.

## Editing content

- All text lives in `index.html` — edit it directly.
- Colors are defined once in `css/style.css` under `:root`
  (`--paper`, `--ink`, `--blue` + opacity variants).
- Each project shows three screenshots. Replace `assets/images/<project>/01.jpg`,
  `02.jpg`, `.03.jpg`. Frames are 16:10 (1440x900); keep that ratio and the layout
  will fit them without cropping.
- The full detail text for each project lives in `.shot-details` inside that
  project's `<article>`. It is visible without JavaScript and becomes the
  read-more overlay when the script runs.
- To update the resume, replace `assets/files/Balakrishnan_M_Resume.pdf`.

## Links used on the page

- GitHub: https://github.com/Bala-self
- LinkedIn: https://www.linkedin.com/in/balakrishnan-mariyappan-b43813294
- Email: balakrishnan.code@email.com
- BillPro repo: https://github.com/Bala-self/billing-software (not deployed publicly)
- Pizza Palace: demo https://pizza-palace-lake.vercel.app/ · repo https://github.com/Bala-self/pizza-palace
- TripAdvisor Clone: demo https://bala-self.github.io/tripadvisor.com/ · repo https://github.com/Bala-self/tripadvisor.com
- Kadai e-commerce website: repo https://github.com/Bala-self/ecommeres-website-using-firebase

## History

- **v4** — Removed the pinned horizontal project timeline entirely. It was replaced
  by a plain vertical stack: simpler, works at every width including phones, and
  keeps the large screenshot. The section header rail survives as a scroll-spy over
  the vertical list.
- **v3** — Pinned horizontal project timeline (since removed), project carousels,
  read-more overlays, like buttons.

## Accessibility & responsive hardening (v5)

Audited at 320 / 375 / 390 / 430 / 768 / 1024 / 1280 / 1440 / 1920 px.

- **Masked line reveal fixed.** A line inside `.mask` starts translated fully
  outside its `overflow: hidden` parent, so its own IntersectionObserver ratio is
  always 0 — the observer never fired and the hero name and footer wordmark never
  appeared. The observer now watches the clipping wrapper (threshold 0) and
  reveals the line inside it.
- **Back-to-top button steps aside.** The content column runs to within 32px of
  the viewport edge, so a fixed bottom-right button unavoidably covered the
  carousel arrows, the read-more button and the panel close button. It now hides
  whenever a visible control sits in its resting rectangle, measured before the
  entrance transform so the check cannot oscillate.
- **Dead tab stops removed.** Four `h3` and one `strong` carried `tabindex="0"`
  without being interactive; the skill headings were also styled with
  `cursor: pointer`, implying a control that did not exist.
- **Touch targets.** Carousel dots are 26×26 with a small painted dot inside;
  footer links and the standalone email link take padding to clear 24px; the like
  button has a 30px minimum height. Links inside a sentence are left tight —
  WCAG 2.5.8 exempts them and padding would break the line box.
- **Type floor.** Every label that sat below 12px (`--font-mono` meta text) is now
  at least 0.75rem.
- **Reduced motion** still shows all content immediately with no transform offset.

### Known limitations

- The Google Fonts request is the only external dependency; the preview iframe has
  no network access, so the site falls back to system fonts there. Downloading the
  repository and opening it in a browser loads them normally.
- Smooth scrolling between distant sections takes ~1.5s, which is the browser's own
  distance-proportional easing for a ~8000px journey.

## Design-system consolidation (v6)

Tokens added to `:root` so the visual language is defined once:

- **Type scale** — seven steps (`--text-2xs` 12px through `--text-xl` 20px).
  Previously 16 distinct non-display font sizes were declared ad hoc across
  individual rules; every non-display size now points at a token. Display
  headings stay fluid via `clamp()`.
- **Radius scale** — `--radius-sm` 6 (chips) · `--radius-md` 8 (buttons and
  controls) · `--radius-lg` 10 (panels) · `--radius-pill`. The skip link moved
  from 6 to 8 so it matches `.btn`, and the `.work-index` chip from 7 to 6.
- **Text-link treatment** — one definition instead of four. Inline links keep
  their underline at rest; links that stand alone as a row drop it and restore
  it on hover.

### Corrected

- **`.btn-outline` border failed WCAG 1.4.11.** At `rgba(15,30,51,0.4)` the
  border measured **2.43:1** against the paper background; the requirement for
  non-text UI boundaries is 3:1. Raised to `0.5`, which measures **3.19:1** and
  is visually near-identical.
- **Read-more text ran 256 characters per line** at 1920px — well past the 45-80
  that reads comfortably at UI sizes. Prose is now capped at 56ch (73 chars per
  line at every viewport); the stack and feature rows, which are scannable token
  lists rather than prose, are allowed 88ch so they stop wrapping raggedly.

### Asset housekeeping

Four full-size source screenshots (1.9 MB) were sitting in `assets/images/`
unused — the carousel uses the crops in `assets/images/<project>/`. They were
moved to `_source-originals/` alongside the site so the deployment ships only
what the page requests. Nothing referenced them, so runtime is unchanged; they
are kept in case the carousel frames ever need re-cropping.
