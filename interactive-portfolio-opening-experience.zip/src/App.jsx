import { useCallback, useEffect, useRef, useState } from "react";
import { AnimatePresence, MotionConfig, useReducedMotion } from "framer-motion";
import Preloader from "./components/Preloader.jsx";
import Intro from "./components/Intro.jsx";
import PortalReveal from "./components/PortalReveal.jsx";
import ChatbotPet from "./components/ChatbotPet.jsx";
import PetChat from "./components/PetChat.jsx";
import Homepage from "./components/Homepage.jsx";

/**
 * Experience state machine
 *   preload → intro → activating (pet jump) → portal (ring reveal) → done
 * A single ref-guard makes the PORTFOLIO trigger idempotent so repeated
 * clicks / skip + click can never start overlapping sequences.
 */
export default function App() {
  const reduced = !!useReducedMotion();
  const [phase, setPhase] = useState("preload");
  const [origin, setOrigin] = useState(null);
  const [chatOpen, setChatOpen] = useState(false);
  const [bubble, setBubble] = useState(false);
  const petRef = useRef(null);
  const busyRef = useRef(false);

  // Lock scrolling and pin to top while the intro owns the screen
  useEffect(() => {
    if ("scrollRestoration" in history) history.scrollRestoration = "manual";
    window.scrollTo(0, 0);
  }, []);

  useEffect(() => {
    const done = phase === "done";
    for (const el of [document.documentElement, document.body]) {
      el.classList.toggle("is-locked", !done);
      el.classList.toggle("is-site", done);
    }
    document.querySelector('meta[name="theme-color"]')?.setAttribute("content", done ? "#f1efea" : "#000000");
  }, [phase]);

  const handlePortfolio = useCallback(
    async (buttonEl) => {
      if (busyRef.current) return;
      busyRef.current = true;
      setPhase("activating");

      const r = buttonEl?.getBoundingClientRect();
      const target = r
        ? { x: r.left + r.width / 2, y: r.top + r.height / 2 }
        : { x: window.innerWidth / 2, y: window.innerHeight / 2 };

      await petRef.current?.activate({
        target,
        onLand: () => {
          setOrigin(petRef.current?.getFeetPoint() ?? { x: 60, y: window.innerHeight });
          setPhase("portal");
        },
      });
    },
    []
  );

  const handlePortalComplete = useCallback(() => {
    setPhase("done");
    petRef.current?.settle();
  }, []);

  // Greeting bubble once the pet settles on the homepage
  useEffect(() => {
    if (phase !== "done") return;
    const show = setTimeout(() => setBubble(true), 900);
    const hide = setTimeout(() => setBubble(false), 7500);
    return () => {
      clearTimeout(show);
      clearTimeout(hide);
    };
  }, [phase]);

  const handlePetClick = () => {
    if (phase !== "done") {
      petRef.current?.wiggle();
      return;
    }
    setBubble(false);
    setChatOpen((o) => !o);
  };

  const introVisible = phase !== "done";

  return (
    <MotionConfig reducedMotion="user">
      {/* 1. Real homepage — always mounted, inert until revealed */}
      <Homepage inert={introVisible} />

      {/* 2. Black intro layer, masked away by the portal */}
      {introVisible && (
        <PortalReveal active={phase === "portal"} origin={origin} reduced={reduced} onComplete={handlePortalComplete}>
          {phase !== "preload" && (
            <Intro reduced={reduced} locked={phase !== "intro"} onPortfolio={handlePortfolio} />
          )}
        </PortalReveal>
      )}

      {/* 3. Preloader */}
      <AnimatePresence>
        {phase === "preload" && <Preloader key="preloader" reduced={reduced} onDone={() => setPhase("intro")} />}
      </AnimatePresence>

      {/* 4. Pet + its chat */}
      <ChatbotPet
        ref={petRef}
        reduced={reduced}
        visible={phase !== "preload"}
        interactive={phase === "done"}
        onClick={handlePetClick}
        label={chatOpen ? "Close chat assistant" : "Open chat assistant"}
      />
      {phase === "done" && (
        <PetChat open={chatOpen} onClose={() => setChatOpen(false)} showBubble={bubble} reduced={reduced} />
      )}
    </MotionConfig>
  );
}
