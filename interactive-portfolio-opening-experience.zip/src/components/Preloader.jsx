import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { EASE } from "../lib/easing";

/**
 * Preloader
 * A restrained boot sequence: a tabular counter and a hairline track.
 * Progress is tied to real work — the Tamil & Devanagari webfonts must be
 * ready before the intro begins, so every glyph renders correctly on first paint.
 * When complete, the hairline contracts to a single point and dissolves.
 */
const FONT_CHECKS = [
  '300 48px "Inter"',
  '300 48px "Noto Sans Tamil"',
  '300 48px "Noto Sans Devanagari"',
  '400 13px "JetBrains Mono"',
];

const SAMPLE = "Hi வணக்கம் नमस्ते 0123";

function waitForFonts(timeout = 3500) {
  if (typeof document === "undefined" || !document.fonts) return Promise.resolve();
  const loads = Promise.all(
    FONT_CHECKS.map((f) => document.fonts.load(f, SAMPLE).catch(() => null))
  ).then(() => document.fonts.ready);
  const timer = new Promise((r) => setTimeout(r, timeout));
  return Promise.race([loads, timer]);
}

export default function Preloader({ reduced, onDone }) {
  const [count, setCount] = useState(0);
  const [phase, setPhase] = useState("loading"); // loading → closing
  const fillRef = useRef(null);
  const doneRef = useRef(onDone);
  doneRef.current = onDone;

  useEffect(() => {
    let ready = false;
    let raf = 0;
    let finished = false;
    let shown = 0;
    const start = performance.now();
    const minDuration = reduced ? 300 : 1900;

    waitForFonts().then(() => {
      ready = true;
    });

    const tick = (now) => {
      const elapsed = now - start;
      const timeGoal = Math.min(elapsed / minDuration, 1) * 100;
      const goal = ready ? timeGoal : Math.min(timeGoal, 86);
      // critically-damped follow → organic, never jumpy
      shown += (goal - shown) * (reduced ? 1 : 0.085);
      if (ready && timeGoal >= 100 && shown > 99.6) shown = 100;

      if (fillRef.current) fillRef.current.style.transform = `scaleX(${shown / 100})`;
      setCount(Math.floor(shown));

      if (shown >= 100) {
        if (!finished) {
          finished = true;
          setPhase("closing");
          setTimeout(() => doneRef.current?.(), reduced ? 150 : 900);
        }
        return;
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [reduced]);

  const closing = phase === "closing";

  return (
    <motion.div
      className="preloader"
      role="status"
      aria-live="polite"
      aria-label={`Loading portfolio, ${count} percent`}
      exit={{ opacity: 0, transition: { duration: reduced ? 0.2 : 0.4 } }}
    >
      <div className="preloader-inner">
        <motion.div
          className="preloader-row"
          animate={closing ? { opacity: 0, y: -10 } : { opacity: 1, y: 0 }}
          initial={{ opacity: 0, y: 6 }}
          transition={{ duration: 0.6, ease: EASE.out }}
        >
          <span>Balakrishnan</span>
          <span className="preloader-count">{String(count).padStart(3, "0")}</span>
        </motion.div>

        <motion.div
          className="preloader-track"
          initial={{ scaleX: 0 }}
          animate={closing ? { scaleX: 0, opacity: 0 } : { scaleX: 1, opacity: 1 }}
          transition={
            closing
              ? { scaleX: { duration: 0.75, ease: EASE.inOut }, opacity: { delay: 0.55, duration: 0.25 } }
              : { duration: 0.9, ease: EASE.out }
          }
        >
          <div ref={fillRef} className="preloader-fill" style={{ transform: "scaleX(0)" }} />
        </motion.div>

        <motion.div
          className="preloader-row"
          animate={closing ? { opacity: 0, y: 10 } : { opacity: 1, y: 0 }}
          initial={{ opacity: 0, y: -6 }}
          transition={{ duration: 0.6, ease: EASE.out, delay: closing ? 0 : 0.1 }}
        >
          <span>Full Stack Developer</span>
          <span aria-hidden="true" className="preloader-glyphs">
            <span lang="en">Aa</span>
            <span lang="ta">அ</span>
            <span lang="hi">अ</span>
          </span>
        </motion.div>
      </div>
    </motion.div>
  );
}
