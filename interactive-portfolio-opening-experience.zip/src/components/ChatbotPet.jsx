import { forwardRef, useCallback, useEffect, useImperativeHandle, useRef, useState } from "react";
import { animate, motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { clamp } from "../lib/easing";

/**
 * ChatbotPet — "Bit"
 * A small, curious robot that lives on the bottom edge of the viewport.
 *  • Eyes follow the pointer (spring-damped), face shifts with parallax depth
 *  • Natural, irregular blinking (with occasional double-blinks)
 *  • Breathing + antenna sway idle loop; curious glances when the visitor is still
 *  • Imperative API: activate() → notice → look at visitor → crouch → jump → land
 */

const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const EYE_X = 5;
const EYE_Y = 3.6;

const ChatbotPet = forwardRef(function ChatbotPet(
  { reduced, visible = true, interactive = false, onClick, label = "Open chat assistant" },
  ref
) {
  const rootRef = useRef(null);
  const jumpRef = useRef(null);
  const squashRef = useRef(null);
  const shadowRef = useRef(null);
  const eyesBlinkRef = useRef(null);
  const antennaBallRef = useRef(null);

  const lockRef = useRef(false); // when true, pointer tracking is suspended
  const lastMoveRef = useRef(0);
  const [mood, setMood] = useState("idle"); // idle | happy | surprised
  const [hover, setHover] = useState(false);

  // Gaze (normalized −1…1), spring-smoothed
  const gx = useMotionValue(0);
  const gy = useMotionValue(0);
  const sx = useSpring(gx, { stiffness: 170, damping: 18, mass: 0.6 });
  const sy = useSpring(gy, { stiffness: 170, damping: 18, mass: 0.6 });
  const eyeX = useTransform(sx, (v) => v * EYE_X);
  const eyeY = useTransform(sy, (v) => v * EYE_Y);
  const faceX = useTransform(sx, (v) => v * 2.2);
  const faceY = useTransform(sy, (v) => v * 1.4);
  const tilt = useTransform(sx, (v) => v * 2.5);

  const lookAtPoint = useCallback((px, py) => {
    const el = rootRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const cx = r.left + r.width / 2;
    const cy = r.top + r.height * 0.55;
    const dx = px - cx;
    const dy = py - cy;
    const dist = Math.hypot(dx, dy) || 1;
    const reach = clamp(dist / 260, 0, 1);
    gx.set((dx / dist) * reach);
    gy.set((dy / dist) * reach);
  }, [gx, gy]);

  // Pointer tracking
  useEffect(() => {
    const onMove = (e) => {
      lastMoveRef.current = performance.now();
      if (lockRef.current) return;
      lookAtPoint(e.clientX, e.clientY);
    };
    window.addEventListener("pointermove", onMove, { passive: true });
    return () => window.removeEventListener("pointermove", onMove);
  }, [lookAtPoint]);

  const blink = useCallback(async (times = 1) => {
    const el = eyesBlinkRef.current;
    if (!el) return;
    for (let i = 0; i < times; i++) {
      await animate(el, { scaleY: [1, 0.08, 1] }, { duration: 0.17, ease: [0.4, 0, 0.6, 1], times: [0, 0.45, 1] });
      if (i < times - 1) await wait(90);
    }
  }, []);

  // Natural blinking
  useEffect(() => {
    if (reduced) return;
    let alive = true;
    let id;
    const loop = () => {
      id = setTimeout(async () => {
        if (!alive) return;
        await blink(Math.random() < 0.22 ? 2 : 1);
        loop();
      }, 2200 + Math.random() * 3600);
    };
    loop();
    return () => {
      alive = false;
      clearTimeout(id);
    };
  }, [blink, reduced]);

  // Curious idle glances when the visitor is still
  useEffect(() => {
    if (reduced) return;
    let id;
    const glances = [
      [-0.9, -0.2],
      [0.85, -0.35],
      [0.2, -0.9],
      [0, 0],
      [0.95, 0.1],
    ];
    const loop = () => {
      id = setTimeout(() => {
        if (!lockRef.current && performance.now() - lastMoveRef.current > 3500) {
          const [x, y] = glances[Math.floor(Math.random() * glances.length)];
          gx.set(x);
          gy.set(y);
        }
        loop();
      }, 3800 + Math.random() * 3000);
    };
    loop();
    return () => clearTimeout(id);
  }, [gx, gy, reduced]);

  const pingAntenna = useCallback(() => {
    if (!antennaBallRef.current || reduced) return;
    animate(antennaBallRef.current, { scale: [1, 1.6, 1] }, { duration: 0.45, ease: [0.22, 1, 0.36, 1] });
  }, [reduced]);

  useImperativeHandle(ref, () => ({
    /** Returns the pet's feet point in viewport coordinates. */
    getFeetPoint() {
      const r = rootRef.current?.getBoundingClientRect();
      if (!r) return { x: 60, y: window.innerHeight };
      return { x: r.left + r.width / 2, y: r.bottom - 1 };
    },

    /** Notice → look at visitor → crouch → jump → land (onLand fires at touchdown). */
    async activate({ target, onLand } = {}) {
      lockRef.current = true;
      const tx = target?.x ?? window.innerWidth / 2;
      const ty = target?.y ?? window.innerHeight / 2;

      // 1. Notice the interaction
      setMood("surprised");
      pingAntenna();
      lookAtPoint(tx, ty);

      if (reduced) {
        await wait(150);
        setMood("happy");
        onLand?.();
        return;
      }

      await wait(420);

      // 2. Turn to the visitor
      gx.set(0.05);
      gy.set(-0.15);
      setMood("idle");
      await blink(1);
      await wait(140);
      setMood("happy");

      const squash = squashRef.current;
      const jump = jumpRef.current;
      const shadow = shadowRef.current;

      // 3. Crouch (anticipation)
      await Promise.all([
        animate(squash, { scaleY: 0.8, scaleX: 1.13, rotate: 0 }, { duration: 0.3, ease: [0.45, 0, 0.55, 1] }),
        animate(shadow, { scaleX: 1.12, opacity: 1 }, { duration: 0.3 }),
      ]);

      // 4. Launch
      const height = clamp(window.innerHeight * 0.16, 70, 140);
      gy.set(0.55);
      await Promise.all([
        animate(jump, { y: -height }, { duration: 0.44, ease: [0.18, 0.85, 0.32, 1] }),
        animate(squash, { scaleY: [0.8, 1.14, 1], scaleX: [1.13, 0.9, 1] }, { duration: 0.44, times: [0, 0.35, 1], ease: "easeOut" }),
        animate(shadow, { scaleX: 0.45, opacity: 0.35 }, { duration: 0.44, ease: [0.18, 0.85, 0.32, 1] }),
      ]);

      // 5. Fall
      gy.set(0.85);
      await Promise.all([
        animate(jump, { y: 0 }, { duration: 0.32, ease: [0.55, 0, 0.92, 0.45] }),
        animate(squash, { scaleY: 1.07, scaleX: 0.95 }, { duration: 0.32, ease: "easeIn" }),
        animate(shadow, { scaleX: 1, opacity: 1 }, { duration: 0.32, ease: [0.55, 0, 0.92, 0.45] }),
      ]);

      // 6. Touchdown — the portal is born here
      onLand?.();
      await animate(squash, { scaleY: 0.76, scaleX: 1.18 }, { duration: 0.09, ease: "easeOut" });
      gy.set(-0.1);
      await animate(squash, { scaleY: 1, scaleX: 1 }, { type: "spring", stiffness: 520, damping: 13 });
    },

    /** Called after the portal completes: relax and resume tracking. */
    settle() {
      lockRef.current = false;
      setMood("happy");
      blink(2);
      setTimeout(() => setMood("idle"), 1400);
    },

    wiggle() {
      if (reduced || !squashRef.current) return;
      pingAntenna();
      animate(squashRef.current, { rotate: [0, -7, 6, -3, 0] }, { duration: 0.6, ease: "easeInOut" });
    },
  }), [blink, gx, gy, lookAtPoint, pingAntenna, reduced]);

  const showHappy = mood === "happy" || (hover && mood === "idle");
  const surprised = mood === "surprised";

  return (
    <motion.div
      ref={rootRef}
      className="pet"
      initial={{ y: "120%" }}
      animate={{ y: visible ? "0%" : "120%" }}
      transition={reduced ? { duration: 0 } : { type: "spring", stiffness: 140, damping: 16, delay: visible ? 0.2 : 0 }}
    >
      <div ref={shadowRef} className="pet-shadow" />
      <div ref={jumpRef} className="pet-jump">
        <div ref={squashRef} className="pet-squash">
          <div className="pet-breathe">
          <motion.div className="pet-tilt" style={{ rotate: tilt }}>
            <svg viewBox="0 0 76 84" aria-hidden="true">
              {/* antenna */}
              <g className="pet-antenna">
                <line x1="38" y1="25" x2="38" y2="12" stroke="#fff" strokeWidth="2.4" strokeLinecap="round" />
                <line x1="38" y1="25" x2="38" y2="12" stroke="#0a0a0a" strokeWidth="0.8" strokeOpacity="0.35" strokeLinecap="round" />
                <motion.circle
                  ref={antennaBallRef}
                  cx="38"
                  cy="9.5"
                  r="3.6"
                  fill="#fff"
                  stroke="#0a0a0a"
                  strokeWidth="1.2"
                  style={{ transformBox: "fill-box", transformOrigin: "50% 50%" }}
                />
              </g>

              {/* ears */}
              <rect x="3.5" y="41" width="6" height="15" rx="3" fill="#fff" stroke="#0a0a0a" strokeWidth="1.2" />
              <rect x="66.5" y="41" width="6" height="15" rx="3" fill="#fff" stroke="#0a0a0a" strokeWidth="1.2" />

              {/* feet */}
              <path d="M21 75 h12 v6.5 a2.5 2.5 0 0 1 -2.5 2.5 h-7 a2.5 2.5 0 0 1 -2.5 -2.5 z" fill="#fff" stroke="#0a0a0a" strokeWidth="1.2" />
              <path d="M43 75 h12 v6.5 a2.5 2.5 0 0 1 -2.5 2.5 h-7 a2.5 2.5 0 0 1 -2.5 -2.5 z" fill="#fff" stroke="#0a0a0a" strokeWidth="1.2" />

              {/* body */}
              <rect x="8" y="23" width="60" height="55" rx="23" fill="#fff" stroke="#0a0a0a" strokeWidth="1.4" />

              {/* face (parallax) */}
              <motion.g style={{ x: faceX, y: faceY }}>
                <rect x="15" y="33" width="46" height="29" rx="13" fill="#0a0a0a" />
                {/* visor glint */}
                <path d="M21 37.5 q4 -2.2 9 -2.2" stroke="#fff" strokeOpacity="0.22" strokeWidth="1.6" strokeLinecap="round" fill="none" />

                <motion.g style={{ x: eyeX, y: eyeY }}>
                  <g
                    ref={eyesBlinkRef}
                    style={{ transformBox: "fill-box", transformOrigin: "50% 50%" }}
                  >
                    {showHappy ? (
                      <>
                        <path d="M25 49.5 q4 -6.5 8 0" stroke="#fff" strokeWidth="2.6" strokeLinecap="round" fill="none" />
                        <path d="M43 49.5 q4 -6.5 8 0" stroke="#fff" strokeWidth="2.6" strokeLinecap="round" fill="none" />
                      </>
                    ) : (
                      <>
                        <rect
                          x={surprised ? 24.5 : 25.5}
                          y={surprised ? 39.5 : 41}
                          width={surprised ? 9 : 7}
                          height={surprised ? 13 : 11}
                          rx={surprised ? 4.5 : 3.5}
                          fill="#fff"
                        />
                        <rect
                          x={surprised ? 42.5 : 43.5}
                          y={surprised ? 39.5 : 41}
                          width={surprised ? 9 : 7}
                          height={surprised ? 13 : 11}
                          rx={surprised ? 4.5 : 3.5}
                          fill="#fff"
                        />
                      </>
                    )}
                  </g>
                  {/* mouth */}
                  {surprised ? (
                    <circle cx="38" cy="56.5" r="1.8" fill="none" stroke="#fff" strokeWidth="1.3" />
                  ) : (
                    <path
                      d={showHappy ? "M34.5 55.5 q3.5 3 7 0" : "M35.5 56 q2.5 1.6 5 0"}
                      stroke="#fff"
                      strokeOpacity="0.85"
                      strokeWidth="1.4"
                      strokeLinecap="round"
                      fill="none"
                    />
                  )}
                </motion.g>
              </motion.g>
            </svg>
          </motion.div>
          </div>
        </div>
      </div>

      <button
        type="button"
        className="pet-hit"
        aria-label={label}
        tabIndex={interactive ? 0 : -1}
        aria-hidden={interactive ? undefined : true}
        onPointerEnter={() => setHover(true)}
        onPointerLeave={() => setHover(false)}
        onClick={onClick}
      />
    </motion.div>
  );
});

export default ChatbotPet;
