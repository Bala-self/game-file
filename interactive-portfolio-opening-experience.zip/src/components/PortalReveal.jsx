import { useEffect, useRef } from "react";
import { cubicBezier, lerp, progress } from "../lib/easing";

/**
 * PortalReveal
 * Wraps the intro layer. When `active`, a hole is cut into the layer with an
 * animated radial mask, exposing the real homepage rendered beneath it.
 * A hairline ring is drawn exactly on the mask boundary so the portal edge
 * reads as a physical ring of light.
 *
 * Motion: the ring is born as a flat ellipse on the ground (perspective of the
 * floor under the pet's feet), rounds into a true circle as it lifts, then
 * sweeps across the viewport with a controlled ease-in-out.
 */

const EMERGE_MS = 420;
const EXPAND_MS = 1700;
const SEED_RX = 46;
const FLAT = 0.22; // ground-plane ellipse ratio at birth

const easeEmerge = cubicBezier(0.16, 1, 0.3, 1);
const easeExpand = cubicBezier(0.72, 0, 0.16, 1);
const easeRound = cubicBezier(0.33, 1, 0.68, 1);

function maskFor(rx, ry, x, y) {
  // 1.25px feather keeps the edge crisp but anti-aliased at any radius
  const edge = Math.max(0, 100 - (1.25 / Math.max(rx, 1)) * 100);
  return `radial-gradient(${rx.toFixed(2)}px ${ry.toFixed(2)}px at ${x}px ${y}px, transparent ${edge.toFixed(3)}%, #000 100%)`;
}

export default function PortalReveal({ active, origin, reduced, onComplete, children }) {
  const layerRef = useRef(null);
  const ringRef = useRef(null);
  const haloRef = useRef(null);
  const completeRef = useRef(onComplete);
  completeRef.current = onComplete;

  useEffect(() => {
    if (!active || !origin) return;
    const layer = layerRef.current;
    const ring = ringRef.current;
    const halo = haloRef.current;
    let raf = 0;
    let cancelled = false;

    if (reduced) {
      const anim = layer.animate([{ opacity: 1 }, { opacity: 0 }], {
        duration: 450,
        easing: "ease-out",
        fill: "forwards",
      });
      anim.onfinish = () => !cancelled && completeRef.current?.();
      return () => {
        cancelled = true;
        anim.cancel();
      };
    }

    const { x, y } = origin;
    const W = window.innerWidth;
    const H = window.innerHeight;
    const maxR = Math.hypot(Math.max(x, W - x), Math.max(y, H - y)) + 4;
    const start = performance.now();

    const setShape = (rx, ry, ringOpacity) => {
      const m = maskFor(rx, ry, x, y);
      layer.style.webkitMaskImage = m;
      layer.style.maskImage = m;
      for (const el of [ring, halo]) {
        el.setAttribute("rx", rx.toFixed(2));
        el.setAttribute("ry", ry.toFixed(2));
      }
      ring.style.opacity = ringOpacity;
      halo.style.opacity = ringOpacity * 0.5;
    };

    const frame = (now) => {
      if (cancelled) return;
      const t = now - start;

      if (t < EMERGE_MS) {
        const p = easeEmerge(t / EMERGE_MS);
        const rx = SEED_RX * p;
        setShape(rx, rx * FLAT, Math.min(1, p * 1.6));
      } else {
        const tb = t - EMERGE_MS;
        const p = progress(tb, 0, EXPAND_MS);
        const rx = lerp(SEED_RX, maxR, easeExpand(p));
        const roundness = lerp(FLAT, 1, easeRound(progress(p, 0, 0.42)));
        const fade = 1 - progress(p, 0.7, 1);
        setShape(rx, rx * roundness, fade);
        if (p >= 1) {
          completeRef.current?.();
          return;
        }
      }
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);

    return () => {
      cancelled = true;
      cancelAnimationFrame(raf);
    };
  }, [active, origin, reduced]);

  return (
    <>
      <div ref={layerRef} className="intro-layer">
        {children}
      </div>
      <svg className="portal-ring" aria-hidden="true">
        <ellipse
          ref={haloRef}
          cx={origin?.x ?? 0}
          cy={origin?.y ?? 0}
          rx="0"
          ry="0"
          fill="none"
          stroke="#fff"
          strokeWidth="7"
          strokeOpacity="0.09"
          style={{ opacity: 0 }}
        />
        <ellipse
          ref={ringRef}
          cx={origin?.x ?? 0}
          cy={origin?.y ?? 0}
          rx="0"
          ry="0"
          fill="none"
          stroke="#fff"
          strokeWidth="1.25"
          vectorEffect="non-scaling-stroke"
          style={{ opacity: 0 }}
        />
      </svg>
    </>
  );
}
