import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { EASE } from "../lib/easing";

/**
 * PetChat — lightweight, offline assistant that answers common
 * questions about Balakrishnan. Keyword matching, no network calls.
 */

const KB = [
  {
    q: "What do you build?",
    keys: ["build", "work", "project", "do you do", "make"],
    a: "Balakrishnan builds end-to-end web products — React front-ends, Node.js APIs, and the databases and infra behind them. Scroll to “Selected work” for a few highlights.",
    href: "#work",
  },
  {
    q: "Tech stack?",
    keys: ["stack", "tech", "tools", "language", "react", "node", "skills"],
    a: "Day to day: React, Next.js, TypeScript/JavaScript, Node.js, Express, PostgreSQL, MongoDB, Redis, Docker and AWS — plus Framer Motion for interfaces like this one.",
    href: "#stack",
  },
  {
    q: "Is he available?",
    keys: ["available", "hire", "freelance", "job", "open"],
    a: "Yes — currently open to full-time roles and selected freelance projects.",
    href: "#contact",
  },
  {
    q: "How do I contact him?",
    keys: ["contact", "email", "mail", "reach", "talk", "github"],
    a: "The quickest route is the contact section — email or GitHub. I'll take you there.",
    href: "#contact",
  },
];

const HELLO = "Hi! I'm Bit, Balakrishnan's assistant. Ask me about his work, stack or availability.";

function answer(text) {
  const t = text.toLowerCase();
  if (/(hi|hello|hey|vanakkam|namaste)\b/.test(t)) return { a: "Hello! வணக்கம்! नमस्ते! What would you like to know?" };
  const hit = KB.find((k) => k.keys.some((key) => t.includes(key)));
  return hit ?? { a: "I'm a small bot, so I know a few things: projects, tech stack, availability and contact. Try one of the suggestions!" };
}

export default function PetChat({ open, onClose, showBubble, reduced }) {
  const [messages, setMessages] = useState([{ from: "bot", text: HELLO }]);
  const [value, setValue] = useState("");
  const listRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus({ preventScroll: true }), 250);
  }, [open]);

  useEffect(() => {
    const el = listRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e) => e.key === "Escape" && onClose?.();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  const ask = (text) => {
    if (!text.trim()) return;
    const res = answer(text);
    setMessages((m) => [...m, { from: "me", text }]);
    setTimeout(() => {
      setMessages((m) => [...m, { from: "bot", text: res.a }]);
      if (res.href) {
        setTimeout(() => {
          document.querySelector(res.href)?.scrollIntoView({ behavior: reduced ? "auto" : "smooth", block: "start" });
        }, 700);
      }
    }, 420);
  };

  const submit = (e) => {
    e.preventDefault();
    ask(value);
    setValue("");
  };

  const pop = reduced
    ? { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 } }
    : {
        initial: { opacity: 0, scale: 0.92, y: 10 },
        animate: { opacity: 1, scale: 1, y: 0 },
        exit: { opacity: 0, scale: 0.95, y: 6 },
      };

  return (
    <AnimatePresence>
      {open ? (
        <motion.section
          key="chat"
          className="pet-chat"
          role="dialog"
          aria-label="Chat with Bit"
          {...pop}
          transition={{ duration: 0.35, ease: EASE.out }}
        >
          <header>
            <span className="status">
              <i aria-hidden="true" /> Bit · assistant
            </span>
            <button className="close" type="button" onClick={onClose} aria-label="Close chat">
              ×
            </button>
          </header>
          <div className="messages" ref={listRef} aria-live="polite">
            {messages.map((m, i) => (
              <motion.div
                key={i}
                className={`msg ${m.from}`}
                initial={reduced ? false : { opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, ease: EASE.out }}
              >
                {m.text}
              </motion.div>
            ))}
          </div>
          <div className="chips">
            {KB.map((k) => (
              <button key={k.q} type="button" onClick={() => ask(k.q)}>
                {k.q}
              </button>
            ))}
          </div>
          <form onSubmit={submit}>
            <input
              ref={inputRef}
              value={value}
              onChange={(e) => setValue(e.target.value)}
              placeholder="Ask Bit something…"
              aria-label="Message"
            />
            <button type="submit">Send</button>
          </form>
        </motion.section>
      ) : showBubble ? (
        <motion.div key="bubble" className="pet-bubble" role="status" {...pop} transition={{ duration: 0.4, ease: EASE.out }}>
          Hi, I'm Bit — Bala's assistant. Tap me if you have questions.
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}
