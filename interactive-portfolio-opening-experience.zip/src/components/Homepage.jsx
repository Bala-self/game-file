import { useEffect, useState } from "react";

/**
 * Homepage — the actual portfolio. Rendered from the very first frame
 * underneath the intro layer (inert until revealed), so the portal exposes
 * the live, interactive DOM — not a screenshot.
 */

const NAV = [
  { href: "#work", label: "Work" },
  { href: "#stack", label: "Stack" },
  { href: "#about", label: "About" },
  { href: "#contact", label: "Contact" },
];

const PROJECTS = [
  {
    no: "01",
    title: "Ledger",
    kind: "Fintech dashboard",
    year: "2025",
    tags: ["React", "Node.js", "PostgreSQL"],
    blurb: "Real-time portfolio tracking with streaming price updates, role-based access and audit-ready reporting.",
    art: "bars",
  },
  {
    no: "02",
    title: "Relay",
    kind: "Real-time messaging",
    year: "2025",
    tags: ["Next.js", "WebSockets", "Redis"],
    blurb: "Multi-room chat with presence, typing indicators and end-to-end delivery receipts at low latency.",
    art: "bubbles",
  },
  {
    no: "03",
    title: "Atlas",
    kind: "Commerce engine",
    year: "2024",
    tags: ["React", "Express", "MongoDB", "Stripe"],
    blurb: "Headless storefront and admin with inventory sync, payments and a lightning-fast product search.",
    art: "grid",
  },
  {
    no: "04",
    title: "Pulse",
    kind: "Analytics API",
    year: "2024",
    tags: ["Node.js", "Docker", "AWS"],
    blurb: "Event ingestion pipeline and query API handling millions of events per day with graceful back-pressure.",
    art: "wave",
  },
];

const STACK = [
  { group: "Front-end", items: ["React", "Next.js", "JavaScript", "TypeScript", "Tailwind CSS", "Framer Motion"] },
  { group: "Back-end", items: ["Node.js", "Express", "REST", "GraphQL", "WebSockets", "Auth / JWT"] },
  { group: "Data", items: ["PostgreSQL", "MongoDB", "Redis", "Prisma", "Mongoose"] },
  { group: "Delivery", items: ["Docker", "AWS", "Vercel", "CI/CD", "Git", "Testing"] },
];

function ProjectArt({ type }) {
  const common = "absolute inset-0 transition-transform duration-700 ease-[cubic-bezier(.22,1,.36,1)] group-hover:scale-[1.04]";
  if (type === "bars")
    return (
      <div className={`${common} flex items-end gap-[6%] px-[12%] pb-[14%]`}>
        {[38, 62, 45, 80, 58, 92, 70].map((h, i) => (
          <span key={i} className="flex-1 rounded-t-sm bg-[#f1efea]/90" style={{ height: `${h}%` }} />
        ))}
      </div>
    );
  if (type === "bubbles")
    return (
      <div className={`${common} flex flex-col justify-center gap-3 px-[14%]`}>
        <span className="h-6 w-2/3 rounded-full bg-[#f1efea]/85" />
        <span className="ml-auto h-6 w-1/2 rounded-full border border-[#f1efea]/60" />
        <span className="h-6 w-3/5 rounded-full bg-[#f1efea]/85" />
        <span className="ml-auto h-6 w-1/3 rounded-full border border-[#f1efea]/60" />
      </div>
    );
  if (type === "grid")
    return (
      <div className={`${common} grid grid-cols-3 gap-3 p-[12%]`}>
        {Array.from({ length: 6 }).map((_, i) => (
          <span key={i} className={`rounded-md ${i % 4 === 0 ? "bg-[#f1efea]/90" : "border border-[#f1efea]/50"}`} />
        ))}
      </div>
    );
  return (
    <svg className={common} viewBox="0 0 200 120" preserveAspectRatio="none" aria-hidden="true">
      {[0, 1, 2, 3].map((i) => (
        <path
          key={i}
          d={`M0 ${70 + i * 8} C 40 ${30 + i * 10}, 70 ${100 - i * 6}, 110 ${60 + i * 4} S 170 ${30 + i * 8}, 200 ${55 + i * 6}`}
          fill="none"
          stroke="#f1efea"
          strokeOpacity={0.9 - i * 0.2}
          strokeWidth="1.2"
        />
      ))}
    </svg>
  );
}

function useClock() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 30000);
    return () => clearInterval(id);
  }, []);
  return now.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", timeZone: "Asia/Kolkata" });
}

export default function Homepage({ inert }) {
  const time = useClock();

  return (
    <div
      className="relative min-h-screen bg-[var(--paper)] text-[var(--ink)]"
      inert={inert ? true : undefined}
      aria-hidden={inert ? true : undefined}
    >
      {/* Nav */}
      <header className="sticky top-0 z-30 border-b border-[var(--line)] bg-[var(--paper)]/85 backdrop-blur-md">
        <nav className="mx-auto flex h-16 max-w-[1400px] items-center justify-between px-5 sm:px-8 lg:px-12">
          <a href="#top" className="flex items-center gap-2.5 text-[15px] font-medium tracking-tight">
            <span className="grid h-7 w-7 place-items-center rounded-full bg-[var(--ink)] text-[11px] font-semibold text-[var(--paper)]">B</span>
            Balakrishnan
          </a>
          <ul className="hidden items-center gap-8 text-[14px] text-[var(--muted)] md:flex">
            {NAV.map((n) => (
              <li key={n.href}>
                <a href={n.href} className="transition-colors hover:text-[var(--ink)]">
                  {n.label}
                </a>
              </li>
            ))}
          </ul>
          <a
            href="#contact"
            className="rounded-full bg-[var(--ink)] px-4 py-2 text-[13px] font-medium text-[var(--paper)] transition-transform hover:-translate-y-px"
          >
            Let's talk
          </a>
        </nav>
      </header>

      <main id="top">
        {/* Hero */}
        <section className="mx-auto max-w-[1400px] px-5 pb-20 pt-10 sm:px-8 sm:pt-14 lg:px-12 lg:pb-28">
          <div className="flex flex-wrap items-center justify-between gap-3 font-[var(--font-mono)] text-[11px] uppercase tracking-[0.14em] text-[var(--muted)]" style={{ fontFamily: "var(--font-mono)" }}>
            <span>Portfolio — ©2026</span>
            <span className="hidden sm:inline">India · {time} IST</span>
            <span className="inline-flex items-center gap-2">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[var(--ink)] opacity-30 motion-reduce:animate-none" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-[var(--ink)]" />
              </span>
              Available for work
            </span>
          </div>

          <h1 className="mt-10 text-[clamp(3.2rem,12.5vw,11.5rem)] font-medium leading-[0.88] tracking-[-0.055em] sm:mt-14">
            Full Stack
            <br />
            <span className="font-normal italic tracking-[-0.03em]" style={{ fontFamily: "var(--font-serif)" }}>
              Developer
            </span>
          </h1>

          <div className="mt-12 grid gap-10 border-t border-[var(--line)] pt-8 md:grid-cols-12 md:gap-6">
            <p className="text-[clamp(1.15rem,2vw,1.55rem)] leading-[1.35] tracking-[-0.015em] md:col-span-7">
              I'm Balakrishnan — I design and build fast, reliable web products, from pixel-perfect interfaces to the APIs and data
              that power them.
            </p>
            <div className="flex flex-wrap items-start gap-3 md:col-span-5 md:justify-end">
              <a
                href="#work"
                className="group inline-flex items-center gap-2 rounded-full bg-[var(--ink)] px-6 py-3.5 text-[14px] font-medium text-[var(--paper)]"
              >
                View selected work
                <span className="transition-transform duration-300 group-hover:translate-x-1">→</span>
              </a>
              <a
                href="#contact"
                className="inline-flex items-center rounded-full border border-[var(--ink)]/25 px-6 py-3.5 text-[14px] font-medium transition-colors hover:border-[var(--ink)]"
              >
                Get in touch
              </a>
            </div>
          </div>

          <dl className="mt-16 grid grid-cols-1 gap-px overflow-hidden rounded-2xl border border-[var(--line)] bg-[var(--line)] sm:grid-cols-3">
            {[
              ["Interfaces", "Accessible, animated, responsive front-ends in React & Next.js."],
              ["Systems", "Typed APIs, real-time services and well-modelled databases."],
              ["Delivery", "Containerised, tested and shipped through CI to the cloud."],
            ].map(([t, d]) => (
              <div key={t} className="bg-[var(--paper)] p-6 sm:p-7">
                <dt className="text-[13px] font-medium uppercase tracking-[0.12em] text-[var(--muted)]">{t}</dt>
                <dd className="mt-3 text-[15px] leading-relaxed">{d}</dd>
              </div>
            ))}
          </dl>
        </section>

        {/* Work */}
        <section id="work" className="scroll-mt-20 bg-[var(--ink)] py-20 text-[var(--paper)] lg:py-28">
          <div className="mx-auto max-w-[1400px] px-5 sm:px-8 lg:px-12">
            <div className="flex items-end justify-between gap-6">
              <h2 className="text-[clamp(2.2rem,6vw,4.5rem)] font-medium leading-none tracking-[-0.045em]">
                Selected <span className="italic font-normal" style={{ fontFamily: "var(--font-serif)" }}>work</span>
              </h2>
              <span className="hidden text-[12px] uppercase tracking-[0.14em] text-white/50 sm:block" style={{ fontFamily: "var(--font-mono)" }}>
                2024 — 2025
              </span>
            </div>

            <div className="mt-12 grid gap-6 md:grid-cols-2">
              {PROJECTS.map((p) => (
                <article key={p.no} className="group rounded-2xl border border-white/10 p-3 transition-colors duration-500 hover:border-white/30">
                  <div className="relative aspect-[16/10] overflow-hidden rounded-xl bg-white/[0.04]">
                    <ProjectArt type={p.art} />
                    <span className="absolute left-4 top-4 text-[11px] tracking-[0.14em] text-white/50" style={{ fontFamily: "var(--font-mono)" }}>
                      {p.no}
                    </span>
                  </div>
                  <div className="px-2 pb-3 pt-5">
                    <div className="flex items-baseline justify-between gap-4">
                      <h3 className="text-[1.6rem] font-medium tracking-[-0.03em]">
                        {p.title} <span className="text-white/45">— {p.kind}</span>
                      </h3>
                      <span className="text-[12px] text-white/45" style={{ fontFamily: "var(--font-mono)" }}>
                        {p.year}
                      </span>
                    </div>
                    <p className="mt-2 max-w-[52ch] text-[15px] leading-relaxed text-white/65">{p.blurb}</p>
                    <ul className="mt-4 flex flex-wrap gap-2">
                      {p.tags.map((t) => (
                        <li key={t} className="rounded-full border border-white/15 px-3 py-1 text-[12px] text-white/75">
                          {t}
                        </li>
                      ))}
                    </ul>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* Stack */}
        <section id="stack" className="scroll-mt-20 mx-auto max-w-[1400px] px-5 py-20 sm:px-8 lg:px-12 lg:py-28">
          <div className="grid gap-12 md:grid-cols-12">
            <div className="md:col-span-4">
              <h2 className="text-[clamp(2.2rem,5vw,4rem)] font-medium leading-none tracking-[-0.045em]">
                The <span className="italic font-normal" style={{ fontFamily: "var(--font-serif)" }}>stack</span>
              </h2>
              <p className="mt-5 max-w-[34ch] text-[15px] leading-relaxed text-[var(--muted)]">
                Tools I reach for to take an idea from a blank editor to a production deployment.
              </p>
            </div>
            <div className="grid gap-px overflow-hidden rounded-2xl border border-[var(--line)] bg-[var(--line)] sm:grid-cols-2 md:col-span-8">
              {STACK.map((s) => (
                <div key={s.group} className="bg-[var(--paper)] p-6 sm:p-7">
                  <h3 className="text-[12px] uppercase tracking-[0.14em] text-[var(--muted)]" style={{ fontFamily: "var(--font-mono)" }}>
                    {s.group}
                  </h3>
                  <ul className="mt-4 flex flex-wrap gap-2">
                    {s.items.map((i) => (
                      <li key={i} className="rounded-full border border-[var(--ink)]/15 px-3 py-1.5 text-[13.5px] transition-colors hover:bg-[var(--ink)] hover:text-[var(--paper)]">
                        {i}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* About */}
        <section id="about" className="scroll-mt-20 border-y border-[var(--line)] bg-[var(--paper-2)]">
          <div className="mx-auto grid max-w-[1400px] gap-10 px-5 py-20 sm:px-8 md:grid-cols-12 lg:px-12 lg:py-28">
            <h2 className="text-[12px] uppercase tracking-[0.14em] text-[var(--muted)] md:col-span-3" style={{ fontFamily: "var(--font-mono)" }}>
              About
            </h2>
            <div className="md:col-span-9">
              <p className="text-[clamp(1.5rem,3.4vw,2.8rem)] leading-[1.18] tracking-[-0.03em]">
                I care about the whole journey of a product — the database schema nobody sees, and the{" "}
                <span className="italic" style={{ fontFamily: "var(--font-serif)" }}>
                  half-second of motion
                </span>{" "}
                everybody feels.
              </p>
              <p className="mt-8 max-w-[60ch] text-[16px] leading-relaxed text-[var(--muted)]">
                I speak English, தமிழ் and हिन्दी, and I like building software the same way: clear, considered and welcoming to
                whoever uses it. I work best in small teams that ship often and sweat the details.
              </p>
            </div>
          </div>
        </section>

        {/* Contact */}
        <section id="contact" className="scroll-mt-20 mx-auto max-w-[1400px] px-5 pb-32 pt-20 sm:px-8 lg:px-12 lg:pt-28">
          <p className="text-[12px] uppercase tracking-[0.14em] text-[var(--muted)]" style={{ fontFamily: "var(--font-mono)" }}>
            Contact
          </p>
          <a
            href="mailto:hello@balakrishnan.dev"
            className="group mt-6 block text-[clamp(2.4rem,8.5vw,7.5rem)] font-medium leading-[0.95] tracking-[-0.05em]"
          >
            Let's build
            <br />
            <span className="italic font-normal" style={{ fontFamily: "var(--font-serif)" }}>
              something
            </span>{" "}
            <span className="inline-block transition-transform duration-500 group-hover:translate-x-3">→</span>
          </a>
          <div className="mt-14 flex flex-wrap gap-x-10 gap-y-4 border-t border-[var(--line)] pt-8 text-[15px]">
            <a className="underline-offset-4 hover:underline" href="mailto:hello@balakrishnan.dev">
              hello@balakrishnan.dev
            </a>
            <a className="underline-offset-4 hover:underline" href="https://github.com/Bala-self" target="_blank" rel="noreferrer">
              GitHub
            </a>
            <a className="underline-offset-4 hover:underline" href="https://www.linkedin.com/" target="_blank" rel="noreferrer">
              LinkedIn
            </a>
          </div>
        </section>
      </main>

      <footer className="border-t border-[var(--line)]">
        <div className="mx-auto flex max-w-[1400px] flex-wrap items-center justify-between gap-3 py-6 pl-[110px] pr-5 text-[12px] text-[var(--muted)] sm:pr-8 lg:pr-12">
          <span>© 2026 Balakrishnan</span>
          <span style={{ fontFamily: "var(--font-mono)" }}>Built with React & Framer Motion</span>
        </div>
      </footer>
    </div>
  );
}
