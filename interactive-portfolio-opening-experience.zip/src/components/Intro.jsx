import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { EASE } from "../lib/easing";

/**
 * Intro
 * Pure-black stage. Greets in English → Tamil → Hindi, then returns to English
 * and offers the PORTFOLIO button.
 *
 * Words (not characters) are the animation unit: splitting Tamil or Devanagari
 * into individual letters breaks conjuncts and vowel signs (e.g. ஷ்ண, कृ, ष्ण),
 * so each word stays a single shaped run and every glyph renders correctly.
 */

export const GREETINGS = [
  { key: "en", lang: "en", label: "EN", text: "Hi, I am Balakrishnan" },
  { key: "ta", lang: "ta", label: "TA", text: "வணக்கம், நான் பாலகிருஷ்ணன்" },
  { key: "hi", lang: "hi", label: "HI", text: "नमस्ते, मैं बालकृष्णन हूँ" },
];

const FINAL = { ...GREETINGS[0], key: "en-final" };

// [time (ms) at which each step begins]
const TIMELINE = [0, 2400, 4900, 7400];
const CTA_DELAY = 8300;

function Greeting({ item, reduced }) {
  const words = item.text.split(" ");

  const container = {
    initial: {},
    enter: { transition: { staggerChildren: reduced ? 0 : 0.075, delayChildren: reduced ? 0 : 0.28 } },
    exit: { transition: { staggerChildren: reduced ? 0 : 0.04 } },
  };

  const word = reduced
    ? {
        initial: { opacity: 0 },
        enter: { opacity: 1, transition: { duration: 0.6, ease: "easeOut" } },
        exit: { opacity: 0, transition: { duration: 0.4, ease: "easeIn" } },
      }
    : {
        initial: { y: "108%", opacity: 0, filter: "blur(10px)" },
        enter: {
          y: "0%",
          opacity: 1,
          filter: "blur(0px)",
          transition: { duration: 1.05, ease: EASE.out },
        },
        exit: {
          y: "-72%",
          opacity: 0,
          filter: "blur(8px)",
          transition: { duration: 0.6, ease: EASE.in },
        },
      };

  return (
    <motion.h1
      className="greeting"
      lang={item.lang}
      variants={container}
      initial="initial"
      animate="enter"
      exit="exit"
      aria-label={item.text}
    >
      {words.map((w, i) => (
        <span key={i} aria-hidden="true">
          <span className="word-mask">
            <motion.span className="word" variants={word}>
              {w}
            </motion.span>
          </span>
          {i < words.length - 1 ? " " : null}
        </span>
      ))}
    </motion.h1>
  );
}

export default function Intro({ reduced, locked, onPortfolio }) {
  const [step, setStep] = useState(0);
  const [showCta, setShowCta] = useState(false);
  const [pressed, setPressed] = useState(false);
  const btnRef = useRef(null);
  const skippedRef = useRef(false);

  useEffect(() => {
    const timers = TIMELINE.slice(1).map((t, i) =>
      setTimeout(() => !skippedRef.current && setStep(i + 1), t)
    );
    timers.push(setTimeout(() => setShowCta(true), CTA_DELAY));
    return () => timers.forEach(clearTimeout);
  }, []);

  // Move focus to the CTA once it appears, for keyboard users.
  useEffect(() => {
    if (showCta) {
      const id = setTimeout(() => btnRef.current?.focus({ preventScroll: true }), 650);
      return () => clearTimeout(id);
    }
  }, [showCta]);

  const current = step < 3 ? GREETINGS[step] : FINAL;
  const activeLang = current.lang;

  const handleClick = () => {
    if (locked || pressed) return;
    setPressed(true);
    onPortfolio?.(btnRef.current);
  };

  const handleSkip = () => {
    if (locked) return;
    skippedRef.current = true;
    setStep(3);
    setShowCta(true);
    onPortfolio?.(btnRef.current);
  };

  return (
    <>
      <div className="intro-topbar">
        <motion.div
          className="lang-index"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.3 }}
          aria-hidden="true"
        >
          {GREETINGS.map((g) => (
            <span key={g.key} className={g.lang === activeLang ? "is-active" : ""}>
              {g.label}
            </span>
          ))}
        </motion.div>
        <motion.button
          type="button"
          className="skip-btn"
          onClick={handleSkip}
          disabled={locked}
          initial={{ opacity: 0 }}
          animate={{ opacity: locked ? 0 : 1 }}
          transition={{ duration: 0.8, delay: locked ? 0 : 1 }}
        >
          Skip intro
        </motion.button>
      </div>

      <div className="intro-center">
        <div className="greeting-stage" aria-live="polite">
          <AnimatePresence initial={true}>
            <Greeting key={current.key} item={current} reduced={reduced} />
          </AnimatePresence>
        </div>

        <div className="cta-slot">
          <AnimatePresence>
            {showCta && (
              <motion.button
                ref={btnRef}
                type="button"
                className="portfolio-btn"
                onClick={handleClick}
                disabled={locked || pressed}
                aria-label="Enter portfolio"
                initial={reduced ? { opacity: 0 } : { opacity: 0, y: 14, filter: "blur(6px)" }}
                animate={
                  pressed
                    ? { opacity: 0.55, y: 0, filter: "blur(0px)", scale: 1 }
                    : { opacity: 1, y: 0, filter: "blur(0px)", scale: 1 }
                }
                whileTap={locked || pressed ? undefined : { scale: 0.94 }}
                transition={{
                  duration: reduced ? 0.4 : 0.9,
                  ease: EASE.out,
                  scale: { type: "spring", stiffness: 520, damping: 22 },
                }}
              >
                PORTFOLIO
              </motion.button>
            )}
          </AnimatePresence>
        </div>
      </div>
    </>
  );
}
