extends CanvasLayer
## Pause menu: resume, save, load, settings, quit. Runs while tree is paused.

var settings_panel: Control
var main_box: VBoxContainer


static func create() -> CanvasLayer:
	var p: CanvasLayer = CanvasLayer.new()
	p.name = "PauseMenu"
	p.layer = 10
	p.set_script(load("res://scripts/ui/pause_menu.gd"))
	p.process_mode = Node.PROCESS_MODE_WHEN_PAUSED
	return p


func _ready() -> void:
	visible = false
	var dim: ColorRect = ColorRect.new()
	dim.color = Color(0, 0, 0, 0.6)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(dim)

	var panel: PanelContainer = PanelContainer.new()
	panel.set_anchors_preset(Control.PRESET_CENTER)
	var style: StyleBoxFlat = StyleBoxFlat.new()
	style.bg_color = Color(0.08, 0.1, 0.14, 0.95)
	style.set_corner_radius_all(10)
	style.content_margin_left = 30
	style.content_margin_right = 30
	style.content_margin_top = 22
	style.content_margin_bottom = 22
	panel.add_theme_stylebox_override("panel", style)
	add_child(panel)

	main_box = VBoxContainer.new()
	main_box.custom_minimum_size = Vector2(280, 0)
	main_box.add_theme_constant_override("separation", 10)
	panel.add_child(main_box)

	var title: Label = Label.new()
	title.text = "PAUSED"
	title.add_theme_font_size_override("font_size", 34)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	main_box.add_child(title)

	_btn("Resume", close)
	_btn("Save Game", func() -> void: SaveSystem.save_game())
	_btn("Load Game", func() -> void:
		SaveSystem.load_game()
		close())
	_btn("Settings", _open_settings)
	_btn("Quit to Menu", func() -> void:
		GameState.save_settings()
		get_tree().paused = false
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		get_tree().change_scene_to_file("res://scenes/main/main_menu.tscn"))

	settings_panel = load("res://scripts/ui/settings_panel.gd").create(close_settings)
	settings_panel.visible = false
	panel.add_child(settings_panel)


func _btn(text: String, action: Callable) -> void:
	var b: Button = Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 42)
	b.pressed.connect(func() -> void:
		_click()
		action.call())
	main_box.add_child(b)


func _click() -> void:
	var snd = AudioStreamPlayer.new()
	snd.stream = load("res://assets/audio/click.wav")
	snd.volume_db = -8.0
	add_child(snd)
	snd.play()
	var t = get_tree().create_timer(0.25)
	t.timeout.connect(snd.queue_free)


func open() -> void:
	visible = true
	get_tree().paused = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	if main_box.get_child_count() > 1:
		(main_box.get_child(1) as Button).grab_focus()


func close() -> void:
	visible = false
	get_tree().paused = false
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _open_settings() -> void:
	main_box.visible = false
	settings_panel.visible = true


func close_settings() -> void:
	GameState.save_settings()
	settings_panel.visible = false
	main_box.visible = true


func _unhandled_input(event: InputEvent) -> void:
	if visible and event.is_action_pressed("ui_cancel"):
		if settings_panel.visible:
			close_settings()
		else:
			close()
