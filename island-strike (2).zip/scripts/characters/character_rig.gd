class_name CharacterRig
extends Node3D
## Articulated humanoid rig built from primitive meshes (no external assets).
## Joint pivots form a hand-rolled skeleton driven by `animate()` — one
## architecture shared by the player AND all NPC kinds (outfit-driven).
## Reference: 25-y/o male, 1.78 m, white tee, charcoal trousers, white
## sneakers, dark hair. Forward convention: -Z (Godot standard).

var hips: Node3D
var spine: Node3D
var head_p: Node3D
var arm_l: Node3D
var arm_r: Node3D
var fore_l: Node3D
var fore_r: Node3D
var leg_l: Node3D
var leg_r: Node3D
var shin_l: Node3D
var shin_r: Node3D
var weapon_mount: Node3D
var shirt_mat: StandardMaterial3D

## Animation LOD: 60 = every frame; 15 = throttled; 0 = frozen (far NPCs).
var lod_hz: float = 60.0
var shoot_t: float = 0.0
var hit_t: float = 0.0

var _phase: float = 0.0
var _rest_hips_y: float = 0.97
var _aim_w: float = 0.0
var _lod_acc: float = 0.0


static func player_outfit() -> Dictionary:
	return {
		"skin": Color(0.85, 0.66, 0.52),
		"hair": Color(0.13, 0.09, 0.06),
		"shirt": Color(0.93, 0.93, 0.95),
		"pants": Color(0.16, 0.17, 0.19),
		"shoes": Color(0.88, 0.88, 0.90),
		"watch": true,
		"jacket": false,
		"hat": false,
		"gender": "male",
		"type": "player",
	}


## Round 11 (audit scan): was rng.randomize() — uncontrolled randomness
## violates the fixed-seed contract (outfits changed every run). NPC
## construction order is deterministic, so a counter-seeded RNG is both
## varied across NPCs and identical across runs.
static var _outfit_counter: int = 0


static func npc_outfit(shirt: Color) -> Dictionary:
	var rng = RandomNumberGenerator.new()
	rng.seed = 917511 + _outfit_counter * 7919
	_outfit_counter += 1
	# Varied clothing per NPC — not just shirt color
	var pants_options: Array = [
		Color(0.16, 0.17, 0.20), Color(0.22, 0.24, 0.30),
		Color(0.30, 0.26, 0.20), Color(0.055, 0.09, 0.16), # denim
		Color(0.35, 0.32, 0.28), Color(0.25, 0.25, 0.26),
	]
	var shoe_options: Array = [
		Color(0.35, 0.33, 0.30), Color(0.88, 0.88, 0.90),
		Color(0.035, 0.035, 0.03), Color(0.15, 0.15, 0.16),
	]
	var has_jacket = rng.randf() < 0.25
	var has_hat = rng.randf() < 0.12
	var gender: String = "female" if rng.randf() < 0.35 else "male"
	return {
		"skin": Color(0.70 + rng.randf() * 0.22, 0.54 + rng.randf() * 0.16,
				0.40 + rng.randf() * 0.16),
		"hair": Color(0.06 + rng.randf() * 0.13, 0.04 + rng.randf() * 0.09,
				0.03 + rng.randf() * 0.06),
		"shirt": shirt,
		"pants": pants_options[rng.randi() % pants_options.size()],
		"shoes": shoe_options[rng.randi() % shoe_options.size()],
		"watch": rng.randf() < 0.15,
		"jacket": has_jacket,
		"hat": has_hat,
		"gender": gender,
		"type": "civilian",
	}

static func police_outfit() -> Dictionary:
	var rng = RandomNumberGenerator.new()
	rng.seed = 917512 + _outfit_counter * 7919
	_outfit_counter += 1
	return {
		"skin": Color(0.72 + rng.randf()*0.18, 0.56 + rng.randf()*0.12, 0.42 + rng.randf()*0.12),
		"hair": Color(0.08, 0.06, 0.04),
		"shirt": Color(0.15, 0.20, 0.50), # police blue
		"pants": Color(0.12, 0.15, 0.35),
		"shoes": Color(0.08, 0.08, 0.09),
		"watch": false,
		"jacket": false,
		"hat": true, # police cap
		"gender": "male",
		"type": "police",
	}

static func gang_outfit() -> Dictionary:
	var rng = RandomNumberGenerator.new()
	rng.seed = 917513 + _outfit_counter * 7919
	_outfit_counter += 1
	# Fixed dark-red for test determinism + setup-order fix
	var shirt_col: Color = Color(0.85, 0.15, 0.15)
	return {
		"skin": Color(0.68 + rng.randf()*0.20, 0.52 + rng.randf()*0.14, 0.38 + rng.randf()*0.14),
		"hair": Color(0.04, 0.03, 0.02),
		"shirt": shirt_col,
		"pants": Color(0.10, 0.10, 0.12),
		"shoes": Color(0.12, 0.12, 0.12),
		"watch": false,
		"jacket": true,
		"hat": rng.randf() < 0.35,
		"gender": "male",
		"type": "gang",
	}

static func commuter_outfit() -> Dictionary:
	var rng = RandomNumberGenerator.new()
	rng.seed = 917514 + _outfit_counter * 7919
	_outfit_counter += 1
	var shirt_opts: Array = [Color(0.92,0.92,0.95), Color(0.75,0.80,0.90), Color(0.95,0.95,0.92)]
	return {
		"skin": Color(0.75 + rng.randf()*0.18, 0.58 + rng.randf()*0.12, 0.45 + rng.randf()*0.12),
		"hair": Color(0.10 + rng.randf()*0.08, 0.07 + rng.randf()*0.05, 0.05 + rng.randf()*0.04),
		"shirt": shirt_opts[rng.randi() % shirt_opts.size()],
		"pants": Color(0.20, 0.20, 0.22),
		"shoes": Color(0.15, 0.12, 0.10),
		"watch": true,
		"jacket": rng.randf() < 0.6,
		"hat": false,
		"gender": "male" if rng.randf()<0.6 else "female",
		"type": "commuter",
	}

static func service_outfit() -> Dictionary:
	var rng = RandomNumberGenerator.new()
	rng.seed = 917515 + _outfit_counter * 7919
	_outfit_counter += 1
	return {
		"skin": Color(0.70 + rng.randf()*0.20, 0.54 + rng.randf()*0.14, 0.40 + rng.randf()*0.14),
		"hair": Color(0.12, 0.08, 0.05),
		"shirt": Color(0.85, 0.65, 0.25), # service orange/brown
		"pants": Color(0.30, 0.28, 0.25),
		"shoes": Color(0.35, 0.30, 0.25),
		"watch": false,
		"jacket": false,
		"hat": true,
		"gender": "male",
		"type": "service",
	}

static func military_outfit() -> Dictionary:
	var rng = RandomNumberGenerator.new()
	rng.seed = 917516 + _outfit_counter * 7919
	_outfit_counter += 1
	return {
		"skin": Color(0.72, 0.56, 0.42),
		"hair": Color(0.06, 0.05, 0.04),
		"shirt": Color(0.35, 0.40, 0.30), # camo green
		"pants": Color(0.30, 0.35, 0.25),
		"shoes": Color(0.15, 0.14, 0.12),
		"watch": false,
		"jacket": false,
		"hat": true,
		"gender": "male",
		"type": "military",
	}

static func beach_outfit() -> Dictionary:
	var rng = RandomNumberGenerator.new()
	rng.seed = 917517 + _outfit_counter * 7919
	_outfit_counter += 1
	var shirt_opts: Array = [Color(0.90,0.30,0.25), Color(0.20,0.55,0.85), Color(0.95,0.80,0.20), Color(0.30,0.85,0.40)]
	return {
		"skin": Color(0.78 + rng.randf()*0.15, 0.60 + rng.randf()*0.12, 0.48 + rng.randf()*0.10),
		"hair": Color(0.18, 0.12, 0.08),
		"shirt": shirt_opts[rng.randi() % shirt_opts.size()],
		"pants": Color(0.85, 0.80, 0.60), # shorts
		"shoes": Color(0.50, 0.40, 0.30), # sandals
		"watch": false,
		"jacket": false,
		"hat": rng.randf() < 0.4,
		"gender": "female" if rng.randf()<0.5 else "male",
		"type": "beach",
	}

static func female_outfit(shirt: Color) -> Dictionary:
	var rng = RandomNumberGenerator.new()
	rng.seed = 917518 + _outfit_counter * 7919
	_outfit_counter += 1
	return {
		"skin": Color(0.75 + rng.randf()*0.18, 0.58 + rng.randf()*0.14, 0.44 + rng.randf()*0.12),
		"hair": Color(0.12 + rng.randf()*0.10, 0.08 + rng.randf()*0.06, 0.04 + rng.randf()*0.04),
		"shirt": shirt,
		"pants": Color(0.055, 0.09, 0.16), # denim
		"shoes": Color(0.88, 0.88, 0.90),
		"watch": rng.randf() < 0.2,
		"jacket": rng.randf() < 0.3,
		"hat": false,
		"gender": "female",
		"type": "civilian",
	}


static func _m(col: Color) -> StandardMaterial3D:
	var mat = StandardMaterial3D.new()
	mat.albedo_color = col
	mat.roughness = 0.85
	return mat


static func _mesh(parent: Node3D, kind: String, size: Vector3, pos: Vector3,
		col: Color) -> MeshInstance3D:
	var mi = MeshInstance3D.new()
	match kind:
		"box":
			var bm = BoxMesh.new()
			bm.size = size
			bm.material = _m(col)
			mi.mesh = bm
		"capsule":
			var cm: CapsuleMesh = CapsuleMesh.new()
			cm.radius = size.x
			cm.height = size.y
			cm.material = _m(col)
			mi.mesh = cm
		"sphere":
			var sm = SphereMesh.new()
			sm.radius = size.x
			sm.height = size.y
			sm.material = _m(col)
			mi.mesh = sm
		"cylinder":
			var cy = CylinderMesh.new()
			cy.top_radius = size.x
			cy.bottom_radius = size.x
			cy.height = size.y
			cy.material = _m(col)
			mi.mesh = cy
	mi.position = pos
	parent.add_child(mi)
	return mi


static func create(outfit: Dictionary) -> CharacterRig:
	var rig: CharacterRig = CharacterRig.new()
	rig.name = "CharacterRig"
	var skin: Color = outfit.get("skin", Color(0.85, 0.66, 0.52))
	var hair: Color = outfit.get("hair", Color(0.12, 0.08, 0.05))
	var shirt: Color = outfit.get("shirt", Color(0.7, 0.7, 0.7))
	var pants: Color = outfit.get("pants", Color(0.2, 0.2, 0.22))
	var shoes: Color = outfit.get("shoes", Color(0.4, 0.38, 0.35))
	var has_jacket: bool = bool(outfit.get("jacket", false))
	var has_hat: bool = bool(outfit.get("hat", false))
	var gender: String = str(outfit.get("gender", "male"))
	var npc_type: String = str(outfit.get("type", "civilian"))
	var dark: Color = Color(0.08, 0.08, 0.09)

	# ---- pelvis + spine ----
	rig.hips = Node3D.new()
	rig.hips.name = "Hips"
	rig.hips.position = Vector3(0, rig._rest_hips_y, 0)
	rig.add_child(rig.hips)
	_mesh(rig.hips, "box", Vector3(0.30, 0.20, 0.19), Vector3.ZERO, pants)
	rig.spine = Node3D.new()
	rig.spine.name = "Spine"
	rig.spine.position = Vector3(0, 0.10, 0)
	rig.hips.add_child(rig.spine)
	rig.shirt_mat = _m(shirt)
	var chest = MeshInstance3D.new()
	var cm: CapsuleMesh = CapsuleMesh.new()
	cm.radius = 0.185
	cm.height = 0.50
	cm.material = rig.shirt_mat
	chest.mesh = cm
	chest.position = Vector3(0, 0.24, 0)
	rig.spine.add_child(chest)

	# Jacket — adds bulk for gang/commuter/beach variants (Blender generator clothing concept)
	if has_jacket:
		var jacket_col: Color = Color(0.15, 0.15, 0.18) if npc_type == "gang" else Color(0.25, 0.28, 0.32) if npc_type == "commuter" else shirt.darkened(0.25)
		var jacket = MeshInstance3D.new()
		var jm = BoxMesh.new()
		jm.size = Vector3(0.42, 0.55, 0.26)
		jm.material = _m(jacket_col)
		jacket.mesh = jm
		jacket.position = Vector3(0, 0.26, 0.02)
		rig.spine.add_child(jacket)

	# ---- head ----
	rig.head_p = Node3D.new()
	rig.head_p.name = "Head"
	rig.head_p.position = Vector3(0, 0.52, 0)
	rig.spine.add_child(rig.head_p)
	# Female head slightly smaller
	var head_radius: float = 0.11 if gender == "male" else 0.105
	_mesh(rig.head_p, "sphere", Vector3(head_radius, 0.22, 0), Vector3(0, 0.10, 0), skin)
	# hair: cap + back mass — female longer hair, male short
	var cap: MeshInstance3D = _mesh(rig.head_p, "sphere", Vector3(0.118, 0.19, 0),
			Vector3(0, 0.135, 0.012), hair)
	cap.rotation_degrees.x = -12.0
	if gender == "female":
		_mesh(rig.head_p, "sphere", Vector3(0.12, 0.20, 0), Vector3(0, 0.04, 0.08), hair) # longer back mass
		_mesh(rig.head_p, "box", Vector3(0.22, 0.18, 0.10), Vector3(0, 0.05, 0.07), hair)
	else:
		_mesh(rig.head_p, "box", Vector3(0.20, 0.14, 0.09), Vector3(0, 0.09, 0.055), hair)

	# Hat — police cap, gang cap/beanie, service hat, beach hat, military helmet
	if has_hat:
		var hat_col: Color
		var hat_size: Vector3
		match npc_type:
			"police":
				hat_col = Color(0.12, 0.15, 0.35)
				hat_size = Vector3(0.24, 0.10, 0.26)
			"gang":
				hat_col = Color(0.10, 0.10, 0.11)
				hat_size = Vector3(0.22, 0.09, 0.24)
			"military":
				hat_col = Color(0.30, 0.35, 0.25)
				hat_size = Vector3(0.25, 0.12, 0.26)
			"beach":
				hat_col = Color(0.90, 0.80, 0.40)
				hat_size = Vector3(0.26, 0.08, 0.26)
			"service":
				hat_col = Color(0.85, 0.65, 0.25)
				hat_size = Vector3(0.23, 0.09, 0.24)
			_:
				hat_col = Color(0.25, 0.25, 0.28)
				hat_size = Vector3(0.22, 0.08, 0.23)
		_mesh(rig.head_p, "box", hat_size, Vector3(0, 0.20, 0), hat_col)

	# ---- arms (short-sleeve tee: sleeve cap + bare arms) ----
	for side in [-1.0, 1.0]:
		var arm = Node3D.new()
		arm.name = "ArmL" if side < 0 else "ArmR"
		arm.position = Vector3(side * 0.24, 0.40, 0)
		rig.spine.add_child(arm)
		_mesh(arm, "cylinder", Vector3(0.078, 0.15, 0), Vector3(0, -0.06, 0), shirt)
		_mesh(arm, "capsule", Vector3(0.055, 0.30, 0), Vector3(0, -0.16, 0), skin)
		var fore = Node3D.new()
		fore.name = "ForeL" if side < 0 else "ForeR"
		fore.position = Vector3(0, -0.30, 0)
		arm.add_child(fore)
		_mesh(fore, "capsule", Vector3(0.048, 0.28, 0), Vector3(0, -0.13, 0), skin)
		_mesh(fore, "box", Vector3(0.06, 0.09, 0.07), Vector3(0, -0.29, 0), skin)
		if side < 0 and outfit.get("watch", false):
			_mesh(fore, "cylinder", Vector3(0.058, 0.05, 0), Vector3(0, -0.23, 0), dark)
		if side < 0:
			rig.arm_l = arm
			rig.fore_l = fore
		else:
			rig.arm_r = arm
			rig.fore_r = fore
	# right hand weapon mount: barrel along arm axis (-y); x=-90 deg maps
	# the gun model's -Z barrel onto local -Y (down at rest, forward when raised)
	rig.weapon_mount = Node3D.new()
	rig.weapon_mount.name = "WeaponMount"
	rig.weapon_mount.position = Vector3(0, -0.29, 0.02)
	rig.weapon_mount.rotation_degrees = Vector3(-90, 0, 0)
	rig.fore_r.add_child(rig.weapon_mount)

	# ---- legs ----
	for side in [-1.0, 1.0]:
		var leg = Node3D.new()
		leg.name = "LegL" if side < 0 else "LegR"
		leg.position = Vector3(side * 0.105, -0.06, 0)
		rig.hips.add_child(leg)
		_mesh(leg, "capsule", Vector3(0.075, 0.46, 0), Vector3(0, -0.23, 0), pants)
		var shin = Node3D.new()
		shin.name = "ShinL" if side < 0 else "ShinR"
		shin.position = Vector3(0, -0.46, 0)
		leg.add_child(shin)
		_mesh(shin, "capsule", Vector3(0.058, 0.42, 0), Vector3(0, -0.21, 0), pants)
		_mesh(shin, "box", Vector3(0.10, 0.08, 0.24), Vector3(0, -0.44, -0.05), shoes)
		if side < 0:
			rig.leg_l = leg
			rig.shin_l = shin
		else:
			rig.leg_r = leg
			rig.shin_r = shin
	return rig


## Attach a weapon node (pistol) to the right-hand mount.
func attach_weapon(weapon: Node3D) -> void:
	var old: Node = weapon.get_parent()
	if old:
		old.remove_child(weapon)
	weapon_mount.add_child(weapon)
	weapon.position = Vector3.ZERO
	weapon.rotation = Vector3.ZERO


## Procedural animation entry point.
## p: speed, max_speed, on_floor, vy, crouch, swim, aim (0..1), reloading, dead.
func animate(delta: float, p: Dictionary) -> void:
	if p.get("dead", false):
		return  # root body handles the death fall; limbs settle via _process below
	# animation LOD throttle (NPCs): accumulate and step at reduced rate
	if lod_hz < 55.0:
		if lod_hz <= 0.0:
			return
		_lod_acc += delta
		if _lod_acc < 1.0 / lod_hz:
			return
		delta = _lod_acc
		_lod_acc = 0.0
	shoot_t = maxf(0.0, shoot_t - delta)
	hit_t = maxf(0.0, hit_t - delta)

	var speed: float = p.get("speed", 0.0)
	var max_speed: float = maxf(p.get("max_speed", 6.0), 0.1)
	var on_floor: bool = p.get("on_floor", true)
	var vy: float = p.get("vy", 0.0)
	var crouch: bool = p.get("crouch", false)
	var swim: bool = p.get("swim", false)
	var reloading: bool = p.get("reloading", false)
	var aim_w_t: float = clampf(p.get("aim", 0.0), 0.0, 1.0)
	_aim_w = lerpf(_aim_w, aim_w_t, 1.0 - float(exp(-14.0 * delta)))
	var k: float = 1.0 - float(exp(-12.0 * delta))

	_phase += delta * (2.0 + speed * 1.65)
	var norm: float = clampf(speed / max_speed, 0.0, 1.0)
	var run_w: float = clampf((speed - 5.4) / 3.2, 0.0, 1.0)
	var move_w: float = clampf(speed / 1.2, 0.0, 1.0)  # idle settles to neutral
	var swing: float = float(sin(_phase)) * (0.30 + 0.42 * norm) * move_w

	var leg_l_t: float = swing
	var leg_r_t: float = -swing
	var knee_l_t: float = -maxf(0.0, -float(sin(_phase))) * (0.30 + 0.55 * norm)
	var knee_r_t: float = -maxf(0.0, float(sin(_phase))) * (0.30 + 0.55 * norm)
	var arm_l_t: float = -swing * 0.7
	var arm_r_t: float = swing * 0.7
	var elbow_t: float = 0.15 + 0.5 * run_w
	var lean_t: float = -0.03 - 0.17 * run_w
	var hips_dy: float = 0.0

	if not on_floor:
		if vy > 0.5:  # jump tuck
			leg_l_t = 0.55
			leg_r_t = 0.30
			knee_l_t = -0.95
			knee_r_t = -0.70
			arm_l_t = -0.55
			arm_r_t = -0.55
		else:  # falling: arms up, legs trail
			leg_l_t = 0.22
			leg_r_t = -0.14
			knee_l_t = -0.45
			knee_r_t = -0.30
			arm_l_t = -0.95
			arm_r_t = -1.10
			lean_t = -0.10

	if swim:
		leg_l_t = float(sin(_phase * 1.3)) * 0.24
		leg_r_t = -leg_l_t
		knee_l_t = -0.2
		knee_r_t = -0.2
		arm_l_t = 1.25 + float(sin(_phase * 1.15)) * 0.85
		arm_r_t = 1.25 - float(sin(_phase * 1.15)) * 0.85
		lean_t = -1.15  # near-horizontal body

	if crouch and on_floor and not swim:
		hips_dy = -0.33
		leg_l_t = 0.85
		leg_r_t = 0.55
		knee_l_t = -1.30
		knee_r_t = -1.05
		lean_t = -0.34
		arm_l_t = 0.28
		arm_r_t = -0.12

	# aim pose: both arms raise to horizontal, gun along arm axis
	var aim_pitch: float = PI / 2.0 - 0.05
	var arm_r_fin: float = lerpf(arm_r_t + 0.08, aim_pitch, _aim_w)
	var arm_l_fin: float = lerpf(arm_l_t, aim_pitch + 0.12, _aim_w * 0.85)
	if shoot_t > 0.0:
		arm_r_fin += 0.22 * (shoot_t / 0.15)  # recoil kick
	lean_t += (hit_t / 0.30) * -0.10  # hit flinch (backward)
	var elbow_l_fin: float = 1.0 if reloading else elbow_t
	var fore_l_t: float = -(0.5 if reloading else 0.12) - (0.35 if reloading else 0.0)
	if reloading:
		arm_l_fin = 0.55  # left hand dips to the magazine

	leg_l.rotation.x = lerpf(leg_l.rotation.x, leg_l_t, k)
	leg_r.rotation.x = lerpf(leg_r.rotation.x, leg_r_t, k)
	shin_l.rotation.x = lerpf(shin_l.rotation.x, knee_l_t, k)
	shin_r.rotation.x = lerpf(shin_r.rotation.x, knee_r_t, k)
	arm_l.rotation.x = lerpf(arm_l.rotation.x, arm_l_fin, k)
	arm_r.rotation.x = lerpf(arm_r.rotation.x, arm_r_fin, k)
	fore_l.rotation.x = lerpf(fore_l.rotation.x, fore_l_t, k)
	fore_r.rotation.x = lerpf(fore_r.rotation.x, -elbow_t if not reloading else -0.2, k)
	spine.rotation.x = lerpf(spine.rotation.x, lean_t, k)
	hips.position.y = lerpf(hips.position.y, _rest_hips_y + hips_dy, k)