extends "res://scripts/npc/person.gd"
## Nav-driven commuter (Phase 10 NPC class 4/5): walks between district
## centers along the navmesh on a fixed deterministic loop. Distinct group so
## the civilian director never counts or despawns them.

var _route: Array[Vector3] = []
var _route_i: int = 0


func _setup() -> void:
	kind = "commuter"
	shirt_color = Color(0.25, 0.3, 0.5)
	add_to_group("commuters")
	add_to_group("nav_npcs")
	health = 100.0
	walk_speed = 2.2
	enable_nav()
	var centers: Array = []
	var districts: Dictionary = get_tree().root.get_node("GameState").world_data.get(
			"districts", {})
	for k: String in districts.keys():
		var r: Rect2 = districts[k]
		centers.append(Vector3(r.position.x + r.size.x * 0.5, 0.3,
				r.position.y + r.size.y * 0.5))
	centers.sort_custom(func(a: Vector3, b: Vector3) -> bool:
		return a.x + a.z < b.x + b.z)
	for i in range(centers.size()):
		_route.append(centers[i])


func _think(_delta: float) -> void:
	if global_position.distance_to(target) < 2.5:
		_route_i = (_route_i + 1) % _route.size()
		target = _route[_route_i]
	target = _route[_route_i]
