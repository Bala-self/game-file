extends "res://scripts/npc/person.gd"
## Military NPC — camo green + helmet + boots
## Spawns near Military Base district, behaves like cop but no arrest

const PATROL_SPEED := 2.8
const SHOOT_RANGE := 35.0
const SHOOT_INTERVAL := 1.2

var spawn_point: Vector3 = Vector3.ZERO
var shoot_timer: float = 0.0
var last_known: Vector3 = Vector3.ZERO
var patrol_a: Vector3 = Vector3.ZERO
var patrol_b: Vector3 = Vector3.ZERO

static func create_at(spawn: Vector3) -> CharacterBody3D:
	var c = CharacterBody3D.new()
	c.set_script(load("res://scripts/npc/npc_military.gd"))
	c.set("spawn_point", spawn)
	return c

func _setup() -> void:
	kind = "military"
	add_to_group("military")
	health = 80
	walk_speed = PATROL_SPEED
	shirt_color = Color(0.35, 0.40, 0.30)
	patrol_a = spawn_point
	patrol_b = spawn_point + Vector3(randf_range(-20, 20), 0, randf_range(-20, 20))
	state = "patrol"
	target = patrol_a

func _think(delta: float) -> void:
	var player = GameState.get_player() if GameState.has_method("get_player") else get_tree().get_first_node_in_group("player")
	if player == null or not is_instance_valid(player):
		_patrol_think()
		return
	var dist_to_player: float = global_position.distance_to(player.global_position)
	var has_los: bool = _has_los_to(player.global_position)
	match state:
		"patrol":
			_patrol_think()
			if dist_to_player < 25.0 and has_los and GameState.wanted > 0:
				state = "pursue"
		"pursue":
			if GameState.wanted == 0 or player.health <= 0:
				state = "patrol"
				target = patrol_a
				return
			last_known = player.global_position
			walk_speed = 4.5
			target = player.global_position
			shoot_timer -= delta
			if dist_to_player < SHOOT_RANGE and has_los and shoot_timer <= 0.0:
				shoot_timer = SHOOT_INTERVAL
				_shoot(player)
		"investigate":
			walk_speed = 3.5
			if global_position.distance_to(target) < 2.5:
				state = "patrol"
				target = patrol_a

func _patrol_think() -> void:
	walk_speed = PATROL_SPEED
	if global_position.distance_to(target) < 1.5:
		var tmp = patrol_a
		patrol_a = patrol_b
		patrol_b = tmp
		target = patrol_a

func on_gunshot(pos: Vector3) -> void:
	if state == "dead":
		return
	if global_position.distance_to(pos) < 60.0:
		target = pos
		state = "investigate"

func _react_to_damage(_from: Vector3) -> void:
	if state != "dead":
		if GameState.wanted == 0:
			GameState.add_wanted(2)
		state = "pursue"

func _shoot(player: Node3D) -> void:
	var snd = AudioStreamPlayer3D.new()
	snd.stream = load("res://assets/audio/shoot.wav")
	snd.volume_db = -8.0
	snd.max_distance = 100.0
	add_child(snd)
	snd.play()
	# finished-signal self-cleanup: no timer lambda capture (Round 16)
	snd.finished.connect(snd.queue_free)
	var from = global_position + Vector3(0, 1.5, 0)
	var to = player.global_position + Vector3(0, 1.2, 0)
	var tracer = MeshInstance3D.new()
	var mesh = CylinderMesh.new()
	mesh.top_radius = 0.012
	mesh.bottom_radius = 0.012
	mesh.height = from.distance_to(to)
	var m = StandardMaterial3D.new()
	m.albedo_color = Color(1, 0.6, 0.3)
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mesh.material = m
	tracer.mesh = mesh
	get_tree().current_scene.add_child(tracer)
	tracer.global_position = (from + to) * 0.5
	tracer.look_at(to)
	tracer.rotate_object_local(Vector3(1, 0, 0), PI / 2)
	var tw = tracer.create_tween()
	tw.tween_property(tracer, "transparency", 1.0, 0.08)
	tw.tween_callback(tracer.queue_free)
	var d = from.distance_to(to)
	var hit_chance = clampf(0.85 - d * 0.01, 0.25, 0.8)
	if randf() < hit_chance:
		player.take_damage(randi_range(5, 10), global_position, self)
