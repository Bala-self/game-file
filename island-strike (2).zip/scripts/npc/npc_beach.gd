extends "res://scripts/npc/person.gd"
## Beach NPC — colorful tank + shorts + sandals + hat
## Spawns in Beachfront district

var flee_from: Vector3 = Vector3.ZERO

static func create() -> CharacterBody3D:
	var c = CharacterBody3D.new()
	c.set_script(load("res://scripts/npc/npc_beach.gd"))
	return c

func _setup() -> void:
	kind = "beach"
	add_to_group("civilians")
	add_to_group("beach_npcs")
	walk_speed = randf_range(1.6, 2.4)
	shirt_color = Color.from_hsv(randf_range(0.0, 1.0), 0.7, 0.9)
	state = "walk"
	target = _random_beach_point()

func _random_beach_point() -> Vector3:
	var districts: Dictionary = get_tree().root.get_node("GameState").world_data.get("districts", {})
	var beach: Rect2 = districts.get("Beachfront", Rect2())
	if beach.size == Vector2.ZERO:
		return _random_sidewalk_point()
	return Vector3(randf_range(beach.position.x, beach.end.x), 0.4, randf_range(beach.position.y, beach.end.y))

func _think(delta: float) -> void:
	state_t -= delta
	match state:
		"walk":
			walk_speed = 2.0
			if global_position.distance_to(target) < 1.5:
				state = "idle"
				state_t = randf_range(2.0, 6.0)
		"idle":
			if state_t <= 0.0:
				state = "walk"
				target = _random_beach_point()
		"flee":
			walk_speed = 4.2
			var away = (global_position - flee_from)
			away.y = 0
			target = global_position + away.normalized() * 20.0
			if state_t <= 0.0:
				state = "walk"
				target = _random_beach_point()

func on_gunshot(pos: Vector3) -> void:
	if state == "dead":
		return
	var d = global_position.distance_to(pos)
	if d < 34.0:
		flee_from = pos
		state = "flee"
		state_t = randf_range(4.0, 7.0)
