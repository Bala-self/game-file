extends "res://scripts/npc/person.gd"
## Dockside Crew — gang member. Territorial: hostile on sight inside the
## Industrial district, pursues and shoots, drops bigger loot.

const AGGRO_RANGE := 22.0
const SHOOT_INTERVAL := 1.1
const COVER_RANGE := 14.0

var territory: Rect2 = Rect2(140, 60, 310, 240)
var shoot_timer: float = 0.0
var cover_t: float = 0.0  # Round 9 S7: remaining time pinned to cover


static func create_in(gang_territory: Rect2) -> CharacterBody3D:
	var g = CharacterBody3D.new()
	g.set_script(load("res://scripts/npc/npc_gang.gd"))
	g.set("territory", gang_territory)
	return g


func _setup() -> void:
	kind = "gang"
	add_to_group("gangs")
	health = 55
	walk_speed = 2.6
	shirt_color = Color(0.45, 0.12, 0.12)  # dark red jacket
	state = "wander"
	target = _wander_point()




func _wander_point() -> Vector3:
	return Vector3(
		randf_range(territory.position.x, territory.end.x), 0.4,
		randf_range(territory.position.y, territory.end.y))


func _think(delta: float) -> void:
	var player = GameState.get_player() if GameState.has_method("get_player") else get_tree().get_first_node_in_group("player")
	match state:
		"wander":
			walk_speed = 2.6
			if global_position.distance_to(target) < 2.0:
				target = _wander_point()
			if player and is_instance_valid(player) and player.health > 0 \
					and global_position.distance_to(player.global_position) < AGGRO_RANGE \
					and _has_los_to(player.global_position):
				state = "hostile"
		"cover":
			# Round 9 S7: break to the nearest vehicle after taking a hit;
			# resume the fight when the pin expires
			cover_t -= delta
			walk_speed = 4.6
			if cover_t <= 0.0 or global_position.distance_to(target) < 1.2:
				state = "hostile"
		"hostile":
			if player == null or not is_instance_valid(player) or player.health <= 0:
				state = "wander"
				target = _wander_point()
				return
			var d = global_position.distance_to(player.global_position)
			walk_speed = 4.2 if d > 12.0 else 0.0
			target = player.global_position
			shoot_timer -= delta
			if shoot_timer <= 0.0 and d < 26.0 and _has_los_to(player.global_position):
				shoot_timer = SHOOT_INTERVAL
				_shoot(player)
		"investigate":
			walk_speed = 3.4
			if global_position.distance_to(target) < 2.5:
				state = "wander"
				target = _wander_point()


func on_gunshot(pos: Vector3) -> void:
	if state == "dead":
		return
	if global_position.distance_to(pos) < 60.0:
		target = pos
		state = "investigate"


## Round 9 S7 (Phase 27 slice): damaged crew break to the nearest vehicle as
## hard cover between bursts — deterministic, only when a car is in range.
func _react_to_damage(from: Vector3) -> void:
	var best_d = COVER_RANGE
	var best: Vector3 = Vector3.ZERO
	for car in get_tree().get_nodes_in_group("cars"):
		if is_instance_valid(car) and not car.wrecked:
			var d: float = car.global_position.distance_to(global_position)
			if d < best_d:
				best_d = d
				best = car.global_position
	if best_d < COVER_RANGE:
		state = "cover"
		cover_t = randf_range(1.4, 2.4)
		target = best + (global_position - best).normalized() * 1.1  # behind it
		return
	var player = GameState.get_player() if GameState.has_method("get_player") else get_tree().get_first_node_in_group("player")
	if player and from.distance_to(player.global_position) < 40.0 and state != "dead":
		state = "hostile"


func _shoot(player: Node3D) -> void:
	var snd = AudioStreamPlayer3D.new()
	snd.stream = load("res://assets/audio/shoot.wav")
	snd.volume_db = -8.0
	snd.max_distance = 100.0
	add_child(snd)
	snd.play()
	# finished-signal self-cleanup: no timer lambda capture (Round 16)
	snd.finished.connect(snd.queue_free)
	var from = global_position + Vector3(0, 1.5, 0)
	var to = player.global_position + Vector3(0, 1.2, 0)
	var tracer = MeshInstance3D.new()
	var mesh = CylinderMesh.new()
	mesh.top_radius = 0.012
	mesh.bottom_radius = 0.012
	mesh.height = from.distance_to(to)
	var m = StandardMaterial3D.new()
	m.albedo_color = Color(1, 0.45, 0.25)
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mesh.material = m
	tracer.mesh = mesh
	get_tree().current_scene.add_child(tracer)
	tracer.global_position = (from + to) * 0.5
	tracer.look_at(to)
	tracer.rotate_object_local(Vector3(1, 0, 0), PI / 2)
	var tw = tracer.create_tween()
	tw.tween_property(tracer, "transparency", 1.0, 0.08)
	tw.tween_callback(tracer.queue_free)
	if randf() < 0.6:
		player.take_damage(randi_range(5, 9), global_position)


func _die(from: Vector3, source: Node = null) -> void:
	# richer loot than civilians
	_drop("money", randi_range(80, 150))
	# suppress the base class generic drop by removing its call path:
	# base _die also drops; call it anyway for crime/report consistency but
	# neutralize its random money by pre-setting a flag the base checks.
	set_meta("no_loot", true)
	super(from)
