extends "res://scripts/npc/person.gd"
## Civilian NPC — Enhanced Witness System + Intimidation
## Implements: LOS <50m + distance gate, 2s reaction cower, 3s phone/report, intimidation 50% stops, night/rain/farmland reduced chance
## Deep fix: type inference error at aim_dir (line 34) — explicit Vector3 + safe null handling

var flee_from: Vector3 = Vector3.ZERO
var reporting: bool = false
var report_t: float = 0.0
var report_target_pos: Vector3 = Vector3.ZERO

static func create() -> CharacterBody3D:
	var c = CharacterBody3D.new()
	c.set_script(load("res://scripts/npc/npc_civilian.gd"))
	return c

func _setup() -> void:
	kind = "civilian"
	add_to_group("civilians")
	walk_speed = randf_range(1.8, 2.6)
	shirt_color = Color.from_hsv(randf(), 0.4, randf_range(0.55, 0.9))
	state = "walk"
	target = _scheduled_sidewalk_point()

func _think(delta: float) -> void:
	state_t -= delta
	if reporting:
		report_t -= delta
		walk_speed = 0.0
		target = global_position
		# Intimidation — if player aims at witness, 50% chance stops reporting
		var player: Node3D = GameState.get_player() if GameState.has_method("get_player") else get_tree().get_first_node_in_group("player") as Node3D
		if player != null and is_instance_valid(player):
			var dist: float = global_position.distance_to(player.global_position)
			var is_aiming: bool = false
			if player.get("aiming") != null:
				is_aiming = bool(player.get("aiming"))
			if dist < 20.0 and is_aiming:
				# Deep fix: explicit type + safe null — previous `var aim_dir := -player.get_node_or_null(...).global_basis.z if ... else Vector3.ZERO`
				# caused "Cannot infer type" because ternary with method chain returns Variant
				var cam_yaw_node: Node3D = player.get_node_or_null("CamYaw") as Node3D
				var aim_dir: Vector3 = Vector3.ZERO
				if cam_yaw_node != null:
					aim_dir = -cam_yaw_node.global_basis.z
				var to_witness: Vector3 = (global_position - player.global_position).normalized()
				if aim_dir.dot(to_witness) > 0.7 and randf() < 0.02:  # aiming at witness
					if randf() < 0.5:
						reporting = false
						state = "flee"
						flee_from = player.global_position
						state_t = randf_range(4.0, 7.0)
						GameState.notify("Witness intimidated — stopped reporting!")
						return
		if report_t <= 0.0:
			# Report finished — no wanted if killed before finish, but nearby witness may see murder severity 5
			if state != "dead":
				var chance: float = 1.0
				# Night/rain/farmland reduced chance
				if GameState.is_night():
					chance *= 0.7
				if GameState.raining:
					chance *= 0.8
				if _is_farmland():
					chance *= 0.6
				if randf() < chance:
					GameState.add_wanted(1)
					GameState.notify("A witness reported you!")
			reporting = false
			state = "flee"
			flee_from = report_target_pos
			state_t = randf_range(4.0, 7.0)
		return

	match state:
		"walk":
			walk_speed = 2.2
			if global_position.distance_to(target) < 1.5:
				state = "idle"
				state_t = randf_range(2.0, 6.0)
		"idle":
			if state_t <= 0.0:
				state = "walk"
				target = _scheduled_sidewalk_point()
		"flee":
			walk_speed = 4.6
			var away: Vector3 = (global_position - flee_from)
			away.y = 0.0
			target = global_position + away.normalized() * 20.0
			if state_t <= 0.0:
				state = "cower"
				state_t = randf_range(3.0, 6.0)
		"cower":
			if state_t <= 0.0:
				state = "walk"
				target = _scheduled_sidewalk_point()

func _is_farmland() -> bool:
	# Check if in farmland district — uses WBKit district helper if available
	var districts: Dictionary = GameState.world_data.get("districts", {})
	if districts.has("Farmland"):
		var r: Rect2 = districts["Farmland"]
		return r.has_point(Vector2(global_position.x, global_position.z))
	# Fallback rect
	return global_position.x > -410.0 and global_position.x < -110.0 and global_position.z > 140.0 and global_position.z < 300.0

func on_gunshot(pos: Vector3) -> void:
	if state == "dead":
		return
	var d: float = global_position.distance_to(pos)
	if d < 34.0:
		flee_from = pos
		state = "flee"
		state_t = randf_range(4.0, 7.0)
		# Witness must have LOS + distance <50m + not fleeing already
		if d < 50.0 and report_cd <= 0.0 and _has_los_to(pos) and state != "flee":
			# 2s reaction cower then 3s phone/report
			report_cd = 45.0
			reporting = true
			report_t = 3.0  # phone/report anim 3s
			report_target_pos = pos
			state_t = 2.0  # reaction cower 2s
			state = "cower"
			# Don't instantly add wanted — wait for report_t finish
		elif d < 24.0 and report_cd <= 0.0 and randf() < 0.5 and not reporting:
			# Legacy fallback — instant report 50% if very close
			report_cd = 45.0
			GameState.add_wanted(1)
			GameState.notify("A witness reported you!")

func on_crime_seen(pos: Vector3, _severity: int) -> void:
	# Called when crime seen directly — _severity unused but kept for API compat
	@warning_ignore("unused_parameter")
	var __severity = _severity
	if state == "dead" or reporting:
		return
	var d: float = global_position.distance_to(pos)
	if d < 50.0 and _has_los_to(pos):
		if report_cd <= 0.0:
			report_cd = 30.0
			reporting = true
			report_t = 3.0
			report_target_pos = pos
			state = "cower"
			state_t = 2.0
