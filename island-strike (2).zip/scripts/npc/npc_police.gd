extends "res://scripts/npc/person.gd"

const PATROL_SPEED := 3.0
## Police NPC — Staged Escalation (No instant shooting without wanted)
## Implements: Observe → Identify → Report → Wanted → Investigate → Search → Pursuit → Arrest Attempt → Escalate → Shooting
## Critical rule: No wanted star → no automatic police shooting

const SHOOT_RANGE := 30.0
const SHOOT_INTERVAL := 1.3
const OBSERVE_RANGE := 25.0
const IDENTIFY_RANGE := 40.0
const ARREST_RANGE := 3.5

var spawn_point: Vector3 = Vector3.ZERO
var shoot_timer: float = 0.0
var last_known: Vector3 = Vector3.ZERO
var search_t: float = 0.0
var patrol_a: Vector3 = Vector3.ZERO
var patrol_b: Vector3 = Vector3.ZERO
var observe_t: float = 0.0
var identify_t: float = 0.0
var reporting_t: float = 0.0
var investigate_t: float = 0.0
var arrest_t: float = 0.0

static func create_at(spawn: Vector3) -> CharacterBody3D:
	var c = CharacterBody3D.new()
	c.set_script(load("res://scripts/npc/npc_police.gd"))
	c.set("spawn_point", spawn)
	return c

func _setup() -> void:
	kind = "cop"
	add_to_group("police")
	health = 70
	walk_speed = PATROL_SPEED
	shirt_color = Color(0.15, 0.2, 0.5)
	patrol_a = spawn_point
	patrol_b = spawn_point + Vector3(randf_range(-15, 15), 0, randf_range(-15, 15))
	state = "patrol"
	target = patrol_a

func _think(delta: float) -> void:
	var player = GameState.get_player() if GameState.has_method("get_player") else get_tree().get_first_node_in_group("player")
	if player == null or not is_instance_valid(player):
		if state not in ["patrol", "leave"]:
			state = "patrol"
			target = patrol_a
		_patrol_think(delta)
		return

	var dist_to_player: float = global_position.distance_to(player.global_position)
	var has_los: bool = _has_los_to(player.global_position)
	var wanted: int = GameState.wanted
	var threat: int = ThreatAssessment.assess(player, global_position, wanted)

	match state:
		"patrol":
			_patrol_think(delta)
			# Detect suspicious behavior without wanted — observe, not shoot
			if dist_to_player < OBSERVE_RANGE and has_los:
				if _is_suspicious(player):
					state = "observe"
					observe_t = 2.0
					target = player.global_position
			# If wanted exists, go to identify/report
			if wanted > 0 and (dist_to_player < 90.0 or has_los):
				state = "identify"
				identify_t = 1.5

		"observe":
			# Observe — stop, look at player 1-2s, no wanted yet
			walk_speed = 0.0
			target = global_position
			observe_t -= delta
			if observe_t <= 0.0:
				if wanted > 0 or _is_crime_seen(player):
					state = "identify"
					identify_t = 1.5
				else:
					state = "patrol"
					target = patrol_a
			# If player does nothing, return to patrol

		"identify":
			# Identify — check distance <40m + LOS
			walk_speed = 2.0
			identify_t -= delta
			if dist_to_player < IDENTIFY_RANGE and has_los:
				if identify_t <= 0.0:
					state = "reporting"
					reporting_t = 2.5
					target = global_position
			else:
				# Lost LOS, go investigate last known
				state = "investigate"
				investigate_t = 10.0
				last_known = player.global_position

		"reporting":
			# Reporting — radio 2.5s, vulnerable, interruptible
			walk_speed = 0.0
			target = global_position
			reporting_t -= delta
			if reporting_t <= 0.0:
				# Emit crime if not already wanted
				if wanted == 0:
					GameState.commit_crime(1, player.global_position)
					GameState.add_wanted(1)
				state = "investigate"
				investigate_t = 12.0
				last_known = player.global_position
			# If player attacks during reporting, jump to armed response
			if _is_attacked():
				state = "armed_response"

		"investigate":
			# Investigate — walk to crime pos, search 10s
			walk_speed = 3.5
			target = last_known
			investigate_t -= delta
			if global_position.distance_to(last_known) < 2.0:
				# Arrived, look around
				walk_speed = 1.0
				if investigate_t <= 0.0:
					if has_los and dist_to_player < 50.0:
						state = "pursue"
					else:
						state = "search"
						search_t = 20.0
			if has_los and dist_to_player < 30.0 and wanted > 0:
				state = "pursue"

		"search":
			# Search — last known + expanding circles, 20-30s, call backup
			walk_speed = 4.0
			target = last_known + Vector3(randf_range(-15,15), 0, randf_range(-15,15))
			search_t -= delta
			if has_los and dist_to_player < 40.0 and wanted > 0:
				state = "pursue"
			elif search_t <= 0.0:
				state = "patrol"
				target = patrol_a

		"pursue":
			if wanted == 0:
				dismiss()
				return
			if player.health <= 0:
				state = "patrol"
				target = patrol_a
				return
			last_known = player.global_position
			walk_speed = 4.9
			target = player.global_position
			shoot_timer -= delta

			# Check arrest vs shooting
			if ThreatAssessment.should_arrest(threat, wanted, dist_to_player):
				state = "arrest_attempt"
				arrest_t = 5.0
			elif ThreatAssessment.should_shoot(threat, wanted, has_los, dist_to_player):
				if dist_to_player < SHOOT_RANGE and has_los:
					if shoot_timer <= 0.0:
						shoot_timer = SHOOT_INTERVAL
						_shoot(player)
				# If high threat, go to armed response (cover)
				if threat >= ThreatAssessment.ThreatLevel.HIGH:
					state = "armed_response"
			elif dist_to_player < 55.0 and wanted >= 3:
				search_t = 8.0

		"arrest_attempt":
			# Arrest attempt — distance <3m, say "Hands up!", prompt [E] to surrender
			walk_speed = 0.0
			target = global_position
			arrest_t -= delta
			if dist_to_player > ARREST_RANGE + 1.0:
				state = "pursue"
			elif arrest_t <= 0.0:
				# Player didn't comply, escalate to pursuit
				state = "pursue"
			else:
				# Check if player surrenders (hold E 2s) — for now auto if crouching + not moving
				if player.has_method("get"):
					var vel: Vector3 = player.get("velocity") if player.get("velocity") != null else Vector3.ZERO
					if vel.length() < 0.5 and Input.is_action_pressed("crouch"):
						_busted_player(player)
						return
				# If player runs, pursue
				if dist_to_player > 2.0 and player.velocity.length() > 3.0:
					state = "pursue"

		"armed_response":
			# Armed response — draw weapon, take cover behind vehicles (like gang S7)
			walk_speed = 3.0
			# Find nearest vehicle as cover
			var cover = _find_nearest_cover()
			if cover != null:
				var to_cover = (global_position - cover.global_position).normalized() * 2.5
				target = cover.global_position + to_cover
				if global_position.distance_to(target) < 1.5:
					walk_speed = 0.0
					# In cover, shoot if LOS
					if has_los and dist_to_player < SHOOT_RANGE and ThreatAssessment.should_shoot(threat, wanted, has_los, dist_to_player):
						if shoot_timer <= 0.0:
							shoot_timer = SHOOT_INTERVAL
							_shoot(player)
			else:
				# No cover, pursue and shoot
				target = player.global_position
				if has_los and dist_to_player < SHOOT_RANGE:
					if shoot_timer <= 0.0:
						shoot_timer = SHOOT_INTERVAL
						_shoot(player)
			# If threat drops, go back to pursue/arrest
			if threat <= ThreatAssessment.ThreatLevel.LOW and wanted <= 2:
				state = "pursue"

		"leave":
			walk_speed = 3.5
			target = spawn_point
			state_t -= delta
			if state_t <= 0.0 or global_position.distance_to(spawn_point) < 2.0:
				queue_free()

func _patrol_think(delta: float) -> void:
	walk_speed = PATROL_SPEED
	if global_position.distance_to(target) < 1.5:
		var tmp = patrol_a
		patrol_a = patrol_b
		patrol_b = tmp
		target = patrol_a

func _is_suspicious(player: Node) -> bool:
	# Suspicious loitering near military, speed, etc.
	if player == null:
		return false
	# Check if near military district
	var pos: Vector3 = player.global_position
	if pos.x > -70 and pos.x < 260 and pos.z > -350 and pos.z < -250:
		return true  # near military
	# Check if player has weapon drawn and aiming
	if player.get("aiming") != null and bool(player.get("aiming")):
		return true
	# Check if sprinting near cop
	if player.get("velocity") != null:
		var vel: Vector3 = player.get("velocity")
		if vel.length() > 7.0 and global_position.distance_to(player.global_position) < 15.0:
			return true
	return false

func _is_crime_seen(player: Node) -> bool:
	if player == null:
		return false
	# Minor crime detected if player has weapon or is shooting
	if player.get("pistol") != null:
		var wp: Node = player.get("pistol")
		if wp.get("cooldown") != null and float(wp.get("cooldown")) > 0.0:
			return true
	return false

func _is_attacked() -> bool:
	# Check if recently damaged
	return Time.get_ticks_msec() / 1000.0 - last_damage < 2.0 if has_method("get") else false

var last_damage: float = 0.0

func _find_nearest_cover() -> Node3D:
	var best: Node3D = null
	var best_d: float = 6.0
	for c in (GameState.get_cached_group("cars") if GameState.has_method("get_cached_group") else get_tree().get_nodes_in_group("cars")):
		if not is_instance_valid(c):
			continue
		var d: float = c.global_position.distance_to(global_position)
		if d < best_d:
			best_d = d
			best = c as Node3D
	return best

func on_gunshot(pos: Vector3) -> void:
	if state == "dead":
		return
	if GameState.wanted > 0:
		last_known = pos
		if state in ["patrol", "observe", "search"]:
			state = "identify"
			identify_t = 1.0

func dismiss() -> void:
	if state != "dead" and state != "leave":
		state = "leave"
		state_t = 10.0

func _react_to_damage(_from: Vector3) -> void:
	last_damage = Time.get_ticks_msec() / 1000.0
	if state != "dead" and state != "leave":
		if GameState.wanted == 0:
			GameState.add_wanted(2)
		state = "armed_response"

func _busted_player(player: Node) -> void:
	# Busted logic — fines + respawn
	GameState.notify("BUSTED! You were arrested")
	GameState.set_wanted(0)
	if player.has_method("respawn"):
		player.respawn(spawn_point + Vector3(5,0,5))
	# Fine
	GameState.try_spend(200)
	state = "patrol"
	target = patrol_a

func _shoot(player: Node3D) -> void:
	var snd = AudioStreamPlayer3D.new()
	snd.stream = load("res://assets/audio/shoot.wav")
	snd.volume_db = -8.0
	snd.max_distance = 100.0
	add_child(snd)
	snd.play()
	# finished-signal self-cleanup: no timer lambda capture (Round 16)
	snd.finished.connect(snd.queue_free)
	# tracer
	var from = global_position + Vector3(0, 1.5, 0)
	var to = player.global_position + Vector3(0, 1.2, 0)
	var tracer = MeshInstance3D.new()
	var mesh = CylinderMesh.new()
	mesh.top_radius = 0.012
	mesh.bottom_radius = 0.012
	mesh.height = from.distance_to(to)
	var m = StandardMaterial3D.new()
	m.albedo_color = Color(1, 0.6, 0.3)
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mesh.material = m
	tracer.mesh = mesh
	get_tree().current_scene.add_child(tracer)
	tracer.global_position = (from + to) * 0.5
	tracer.look_at(to)
	tracer.rotate_object_local(Vector3(1, 0, 0), PI / 2)
	var tw = tracer.create_tween()
	tw.tween_property(tracer, "transparency", 1.0, 0.08)
	tw.tween_callback(tracer.queue_free)
	var d = from.distance_to(to)
	var hit_chance = clampf(0.9 - d * 0.012, 0.3, 0.85)
	if randf() < hit_chance:
		player.take_damage(randi_range(4, 8), global_position, self)
