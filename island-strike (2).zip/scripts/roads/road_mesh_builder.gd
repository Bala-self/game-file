class_name RoadMeshBuilder
extends Object
## ROAD GEOMETRY GENERATION (§32/§33/§34/§41/§43/§74/§75).
##
## Every dimension comes from the RoadSchema profile for the segment's
## class — the builder, collision, markings and (later) sidewalks all read
## the same source, so nothing is duplicated per-system (§31).
##
## Rules implemented here:
##   * one mesh per sector chunk, never one world-sized mesh (§32);
##   * surface follows the grade-capped alignment, lifted off the terrain,
##     with outer rows blended down to ground so the road neither floats
##     nor buries (§33);
##   * bridge decks use the structural deck elevation, never terrain (§41);
##   * tunnel bores get a liner so terrain never shows through (§43);
##   * markings derive from lane/marking profile data (§39);
##   * guardrails come from the drop profile, not from every curb (§43);
##   * chunks are positioned like terrain chunks: body at the chunk centre,
##     children offset by -centre, so streaming distance is measured right.

const S := preload("res://scripts/roads/road_schema.gd")
const C := preload("res://scripts/roads/road_terrain_contract.gd")
const G := preload("res://scripts/roads/road_graph.gd")
const T := preload("res://scripts/world/terrain.gd")
const WC := preload("res://scripts/world/world_contract.gd")

## Chunk target length. Kept well under the streamer's 150 m MIN_AABB so a
## chunk is never mistaken for environment-scale always-on geometry.
const CHUNK_TARGET_M := 90.0
const LIFT_M := 0.10
## Outer rows fall to terrain across this distance (§33 edge blending).
const EDGE_BLEND_M := 3.0
const GUARDRAIL_DROP_M := 4.0
const GUARDRAIL_PROBE_M := 3.5
const MARK_WIDTH_M := 0.16
const MARK_DASH_M := 3.0
const MARK_GAP_M := 5.0
## Far-field visibility (§74). Markings are part of the surface mesh, so
## the mesh itself fades; roadside furniture is anchors only this phase.
const VIS_MARGIN_M := 120.0

const COL_CONCRETE := Color(0.42, 0.42, 0.43)
const COL_GRAVEL := Color(0.44, 0.40, 0.34)
const COL_DIRT := Color(0.40, 0.33, 0.24)
const COL_ASPHALT := Color(0.19, 0.19, 0.21)
const COL_SIDEWALK := Color(0.52, 0.51, 0.49)
const COL_CURB := Color(0.46, 0.45, 0.44)
const COL_MARK_YELLOW := Color(0.85, 0.72, 0.12)
const COL_MARK_WHITE := Color(0.86, 0.86, 0.84)
const COL_RAIL := Color(0.62, 0.63, 0.65)
const COL_TUNNEL_LINER := Color(0.24, 0.24, 0.26)

## Anchors for later dressing prompts (§38/§44): positions only, no meshes.
## Prompt 04 deliberately does not place hundreds of lamps or signs.
static var _sign_anchors: Array = []
static var _lamp_anchors: Array = []
static var _crossing_anchors: Array = []


## Deterministic per-road tint from the road id (no RNG) so the network
## does not read as one flat grey sheet.
static func _surface_color(def: S.RoadDefinition, road_id: String) -> Color:
	var base: Color
	match def.surface_type:
		S.SURF_CONCRETE: base = COL_CONCRETE
		S.SURF_GRAVEL: base = COL_GRAVEL
		S.SURF_DIRT: base = COL_DIRT
		_: base = COL_ASPHALT
	var h: int = 0
	for i in range(road_id.length()):
		h = (h * 31 + road_id.unicode_at(i)) & 0xFFFF
	var v: float = float(h % 7) * 0.004 - 0.012
	return Color(clampf(base.r + v, 0.0, 1.0), clampf(base.g + v, 0.0, 1.0),
			clampf(base.b + v, 0.0, 1.0))


## Cross-section rows from the profile only (§31), ordered left -> right.
static func cross_section(def: S.RoadDefinition) -> Array:
	var rows: Array = []
	var hw: float = def.carriageway_half_width()
	var sw: float = def.sidewalk_width if def.sidewalk else 0.0
	var cw: float = def.curb_width if def.curb else 0.0
	if sw > 0.0:
		rows.append({"x": -(hw + cw + sw), "kind": "verge_outer", "y": -0.05})
		rows.append({"x": -(hw + cw), "kind": "sidewalk", "y": 0.16})
	if cw > 0.0:
		rows.append({"x": -(hw + cw), "kind": "curb_top", "y": 0.14})
		rows.append({"x": -hw, "kind": "curb_face", "y": 0.0})
	rows.append({"x": -hw, "kind": "shoulder", "y": 0.0})
	if def.divided and def.median_width > 0.0:
		var mw: float = def.median_width * 0.5
		rows.append({"x": -mw, "kind": "carriageway", "y": 0.03})
		rows.append({"x": -mw, "kind": "median", "y": 0.10})
		rows.append({"x": mw, "kind": "median", "y": 0.10})
		rows.append({"x": mw, "kind": "carriageway", "y": 0.03})
	else:
		rows.append({"x": 0.0, "kind": "carriageway", "y": 0.03})
	rows.append({"x": hw, "kind": "shoulder", "y": 0.0})
	if cw > 0.0:
		rows.append({"x": hw, "kind": "curb_face", "y": 0.0})
		rows.append({"x": hw + cw, "kind": "curb_top", "y": 0.14})
	if sw > 0.0:
		rows.append({"x": hw + cw, "kind": "sidewalk", "y": 0.16})
		rows.append({"x": hw + cw + sw, "kind": "verge_outer", "y": -0.05})
	return rows


static func _row_color(kind: String, surf: Color) -> Color:
	match kind:
		"sidewalk": return COL_SIDEWALK
		"curb_top", "curb_face": return COL_CURB
		"median": return COL_CONCRETE
		"verge_outer": return surf.darkened(0.18)
	return surf


## Build every road mesh under `parent`. Returns counts + timing that the
## performance gates (70-74) read directly.
static func build(parent: Node3D) -> Dictionary:
	var t0: int = Time.get_ticks_msec()
	G.build()
	_sign_anchors.clear(); _lamp_anchors.clear(); _crossing_anchors.clear()
	var root := Node3D.new()
	root.name = "RoadNetwork"
	parent.add_child(root)
	var mat := _material()
	var stats := {"meshes": 0, "verts": 0, "tris": 0, "collisions": 0,
			"nodes": 0, "guardrails": 0, "marks": 0, "chunks": 0,
			"sign_anchors": 0, "lamp_anchors": 0, "crossing_anchors": 0,
			"build_ms": 0}
	var segs: Array = G.segments()
	for si in range(segs.size()):
		var seg = segs[si]
		var def: S.RoadDefinition = S.class_registry()[seg.class_id]
		var bridge = _bridge_for(seg.id)
		var tunnel = _tunnel_for(seg.id)
		for ch: Dictionary in _split_into_chunks(seg):
			_build_chunk(root, seg, def, ch, mat, bridge, tunnel, stats)
	_collect_anchors(seg, def)
	stats["sign_anchors"] = _sign_anchors.size()
	stats["lamp_anchors"] = _lamp_anchors.size()
	stats["crossing_anchors"] = _crossing_anchors.size()
	stats["build_ms"] = Time.get_ticks_msec() - t0
	stats["nodes"] = _count_nodes(root)
	return stats


static func dressing_anchors() -> Dictionary:
	return {"signs": _sign_anchors, "lamps": _lamp_anchors,
			"crossings": _crossing_anchors}


static func _count_nodes(n: Node) -> int:
	var c: int = 1
	for k in n.get_children():
		c += _count_nodes(k)
	return c


static func _material() -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.vertex_color_use_as_albedo = true
	m.roughness = 0.92
	m.metallic = 0.0
	return m


static func _bridge_for(segment_id: String):
	for br in G.bridges():
		if br.segment_id == segment_id:
			return br
	return null


static func _tunnel_for(segment_id: String):
	for tn in G.tunnels():
		if tn.segment_id == segment_id:
			return tn
	return null


## Chunk splitting on sector boundaries (§49/§53): a chunk never straddles
## two sectors, which is what makes ownership deterministic and duplicate
## generation impossible.
static func _split_into_chunks(seg) -> Array:
	var out: Array = []
	var pts: Array = seg.points
	var n: int = pts.size()
	if n < 2:
		return out
	var start: int = 0
	var acc: float = 0.0
	for i in range(1, n):
		acc += ((pts[i] - pts[i - 1]) as Vector2).length()
		var boundary: bool = WC.sector_of(pts[i - 1]) != WC.sector_of(pts[i])
		if (acc >= CHUNK_TARGET_M or boundary) and i > start:
			out.append({"from": start, "to": i,
					"sector": WC.micro_id(WC.sector_of(pts[start]))})
			start = i
			acc = 0.0
	if start < n - 1:
		out.append({"from": start, "to": n - 1,
				"sector": WC.micro_id(WC.sector_of(pts[start]))})
	return out


static func _build_chunk(root: Node3D, seg, def: S.RoadDefinition,
		ch: Dictionary, mat: StandardMaterial3D, bridge, tunnel,
		stats: Dictionary) -> void:
	var from: int = ch["from"]
	var to: int = ch["to"]
	if to <= from:
		return
	var pts: Array = seg.points
	var elev: PackedFloat64Array = seg.elev
	var rows: Array = cross_section(def)
	var surf: Color = _surface_color(def, seg.road_id)
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	# ribbon vertices, row by row
	var row_verts: Array = []
	for ri in range(rows.size()):
		row_verts.append([])
	for i in range(from, to + 1):
		var p: Vector2 = pts[i]
		var tan := _tangent(pts, i)
		var nrm := Vector2(-tan.y, tan.x)
		var on_bridge: bool = bridge != null and i >= bridge.start_index \
				and i <= bridge.end_index
		var base_y: float = bridge.deck_height if on_bridge else elev[i] + LIFT_M
		for ri in range(rows.size()):
			var row: Dictionary = rows[ri]
			var off: float = row["x"]
			var kind: String = row["kind"]
			var pos := Vector3(p.x + nrm.x * off, base_y + float(row["y"]),
					p.y + nrm.y * off)
			if not on_bridge and kind == "verge_outer":
				var g: float = T.height_at(pos.x, pos.z)
				pos.y = clampf(g + 0.02, base_y - EDGE_BLEND_M, base_y + 0.02)
			st.set_color(_row_color(kind, surf))
			st.add_vertex(pos)
			row_verts[ri].append(pos)
	# stitch adjacent rows into strips
	for ri in range(rows.size() - 1):
		var a: Array = row_verts[ri]
		var b: Array = row_verts[ri + 1]
		var col: Color = _row_color(str(rows[ri]["kind"]), surf)
		for k in range(a.size() - 1):
			_quad(st, a[k], a[k + 1], b[k + 1], b[k], col)
	stats["marks"] += _add_markings(st, seg, def, from, to)
	stats["guardrails"] += _add_guardrails(st, seg, def, from, to, bridge)
	if bridge != null:
		_add_bridge_structure(st, seg, def, from, to, bridge)
	if tunnel != null:
		_add_tunnel_liner(st, seg, def, from, to, tunnel)
	var mesh: ArrayMesh = st.commit()
	if mesh == null or mesh.get_surface_count() == 0:
		return
	# centre the chunk like terrain chunks so streaming measures correctly
	var mid: Vector2 = pts[(from + to) / 2]
	var center := Vector3(mid.x, elev[(from + to) / 2], mid.y)
	var body := StaticBody3D.new()
	body.name = "RoadBody_%s_%d" % [seg.road_id, from]
	body.position = center
	body.collision_layer = 1
	body.collision_mask = 0
	body.set_meta("road_segment_id", seg.id)
	body.set_meta("road_class", seg.class_id)
	body.set_meta("road_sector", ch["sector"])
	root.add_child(body)
	var col := CollisionShape3D.new()
	col.shape = mesh.create_trimesh_shape()
	col.position = -center
	body.add_child(col)
	var mi := MeshInstance3D.new()
	mi.name = "RoadChunk_%s_%d" % [seg.road_id, from]
	mi.position = -center
	mi.mesh = mesh
	mi.material_override = mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mi.visibility_range_end = def.lod_far
	mi.visibility_range_begin = 0.0
	mi.visibility_range_fade_mode = GeometryInstance3D.VISIBILITY_RANGE_FADE_SELF
	body.add_child(mi)
	body.add_to_group("road_chunks")
	mi.add_to_group("road_chunks")
	stats["chunks"] += 1
	stats["meshes"] += 1
	stats["collisions"] += 1
	var faces: int = mesh.get_faces().size()
	stats["verts"] += faces / 3
	stats["tris"] += faces / 3


static func _tangent(pts: Array, i: int) -> Vector2:
	var n: int = pts.size()
	if i <= 0:
		return ((pts[1] - pts[0]) as Vector2).normalized()
	if i >= n - 1:
		return ((pts[n - 1] - pts[n - 2]) as Vector2).normalized()
	return ((pts[i + 1] - pts[i - 1]) as Vector2).normalized()


static func _quad(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3,
		d: Vector3, col: Color) -> void:
	st.set_color(col)
	st.add_vertex(a)
	st.add_vertex(b)
	st.add_vertex(c)
	st.set_color(col)
	st.add_vertex(a)
	st.add_vertex(c)
	st.add_vertex(d)


## Markings derived from the class marking profile + lane counts (§39).
static func _add_markings(st: SurfaceTool, seg, def: S.RoadDefinition,
		from: int, to: int) -> int:
	if def.marking == S.MARK_NONE:
		return 0
	var added: int = 0
	var hw: float = def.carriageway_half_width()
	added += _stripe(st, seg, from, to, -(hw - 0.35), COL_MARK_WHITE, false)
	added += _stripe(st, seg, from, to, hw - 0.35, COL_MARK_WHITE, false)
	match def.marking:
		S.MARK_CENTER_DASH:
			added += _stripe(st, seg, from, to, 0.0, COL_MARK_YELLOW, true)
		S.MARK_DOUBLE_CENTER:
			added += _stripe(st, seg, from, to, -0.22, COL_MARK_YELLOW, false)
			added += _stripe(st, seg, from, to, 0.22, COL_MARK_YELLOW, false)
		S.MARK_LANE_DIVIDER:
			if def.lanes_per_direction >= 2:
				added += _stripe(st, seg, from, to, 0.0, COL_MARK_WHITE, false)
				for li in range(1, def.lanes_per_direction):
					var off: float = def.lane_width * (float(li) \
							- float(def.lanes_per_direction) * 0.5)
					added += _stripe(st, seg, from, to, off, COL_MARK_WHITE, true)
					added += _stripe(st, seg, from, to, -off, COL_MARK_WHITE, true)
			else:
				added += _stripe(st, seg, from, to, 0.0, COL_MARK_YELLOW, false)
	return added


static func _stripe(st: SurfaceTool, seg, from: int, to: int, lateral: float,
		col: Color, dashed: bool) -> int:
	var pts: Array = seg.points
	var elev: PackedFloat64Array = seg.elev
	var added: int = 0
	var since: float = 0.0
	var drawing: bool = not dashed
	var half: float = MARK_WIDTH_M * 0.5
	for i in range(from, to):
		var a: Vector2 = pts[i]
		var b: Vector2 = pts[i + 1]
		since += (b - a).length()
		if dashed:
			if drawing and since >= MARK_DASH_M:
				drawing = false
				since = 0.0
			elif not drawing and since >= MARK_GAP_M:
				drawing = true
				since = 0.0
			if not drawing:
				continue
		var na := _perp(pts, i)
		var nb := _perp(pts, i + 1)
		var y0: float = elev[i] + LIFT_M + 0.05
		var y1: float = elev[i + 1] + LIFT_M + 0.05
		var p1 := Vector3(a.x + na.x * (lateral - half), y0, a.y + na.y * (lateral - half))
		var p2 := Vector3(a.x + na.x * (lateral + half), y0, a.y + na.y * (lateral + half))
		var p3 := Vector3(b.x + nb.x * (lateral + half), y1, b.y + nb.y * (lateral + half))
		var p4 := Vector3(b.x + nb.x * (lateral - half), y1, b.y + nb.y * (lateral - half))
		_quad(st, p1, p2, p3, p4, col)
		added += 1
	return added


static func _perp(pts: Array, i: int) -> Vector2:
	var t := _tangent(pts, i)
	return Vector2(-t.y, t.x)


## Guardrails from the drop profile (§43) and on bridge decks (§41).
static func _add_guardrails(st: SurfaceTool, seg, def: S.RoadDefinition,
		from: int, to: int, bridge) -> int:
	if def.guardrail_profile == "never":
		return 0
	var pts: Array = seg.points
	var elev: PackedFloat64Array = seg.elev
	var hw: float = def.carriageway_half_width() + def.shoulder_width
	var added: int = 0
	for side in [-1.0, 1.0]:
		for i in range(from, to):
			var on_bridge: bool = bridge != null and i >= bridge.start_index \
					and i <= bridge.end_index
			var need: bool = on_bridge or def.guardrail_profile == "always"
			if not need:
				var nrm := _perp(pts, i)
				var probe := Vector2((pts[i] as Vector2).x + nrm.x * side * (hw + GUARDRAIL_PROBE_M),
						(pts[i] as Vector2).y + nrm.y * side * (hw + GUARDRAIL_PROBE_M))
				var drop: float = elev[i] - T.height_at(probe.x, probe.y)
				need = drop >= GUARDRAIL_DROP_M and def.speed_limit_kmh >= 45.0
			if not need:
				continue
			var tan := _tangent(pts, i)
			var off: float = side * (hw + 0.3)
			var y: float = bridge.deck_height if on_bridge else elev[i] + LIFT_M
			var base := Vector3((pts[i] as Vector2).x + _perp(pts, i).x * off, y,
					(pts[i] as Vector2).y + _perp(pts, i).y * off)
			_rail_box(st, base, tan, 1.0, 0.26)
			added += 1
	return added


static func _rail_box(st: SurfaceTool, base: Vector3, tan: Vector2,
		height: float, thickness: float) -> void:
	var nrm := Vector2(-tan.y, tan.x)
	var top := base + Vector3(0, height, 0)
	var half: float = thickness * 0.5
	var a := base + Vector3(nrm.x * half, 0, nrm.y * half)
	var b := base - Vector3(nrm.x * half, 0, nrm.y * half)
	var c := top - Vector3(nrm.x * half, 0, nrm.y * half)
	var d := top + Vector3(nrm.x * half, 0, nrm.y * half)
	_quad(st, a, b, c, d, COL_RAIL)
	_quad(st, d, c, b, a, COL_RAIL)


## Bridge edge beams (§41) so the deck reads as structure, not flat road.
static func _add_bridge_structure(st: SurfaceTool, seg, def: S.RoadDefinition,
		from: int, to: int, bridge) -> void:
	var pts: Array = seg.points
	var hw: float = def.carriageway_half_width() + def.shoulder_width
	for i in range(from, to):
		if i < bridge.start_index or i >= bridge.end_index:
			continue
		for side in [-1.0, 1.0]:
			var na := _perp(pts, i)
			var nb := _perp(pts, i + 1)
			var off: float = side * (hw + 0.4)
			var off2: float = off + side * 0.5
			var y: float = bridge.deck_height
			var yb: float = y - 1.1
			var a := Vector3((pts[i] as Vector2).x + na.x * off, y, (pts[i] as Vector2).y + na.y * off)
			var b := Vector3((pts[i] as Vector2).x + na.x * off2, yb, (pts[i] as Vector2).y + na.y * off2)
			var c := Vector3((pts[i + 1] as Vector2).x + nb.x * off2, yb, (pts[i + 1] as Vector2).y + nb.y * off2)
			var d := Vector3((pts[i + 1] as Vector2).x + nb.x * off, y, (pts[i + 1] as Vector2).y + nb.y * off)
			_quad(st, a, b, c, d, COL_CONCRETE)


## Tunnel liner (§43): walls + crown so terrain cannot show through.
static func _add_tunnel_liner(st: SurfaceTool, seg, def: S.RoadDefinition,
		from: int, to: int, tunnel) -> void:
	var pts: Array = seg.points
	var elev: PackedFloat64Array = seg.elev
	var hw: float = def.carriageway_half_width() + def.shoulder_width + 0.6
	var h: float = C.TUNNEL_HEADROOM_M
	for i in range(from, to):
		if i < tunnel.start_index or i >= tunnel.end_index:
			continue
		var na := _perp(pts, i)
		var nb := _perp(pts, i + 1)
		var y0: float = elev[i] + LIFT_M
		var y1: float = elev[i + 1] + LIFT_M
		for side in [-1.0, 1.0]:
			var off: float = side * hw
			var a := Vector3((pts[i] as Vector2).x + na.x * off, y0, (pts[i] as Vector2).y + na.y * off)
			var b := Vector3((pts[i] as Vector2).x + na.x * off, y0 + h, (pts[i] as Vector2).y + na.y * off)
			var c := Vector3((pts[i + 1] as Vector2).x + nb.x * off, y1 + h, (pts[i + 1] as Vector2).y + nb.y * off)
			var d := Vector3((pts[i + 1] as Vector2).x + nb.x * off, y1, (pts[i + 1] as Vector2).y + nb.y * off)
			_quad(st, a, b, c, d, COL_TUNNEL_LINER)
			_quad(st, d, c, b, a, COL_TUNNEL_LINER)
		var la := Vector3((pts[i] as Vector2).x + na.x * hw, y0 + h, (pts[i] as Vector2).y + na.y * hw)
		var lb := Vector3((pts[i] as Vector2).x - na.x * hw, y0 + h, (pts[i] as Vector2).y - na.y * hw)
		var lc := Vector3((pts[i + 1] as Vector2).x - nb.x * hw, y1 + h, (pts[i + 1] as Vector2).y - nb.y * hw)
		var ld := Vector3((pts[i + 1] as Vector2).x + nb.x * hw, y1 + h, (pts[i + 1] as Vector2).y + nb.y * hw)
		_quad(st, la, lb, lc, ld, COL_TUNNEL_LINER)


## Sign / lamp / crossing anchors (§38/§44/§45) — data only. Prompt 12/16
## turn these into meshes; Prompt 04 must not dress the world yet.
static func _collect_anchors(seg, def: S.RoadDefinition) -> void:
	var pts: Array = seg.points
	var elev: PackedFloat64Array = seg.elev
	var hw: float = def.total_half_width()
	if def.lighting:
		var spacing: float = maxf(20.0, def.lamp_spacing_m)
		var acc: float = 0.0
		for i in range(1, pts.size()):
			acc += ((pts[i] - pts[i - 1]) as Vector2).length()
			if acc >= spacing:
				acc = 0.0
				var nrm := _perp(pts, i)
				for side in [-1.0, 1.0]:
					_lamp_anchors.append({
						"road_id": seg.road_id,
						"position": Vector3((pts[i] as Vector2).x + nrm.x * side * (hw + 0.6),
								elev[i] + 0.2, (pts[i] as Vector2).y + nrm.y * side * (hw + 0.6)),
						"sector": WC.micro_id(WC.sector_of(pts[i])),
					})
	if def.signage:
		var n2: int = pts.size()
		var nrm2 := _perp(pts, n2 - 1)
		_sign_anchors.append({
			"road_id": seg.road_id,
			"kind": "speed_limit",
			"value_kmh": def.speed_limit_kmh,
			"position": Vector3((pts[n2 - 1] as Vector2).x + nrm2.x * (hw + 1.0),
					elev[n2 - 1] + 0.2, (pts[n2 - 1] as Vector2).y + nrm2.y * (hw + 1.0)),
			"sector": WC.micro_id(WC.sector_of(pts[n2 - 1])),
		})
	if def.pedestrian_allowed and def.sidewalk:
		var stride: int = maxi(1, pts.size() / 4)
		for i in range(0, pts.size(), stride):
			_crossing_anchors.append({
				"road_id": seg.road_id,
				"position": Vector3((pts[i] as Vector2).x, elev[i] + 0.2,
						(pts[i] as Vector2).y),
				"sector": WC.micro_id(WC.sector_of(pts[i])),
			})
