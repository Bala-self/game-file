class_name RoadTerrainContract
extends Object
## ROAD <-> TERRAIN CONTRACT (Prompt 04, §33/§68/§79).
##
## P03 terrain is the authority. Roads never deform it at runtime. Instead
## this contract exposes:
##   * deterministic grade-capped vertical alignment (roads do not "surf"
##     the detail noise — they follow a smoothed profile);
##   * an authored corridor table (§79) that terrain_authoring may consume
##     to blend a carriageway band, so steep valley roads become drivable
##     WITHOUT hidden runtime deformation;
##   * bridge/tunnel elevation overrides so structures never inherit a
##     mountain slope (§41) and tunnel bores stay inside the rock (§18);
##   * the viability queries the generator must ask (§6):
##     is_road_viable / grade / water / cliff / protected / boundary.

const S := preload("res://scripts/roads/road_schema.gd")
const T := preload("res://scripts/world/terrain.gd")
const TA := preload("res://scripts/world/terrain_authoring.gd")
const WC := preload("res://scripts/world/world_contract.gd")

## Road surface sits this far above the resolved ground — enough to avoid
## z-fighting/burial under detail noise, small enough to read as contact.
const SURFACE_OFFSET_M := 0.12
## Vertical alignment smoothing arm (m). Long enough to average out the
## 18 m detail fbm so grade reflects the landform, not the noise.
const SMOOTH_ARM_M := 24.0
## Authored cut/fill band half-width used when a corridor needs blending.
const CORRIDOR_HALF_WIDTH_M := 14.0
## A corridor is "requested" only where the raw grade exceeds the class
## limit by more than this margin (avoid needless terrain blending).
const CORRIDOR_REQUEST_MARGIN := 1.25
## Max bridge deck grade (§42 approaches must be smooth).
const BRIDGE_DECK_MAX_GRADE := 0.055
## Tunnel: minimum rock cover between crown and terrain surface (§18/§43).
const TUNNEL_MIN_COVER_M := 6.0
const TUNNEL_HEADROOM_M := 5.2

## Result of asking the terrain whether a road point is buildable (§6).
## "reason" is stable text the tests assert on.
class Viability:
	var viable: bool = false
	var reason: String = "ok"
	var grade_pct: float = 0.0
	var height: float = 0.0
	var water_depth: float = 0.0
	var dist_to_water: float = 0.0
	var in_world: bool = true


## Ask the P03 terrain about a candidate road point for a road class.
## Returns every rejection class §6 names: invalid / grade / water /
## cliff / protected / boundary.
static func query_viability(p: Vector2, class_id: String) -> Viability:
	var v := Viability.new()
	var def: S.RoadDefinition = S.class_registry()[class_id]
	v.in_world = WC.is_playable(Vector3(p.x, 0.0, p.y))
	if not v.in_world:
		v.reason = "boundary"
		return v
	# boundary margin: legal road area is the P02 hard contract (§77/§78)
	if p.length() > WC.ROAD_LIMIT_RADIUS_M:
		v.reason = "boundary"
		return v
	v.height = T.height_at(p.x, p.y)
	v.grade_pct = T.grade_percent(p.x, p.y)
	v.dist_to_water = T.distance_to_water(p.x, p.y)
	v.water_depth = T.water_depth_at(p.x, p.y)
	if v.height < TA.SEA_LEVEL_M + 0.35:
		v.reason = "water"
		return v
	if v.dist_to_water >= 0.0 and v.dist_to_water < 3.0 and v.height < TA.SEA_LEVEL_M + 1.0:
		v.reason = "water"
		return v
	if T.coast_class_at(p.x, p.y) == "cliff" and v.grade_pct > def.max_grade_pct * 2.0:
		v.reason = "cliff"
		return v
	var constraint: String = def.terrain_constraint
	var lim: float = float(T.ROAD_GRADE_LIMITS.get(constraint, 10.0))
	if not T.is_road_viable(p.x, p.y, constraint):
		v.reason = "grade"
		return v
	# class limit is stricter than the terrain table for some classes
	if v.grade_pct > minf(def.max_grade_pct, lim):
		v.reason = "grade"
		return v
	if _protected(p):
		v.reason = "protected"
		return v
	v.viable = true
	return v


## Authored no-build areas. Kept explicit and small (§79: intentional data,
## not a hidden rule). The lake body is routed around (§17), not bridged.
static func _protected(p: Vector2) -> bool:
	var lake: Vector2 = Vector2(TA.LAKE_CENTER)
	if (p - lake).length() < TA.LAKE_RADIUS_M - 40.0:
		return true   # open lake water — roads route around it
	return false


## ------------------------------------------------------------------
## Centerline densification (deterministic Catmull-Rom, §7/§67)
## ------------------------------------------------------------------

## Centripetal Catmull-Rom through the authored control points, resampled
## at ~spacing. Deterministic; no RNG; curvature limited by the authored
## point spacing rather than by noise.
static func densify(ctrl: Array, spacing: float = 12.0) -> Array:
	var pts: Array = []
	if ctrl.size() < 2:
		return pts
	if ctrl.size() == 2:
		var a: Vector2 = ctrl[0]
		var b: Vector2 = ctrl[1]
		var n: int = maxi(2, int(ceil((b - a).length() / spacing)))
		for i in range(n + 1):
			pts.append(a.lerp(b, float(i) / float(n)))
		return pts
	var ext: Array = [ctrl[0] + (ctrl[0] - ctrl[1])]
	for c in ctrl:
		ext.append(c)
	ext.append(ctrl[ctrl.size() - 1] + (ctrl[ctrl.size() - 1] - ctrl[ctrl.size() - 2]))
	for i in range(1, ext.size() - 2):
		var p0: Vector2 = ext[i - 1]
		var p1: Vector2 = ext[i]
		var p2: Vector2 = ext[i + 1]
		var p3: Vector2 = ext[i + 2]
		var seg_len: float = (p2 - p1).length()
		var steps: int = maxi(2, int(ceil(seg_len / spacing)))
		for s in range(steps):
			var t: float = float(s) / float(steps)
			pts.append(_catmull(p0, p1, p2, p3, t))
	pts.append(ext[ext.size() - 2])
	return pts


static func _catmull(p0: Vector2, p1: Vector2, p2: Vector2, p3: Vector2, t: float) -> Vector2:
	var t2: float = t * t
	var t3: float = t2 * t
	return 0.5 * ((2.0 * p1) + (-p0 + p2) * t
			+ (2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3) * t2
			+ (-p0 + 3.0 * p1 - 3.0 * p2 + p3) * t3)


## Raw terrain elevation of a centerline point (before smoothing).
static func raw_ground(p: Vector2) -> float:
	return T.height_at(p.x, p.y)


## Smoothed ground elevation used for vertical alignment (§68): average of
## the terrain over a +/-SMOOT arm, so the road follows the landform.
static func smoothed_ground(p: Vector2, tangent: Vector2) -> float:
	var n := Vector2(-tangent.y, tangent.x)
	var acc: float = 0.0
	var wsum: float = 0.0
	for i in range(-2, 3):
		var off: Vector2 = p + tangent * (float(i) * SMOOTH_ARM_M * 0.5)
		var w: float = 1.0 - absf(float(i)) * 0.2
		acc += T.height_at(off.x, off.y) * w
		wsum += w
	for i in range(-1, 2):
		var off2: Vector2 = p + n * (float(i) * 6.0)
		acc += T.height_at(off2.x, off2.y)
		wsum += 1.0
	return acc / wsum


## Grade-capped vertical alignment. Walks the polyline forward and back,
## clamping elevation change to max_grade — this is what keeps a road
## legal on a slope without flattening the world (§68, §79).
## Returns PackedFloat64Array of elevations, one per point.
static func vertical_alignment(pts: Array, max_grade_frac: float) -> PackedFloat64Array:
	var n: int = pts.size()
	var elev := PackedFloat64Array()
	elev.resize(n)
	if n == 0:
		return elev
	for i in range(n):
		var p: Vector2 = pts[i]
		var tan := Vector2(1, 0)
		if i > 0 and i < n - 1:
			tan = ((pts[i + 1] - pts[i - 1]) as Vector2).normalized()
		elif i > 0:
			tan = ((pts[i] - pts[i - 1]) as Vector2).normalized()
		else:
			tan = ((pts[1] - pts[0]) as Vector2).normalized()
		elev[i] = smoothed_ground(p, tan)
	# forward pass
	for i in range(1, n):
		var d: float = ((pts[i] - pts[i - 1]) as Vector2).length()
		var maxd: float = d * max_grade_frac
		elev[i] = clampf(elev[i], elev[i - 1] - maxd, elev[i - 1] + maxd)
	# backward pass (keeps both directions legal)
	for i in range(n - 2, -1, -1):
		var d2: float = ((pts[i + 1] - pts[i]) as Vector2).length()
		var maxd2: float = d2 * max_grade_frac
		elev[i] = clampf(elev[i], elev[i + 1] - maxd2, elev[i + 1] + maxd2)
	return elev


## Design grade (%) between consecutive aligned points.
static func design_grade_pct(pts: Array, elev: PackedFloat64Array, i: int) -> float:
	if i <= 0 or i >= pts.size():
		return 0.0
	var d: float = ((pts[i] - pts[i - 1]) as Vector2).length()
	if d < 0.001:
		return 0.0
	return absf(elev[i] - elev[i - 1]) / d * 100.0


## ------------------------------------------------------------------
## Structures (§41/§42/§18)
## ------------------------------------------------------------------

## Bridge deck elevation over an anchor: water level + navigation
## clearance, but never below the approach road, and never steeper than
## BRIDGE_DECK_MAX_GRADE relative to the road it serves.
static func bridge_deck_elevation(anchor: Vector2, clearance_m: float,
		approach_elev: float) -> float:
	var wl: float = T.water_level_at(anchor.x, anchor.y)
	if wl <= TA.SEA_LEVEL_M - 0.05:
		wl = TA.SEA_LEVEL_M
	return maxf(wl + clearance_m, approach_elev)


## Bridge span range (index range along a densified centerline) covering
## the anchor +/- span/2, measured by arc length.
static func bridge_span_range(pts: Array, anchor: Vector2, span_m: float) -> Vector2i:
	var lo: int = -1
	var hi: int = -1
	var best: float = 1e9
	for i in range(pts.size()):
		var d: float = ((pts[i] as Vector2) - anchor).length()
		if d < best:
			best = d
			lo = i
	if lo < 0:
		return Vector2i(-1, -1)
	hi = lo
	var half: float = span_m * 0.5
	var j: int = lo
	while j > 0 and _arc_back(pts, lo, j) < half:
		j -= 1
	var start: int = j
	j = lo
	while j < pts.size() - 1 and _arc_fwd(pts, lo, j) < half:
		j += 1
	var endi: int = j
	return Vector2i(start, endi)


static func _arc_back(pts: Array, a: int, b: int) -> float:
	var s: float = 0.0
	for i in range(b, a):
		s += ((pts[i + 1] - pts[i]) as Vector2).length()
	return s


static func _arc_fwd(pts: Array, a: int, b: int) -> float:
	var s: float = 0.0
	for i in range(a, b):
		s += ((pts[i + 1] - pts[i]) as Vector2).length()
	return s


## Water clearance actually achieved under a deck (for gate 39).
static func bridge_clearance(anchor: Vector2, deck_y: float) -> float:
	var wl: float = T.water_level_at(anchor.x, anchor.y)
	if wl <= TA.SEA_LEVEL_M - 0.05:
		wl = TA.SEA_LEVEL_M
	return deck_y - wl


## Tunnel: crown elevation must stay at least TUNNEL_MIN_COVER_M under the
## terrain, and the deck must leave TUNNEL_HEADROOM_M. Returns the required
## deck elevation ceiling for a point, or NAN where a tunnel is not valid.
static func tunnel_max_deck(p: Vector2) -> float:
	var ground: float = T.height_at(p.x, p.y)
	return ground - TUNNEL_MIN_COVER_M


static func tunnel_is_valid(p: Vector2, deck_y: float) -> bool:
	return deck_y + TUNNEL_HEADROOM_M <= T.height_at(p.x, p.y)


## ------------------------------------------------------------------
## Authored corridor table (§79)
## ------------------------------------------------------------------
## Corridors are declared as DATA. The road builder publishes them; the
## terrain system may consume them at authoring time to blend a band.
## Nothing here deforms terrain at runtime.
class Corridor:
	var road_id: String = ""
	var centerline: Array = []
	var half_width_m: float = CORRIDOR_HALF_WIDTH_M
	var blend_m: float = 18.0
	var reason: String = ""


## Corridors that need terrain blending: derived deterministically by
## probing the authored centerlines against the terrain, so the table is a
## consequence of the design rather than a hand-waved list.
static func required_corridors(roads: Array) -> Array:
	var out: Array = []
	for rec in roads:
		var def: S.RoadDefinition = S.class_registry()[rec.class_id]
		if def.terrain_constraint == "freeway":
			continue   # freeways must find their own ground (§10)
		var pts: Array = densify(rec.centerline, 20.0)
		var worst: float = 0.0
		for p in pts:
			var g: float = T.grade_percent((p as Vector2).x, (p as Vector2).y)
			worst = maxf(worst, g)
		var lim: float = minf(def.max_grade_pct,
				float(T.ROAD_GRADE_LIMITS.get(def.terrain_constraint, 10.0)))
		if worst > lim * CORRIDOR_REQUEST_MARGIN:
			var c := Corridor.new()
			c.road_id = rec.id
			c.centerline = rec.centerline
			c.reason = "raw grade %.1f%% exceeds %s limit %.1f%%" % [worst, rec.class_id, lim]
			out.append(c)
	return out
