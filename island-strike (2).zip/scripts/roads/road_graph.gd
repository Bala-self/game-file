class_name RoadGraph
extends Object
## ROAD GRAPH (§20/§21/§24/§49/§51/§52).
##
## The logical network, built from RoadData + RoadSchema. Deliberately free
## of Node3D objects (§73): a route can be computed with zero road geometry
## loaded, which is what makes the graph cheap to keep resident while road
## meshes stream.
##
## Layers exposed here:
##   * segments  — centerline pieces with class, elevation, sector/district
##   * junctions — welded nodes with control type + turn rules
##   * lanes     — directed lane polylines with next/previous links
##   * structures— bridges, tunnels, overpasses, roundabouts
##   * routing   — Dijkstra over the lane graph with a static cost model
##
## Determinism (§57): everything derives from authored data + terrain.
## No RNG, no dictionary iteration order in emitted IDs.

const S := preload("res://scripts/roads/road_schema.gd")
const D := preload("res://scripts/roads/road_data.gd")
const C := preload("res://scripts/roads/road_terrain_contract.gd")
const T := preload("res://scripts/world/terrain.gd")
const WC := preload("res://scripts/world/world_contract.gd")
const WSR := preload("res://scripts/world/world_sector_registry.gd")

## Junction welding tolerance. Authored roads share exact coordinates at
## intended junctions; this only absorbs resampling error.
const WELD_M := 12.0
## Two centerlines crossing closer than this are the same junction.
const CROSS_SNAP_M := 8.0
## Centerline sampling for graph/geometry work.
const SAMPLE_M := 10.0
## A lane turn is legal if the deflection is under this (no U-turns).
const UTURN_MIN_DEG := 120.0

# ---------------------------------------------------------------- types

class Segment:
	var id: String = ""
	var road_id: String = ""
	var class_id: String = ""
	var points: Array = []            # Vector2 XZ, ordered
	var elev: PackedFloat64Array = PackedFloat64Array()
	var start_node_id: String = ""
	var end_node_id: String = ""
	var length_m: float = 0.0
	var grade_profile: PackedFloat64Array = PackedFloat64Array()
	var curvature_profile: PackedFloat64Array = PackedFloat64Array()
	var max_grade_pct: float = 0.0
	var avg_grade_pct: float = 0.0
	var bridge_id: String = ""
	var tunnel_id: String = ""
	var one_way: bool = false
	var direction_sign: float = 1.0
	var restricted: bool = false
	var emergency_only: bool = false
	var intentional_dead_end: bool = false
	var sector_ids: Array = []
	var district_ids: Array = []
	var dominant_district: String = ""
	var route_priority: int = 3
	var is_legacy: bool = false


class Junction:
	var id: String = ""
	var position: Vector2 = Vector2.ZERO
	var elevation: float = 0.0
	var connected_road_ids: Array = []
	var connected_segment_ids: Array = []
	var type: String = S.JCT_T_JUNCTION
	var control_type: String = "uncontrolled"
	var turn_rules: Dictionary = {}     # from_road_id -> Array of to_road_id
	var signal_id: String = ""
	var roundabout_id: String = ""
	var pedestrian_crossings: Array = []
	var sector_id: String = ""
	var district_id: String = ""
	var grade_separated_over: String = ""


class Lane:
	var id: String = ""
	var road_id: String = ""
	var segment_id: String = ""
	var direction: int = 1            # +1 with point order, -1 against
	var index: int = 0                # lane index within its carriageway
	var points: Array = []            # Vector2, in travel direction
	var elev: PackedFloat64Array = PackedFloat64Array()
	var width_m: float = 3.5
	var speed_limit_kmh: float = 50.0
	var start_node_id: String = ""
	var end_node_id: String = ""
	var allowed_turns: Array = []     # turn keys at the end node
	var next_lane_ids: Array = []
	var previous_lane_ids: Array = []
	var sector_ids: Array = []
	var vehicle_classes: Array = ["car", "van", "truck"]
	var pedestrian_crossing_links: Array = []
	var restricted: bool = false


class Bridge:
	var id: String = ""
	var road_id: String = ""
	var segment_id: String = ""
	var start_index: int = -1
	var end_index: int = -1
	var anchor: Vector2 = Vector2.ZERO
	var start: Vector2 = Vector2.ZERO
	var end_pos: Vector2 = Vector2.ZERO
	var length_m: float = 0.0
	var deck_height: float = 0.0
	var lane_count: int = 2
	var foundation_points: Array = []
	var approach_segments: Array = []
	var water_clearance_m: float = 0.0
	var sector_ids: Array = []
	var lod_profile: String = "landmark"


class Tunnel:
	var id: String = ""
	var road_id: String = ""
	var segment_id: String = ""
	var start_index: int = -1
	var end_index: int = -1
	var entrance: Vector2 = Vector2.ZERO
	var exit_pos: Vector2 = Vector2.ZERO
	var length_m: float = 0.0
	var lane_count: int = 2
	var lighting_profile: String = "tunnel_standard"
	var ventilation_profile: String = "natural_placeholder"
	var sector_ids: Array = []
	var interior_streaming_rule: String = "always_active_when_road_active"
	var cover_ok: bool = true


class Route:
	var success: bool = false
	var reason: String = ""
	var start_node: String = ""
	var target_node: String = ""
	var road_ids: Array = []
	var lane_ids: Array = []
	var junction_ids: Array = []
	var distance_m: float = 0.0
	var estimated_time_s: float = 0.0
	var cost: float = 0.0
	var waypoints: Array = []          # Vector3 world positions
	var turn_instructions_placeholder: Array = []
	var route_revision: String = S.ROAD_REVISION
	var bridges_used: Array = []
	var tunnels_used: Array = []
	var alternative: Route = null
	## Distance from the route end point to the requested goal when the goal
	## was not on a road (-1 when the goal was on a road).
	var goal_walk_off_m: float = -1.0
	## Distance from the requested start to the nearest lane when the start
	## was not on a road (-1 when it was).
	var start_walk_off_m: float = -1.0

	func to_dict() -> Dictionary:
		return {
			"success": success, "reason": reason, "start_node": start_node,
			"target_node": target_node, "road_ids": road_ids,
			"lane_ids": lane_ids, "junction_ids": junction_ids,
			"distance_m": distance_m, "estimated_time_s": estimated_time_s,
			"cost": cost, "route_revision": route_revision,
			"bridges_used": bridges_used, "tunnels_used": tunnels_used,
			"waypoint_count": waypoints.size(),
		}


# ---------------------------------------------------------------- state

static var _built := false
static var _segments: Array = []
static var _junctions: Array = []
static var _lanes: Array = []
static var _bridges: Array = []
static var _tunnels: Array = []
static var _overpasses: Array = []
static var _roundabouts: Array = []
static var _seg_by_id: Dictionary = {}
static var _jct_by_id: Dictionary = {}
static var _lane_by_id: Dictionary = {}
static var _segments_by_sector: Dictionary = {}
static var _junctions_by_sector: Dictionary = {}
static var _lanes_by_sector: Dictionary = {}
static var _bridges_by_sector: Dictionary = {}
static var _tunnels_by_sector: Dictionary = {}
static var _roads_by_id: Dictionary = {}
static var _metrics: Dictionary = {}


static func reset() -> void:
	_built = false
	_segments.clear(); _junctions.clear(); _lanes.clear()
	_bridges.clear(); _tunnels.clear(); _overpasses.clear(); _roundabouts.clear()
	_seg_by_id.clear(); _jct_by_id.clear(); _lane_by_id.clear(); _jct_grid.clear()
	_segments_by_sector.clear(); _junctions_by_sector.clear()
	_lanes_by_sector.clear(); _bridges_by_sector.clear(); _tunnels_by_sector.clear()
	_roads_by_id.clear(); _metrics.clear()


# ---------------------------------------------------------------- build

static func build() -> void:
	if _built:
		return
	reset()
	_roads_by_id = D.roads_by_id()
	var polys: Dictionary = _densify_and_align()
	var splits: Dictionary = _find_splits(polys)
	_build_segments(polys, splits)
	_build_junctions()
	_build_lanes()
	# set the flag BEFORE metrics: connected_components() (called from
	# metrics) re-enters build(); without this the recursion never ends
	_built = true
	_build_structures()
	_index_sectors()
	_compute_metrics()


## Phase 1: densify every authored centerline and compute its vertical
## alignment ONCE per road (so elevation is continuous across the splits
## that junctions introduce later).
static func _densify_and_align() -> Dictionary:
	var out: Dictionary = {}
	var order: Array = _roads_by_id.keys()
	order.sort()
	for rid: String in order:
		var rec: D.RoadRecord = _roads_by_id[rid]
		var def: S.RoadDefinition = S.class_registry()[rec.class_id]
		var pts: Array = C.densify(rec.centerline, SAMPLE_M)
		if pts.size() < 2:
			continue
		var elev: PackedFloat64Array = C.vertical_alignment(pts, def.max_grade_pct / 100.0)
		out[rid] = {"pts": pts, "elev": elev}
	return out


## Phase 2: find interior split indices per road.
## Two sources, because a junction exists wherever two roads meet:
##   * genuine crossings (centerlines intersect mid-span);
##   * junctions authored as a shared coordinate that lands mid-span on the
##     OTHER road (a spur meeting a through road) — without this the through
##     road keeps driving straight past the junction and the spur is left
##     dangling, which is what fragments the graph.
static func _find_splits(polys: Dictionary) -> Dictionary:
	var splits: Dictionary = {}
	var ids: Array = polys.keys()
	ids.sort()
	for rid: String in ids:
		splits[rid] = {}
	var coarse: Dictionary = {}
	var bounds: Dictionary = {}
	for rid2: String in ids:
		var pts: Array = polys[rid2]["pts"]
		var dec: Array = []
		for k in range(0, pts.size(), 4):
			dec.append(pts[k])
		dec.append(pts[pts.size() - 1])
		coarse[rid2] = dec
		bounds[rid2] = _bounds(pts)
	# (a) endpoint of one road landing on the interior of another
	for rid3: String in ids:
		var pts3: Array = polys[rid3]["pts"]
		for endp_v in [pts3[0], pts3[pts3.size() - 1]]:
			var endp: Vector2 = endp_v
			for rid4: String in ids:
				if rid4 == rid3:
					continue
				if not (bounds[rid4] as Rect2).has_point(endp):
					continue
				var pts4: Array = polys[rid4]["pts"]
				var idx: int = _nearest_index(pts4, endp)
				if idx <= 1 or idx >= pts4.size() - 2:
					continue   # near an end -> endpoint welding handles it
				if ((pts4[idx] as Vector2) - endp).length() > WELD_M:
					continue
				splits[rid4][idx] = true
	# (b) true mid-span crossings (coarse-to-fine; the naive dense all-pairs
	#     scan is ~70M segment tests and takes minutes)
	for i in range(ids.size()):
		for j in range(i + 1, ids.size()):
			var ida: String = ids[i]
			var idb: String = ids[j]
			if not (bounds[ida] as Rect2).intersects(bounds[idb] as Rect2):
				continue
			var hit := _first_crossing_pts(coarse[ida], coarse[idb], 0.02)
			if hit.x > 1e8:
				continue
			var hit2 := _first_crossing_pts(polys[ida]["pts"], polys[idb]["pts"], 0.05)
			if hit2.x > 1e8:
				continue
			var hp := Vector2(hit2.x, hit2.y)
			var ia: int = _nearest_index(polys[ida]["pts"], hp)
			var ib: int = _nearest_index(polys[idb]["pts"], hp)
			if ia > 1 and ia < polys[ida]["pts"].size() - 2:
				splits[ida][ia] = true
			if ib > 1 and ib < polys[idb]["pts"].size() - 2:
				splits[idb][ib] = true
	return splits


## Phase 3: emit segments, splitting each road at its interior junctions so
## every crossing becomes a real graph node with turn options (§20/§21).
static func _build_segments(polys: Dictionary, splits: Dictionary) -> void:
	var ids: Array = polys.keys()
	ids.sort()
	for rid: String in ids:
		var rec: D.RoadRecord = _roads_by_id[rid]
		var pts: Array = polys[rid]["pts"]
		var elev: PackedFloat64Array = polys[rid]["elev"]
		var cuts: Array = splits[rid].keys()
		cuts.sort()
		var bounds_idx: Array = [0] + cuts + [pts.size() - 1]
		for si in range(bounds_idx.size() - 1):
			var a: int = bounds_idx[si]
			var b: int = bounds_idx[si + 1]
			if b <= a:
				continue
			var seg := Segment.new()
			seg.id = "%s.S%d" % [rid, si]
			seg.road_id = rid
			seg.class_id = rec.class_id
			seg.points = pts.slice(a, b + 1)
			seg.elev = elev.slice(a, b + 1)
			seg.one_way = rec.one_way
			seg.direction_sign = rec.direction_sign
			seg.restricted = rec.restricted
			seg.emergency_only = rec.emergency_only
			seg.intentional_dead_end = rec.intentional_dead_end
			seg.route_priority = rec.route_priority
			seg.is_legacy = rid.begins_with("LEG_")
			seg.length_m = _polyline_length(seg.points)
			seg.grade_profile = _grade_profile(seg.points, seg.elev)
			seg.curvature_profile = _curvature_profile(seg.points)
			seg.max_grade_pct = _max_of(seg.grade_profile)
			seg.avg_grade_pct = _avg_of(seg.grade_profile)
			seg.sector_ids = _sectors_of(seg.points)
			seg.district_ids = _districts_of(seg.points)
			seg.dominant_district = _dominant(seg.district_ids)
			_segments.append(seg)
			_seg_by_id[seg.id] = seg


## Phase 4: junction nodes at every segment endpoint (welded).
static func _build_junctions() -> void:
	for seg: Segment in _segments:
		seg.start_node_id = _junction_at(seg.points[0], seg)
		seg.end_node_id = _junction_at(seg.points[seg.points.size() - 1], seg)
	# A junction may accumulate roads/segments as later endpoints weld onto
	# it, so classification runs once every endpoint is registered.
	for jn: Junction in _junctions:
		jn.connected_road_ids.sort()
		jn.connected_segment_ids.sort()
		_classify_junction(jn)


const JCT_CELL_M := 64.0
static var _jct_grid: Dictionary = {}


static func _jct_cell(p: Vector2) -> Vector2i:
	return Vector2i(int(floor(p.x / JCT_CELL_M)), int(floor(p.y / JCT_CELL_M)))


## Junction lookup on a coarse grid: exact shared coordinates (the authored
## convention) plus a weld tolerance for resampling error. Deterministic —
## candidates are sorted by id before the tolerance test.
static func _junction_at(p: Vector2, seg: Segment) -> String:
	var c := _jct_cell(p)
	var candidates: Array = []
	for dx in range(-1, 2):
		for dy in range(-1, 2):
			var key := Vector2i(c.x + dx, c.y + dy)
			if _jct_grid.has(key):
				for jid: String in _jct_grid[key]:
					candidates.append(jid)
	candidates.sort()
	for jid: String in candidates:
		var jn: Junction = _jct_by_id[jid]
		if jn.position.distance_to(p) <= WELD_M:
			if seg.road_id not in jn.connected_road_ids:
				jn.connected_road_ids.append(seg.road_id)
			if seg.id not in jn.connected_segment_ids:
				jn.connected_segment_ids.append(seg.id)
			return jn.id
	var jn2 := Junction.new()
	jn2.id = "JCT_%03d" % _junctions.size()
	jn2.position = p
	jn2.elevation = T.height_at(p.x, p.y)
	jn2.connected_road_ids = [seg.road_id]
	jn2.connected_segment_ids = [seg.id]
	jn2.sector_id = WC.micro_id(WC.sector_of(p))
	jn2.district_id = WSR.district_at_xz(p)
	_junctions.append(jn2)
	_jct_by_id[jn2.id] = jn2
	var ck := _jct_cell(p)
	if not _jct_grid.has(ck):
		_jct_grid[ck] = []
	_jct_grid[ck].append(jn2.id)
	return jn2.id


static func _first_crossing_pts(pa: Array, pb: Array, margin: float) -> Vector2:
	var hi: float = 1.0 - margin
	for i in range(pa.size() - 1):
		var a1: Vector2 = pa[i]
		var a2: Vector2 = pa[i + 1]
		for j in range(pb.size() - 1):
			var x := _seg_intersect_m(a1, a2, pb[j], pb[j + 1], margin, hi)
			if x.x < 1e8:
				return x
	return Vector2(1e9, 1e9)


static func _seg_intersect_m(p1: Vector2, p2: Vector2, p3: Vector2, p4: Vector2,
		lo: float, hi: float) -> Vector2:
	var d1: Vector2 = p2 - p1
	var d2: Vector2 = p4 - p3
	var denom: float = d1.x * d2.y - d1.y * d2.x
	if absf(denom) < 1e-9:
		return Vector2(1e9, 1e9)
	var t: float = ((p3.x - p1.x) * d2.y - (p3.y - p1.y) * d2.x) / denom
	var u: float = ((p3.x - p1.x) * d1.y - (p3.y - p1.y) * d1.x) / denom
	# ends are handled by endpoint welding
	if t < lo or t > hi or u < lo or u > hi:
		return Vector2(1e9, 1e9)
	return p1 + d1 * t


static func _bounds(pts: Array) -> Rect2:
	var mn := Vector2(1e9, 1e9)
	var mx := Vector2(-1e9, -1e9)
	for p: Vector2 in pts:
		mn.x = minf(mn.x, p.x); mn.y = minf(mn.y, p.y)
		mx.x = maxf(mx.x, p.x); mx.y = maxf(mx.y, p.y)
	return Rect2(mn, mx - mn)


## Junction type + control (§20). Derived from the classes that meet, the
## authored structures, and the migrated legacy signal positions (§36).
static func _classify_junction(jn: Junction) -> void:
	var classes: Array = []
	for rid: String in jn.connected_road_ids:
		var rec: D.RoadRecord = _roads_by_id[rid]
		if rec != null:
			classes.append(rec.class_id)
	var n: int = jn.connected_road_ids.size()
	# roundabout?
	for rb: Dictionary in D.ROUNDABOUTS:
		if jn.position.distance_to(Vector2(rb["position"])) < 12.0:
			jn.type = S.JCT_ROUNDABOUT
			jn.roundabout_id = str(rb["id"])
			jn.control_type = "yield_on_entry"
			return
	# overpass?
	for ov: Dictionary in D.OVERPASSES:
		if jn.position.distance_to(Vector2(ov["position"])) < 20.0:
			jn.type = S.JCT_GRADE_SEPARATED
			jn.grade_separated_over = str(ov["over_road_id"])
			jn.control_type = "none"
			return
	# ramp / merge / fork
	if S.CLASS_RAMP in classes:
		jn.type = S.JCT_FREEWAY_RAMP if n <= 2 else S.JCT_MERGE
		jn.control_type = "merge"
		return
	if S.CLASS_FREEWAY in classes:
		jn.type = S.JCT_MERGE if n <= 2 else S.JCT_FORK
		jn.control_type = "merge"
		return
	# legacy signal positions migrate onto the new graph (§36)
	for k in range(K_traffic_light_count()):
		var lp: Vector2 = K_traffic_light(k)
		if jn.position.distance_to(lp) < 14.0:
			jn.type = S.JCT_CROSS if n >= 4 else S.JCT_T_JUNCTION
			jn.control_type = "signal"
			jn.signal_id = "SIG_%02d" % k
			return
	# major arterial crossings get signals (§11: not every 50 m)
	var majors: int = 0
	for c: String in classes:
		if c in [S.CLASS_PRIMARY_ARTERIAL, S.CLASS_SECONDARY_ARTERIAL]:
			majors += 1
	if n >= 3 and majors >= 2:
		jn.type = S.JCT_CROSS if n >= 4 else S.JCT_T_JUNCTION
		jn.control_type = "signal"
		jn.signal_id = "SIG_NEW_%s" % jn.id
		return
	if n >= 4:
		jn.type = S.JCT_CROSS
	elif n == 3:
		jn.type = S.JCT_T_JUNCTION
	elif n == 2:
		jn.type = S.JCT_CROSS
	else:
		jn.type = S.JCT_DRIVEWAY_ACCESS
	# stop/yield: lower class gives way (§37)
	if _has_priority_spread(classes):
		jn.control_type = "stop_minor"
	else:
		jn.control_type = "yield"


static var _tl_cache: Array = []
static func K_traffic_light_count() -> int:
	_tl_ensure()
	return _tl_cache.size()
static func K_traffic_light(i: int) -> Vector2:
	_tl_ensure()
	return _tl_cache[i]
static func _tl_ensure() -> void:
	if not _tl_cache.is_empty():
		return
	var K := load("res://scripts/world/wb_kit.gd")
	for tl: Vector2 in K.TRAFFIC_LIGHTS:
		_tl_cache.append(tl)


static func _has_priority_spread(classes: Array) -> bool:
	var best: int = 99
	var worst: int = -1
	for c: String in classes:
		var rank: int = _class_rank(c)
		best = mini(best, rank)
		worst = maxi(worst, rank)
	return worst - best >= 2


## Lower = higher priority. Used for turn rules and stop/yield assignment.
static func _class_rank(class_id: String) -> int:
	match class_id:
		S.CLASS_FREEWAY: return 0
		S.CLASS_RAMP: return 1
		S.CLASS_PRIMARY_ARTERIAL: return 2
		S.CLASS_SECONDARY_ARTERIAL, S.CLASS_RURAL_ARTERIAL: return 3
		S.CLASS_URBAN_COLLECTOR, S.CLASS_INDUSTRIAL, S.CLASS_COASTAL, \
		S.CLASS_BRIDGE, S.CLASS_TUNNEL, S.CLASS_FRONTAGE: return 4
		S.CLASS_RURAL_COLLECTOR, S.CLASS_RESIDENTIAL, S.CLASS_MOUNTAIN: return 5
		S.CLASS_SERVICE, S.CLASS_PARK_ACCESS, S.CLASS_FARM: return 6
		S.CLASS_ALLEY, S.CLASS_DIRT: return 7
	return 5


## Lane graph (§21). Each segment yields one lane chain per allowed
## direction; lanes link through junctions with turn rules applied.
static func _build_lanes() -> void:
	for seg: Segment in _segments:
		var def: S.RoadDefinition = S.class_registry()[seg.class_id]
		var dirs: Array = [1.0] if seg.one_way else [1.0, -1.0]
		if seg.one_way and seg.direction_sign < 0.0:
			dirs = [-1.0]
		for d: float in dirs:
			for li in range(def.lanes_per_direction):
				var lane := Lane.new()
				lane.id = "%s.%s.L%d.%s" % [seg.road_id, seg.id.split(".")[1], li,
						"F" if d > 0.0 else "B"]
				lane.road_id = seg.road_id
				lane.segment_id = seg.id
				lane.direction = int(d)
				lane.index = li
				lane.width_m = def.lane_width
				lane.speed_limit_kmh = def.speed_limit_kmh
				lane.restricted = seg.restricted
				lane.sector_ids = seg.sector_ids
				if d > 0.0:
					lane.points = seg.points.duplicate()
					lane.elev = seg.elev.duplicate()
					lane.start_node_id = seg.start_node_id
					lane.end_node_id = seg.end_node_id
				else:
					var rp: Array = seg.points.duplicate()
					rp.reverse()
					lane.points = rp
					var re: PackedFloat64Array = seg.elev.duplicate()
					re.reverse()
					lane.elev = re
					lane.start_node_id = seg.end_node_id
					lane.end_node_id = seg.start_node_id
				if not def.traffic_allowed:
					lane.vehicle_classes = []
				_lanes.append(lane)
				_lane_by_id[lane.id] = lane
	# junction turn links
	for jn: Junction in _junctions:
		var incoming: Array = []
		var outgoing: Array = []
		for lane: Lane in _lanes:
			if lane.end_node_id == jn.id:
				incoming.append(lane)
			if lane.start_node_id == jn.id:
				outgoing.append(lane)
		for inc: Lane in incoming:
			var inc_def: S.RoadDefinition = S.class_registry()[_seg_by_id[inc.segment_id].class_id]
			for out: Lane in outgoing:
				# Same-road pairs are refused by _turn_allowed unless this is a
				# terminus turnaround, so they must reach the rule — filtering
				# them here would silently disconnect every end-of-road join.
				var out_def: S.RoadDefinition = S.class_registry()[_seg_by_id[out.segment_id].class_id]
				if not _turn_allowed(inc, out, inc_def, out_def, jn):
					continue
				inc.next_lane_ids.append(out.id)
				out.previous_lane_ids.append(inc.id)
				inc.allowed_turns.append("%s->%s" % [out.road_id, out.id])
	# dead-end lanes get no next; that is intentional and marked
	for lane: Lane in _lanes:
		lane.allowed_turns.sort()
		lane.next_lane_ids.sort()
		lane.previous_lane_ids.sort()


static func _turn_allowed(inc: Lane, out: Lane, inc_def: S.RoadDefinition,
		out_def: S.RoadDefinition, jn: Junction) -> bool:
	# A through movement on the same road is never a turn: the junction just
	# splits the road into segments. Testing on segment identity alone is not
	# enough, because a junction splits a road into two segments — the guard
	# has to be "same road", otherwise every ramp junction severs the
	# carriageway it belongs to.
	if inc.road_id == out.road_id:
		if inc.segment_id != out.segment_id:
			return true
		# Two directions of the same segment at the same node is a U-turn.
		# It is offered when traffic has nowhere else to go: either the road
		# ends at this junction, or this segment is one-way so the opposite
		# direction is the only exit. Refusing it there strands the whole
		# branch — a freeway terminus is exactly this case.
		if _segment_is_road_end(inc.segment_id, jn):
			return true
		return _seg_by_id[inc.segment_id].one_way
	# Limited access (§10). Ramps are the only way on or off a freeway, and
	# two ramps never join each other.
	if inc_def.id == S.CLASS_RAMP and out_def.id == S.CLASS_RAMP:
		return false
	if out_def.id == S.CLASS_FREEWAY and inc_def.id != S.CLASS_RAMP:
		return false
	if inc_def.id == S.CLASS_FREEWAY and out_def.id != S.CLASS_RAMP:
		return false
	return true


static func _segment_is_road_end(segment_id: String, jn: Junction) -> bool:
	var seg: Segment = _seg_by_id[segment_id]
	for other: Segment in _segments:
		if other.road_id != seg.road_id or other.id == seg.id:
			continue
		if other.start_node_id == jn.id or other.end_node_id == jn.id:
			return false
	return true


static func _reversal(inc: Lane, out: Lane) -> bool:
	var a: Vector2 = _end_heading(inc)
	var b: Vector2 = _start_heading(out)
	return a.dot(b) < -0.6


static func _end_heading(lane: Lane) -> Vector2:
	var n: int = lane.points.size()
	return ((lane.points[n - 1] - lane.points[maxi(0, n - 3)]) as Vector2).normalized()


static func _start_heading(lane: Lane) -> Vector2:
	var n: int = lane.points.size()
	return ((lane.points[mini(n - 1, 2)] - lane.points[0]) as Vector2).normalized()


## Bridges / tunnels attached to their authored roads (§41/§18).
static func _build_structures() -> void:
	for b: Dictionary in D.BRIDGES:
		var rec: D.RoadRecord = _roads_by_id.get(str(b["road_id"]))
		if rec == null:
			push_warning("RoadGraph: bridge %s references unknown road" % str(b["id"]))
			continue
		var seg: Segment = _segment_nearest(rec.id, b["anchor"])
		if seg == null:
			continue
		var anchor: Vector2 = b["anchor"]
		var span: Vector2i = C.bridge_span_range(seg.points, anchor, float(b["span_m"]))
		if span.x < 0:
			continue
		var br := Bridge.new()
		br.id = str(b["id"])
		br.road_id = rec.id
		br.segment_id = seg.id
		br.start_index = span.x
		br.end_index = span.y
		br.anchor = anchor
		br.start = seg.points[span.x]
		br.end_pos = seg.points[span.y]
		br.length_m = _index_span_length(seg.points, span.x, span.y)
		br.lane_count = int(S.class_registry()[seg.class_id].lane_count)
		var approach: float = maxf(seg.elev[maxi(0, span.x - 1)],
				seg.elev[mini(seg.elev.size() - 1, span.y + 1)])
		br.deck_height = C.bridge_deck_elevation(anchor, float(b["water_clearance_m"]), approach)
		br.water_clearance_m = C.bridge_clearance(anchor, br.deck_height)
		br.foundation_points = _foundation_points(seg, span)
		br.approach_segments = [seg.id]
		br.sector_ids = _sectors_of_points([br.start, br.end_pos])
		# the deck overrides terrain elevation along the whole road, across
		# segment splits, with an adaptive grade-legal ramp at each end
		_apply_bridge_deck(rec.id, anchor, float(b["span_m"]), br.deck_height)
		_bridges.append(br)
	for t: Dictionary in D.TUNNELS:
		var rec2: D.RoadRecord = _roads_by_id.get(str(t["road_id"]))
		if rec2 == null:
			continue
		var seg2: Segment = _segment_nearest(rec2.id, t["entrance"])
		if seg2 == null:
			continue
		var tn := Tunnel.new()
		tn.id = str(t["id"])
		tn.road_id = rec2.id
		tn.segment_id = seg2.id
		tn.entrance = t["entrance"]
		tn.exit_pos = t["exit"]
		var si: Vector2i = _index_range_between(seg2.points, tn.entrance, tn.exit_pos)
		tn.start_index = si.x
		tn.end_index = si.y
		tn.length_m = _index_span_length(seg2.points, si.x, si.y)
		tn.lane_count = int(S.class_registry()[seg2.class_id].lane_count)
		tn.lighting_profile = str(t["lighting_profile"])
		tn.ventilation_profile = str(t["ventilation_profile"])
		tn.interior_streaming_rule = str(t["interior_streaming_rule"])
		tn.sector_ids = _sectors_of_points([tn.entrance, tn.exit_pos])
		tn.cover_ok = _tunnel_cover_ok(seg2, si)
		_tunnels.append(tn)
	for ov: Dictionary in D.OVERPASSES:
		_overpasses.append(ov.duplicate())
	for rb: Dictionary in D.ROUNDABOUTS:
		_roundabouts.append(rb.duplicate())
	# cross-reference from segments
	for br2: Bridge in _bridges:
		var s2: Segment = _seg_by_id[br2.segment_id]
		s2.bridge_id = br2.id
	for tn2: Tunnel in _tunnels:
		var s3: Segment = _seg_by_id[tn2.segment_id]
		s3.tunnel_id = tn2.id


static func _segment_nearest(road_id: String, p: Vector2) -> Segment:
	var best: Segment = null
	var bd: float = 1e9
	for sg: Segment in _segments:
		if sg.road_id != road_id:
			continue
		var d: float = 1e9
		for pt: Vector2 in sg.points:
			d = minf(d, (pt - p).length())
		if d < bd:
			bd = d
			best = sg
	return best


## Deck elevation applied along the whole road (junction splits make the
## bridge road several segments; the deck must be continuous across them).
## Ramp length adapts to the class grade limit so approaches stay legal (§42).
static func _apply_bridge_deck(road_id: String, anchor: Vector2, span_m: float,
		deck_y: float) -> void:
	var half: float = span_m * 0.5
	for sg: Segment in _segments:
		if sg.road_id != road_id:
			continue
		var def: S.RoadDefinition = S.class_registry()[sg.class_id]
		var max_g: float = maxf(0.02, def.max_grade_pct / 100.0)
		for i in range(sg.points.size()):
			var d: float = ((sg.points[i] as Vector2) - anchor).length()
			if d <= half:
				sg.elev[i] = deck_y
				continue
			var ramp_m: float = clampf(absf(deck_y - sg.elev[i]) / max_g, 40.0, 400.0)
			if d > half + ramp_m:
				continue
			var w: float = 1.0 - (d - half) / ramp_m
			sg.elev[i] = lerpf(sg.elev[i], deck_y, w)


static func _tunnel_cover_ok(seg: Segment, span: Vector2i) -> bool:
	if span.x < 0:
		return false
	# the bore must be under rock between the portals; at the portals
	# themselves the road meets the surface, so those are excluded
	for i in range(span.x + 2, span.y - 1):
		var p: Vector2 = seg.points[i]
		if seg.elev[i] + C.TUNNEL_HEADROOM_M > T.height_at(p.x, p.y) + 0.5:
			return false
	return true


static func _foundation_points(seg: Segment, span: Vector2i) -> Array:
	var out: Array = []
	var step: int = maxi(1, int((span.y - span.x) / 4))
	for i in range(span.x, span.y + 1, step):
		out.append(seg.points[i])
	out.append(seg.points[span.y])
	return out


static func _index_range_between(pts: Array, a: Vector2, b: Vector2) -> Vector2i:
	var ia: int = _nearest_index(pts, a)
	var ib: int = _nearest_index(pts, b)
	return Vector2i(mini(ia, ib), maxi(ia, ib))


static func _nearest_index(pts: Array, p: Vector2) -> int:
	var best: int = 0
	var bd: float = 1e9
	for i in range(pts.size()):
		var d: float = ((pts[i] as Vector2) - p).length_squared()
		if d < bd:
			bd = d
			best = i
	return best


static func _index_span_length(pts: Array, a: int, b: int) -> float:
	var s: float = 0.0
	for i in range(a, b):
		s += ((pts[i + 1] - pts[i]) as Vector2).length()
	return s


# ---------------------------------------------------------------- indices

static func _index_sectors() -> void:
	for seg: Segment in _segments:
		for s: String in seg.sector_ids:
			_add(_segments_by_sector, s, seg.id)
	for jn: Junction in _junctions:
		_add(_junctions_by_sector, jn.sector_id, jn.id)
	for lane: Lane in _lanes:
		for s2: String in lane.sector_ids:
			_add(_lanes_by_sector, s2, lane.id)
	for br: Bridge in _bridges:
		for s3: String in br.sector_ids:
			_add(_bridges_by_sector, s3, br.id)
	for tn: Tunnel in _tunnels:
		for s4: String in tn.sector_ids:
			_add(_tunnels_by_sector, s4, tn.id)


static func _add(d: Dictionary, k: String, v: String) -> void:
	if not d.has(k):
		d[k] = []
	if v not in d[k]:
		d[k].append(v)


static func _sectors_of(pts: Array) -> Array:
	return _sectors_of_points(pts)


static func _sectors_of_points(pts: Array) -> Array:
	var out: Array = []
	for p: Vector2 in pts:
		var id: String = WC.micro_id(WC.sector_of(p))
		if id not in out:
			out.append(id)
	out.sort()
	return out


static func _districts_of(pts: Array) -> Array:
	var out: Array = []
	var stride: int = maxi(1, pts.size() / 12)
	for i in range(0, pts.size(), stride):
		var id: String = WSR.district_at_xz(pts[i])
		if id != "" and id not in out:
			out.append(id)
	var last: String = WSR.district_at_xz(pts[pts.size() - 1])
	if last != "" and last not in out:
		out.append(last)
	out.sort()
	return out


static func _dominant(ids: Array) -> String:
	return "" if ids.is_empty() else str(ids[0])


# ---------------------------------------------------------------- helpers

static func _polyline_length(pts: Array) -> float:
	var s: float = 0.0
	for i in range(pts.size() - 1):
		s += ((pts[i + 1] - pts[i]) as Vector2).length()
	return s


static func _grade_profile(pts: Array, elev: PackedFloat64Array) -> PackedFloat64Array:
	var g := PackedFloat64Array()
	g.resize(pts.size())
	for i in range(pts.size()):
		g[i] = C.design_grade_pct(pts, elev, i) if i > 0 else 0.0
	return g


static func _curvature_profile(pts: Array) -> PackedFloat64Array:
	var k := PackedFloat64Array()
	k.resize(pts.size())
	for i in range(1, pts.size() - 1):
		var a: Vector2 = (pts[i] - pts[i - 1]).normalized()
		var b: Vector2 = (pts[i + 1] - pts[i]).normalized()
		k[i] = absf(a.angle_to(b))
	return k


static func _max_of(a: PackedFloat64Array) -> float:
	var m: float = 0.0
	for v in a:
		m = maxf(m, v)
	return m


static func _avg_of(a: PackedFloat64Array) -> float:
	if a.is_empty():
		return 0.0
	var s: float = 0.0
	for v in a:
		s += v
	return s / float(a.size())


# ---------------------------------------------------------------- queries

static func segments() -> Array:
	build()
	return _segments


static func junctions() -> Array:
	build()
	return _junctions


static func lanes() -> Array:
	build()
	return _lanes


static func bridges() -> Array:
	build()
	return _bridges


static func tunnels() -> Array:
	build()
	return _tunnels


static func overpasses() -> Array:
	build()
	return _overpasses


static func roundabouts() -> Array:
	build()
	return _roundabouts


static func segment(id: String) -> Segment:
	build()
	return _seg_by_id.get(id)


static func junction(id: String) -> Junction:
	build()
	return _jct_by_id.get(id)


static func lane(id: String) -> Lane:
	build()
	return _lane_by_id.get(id)


static func roads_in_sector(sector_id: String) -> Array:
	build()
	return _segments_by_sector.get(sector_id, [])


static func intersections_in_sector(sector_id: String) -> Array:
	build()
	return _junctions_by_sector.get(sector_id, [])


static func lane_edges_in_sector(sector_id: String) -> Array:
	build()
	return _lanes_by_sector.get(sector_id, [])


static func bridges_in_sector(sector_id: String) -> Array:
	build()
	return _bridges_by_sector.get(sector_id, [])


static func tunnels_in_sector(sector_id: String) -> Array:
	build()
	return _tunnels_by_sector.get(sector_id, [])


static func metrics() -> Dictionary:
	build()
	return _metrics


# ======================================================================
# ROUTING / GPS FOUNDATION (§24/§25/§62/§63)
# ======================================================================
## Dijkstra over the lane graph with a deterministic static cost model.
## The graph is lightweight data, so routing works with zero road geometry
## loaded (§49).

const NEAREST_LANE_SEARCH_M := 60.0
## Destinations are places, not centerlines: an airport apron, a freight
## yard, a cul-de-sac house all sit well off the road that serves them. The
## goal radius is therefore wider than the start radius — a start is where
## the vehicle already is (on a road), a goal is where the player wants to
## be (a district landmark). Beyond the hard radius the router falls back to
## the nearest lane and reports the walk-off distance instead of failing.
const GOAL_REACH_M := 150.0
const GOAL_FALLBACK_M := 900.0


static func _lane_cost(lane: Lane, profile: String) -> float:
	var seg: Segment = _seg_by_id[lane.segment_id]
	var def: S.RoadDefinition = S.class_registry()[seg.class_id]
	var factor: float = float(S.COST_CLASS_FACTOR.get(seg.class_id, 0.8))
	var bias: float = float(S.PROFILE_FACTOR_BIAS.get(profile, 1.0))
	var f_eff: float = pow(factor, bias) if bias > 0.0 else 1.0
	var cost: float = lane_length(lane) / maxf(f_eff, 0.01)
	cost += lane_length(lane) * (seg.avg_grade_pct / 100.0) * S.COST_GRADE_PENALTY
	if seg.restricted:
		cost += S.COST_EMERGENCY_RESTRICTED if profile == S.PROFILE_EMERGENCY \
				or profile == S.PROFILE_MISSION else S.COST_RESTRICTED_BLOCK
	if seg.bridge_id != "":
		cost *= 0.97
	if seg.tunnel_id != "":
		cost *= 0.98
	# junction control penalty on entering the end node
	var jn: Junction = _jct_by_id.get(lane.end_node_id)
	if jn != null:
		match jn.control_type:
			"signal": cost += S.COST_TURN_PENALTY_S
			"stop_minor": cost += S.COST_TURN_PENALTY_S * 0.7
			"yield", "yield_on_entry": cost += S.COST_TURN_PENALTY_MINOR
			"merge": cost += S.COST_TURN_PENALTY_MINOR
	return cost


static func lane_length(lane: Lane) -> float:
	return _polyline_length(lane.points)


static func _travel_time_s(lane: Lane) -> float:
	var seg: Segment = _seg_by_id[lane.segment_id]
	var def: S.RoadDefinition = S.class_registry()[seg.class_id]
	var v: float = maxf(2.8, def.speed_limit_ms() * (1.0 - seg.avg_grade_pct / 200.0))
	var t: float = lane_length(lane) / v
	var jn: Junction = _jct_by_id.get(lane.end_node_id)
	if jn != null:
		match jn.control_type:
			"signal": t += 12.0
			"stop_minor": t += 6.0
			"yield", "yield_on_entry": t += 3.0
			"merge": t += 4.0
	return t


## Nearest lane search result helper.
static func nearest_lane(pos: Vector2) -> Dictionary:
	build()
	var best := {"lane_id": "", "distance": 1e9, "point": Vector2.ZERO,
			"lane": null}
	for lane: Lane in _lanes:
		var r := _project_on_polyline(lane.points, pos)
		if r["dist"] < best["distance"]:
			best = {"lane_id": lane.id, "distance": r["dist"],
					"point": r["point"], "lane": lane, "along_m": r["along"]}
	return best


static func nearest_road(pos: Vector2) -> Dictionary:
	var nl := nearest_lane(pos)
	if nl["lane"] == null:
		return {"road_id": "", "distance": 1e9, "point": Vector2.ZERO}
	var lane: Lane = nl["lane"]
	return {"road_id": lane.road_id, "segment_id": lane.segment_id,
			"distance": nl["distance"], "point": nl["point"]}


static func nearest_junction(pos: Vector2) -> Dictionary:
	build()
	var best := {"junction_id": "", "distance": 1e9, "position": Vector2.ZERO}
	for jn: Junction in _junctions:
		var d: float = jn.position.distance_to(pos)
		if d < best["distance"]:
			best = {"junction_id": jn.id, "distance": d, "position": jn.position}
	return best


static func distance_to_road(pos: Vector2) -> float:
	return float(nearest_lane(pos)["distance"])


static func project_to_lane(pos: Vector2, lane_id: String) -> Dictionary:
	build()
	var lane: Lane = _lane_by_id.get(lane_id)
	if lane == null:
		return {"valid": false}
	var r := _project_on_polyline(lane.points, pos)
	return {"valid": true, "point": r["point"], "dist": r["dist"],
			"along_m": r["along"]}


static func _project_on_polyline(pts: Array, p: Vector2) -> Dictionary:
	var bd: float = 1e9
	var bp := Vector2.ZERO
	var along: float = 0.0
	var cum: float = 0.0
	for i in range(pts.size() - 1):
		var a: Vector2 = pts[i]
		var b: Vector2 = pts[i + 1]
		var ab: Vector2 = b - a
		var seg_len: float = ab.length()
		var t: float = clampf((p - a).dot(ab) / maxf(seg_len * seg_len, 1e-6), 0.0, 1.0)
		var q: Vector2 = a + ab * t
		var d: float = (p - q).length()
		if d < bd:
			bd = d
			bp = q
			along = cum + seg_len * t
		cum += seg_len
	return {"dist": bd, "point": bp, "along": along}


## Core route query (§62). Deterministic; same inputs -> same route.
static func find_route(start_world: Vector2, target_world: Vector2,
		profile: String = S.PROFILE_NORMAL, avoid_lane_ids: Array = []) -> Route:
	build()
	var route := Route.new()
	if profile == S.PROFILE_PEDESTRIAN_FUTURE:
		route.reason = "PEDESTRIAN_FUTURE profile is a Prompt 12 placeholder"
		return route
	# candidate entry/exit lanes
	var entries: Array = []
	var exits: Array = []
	var near_exits: Array = []
	var near_entries: Array = []
	var fallback_reach: float = -1.0
	var start_walk_off: float = -1.0
	for lane: Lane in _lanes:
		if lane.vehicle_classes.is_empty():
			continue
		if lane.restricted and profile != S.PROFILE_EMERGENCY \
				and profile != S.PROFILE_MISSION:
			continue
		var rs := _project_on_polyline(lane.points, start_world)
		if rs["dist"] <= NEAREST_LANE_SEARCH_M:
			entries.append({"lane": lane, "reach": rs["dist"], "along": rs["along"]})
		elif rs["dist"] <= GOAL_FALLBACK_M:
			near_entries.append({"lane": lane, "reach": rs["dist"],
					"along": rs["along"]})
		var rg := _project_on_polyline(lane.points, target_world)
		if rg["dist"] <= GOAL_REACH_M:
			exits.append({"lane": lane, "reach": rg["dist"], "along": rg["along"]})
		elif rg["dist"] <= GOAL_FALLBACK_M:
			near_exits.append({"lane": lane, "reach": rg["dist"],
					"along": rg["along"]})
	if entries.is_empty():
		# same rule as the goal: a start point is a place, and if the nearest
		# lane is a little further than the nominal search radius the caller
		# still wants a route rather than a hard failure
		var best_entry := {"reach": 1e18}
		for cand2: Dictionary in near_entries:
			if float(cand2["reach"]) < float(best_entry["reach"]):
				best_entry = cand2
		if best_entry.has("lane"):
			entries.append(best_entry)
			start_walk_off = float(best_entry["reach"])
		else:
			route.reason = "no road within %.0f m of start" % NEAREST_LANE_SEARCH_M
			return route
	if exits.is_empty():
		# No lane is genuinely at the goal. Take the closest one so the caller
		# still gets a route plus an honest walk-off distance, instead of a
		# hard failure at a landmark that simply sits off the road.
		var best_near := {"reach": 1e18}
		for cand: Dictionary in near_exits:
			if float(cand["reach"]) < float(best_near["reach"]):
				best_near = cand
		if best_near.has("lane"):
			exits.append(best_near)
			fallback_reach = float(best_near["reach"])
		else:
			route.reason = "no road within %.0f m of target" % GOAL_FALLBACK_M
			return route
	# Dijkstra over lane graph
	var dist: Dictionary = {}
	var prev: Dictionary = {}
	var settled: Dictionary = {}
	var queue: Array = []   # [cost, lane_id] simple sorted-insert frontier
	for e: Dictionary in entries:
		var lane0: Lane = e["lane"]
		var c0: float = float(e["reach"]) + _partial_cost(lane0, float(e["along"]), profile)
		if not dist.has(lane0.id) or c0 < dist[lane0.id]:
			dist[lane0.id] = c0
			prev[lane0.id] = ""
			_push(queue, [c0, lane0.id])

	var best_exit := {"cost": 1e18, "lane": null, "along": 0.0}
	var guard: int = 0
	while not queue.is_empty():
		guard += 1
		if guard > 400000:
			break
		var cur: Array = queue.pop_front()
		var cid: String = cur[1]
		if settled.has(cid):
			continue
		settled[cid] = true
		var cl: Lane = _lane_by_id[cid]
		# exit test. The comparison is on *cost*, which already carries the
		# 1e9 restricted block for normal profiles, so a barred lane can never
		# win. Adding a distance-preference here would make the public approach
		# road beat the restricted road even for EMERGENCY, which is exactly
		# the profile the restricted road exists to serve (§28/§46).
		var rg2 := _project_on_polyline(cl.points, target_world)
		if rg2["dist"] <= GOAL_REACH_M or (fallback_reach > 0.0 \
				and rg2["dist"] <= GOAL_FALLBACK_M):
			var total: float = dist[cid] + _partial_cost_from_start(cl, float(rg2["along"]), profile)
			if total < best_exit["cost"]:
				best_exit = {"cost": total, "lane": cl, "along": rg2["along"]}
		for nid: String in cl.next_lane_ids:
			if nid in avoid_lane_ids:
				continue
			var nl: Lane = _lane_by_id[nid]
			if nl.restricted and profile != S.PROFILE_EMERGENCY \
					and profile != S.PROFILE_MISSION:
				continue
			var nc: float = dist[cid] + _lane_cost(nl, profile)
			if not dist.has(nid) or nc < dist[nid]:
				dist[nid] = nc
				prev[nid] = cid
				_push(queue, [nc, nid])
	if best_exit["lane"] == null:
		route.reason = "no connected lane path"
		return route
	# reconstruct
	var chain: Array = []
	var at: Lane = best_exit["lane"]
	while at != null:
		chain.append(at)
		var pid: String = prev.get(at.id, "")
		at = _lane_by_id.get(pid) if pid != "" else null
	chain.reverse()
	var r := _assemble_route(chain, best_exit, profile, start_world, target_world)
	if fallback_reach > 0.0:
		r.goal_walk_off_m = fallback_reach
	if start_walk_off > 0.0:
		r.start_walk_off_m = start_walk_off
	if fallback_reach > 0.0 or start_walk_off > 0.0:
		r.reason = "ok (start %.0f m / goal %.0f m off-road; walk-off reported)" % [
				maxf(start_walk_off, 0.0), maxf(fallback_reach, 0.0)]
	return r


## Cost of the tail of a lane (from projection point to lane end).
static func _partial_cost(lane: Lane, along: float, profile: String) -> float:
	var full: float = _lane_cost(lane, profile)
	var len: float = lane_length(lane)
	if len <= 0.001:
		return full
	return full * clampf(1.0 - along / len, 0.0, 1.0)


## Cost of the head of a lane (lane start to projection point) — used for
## the exit lane so the route cost stays metric-consistent.
static func _partial_cost_from_start(lane: Lane, along: float, profile: String) -> float:
	var full: float = _lane_cost(lane, profile)
	var len: float = lane_length(lane)
	if len <= 0.001:
		return full
	return full * clampf(along / len, 0.0, 1.0) - full


static func _push(queue: Array, item: Array) -> void:
	# small sorted-insert frontier: lane graphs here are ~1-2k edges, and a
	# deterministic tie-break on id keeps repeated runs identical
	var lo: int = 0
	var hi: int = queue.size()
	while lo < hi:
		var mid: int = (lo + hi) / 2
		if queue[mid][0] < item[0] or (queue[mid][0] == item[0] and queue[mid][1] < item[1]):
			lo = mid + 1
		else:
			hi = mid
	queue.insert(lo, item)


static func _assemble_route(chain: Array, best_exit: Dictionary, profile: String,
		start_world: Vector2, target_world: Vector2) -> Route:
	var route := Route.new()
	route.success = true
	route.reason = "ok"
	var total_cost: float = 0.0
	var total_time: float = 0.0
	var dist_m: float = 0.0
	var jseen: Dictionary = {}
	for i in range(chain.size()):
		var lane: Lane = chain[i]
		route.lane_ids.append(lane.id)
		if route.road_ids.is_empty() or route.road_ids[-1] != lane.road_id:
			route.road_ids.append(lane.road_id)
		var seg: Segment = _seg_by_id[lane.segment_id]
		if seg.bridge_id != "" and seg.bridge_id not in route.bridges_used:
			route.bridges_used.append(seg.bridge_id)
		if seg.tunnel_id != "" and seg.tunnel_id not in route.tunnels_used:
			route.tunnels_used.append(seg.tunnel_id)
		var partial: bool = false
		if i == 0 or i == chain.size() - 1:
			partial = true
		if partial:
			var rp := _project_on_polyline(lane.points,
					start_world if i == 0 else target_world)
			var len: float = lane_length(lane)
			var frac: float = clampf(float(rp["along"]) / maxf(len, 0.001), 0.0, 1.0)
			if i == 0:
				dist_m += len * (1.0 - frac)
				total_cost += _lane_cost(lane, profile) * (1.0 - frac)
				total_time += _travel_time_s(lane) * (1.0 - frac)
			else:
				dist_m += len * frac
				total_cost += _lane_cost(lane, profile) * frac
				total_time += _travel_time_s(lane) * frac
		else:
			dist_m += lane_length(lane)
			total_cost += _lane_cost(lane, profile)
			total_time += _travel_time_s(lane)
		if lane.start_node_id != "" and not jseen.has(lane.start_node_id):
			jseen[lane.start_node_id] = true
			route.junction_ids.append(lane.start_node_id)
	# waypoints: entry point, every lane junction, exit point
	var first: Lane = chain[0]
	var last: Lane = chain[chain.size() - 1]
	var w0 := _project_on_polyline(first.points, start_world)
	route.waypoints.append(Vector3(w0["point"].x, _elev_at(first, float(w0["along"])), w0["point"].y))
	for lane2: Lane in chain:
		var n: int = lane2.points.size()
		var endp: Vector2 = lane2.points[n - 1]
		route.waypoints.append(Vector3(endp.x, lane2.elev[n - 1], endp.y))
	var w1 := _project_on_polyline(last.points, target_world)
	route.waypoints.append(Vector3(w1["point"].x, _elev_at(last, float(w1["along"])), w1["point"].y))
	route.start_node = first.start_node_id
	route.target_node = last.end_node_id
	route.distance_m = dist_m
	route.estimated_time_s = total_time
	route.cost = total_cost
	route.turn_instructions_placeholder = _turn_placeholders(chain)
	return route


static func _elev_at(lane: Lane, along: float) -> float:
	var cum: float = 0.0
	for i in range(lane.points.size() - 1):
		var d: float = ((lane.points[i + 1] - lane.points[i]) as Vector2).length()
		if cum + d >= along:
			var t: float = (along - cum) / maxf(d, 0.001)
			return lerpf(lane.elev[i], lane.elev[i + 1], t)
		cum += d
	return lane.elev[lane.elev.size() - 1]


static func _turn_placeholders(chain: Array) -> Array:
	var out: Array = []
	for i in range(1, chain.size()):
		var a: Lane = chain[i - 1]
		var b: Lane = chain[i]
		if a.road_id == b.road_id:
			continue
		var jn: Junction = _jct_by_id.get(a.end_node_id)
		out.append({"at_junction": a.end_node_id,
				"from": a.road_id, "to": b.road_id,
				"control": jn.control_type if jn != null else "none"})
	return out


## Convenience wrappers (§62 required API).
static func find_route_v3(start_world: Vector3, target_world: Vector3,
		profile: String = S.PROFILE_NORMAL) -> Route:
	return find_route(Vector2(start_world.x, start_world.z),
			Vector2(target_world.x, target_world.z), profile)


static func find_route_profile(start_world: Vector2, target_world: Vector2,
		profile: String) -> Route:
	return find_route(start_world, target_world, profile)


## Alternative route (§56): re-run with the primary route's lanes penalised
## out. Only returned when it differs meaningfully and stays valid.
static func find_route_with_alternative(start_world: Vector2, target_world: Vector2,
		profile: String = S.PROFILE_NORMAL) -> Route:
	var primary := find_route(start_world, target_world, profile)
	if not primary.success:
		return primary
	var alt := find_route(start_world, target_world, profile, primary.lane_ids)
	if alt.success:
		var shared: int = 0
		for lid: String in alt.lane_ids:
			if lid in primary.lane_ids:
				shared += 1
		var ratio: float = float(shared) / maxf(1, alt.lane_ids.size())
		if ratio < 0.9 and alt.cost < primary.cost * 2.0:
			primary.alternative = alt
	return primary


# ======================================================================
# CONNECTIVITY + METRICS (§54/§72)
# ======================================================================

## Union-find over junctions connected by segments. Returns an array of
## components, each an array of junction ids (sorted, deterministic).
static func connected_components() -> Array:
	build()
	var parent: Dictionary = {}
	for jn: Junction in _junctions:
		parent[jn.id] = jn.id
	for seg: Segment in _segments:
		if seg.start_node_id == "" or seg.end_node_id == "":
			continue
		# A segment whose end is a dead-end stub (that junction touches no
		# other road) must NOT weld two roads into one component: without
		# this check every cul-de-sac silently "connects" its neighbours
		# and the isolated-component gate becomes meaningless.
		if _junction_degree(seg.start_node_id) < 2:
			continue
		if _junction_degree(seg.end_node_id) < 2:
			continue
		_union(parent, seg.start_node_id, seg.end_node_id)
	var groups: Dictionary = {}
	var ids: Array = parent.keys()
	ids.sort()
	for jid: String in ids:
		# dead-end stubs are metadata (§22/§54), not network components
		if _junction_degree(jid) < 2:
			continue
		var root: String = _find(parent, jid)
		if not groups.has(root):
			groups[root] = []
		groups[root].append(jid)
	var out: Array = []
	var keys: Array = groups.keys()
	keys.sort()
	for k: String in keys:
		out.append(groups[k])
	return out


static func _junction_degree(jid: String) -> int:
	var jn: Junction = _jct_by_id.get(jid)
	return 0 if jn == null else jn.connected_road_ids.size()


static func _find(parent: Dictionary, x: String) -> String:
	var r: String = x
	while parent[r] != r:
		r = parent[r]
	return r


static func _union(parent: Dictionary, a: String, b: String) -> void:
	var ra: String = _find(parent, a)
	var rb: String = _find(parent, b)
	if ra != rb:
		# deterministic: smaller id becomes root
		if ra < rb:
			parent[rb] = ra
		else:
			parent[ra] = rb


static func _compute_metrics() -> void:
	var by_class: Dictionary = {}
	var total: float = 0.0
	var longest := {"id": "", "len": 0.0}
	var highest_grade := {"id": "", "grade": 0.0}
	for seg: Segment in _segments:
		total += seg.length_m
		by_class[seg.class_id] = float(by_class.get(seg.class_id, 0.0)) + seg.length_m
		if seg.length_m > longest["len"]:
			longest = {"id": seg.road_id, "len": seg.length_m}
		if seg.max_grade_pct > highest_grade["grade"]:
			highest_grade = {"id": seg.road_id, "grade": seg.max_grade_pct}
	var signals: int = 0
	for jn: Junction in _junctions:
		if jn.control_type == "signal":
			signals += 1
	var dead_ends: int = 0
	for rid: String in _roads_by_id.keys():
		var rec: D.RoadRecord = _roads_by_id[rid]
		if rec.intentional_dead_end:
			dead_ends += 1
	var longest_bridge := {"id": "", "len": 0.0}
	for br: Bridge in _bridges:
		if br.length_m > longest_bridge["len"]:
			longest_bridge = {"id": br.id, "len": br.length_m}
	var longest_tunnel := {"id": "", "len": 0.0}
	for tn: Tunnel in _tunnels:
		if tn.length_m > longest_tunnel["len"]:
			longest_tunnel = {"id": tn.id, "len": tn.length_m}
	var edges: int = 0
	for lane: Lane in _lanes:
		edges += lane.next_lane_ids.size()
	_metrics = {
		"road_schema_version": S.ROAD_SCHEMA_VERSION,
		"road_revision": S.ROAD_REVISION,
		"source_terrain_revision": S.SOURCE_TERRAIN_REVISION,
		"terrain_fingerprint": S.terrain_fingerprint(),
		"total_length_m": total,
		"length_by_class_m": by_class,
		"segment_count": _segments.size(),
		"junction_count": _junctions.size(),
		"signal_count": signals,
		"roundabout_count": _roundabouts.size(),
		"lane_count": _lanes.size(),
		"graph_nodes": _junctions.size(),
		"graph_edges": edges,
		"connected_components": connected_components().size(),
		"intentional_dead_ends": dead_ends,
		"bridge_count": _bridges.size(),
		"tunnel_count": _tunnels.size(),
		"overpass_count": _overpasses.size(),
		"longest_road": longest,
		"highest_grade": highest_grade,
		"largest_bridge": longest_bridge,
		"longest_tunnel": longest_tunnel,
		"legacy_roads_migrated": _count_legacy(),
	}


static func _count_legacy() -> int:
	var n: int = 0
	for seg: Segment in _segments:
		if seg.is_legacy:
			n += 1
	return n
