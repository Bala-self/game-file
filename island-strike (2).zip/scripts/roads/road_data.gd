class_name RoadData
extends Object
## AUTHORED ROAD CENTERLINE DATABASE (Reconstruction Prompt 04, Phases C-F).
## Static, deterministic, hand-authored control points — NOT procedural noise
## and NOT extracted from any proprietary map. Every corridor was validated
## against WorldTerrain with headless probes (height_at / grade_percent /
## is_road_viable / distance_to_water / water_level_at): the freeway follows
## the flat eastern shelf and viaducts the east inlet; mountain roads ride
## the P03-authored valleys V1/V2; the west ridge tunnel replaces an
## impossible 40%+ climb; the east rock fissure band (|z|<15, x>1900) is
## avoided; the lake is crossed once at the P03 outlet anchor and otherwise
## routed around; all three P03 river bridge anchors are consumed.
##
## Layer separation (§50): this file is the ROAD DATABASE only. Geometry
## lives in road_mesh_builder.gd, traversal in road_graph.gd.
##
## Shared junction coordinates are EXACT duplicates between roads so the
## graph welds them deterministically (no tolerance guessing).

const S := preload("res://scripts/roads/road_schema.gd")

## =====================================================================
## FREEWAYS (§10)
## =====================================================================
## Harbor Freeway: N-S spine on the flat eastern shelf. Crosses the east
## inlet on a viaduct (BRG_EAST_INLET_01) — probed water strip
## x 650..840+, z -200..220, depth 1.5-3.2 m under sea level -1.3.
const CL_FWY_HARBOR: Array = [
	Vector2(330, -1500), Vector2(430, -1200), Vector2(520, -920),
	Vector2(600, -620), Vector2(640, -330), Vector2(700, -150),
	Vector2(720, 100), Vector2(750, 300), Vector2(800, 560),
	Vector2(860, 900), Vector2(910, 1340), Vector2(940, 1740),
	Vector2(960, 2100),
]
## Palmetto Freeway: SW corridor over the downtown slope — probed worst
## grade 0.32%, entirely viable freeway ground.
const CL_FWY_PALMETTO: Array = [
	Vector2(-260, 360), Vector2(-520, 720), Vector2(-820, 1080),
	Vector2(-1150, 1420), Vector2(-1500, 1700), Vector2(-1750, 1900),
]

## Harbor Freeway carriageways (§10: divided limited-access highway).
## The original single CL_FWY_HARBOR axis is kept as the geometric
## reference for bridge/overpass anchors; the two 22 m-offset
## carriageways below are what the graph actually builds, each one-way.
## 22 m is the full cross-section (2 x 3 x 3.7 lane + 2 x 2.5 shoulder
## + 4.0 median) and, critically, exceeds the junction weld radius so a
## ramp junction on one carriageway can never weld to the other.
const CL_FWY_HARBOR_NB: Array = [
	Vector2(918, 1741.4), Vector2(888.1, 1342.1),
	Vector2(838.2, 903.1), Vector2(778.4, 564), Vector2(728.3, 303.8),
	Vector2(698.1, 102.4), Vector2(678.4, -146), Vector2(618.5, -325.4),
	Vector2(578.4, -615.6), Vector2(498.9, -913.8), Vector2(409.1, -1193.2),
	Vector2(309.1, -1493),
]
const CL_FWY_HARBOR_SB: Array = [
	Vector2(350.9, -1507), Vector2(450.9, -1206.8), Vector2(541.1, -926.2),
	Vector2(621.6, -624.4), Vector2(661.5, -334.6), Vector2(721.6, -154),
	Vector2(741.9, 97.6), Vector2(771.7, 296.2), Vector2(821.6, 556),
	Vector2(881.8, 896.9), Vector2(931.9, 1337.9), Vector2(962, 1738.6),
]

## Palmetto Freeway carriageways — same treatment; authored axis runs
## NE(-260,360) -> SW(-1750,1900), so WB follows it and EB reverses.
const CL_FWY_PALMETTO_WB: Array = [
	Vector2(-277.8, 347.1), Vector2(-537.4, 706.5), Vector2(-836.4, 1065.3),
	Vector2(-1164.8, 1403.7), Vector2(-1513.7, 1682.8), Vector2(-1763.7, 1882.8),
]
const CL_FWY_PALMETTO_EB: Array = [
	Vector2(-1736.3, 1917.2), Vector2(-1486.3, 1717.2), Vector2(-1135.2, 1436.3),
	Vector2(-803.6, 1094.7), Vector2(-502.6, 733.5), Vector2(-242.2, 372.9),
]

## =====================================================================
## PRIMARY ARTERIALS (§11)
## =====================================================================
## Harbor Boulevard: main E-W spine; crosses the river at P03 anchor 2
## (1250,-150); routed north of the east inlet (z -320 band is dry) and
## south end avoids the rock fissure band (z 0, x>1900).
## Harbor Boulevard runs east on the north side of the Harbor Freeway and
## joins it at the frontage interchange (§10: no at-grade freeway crossing).
const CL_ART_HARBOR: Array = [
	Vector2(-420, -67), Vector2(0, -67), Vector2(400, -100),
	Vector2(520, -180), Vector2(610, 50), Vector2(760, -120),
	Vector2(900, -330),
	Vector2(1100, -260), Vector2(1250, -150), Vector2(1450, -60),
	Vector2(1700, 20), Vector2(1950, 90), Vector2(2150, 180),
	Vector2(2320, 330),
]
## Central Avenue: N-S city spine (legacy main N-S continues south over
## the downtown slope; probed worst 1.0%).
## Central Avenue stops at the Palmetto interchange (§10: a surface road
## never crosses a freeway at grade). Traffic continues north on the
## Palmetto EB off-ramp / WB on-ramp pair instead of cutting across.
const CL_ART_CENTRAL_NS: Array = [
	Vector2(-267, -320), Vector2(-267, 0), Vector2(-267, 320),
]
## South Ring: connects the freeway to the southern districts.
const CL_ART_SOUTH_RING: Array = [
	Vector2(881.8, 896.9), Vector2(650, 1080), Vector2(400, 1200),
	Vector2(150, 1300), Vector2(-100, 1380), Vector2(-400, 1480),
]
## Airport approach: from the Harbor Freeway south terminus into the
## palmetto_intl wedge (probed flat, 0.2-0.9%). Skeleton only (§27).
const CL_ART_AIRPORT: Array = [
	Vector2(1150, 2150), Vector2(1350, 2250),
]

## =====================================================================
## SECONDARY ARTERIALS
## =====================================================================
## River East Parkway: east river bank south, lake west shore, ONE lake
## crossing at the P03 outlet anchor (1700,900) — §17 value case: the
## direct industrial link, lake otherwise routed around by PARK_LAKE_01.
const CL_ART2_RIVER_EAST: Array = [
	Vector2(1450, -60), Vector2(1400, 150), Vector2(1350, 400),
	Vector2(1300, 650), Vector2(1240, 1000), Vector2(1330, 1233),
	Vector2(1500, 1150), Vector2(1700, 900), Vector2(1850, 780),
	Vector2(1903, 667), Vector2(2020, 950), Vector2(2100, 1400),
]
## Industrial Parkway: refinery/port spine; avoids the fissure band by
## staying at z >= 100 east of x 1900.
const CL_ART2_INDUSTRIAL: Array = [
	Vector2(2320, 330), Vector2(2350, 600), Vector2(2350, 800),
	Vector2(2200, 1100), Vector2(2050, 1250), Vector2(1903, 1233),
]

## =====================================================================
## HIGHWAY RAMPS (§10) — diamond/half-diamond connections
## =====================================================================
const CL_RMP_HFWY_N: Array = [
	Vector2(409.1, -1193.2), Vector2(470, -1290), Vector2(520, -1420),
]
const CL_RMP_HFWY_E: Array = [
	Vector2(417, -67), Vector2(500, -150), Vector2(578.4, -615.6),
]
const CL_RMP_HFWY_S: Array = [
	Vector2(417, 143), Vector2(560, 220), Vector2(741.9, 97.6),
]
const CL_RMP_HFWY_AIR: Array = [
	Vector2(919, 1339.1), Vector2(1020, 1500), Vector2(1150, 1700),
	Vector2(1150, 2150),
]
## =====================================================================
## Ramps (§10/§26). Each carriageway is a one-way road, so an off-ramp
## serves only the direction it leaves and both directions need their own
## pair. A ramp always joins the surface network at its far end — never a
## ramp-to-ramp join, which would be an illegal movement in the lane graph.
## =====================================================================
## Harbor Freeway SB: off-ramp to the airport approach.
## Harbor Freeway SB: off-ramp to the airport approach. The carriageway
## itself ends at the ramp head, never at grade on a surface road.
const CL_RMP_HARBOR_SB_OFF: Array = [
	Vector2(962, 1738.6), Vector2(1020, 1500), Vector2(1150, 1700),
	Vector2(1150, 2150),
]
## Harbor Freeway SB: off-ramp to the north rural network.
const CL_RMP_HARBOR_SB_N_OFF: Array = [
	Vector2(350.9, -1507), Vector2(400, -1350), Vector2(409.1, -1193.2),
]
## Harbor Freeway NB: off-ramp to the airport approach (the NB carriageway
## runs S->N, so its off-ramp leaves from the north end).
const CL_RMP_HARBOR_NB_AIR_OFF: Array = [
	Vector2(918, 1741.4), Vector2(1000, 1800), Vector2(1150, 2150),
]
## Harbor Freeway NB: off-ramp to the South Ring / beach link, and on-ramp
## from it.
const CL_RMP_HARBOR_NB_OFF: Array = [
	Vector2(838.2, 903.1), Vector2(760, 1000), Vector2(650, 1080),
]
const CL_RMP_HARBOR_NB_ON: Array = [
	Vector2(400, 1200), Vector2(700, 1200), Vector2(888.1, 1342.1),
]
## Harbor Freeway SB: off-ramp to the Harbor frontage road.
const CL_RMP_HARBOR_SB_FRONT_OFF: Array = [
	Vector2(721.6, -154), Vector2(660, -150), Vector2(610, 50),
]
## Harbor Freeway NB: on-ramp from the Harbor frontage road.
const CL_RMP_HARBOR_NB_FRONT_ON: Array = [
	Vector2(610, 50), Vector2(620, -200), Vector2(618.5, -325.4),
]
## Palmetto Freeway WB: off-ramp to the beach service road.
const CL_RMP_PALMETTO_WB_OFF: Array = [
	Vector2(-537.4, 706.5), Vector2(-650, 550), Vector2(-820, 300),
]
## Palmetto Freeway WB: on-ramp from Central Avenue (the WB carriageway
## starts here, so traffic can enter the freeway from the city side).
const CL_RMP_PALMETTO_WB_CITY_ON: Array = [
	Vector2(-267, 320), Vector2(-280, 420), Vector2(-277.8, 347.1),
]
## Palmetto Freeway EB: on-ramp from the beach service road.
const CL_RMP_PALMETTO_EB_ON: Array = [
	Vector2(-1650, 1680), Vector2(-1560, 1800), Vector2(-1736.3, 1917.2),
]
## Palmetto Freeway EB: off-ramp to Bay Coast Road.
## Palmetto Freeway EB: off-ramp to Bay Coast Road (mid-corridor) and the
## city-side off-ramp that ends the EB carriageway at Central Avenue.
const CL_RMP_PALMETTO_EB_OFF: Array = [
	Vector2(-803.6, 1094.7), Vector2(-900, 1200), Vector2(-1000, 1300),
]
const CL_RMP_PALMETTO_EB_CITY_OFF: Array = [
	Vector2(-242.2, 372.9), Vector2(-200, 300), Vector2(-67, 320),
]
## Palmetto Freeway WB: on-ramp from Bay Coast Road.
const CL_RMP_PALMETTO_WB_ON: Array = [
	Vector2(-1000, 1300), Vector2(-1250, 1450), Vector2(-1500, 1650),
	Vector2(-1763.7, 1882.8),
]

## =====================================================================
## URBAN COLLECTORS (§12) — varied geometry, not one grid
## =====================================================================
const CL_COL_CORE_EW: Array = [
	Vector2(-420, -67), Vector2(-60, -67), Vector2(300, -67),
	Vector2(417, -67),
]
const CL_COL_CORE_SOUTH: Array = [
	Vector2(-267, 320), Vector2(-200, 500), Vector2(-100, 650),
	Vector2(0, 760),
]
const CL_COL_DOWNTOWN_01: Array = [
	Vector2(-400, -187), Vector2(-200, -190), Vector2(-60, -195),
	Vector2(100, -200),
]
const CL_COL_DOWNTOWN_02: Array = [
	Vector2(-157, -280), Vector2(-160, -190), Vector2(-165, -67),
	Vector2(-170, 60),
]
const CL_COL_INNER_01: Array = [
	Vector2(-60, -67), Vector2(60, 100), Vector2(180, 260),
	Vector2(280, 420), Vector2(350, 560),
]
const CL_COL_PARK_EDGE: Array = [
	Vector2(280, 420), Vector2(420, 520), Vector2(520, 640),
	Vector2(560, 780),
]
const CL_COL_BEACH_LINK: Array = [
	Vector2(350, 560), Vector2(450, 750), Vector2(520, 950),
	Vector2(650, 1080),
]

## =====================================================================
## SUBURBS (§12): loops + cul-de-sacs
## =====================================================================
const CL_RES_LOOP_A: Array = [
	Vector2(0, 760), Vector2(-150, 850), Vector2(-280, 980),
	Vector2(-250, 1120), Vector2(-100, 1200), Vector2(60, 1150),
]
const CL_RES_CULDE_A: Array = [
	Vector2(-280, 980), Vector2(-350, 1080), Vector2(-330, 1200),
]
const CL_RES_LOOP_B: Array = [
	Vector2(60, 1150), Vector2(200, 1220), Vector2(340, 1180),
	Vector2(400, 1050), Vector2(320, 930), Vector2(180, 900),
	Vector2(60, 950), Vector2(0, 760),
]
const CL_RES_CULDE_B: Array = [
	Vector2(340, 1180), Vector2(420, 1280), Vector2(400, 1400),
]
const CL_RES_SUB_01: Array = [
	Vector2(-100, 1200), Vector2(-150, 1320), Vector2(-100, 1380),
]

## =====================================================================
## INDUSTRIAL (§29): wide, truck-friendly
## =====================================================================
const CL_IND_YARD_A: Array = [
	Vector2(2350, 600), Vector2(2480, 640), Vector2(2560, 760),
]
const CL_IND_SERVICE: Array = [
	Vector2(2200, 1100), Vector2(2330, 1050), Vector2(2420, 950),
]

## =====================================================================
## AIRPORT SKELETON (§27) — palmetto_intl wedge, no terminal buildings
## =====================================================================
const CL_AIR_TERMINAL: Array = [
	Vector2(1350, 2250), Vector2(1420, 2380), Vector2(1400, 2500),
]
const CL_AIR_FREIGHT: Array = [
	Vector2(1350, 2250), Vector2(1500, 2100), Vector2(1500, 1950),
]
const CL_AIR_PARKING: Array = [
	Vector2(1150, 2150), Vector2(1050, 2300),
]

## =====================================================================
## MILITARY / RESTRICTED (§28) — mountain spur off valley V2
## =====================================================================
const CL_MIL_PUBLIC: Array = [
	Vector2(280, -1850), Vector2(150, -1950), Vector2(50, -2050),
]
const CL_MIL_INTERNAL: Array = [
	Vector2(50, -2050), Vector2(-50, -2150),
]

## =====================================================================
## RURAL (§13)
## =====================================================================
## North Rural: crosses the river at P03 anchor 1 (760,-1100); ends at a
## marked foothill terminus (fissure band blocks the direct east link;
## industrial connects via Harbor Boulevard instead).
const CL_RURAL_NORTH: Array = [
	Vector2(409.1, -1193.2), Vector2(520, -1420), Vector2(760, -1100),
	Vector2(900, -1150), Vector2(1200, -1350), Vector2(1600, -1500),
	Vector2(1900, -1600), Vector2(2100, -1400), Vector2(2250, -900),
	Vector2(2300, -450),
]
const CL_RURAL_SOUTH: Array = [
	Vector2(150, 1300), Vector2(300, 1500), Vector2(400, 1640),
	Vector2(600, 1800), Vector2(800, 1900),
]
const CL_RURAL_EAST: Array = [
	Vector2(2100, 1400), Vector2(2190, 1180), Vector2(2200, 1100),
]

## =====================================================================
## FARM / DIRT (§13)
## =====================================================================
const CL_FARM_A: Array = [
	Vector2(520, -1420), Vector2(500, -1700), Vector2(420, -1950),
	Vector2(409.1, -1193.2),
]
const CL_FARM_B: Array = [
	Vector2(1200, -1350), Vector2(1250, -1550), Vector2(1350, -1750),
	Vector2(1500, -1850), Vector2(1600, -1500),
]
const CL_DIRT_SCENIC: Array = [
	Vector2(400, 1640), Vector2(600, 1800), Vector2(850, 1950),
	Vector2(1050, 2050), Vector2(1150, 2150),
]
const CL_DIRT_RIDGE: Array = [
	Vector2(-820, 300), Vector2(-980, 500), Vector2(-1120, 800),
	Vector2(-1250, 650),
]

## =====================================================================
## MOUNTAIN (§14): valley-first, deliberate switchbacks, one tunnel.
## Corridors are flattened by authored TA.ROAD_CORRIDORS data (§79),
## never by runtime deformation.
## =====================================================================
## Valley V2 road: south valley floor up to the valley-head junction with
## V1 (raw floor averages 9.2% over this run — probed viable at 12%).
const CL_MTN_V2: Array = [
	Vector2(409.1, -1193.2), Vector2(280, -1700), Vector2(280, -1850),
	Vector2(310, -2000), Vector2(330, -2150),
]
## Valley V1 main: the long east-west valley floor between ridges R1/R2
## (junction 95 m -> 194 m over ~920 m = 10.8% average, corridor-capped 12%).
const CL_MTN_V1: Array = [
	Vector2(330, -2150), Vector2(250, -2190), Vector2(0, -2240),
	Vector2(-250, -2260), Vector2(-400, -2230), Vector2(-650, -2160),
]
## V1 west descent: deliberate switchback legs doubling the length so the
## 127 m drop to the tunnel portal runs at ~11.5% instead of 16% (§14).
const CL_MTN_V1_DESCENT: Array = [
	Vector2(-650, -2160), Vector2(-750, -2050), Vector2(-900, -2100),
	Vector2(-1000, -2000), Vector2(-850, -1950), Vector2(-1050, -1900),
	Vector2(-1250, -1980),
]
## Sentinel switchback road: deliberate hairpin anchors to the summit
## overlook (stops short of the 297 m peak itself — P03 landmark).
const CL_MTN_SENTINEL: Array = [
	Vector2(-250, -2260), Vector2(-330, -2330), Vector2(-300, -2430),
	Vector2(-170, -2470), Vector2(-60, -2430), Vector2(0, -2350),
]
## West ridge tunnel road: V1 west end under the R1 west spur to the
## NW coastal road. Portals probed: h 32.5 / 21.9, grade ~2-3%.
const CL_MTN_TUNNEL_WEST: Array = [
	Vector2(-1250, -1980), Vector2(-1450, -1900), Vector2(-1680, -1760),
]
## West descent: tunnel portal down to the coast road junction.
const CL_MTN_WEST_DESCENT: Array = [
	Vector2(-1680, -1760), Vector2(-1850, -1600), Vector2(-1950, -1450),
	Vector2(-2000, -1250),
]

## =====================================================================
## COASTAL (§15): inland where natural, waterfront where urban.
## No north-coast road: probed north strip is a 250-290 m mountain wall.
## =====================================================================
## Northwest Coastal Road: the coastal loop's western arm. Its inland end
## meets the mountain west descent so the coast is reachable from the
## mountain network without backtracking through the city (§15/§26).
const CL_COAST_NW: Array = [
	Vector2(-540, -350), Vector2(-620, -700), Vector2(-900, -1050),
	Vector2(-1350, -1250), Vector2(-1700, -1300), Vector2(-1900, -1450),
	Vector2(-2000, -1250),
]
## Bay Shore Road runs to the Palmetto WB off-ramp landing (§10): a coastal
## road must not cross the freeway at grade.
const CL_COAST_BAY: Array = [
	Vector2(-560, -40), Vector2(-600, 300), Vector2(-680, 700),
	Vector2(-820, 1000), Vector2(-1000, 1300),
]
const CL_COAST_SUNSET: Array = [
	Vector2(-1000, 1300), Vector2(-1400, 1560), Vector2(-1650, 1680),
	Vector2(-1850, 1800), Vector2(-1950, 1500), Vector2(-2050, 1100),
]
const CL_COAST_MARINA: Array = [
	Vector2(-560, -40), Vector2(-700, -80), Vector2(-840, -160),
]

## =====================================================================
## FRONTAGE / SERVICE (§5)
## =====================================================================
const CL_FRONT_HARBOR: Array = [
	Vector2(618.5, -325.4), Vector2(600, -200), Vector2(610, 50),
	Vector2(650, 300),
]
const CL_SVC_MARINA: Array = [
	Vector2(-840, -160), Vector2(-880, -320), Vector2(-860, -500),
]
const CL_SVC_BEACH: Array = [
	Vector2(-1850, 1800), Vector2(-1560, 1800), Vector2(-1650, 1680),
]

## =====================================================================
## PARK / RECREATION (§30): lake shoreline scenic loop road
## =====================================================================
const CL_PARK_LAKE: Array = [
	Vector2(1330, 1233), Vector2(1550, 1350), Vector2(1800, 1300),
	Vector2(1903, 1233),
]

## =====================================================================
## ALLEY (§5)
## =====================================================================
const CL_ALLEY_DTN: Array = [
	Vector2(-200, -190), Vector2(-120, -260), Vector2(-60, -330),
]

## =====================================================================
## LEGACY GRID (P01/P02 wb_kit ROADS rects, §61 migration): the old
## rect network stays rendered by WBRoads; here it is re-expressed as
## centerlines so the graph, GPS and traffic can use it. One record per
## legacy rect, deterministic LEG_* IDs, mapped to new classes.
## =====================================================================
const LEGACY_ROADS: Array = [
	# id, class, rect (mirrors wb_kit.ROADS order), one_way?
	{"id": "LEG_PERIM_N_01", "cls": S.CLASS_URBAN_COLLECTOR, "rect": Rect2(-410, -317, 820, 14)},
	{"id": "LEG_PERIM_S_01", "cls": S.CLASS_URBAN_COLLECTOR, "rect": Rect2(-410, 303, 820, 14)},
	{"id": "LEG_PERIM_W_01", "cls": S.CLASS_URBAN_COLLECTOR, "rect": Rect2(-417, -310, 14, 620)},
	{"id": "LEG_PERIM_E_01", "cls": S.CLASS_URBAN_COLLECTOR, "rect": Rect2(403, -310, 14, 620)},
	{"id": "LEG_MAIN_EW_01", "cls": S.CLASS_URBAN_COLLECTOR, "rect": Rect2(-410, -67, 820, 14)},
	{"id": "LEG_EW_SOUTH_01", "cls": S.CLASS_URBAN_COLLECTOR, "rect": Rect2(-410, 143, 530, 14)},
	{"id": "LEG_MAIN_NS_01", "cls": S.CLASS_URBAN_COLLECTOR, "rect": Rect2(-267, -310, 14, 620)},
	{"id": "LEG_NS_AVE_01", "cls": S.CLASS_URBAN_COLLECTOR, "rect": Rect2(53, -310, 14, 620)},
	{"id": "LEG_IND_ACCESS_01", "cls": S.CLASS_INDUSTRIAL, "rect": Rect2(173, -310, 14, 620)},
	{"id": "LEG_DTN_EW_01", "cls": S.CLASS_RESIDENTIAL, "rect": Rect2(-400, -187, 280, 14)},
	{"id": "LEG_DTN_NS_01", "cls": S.CLASS_RESIDENTIAL, "rect": Rect2(-157, -280, 14, 220)},
	{"id": "LEG_AIR_SPUR_01", "cls": S.CLASS_SERVICE, "rect": Rect2(303, -310, 14, 100)},
	{"id": "LEG_AIR_SERVICE_01", "cls": S.CLASS_SERVICE, "rect": Rect2(243, -227, 194, 12)},
	{"id": "LEG_BEACH_RD_01", "cls": S.CLASS_COASTAL, "rect": Rect2(-387, -310, 14, 620)},
	{"id": "LEG_DIRT_01", "cls": S.CLASS_DIRT, "rect": Rect2(-410, 224, 290, 8)},
]


## =====================================================================
## Bridges (§16/§41). The three P03 RIVER anchors are consumed; the east
## inlet viaduct is a fourth bridge on DIFFERENT water, justified in the
## P04 doc (§16 forbids a fourth RIVER bridge / bridge spam).
## =====================================================================
const BRIDGES: Array = [
	{
		"id": "BRG_RIVER_NORTH_01",
		"road_id": "RURAL_NORTH_01",
		"anchor": Vector2(760, -1100),
		"span_m": 92.0,
		"water_clearance_m": 6.5,
		"landmark": true,
		"note": "P03 anchor 1 — North Rural crossing, upper river",
	},
	{
		"id": "BRG_RIVER_CENTRAL_01",
		"road_id": "ART_HARBOR_01",
		"anchor": Vector2(1250, -150),
		"span_m": 84.0,
		"water_clearance_m": 6.0,
		"landmark": true,
		"note": "P03 anchor 2 — Harbor Boulevard crossing, mid river",
	},
	{
		"id": "BRG_LAKE_OUTLET_01",
		"road_id": "ART2_RIVER_EAST_01",
		"anchor": Vector2(1700, 900),
		"span_m": 430.0,
		"water_clearance_m": 5.0,
		"landmark": true,
		"note": "P03 anchor 3 — lake outlet viaduct; the single lake crossing (§17)",
	},
	{
		"id": "BRG_EAST_INLET_01",
		"road_id": "FWY_HARBOR_SB_01",
		"anchor": Vector2(710, -25),
		"span_m": 560.0,
		"water_clearance_m": 5.5,
		"landmark": true,
		"note": "Harbor Freeway viaduct over the east inlet (not a river anchor)",
	},
]

## =====================================================================
## Tunnels (§18): one — west ridge penetration giving the mountain
## network its second exit (pursuit topology, §47). Without it the V1
## valley is a dead-end box; the surface alternative is a 40%+ climb.
## =====================================================================
const TUNNELS: Array = [
	{
		"id": "TUN_WEST_RIDGE_01",
		"road_id": "MTN_TUNNEL_WEST_01",
		"entrance": Vector2(-1300, -1960),
		"exit": Vector2(-1620, -1790),
		"length_m": 360.0,
		"lighting_profile": "tunnel_standard",
		"ventilation_profile": "natural_placeholder",
		"interior_streaming_rule": "always_active_when_road_active",
		"note": "under the R1 west spur; portals h 32.5 -> 21.9 (2% grade)",
	},
]

## =====================================================================
## Overpasses (§19): selective grade separations only
## =====================================================================
const OVERPASSES: Array = [
	{
		"id": "OVP_HFWY_RING_01",
		"over_road_id": "FWY_HARBOR_SB_01",
		"under_road_id": "ART_SOUTH_RING_01",
		"position": Vector2(881.8, 896.9),
		"clearance_m": 5.2,
		"note": "ring road passes under the freeway",
	},
]

## =====================================================================
## Roundabouts (§35): two, at high-value junctions only
## =====================================================================
const ROUNDABOUTS: Array = [
	{"id": "RBT_SUBURB_GATE_01", "position": Vector2(0, 760), "radius_m": 16.0,
		"circulating_lanes": 1, "yield_on_entry": true},
	{"id": "RBT_EAST_JUNCTION_01", "position": Vector2(2100, 1400), "radius_m": 18.0,
		"circulating_lanes": 1, "yield_on_entry": true},
]


## One authored road: deterministic ID + class + centerline + metadata.
class RoadRecord:
	var id: String = ""
	var display_name: String = ""
	var class_id: String = ""
	var centerline: Array = []          # Vector2 XZ control points
	var one_way: bool = false
	var direction_sign: float = 1.0     # +1 = traffic flows with point order
	var reversible_placeholder: bool = false
	var restricted: bool = false        # public traffic barred (§28)
	var emergency_only: bool = false
	var intentional_dead_end: bool = false
	var dead_end_marked: bool = false
	var route_priority: int = 3
	var notes: String = ""

	func bridge_ids() -> Array:
		var out: Array = []
		for b: Dictionary in BRIDGES:
			if str(b["road_id"]) == id:
				out.append(str(b["id"]))
		return out

	func tunnel_ids() -> Array:
		var out: Array = []
		for t: Dictionary in TUNNELS:
			if str(t["road_id"]) == id:
				out.append(str(t["id"]))
		return out


static func _r(id: String, dname: String, cls: String, cl: Array,
		priority: int = 3) -> RoadRecord:
	var rec := RoadRecord.new()
	rec.id = id
	rec.display_name = dname
	rec.class_id = cls
	rec.centerline = cl
	rec.route_priority = priority
	return rec


## The authored network (§71 deterministic IDs).
static func roads() -> Array:
	var out: Array = []

	# --- Freeways: divided, each carriageway a one-way road (§10/§22).
	# The `_r(..., 1)` calls these used to carry passed 1 as route_priority
	# (a routing weight) while one_way stayed false, so the freeway was
	# modelled as one bidirectional centerline with no median and ramps
	# could never legally reach the other direction. Carriageways fix it.
	var fhnb := _r("FWY_HARBOR_NB_01", "Harbor Freeway Northbound",
			S.CLASS_FREEWAY, CL_FWY_HARBOR_NB)
	fhnb.one_way = true; fhnb.direction_sign = 1.0; fhnb.route_priority = 1
	out.append(fhnb)
	var fhsb := _r("FWY_HARBOR_SB_01", "Harbor Freeway Southbound",
			S.CLASS_FREEWAY, CL_FWY_HARBOR_SB)
	fhsb.one_way = true; fhsb.direction_sign = 1.0; fhsb.route_priority = 1
	out.append(fhsb)
	var fpwb := _r("FWY_PALMETTO_WB_01", "Palmetto Freeway Westbound",
			S.CLASS_FREEWAY, CL_FWY_PALMETTO_WB)
	fpwb.one_way = true; fpwb.direction_sign = 1.0; fpwb.route_priority = 1
	out.append(fpwb)
	var fpeb := _r("FWY_PALMETTO_EB_01", "Palmetto Freeway Eastbound",
			S.CLASS_FREEWAY, CL_FWY_PALMETTO_EB)
	fpeb.one_way = true; fpeb.direction_sign = 1.0; fpeb.route_priority = 1
	out.append(fpeb)

	# --- Primary arterials ---
	out.append(_r("ART_HARBOR_01", "Harbor Boulevard", S.CLASS_PRIMARY_ARTERIAL, CL_ART_HARBOR, 1))
	out.append(_r("ART_CENTRAL_NS_01", "Central Avenue", S.CLASS_PRIMARY_ARTERIAL, CL_ART_CENTRAL_NS, 1))
	out.append(_r("ART_SOUTH_RING_01", "South Ring Road", S.CLASS_PRIMARY_ARTERIAL, CL_ART_SOUTH_RING, 1))
	out.append(_r("ART_AIRPORT_01", "Airport Approach", S.CLASS_PRIMARY_ARTERIAL, CL_ART_AIRPORT, 2))

	# --- Secondary arterials ---
	out.append(_r("ART2_RIVER_EAST_01", "River East Parkway", S.CLASS_SECONDARY_ARTERIAL, CL_ART2_RIVER_EAST, 2))
	out.append(_r("ART2_INDUSTRIAL_01", "Industrial Parkway", S.CLASS_SECONDARY_ARTERIAL, CL_ART2_INDUSTRIAL, 2))

	# --- Ramps ---
	# The legacy single ramps (RMP_HFWY_N/E/S, RMP_PALM_W) were authored
	# against the old single freeway axis; with divided carriageways they
	# crossed a carriageway at grade, which is an illegal at-grade freeway
	# crossing. They are retired, not silently kept: the ramp pairs below
	# give both directions proper access.
	out.append(_r("RMP_HARBOR_NB_OFF_01", "Harbor Fwy NB Off-Ramp",
			S.CLASS_RAMP, CL_RMP_HARBOR_NB_OFF))
	out.append(_r("RMP_HARBOR_NB_ON_01", "Harbor Fwy NB On-Ramp",
			S.CLASS_RAMP, CL_RMP_HARBOR_NB_ON))
	out.append(_r("RMP_HARBOR_SB_OFF_01", "Harbor Fwy SB Off-Ramp",
			S.CLASS_RAMP, CL_RMP_HARBOR_SB_OFF))
	out.append(_r("RMP_PALMETTO_WB_OFF_01", "Palmetto Fwy WB Off-Ramp",
			S.CLASS_RAMP, CL_RMP_PALMETTO_WB_OFF))
	out.append(_r("RMP_PALMETTO_WB_ON_01", "Palmetto Fwy WB On-Ramp",
			S.CLASS_RAMP, CL_RMP_PALMETTO_WB_ON))
	out.append(_r("RMP_PALMETTO_EB_OFF_01", "Palmetto Fwy EB Off-Ramp",
			S.CLASS_RAMP, CL_RMP_PALMETTO_EB_OFF))
	out.append(_r("RMP_PALMETTO_EB_CITY_OFF_01", "Palmetto Fwy EB City Off-Ramp",
			S.CLASS_RAMP, CL_RMP_PALMETTO_EB_CITY_OFF))
	out.append(_r("RMP_PALMETTO_WB_CITY_ON_01", "Palmetto Fwy WB City On-Ramp",
			S.CLASS_RAMP, CL_RMP_PALMETTO_WB_CITY_ON))
	out.append(_r("RMP_PALMETTO_EB_ON_01", "Palmetto Fwy EB On-Ramp",
			S.CLASS_RAMP, CL_RMP_PALMETTO_EB_ON))
	out.append(_r("RMP_HARBOR_SB_FRONT_OFF_01", "Harbor Fwy SB Frontage Off-Ramp",
			S.CLASS_RAMP, CL_RMP_HARBOR_SB_FRONT_OFF))
	out.append(_r("RMP_HARBOR_NB_AIR_OFF_01", "Harbor Fwy NB Airport Off-Ramp",
			S.CLASS_RAMP, CL_RMP_HARBOR_NB_AIR_OFF))
	out.append(_r("RMP_HARBOR_SB_N_OFF_01", "Harbor Fwy SB North Off-Ramp",
			S.CLASS_RAMP, CL_RMP_HARBOR_SB_N_OFF))
	out.append(_r("RMP_HARBOR_NB_FRONT_ON_01", "Harbor Fwy NB Frontage On-Ramp",
			S.CLASS_RAMP, CL_RMP_HARBOR_NB_FRONT_ON))

	# --- Urban collectors ---
	out.append(_r("COL_CORE_EW_01", "Core East-West Street", S.CLASS_URBAN_COLLECTOR, CL_COL_CORE_EW))
	out.append(_r("COL_CORE_SOUTH_01", "Core South Street", S.CLASS_URBAN_COLLECTOR, CL_COL_CORE_SOUTH))
	out.append(_r("COL_DOWNTOWN_01", "Downtown Street", S.CLASS_URBAN_COLLECTOR, CL_COL_DOWNTOWN_01))
	out.append(_r("COL_DOWNTOWN_02", "Downtown Cross Street", S.CLASS_URBAN_COLLECTOR, CL_COL_DOWNTOWN_02))
	out.append(_r("COL_INNER_01", "Inner City Diagonal", S.CLASS_URBAN_COLLECTOR, CL_COL_INNER_01))
	out.append(_r("COL_PARK_EDGE_01", "Park Edge Street", S.CLASS_URBAN_COLLECTOR, CL_COL_PARK_EDGE))
	out.append(_r("COL_BEACH_LINK_01", "Beach Link Street", S.CLASS_URBAN_COLLECTOR, CL_COL_BEACH_LINK))

	# --- Suburbs ---
	out.append(_r("RES_LOOP_A_01", "Suburb Loop A", S.CLASS_RESIDENTIAL, CL_RES_LOOP_A))
	var cda := _r("RES_CULDE_A_01", "Cul-de-sac A", S.CLASS_RESIDENTIAL, CL_RES_CULDE_A)
	cda.intentional_dead_end = true; cda.dead_end_marked = true
	out.append(cda)
	out.append(_r("RES_LOOP_B_01", "Suburb Loop B", S.CLASS_RESIDENTIAL, CL_RES_LOOP_B))
	var cdb := _r("RES_CULDE_B_01", "Cul-de-sac B", S.CLASS_RESIDENTIAL, CL_RES_CULDE_B)
	cdb.intentional_dead_end = true; cdb.dead_end_marked = true
	out.append(cdb)
	out.append(_r("RES_SUB_01", "Suburb Connector", S.CLASS_RESIDENTIAL, CL_RES_SUB_01))

	# --- Industrial ---
	out.append(_r("IND_YARD_A_01", "Industrial Yard Road", S.CLASS_INDUSTRIAL, CL_IND_YARD_A))
	out.append(_r("IND_SERVICE_01", "Industrial Service Road", S.CLASS_INDUSTRIAL, CL_IND_SERVICE))

	# --- Airport skeleton ---
	out.append(_r("AIR_TERMINAL_01", "Terminal Access", S.CLASS_URBAN_COLLECTOR, CL_AIR_TERMINAL))
	out.append(_r("AIR_FREIGHT_01", "Freight Access", S.CLASS_INDUSTRIAL, CL_AIR_FREIGHT))
	var airp := _r("AIR_PARKING_01", "Parking Access", S.CLASS_SERVICE, CL_AIR_PARKING)
	airp.intentional_dead_end = true; airp.dead_end_marked = true
	out.append(airp)

	# --- Military ---
	out.append(_r("MIL_PUBLIC_01", "Camp Approach Road", S.CLASS_MOUNTAIN, CL_MIL_PUBLIC))
	var mil := _r("MIL_INTERNAL_01", "Restricted Internal Road", S.CLASS_SERVICE, CL_MIL_INTERNAL)
	mil.restricted = true; mil.emergency_only = true
	mil.intentional_dead_end = true; mil.dead_end_marked = true
	out.append(mil)

	# --- Rural ---
	out.append(_r("RURAL_NORTH_01", "North Rural Road", S.CLASS_RURAL_ARTERIAL, CL_RURAL_NORTH))
	out.append(_r("RURAL_SOUTH_01", "South Rural Road", S.CLASS_RURAL_COLLECTOR, CL_RURAL_SOUTH))
	var rure := _r("RURAL_EAST_01", "East Rural Road", S.CLASS_RURAL_COLLECTOR, CL_RURAL_EAST)
	out.append(rure)

	# --- Farm / dirt ---
	out.append(_r("FARM_TRACK_A_01", "Farm Track A", S.CLASS_FARM, CL_FARM_A))
	out.append(_r("FARM_TRACK_B_01", "Farm Track B", S.CLASS_FARM, CL_FARM_B))
	out.append(_r("DIRT_SCENIC_01", "Scenic Dirt Track", S.CLASS_DIRT, CL_DIRT_SCENIC))
	var dirt2 := _r("DIRT_RIDGE_01", "Ridge Access Track", S.CLASS_DIRT, CL_DIRT_RIDGE)
	dirt2.intentional_dead_end = true; dirt2.dead_end_marked = true
	out.append(dirt2)

	# --- Mountain ---
	var mtnv2 := _r("MTN_V2_01", "South Valley Road", S.CLASS_MOUNTAIN, CL_MTN_V2)
	mtnv2.intentional_dead_end = true; mtnv2.dead_end_marked = true  # valley head terminus
	out.append(mtnv2)
	out.append(_r("MTN_V1_01", "North Valley Road", S.CLASS_MOUNTAIN, CL_MTN_V1))
	out.append(_r("MTN_V1_DESCENT_01", "Valley Switchback Descent", S.CLASS_MOUNTAIN, CL_MTN_V1_DESCENT))
	var sentinel := _r("MTN_SENTINEL_01", "Sentinel Switchback Road", S.CLASS_MOUNTAIN, CL_MTN_SENTINEL)
	sentinel.intentional_dead_end = true; sentinel.dead_end_marked = true  # summit overlook
	out.append(sentinel)
	out.append(_r("MTN_TUNNEL_WEST_01", "West Ridge Tunnel Road", S.CLASS_TUNNEL, CL_MTN_TUNNEL_WEST))
	out.append(_r("MTN_WEST_DESCENT_01", "West Descent Road", S.CLASS_MOUNTAIN, CL_MTN_WEST_DESCENT))

	# --- Coastal ---
	var cnw := _r("COAST_NW_01", "Northwest Coastal Road", S.CLASS_COASTAL, CL_COAST_NW)
	cnw.intentional_dead_end = true; cnw.dead_end_marked = true  # beach overlook terminus
	out.append(cnw)
	out.append(_r("COAST_BAY_01", "Bay Shore Road", S.CLASS_COASTAL, CL_COAST_BAY))
	var csun := _r("COAST_SUNSET_01", "Sunset Coastal Road", S.CLASS_COASTAL, CL_COAST_SUNSET)
	csun.intentional_dead_end = true; csun.dead_end_marked = true  # sunset point terminus
	out.append(csun)
	out.append(_r("COAST_MARINA_01", "Marina Access Road", S.CLASS_COASTAL, CL_COAST_MARINA))

	# --- Frontage / service ---
	out.append(_r("FRONT_HARBOR_01", "Harbor Frontage Road", S.CLASS_FRONTAGE, CL_FRONT_HARBOR))
	var svcm := _r("SVC_MARINA_01", "Marina Service Road", S.CLASS_SERVICE, CL_SVC_MARINA)
	svcm.intentional_dead_end = true; svcm.dead_end_marked = true
	out.append(svcm)
	var svcB := _r("SVC_BEACH_01", "Beach Service Road", S.CLASS_SERVICE, CL_SVC_BEACH)
	svcB.intentional_dead_end = true; svcB.dead_end_marked = true
	out.append(svcB)

	# --- Park ---
	out.append(_r("PARK_LAKE_01", "Lakeside Park Road", S.CLASS_PARK_ACCESS, CL_PARK_LAKE))

	# --- Alley ---
	var alley := _r("ALLEY_DTN_01", "Downtown Alley", S.CLASS_ALLEY, CL_ALLEY_DTN)
	alley.one_way = true
	out.append(alley)

	# --- Legacy grid migration (§61): rects -> centerlines, no geometry
	# rebuild (WBRoads keeps drawing the legacy decals).
	for leg: Dictionary in LEGACY_ROADS:
		var r: Rect2 = leg["rect"]
		var horizontal: bool = r.size.x >= r.size.y
		var cl: Array = []
		if horizontal:
			var y: float = r.position.y + r.size.y * 0.5
			cl = [Vector2(r.position.x, y), Vector2(r.end.x, y)]
		else:
			var x: float = r.position.x + r.size.x * 0.5
			cl = [Vector2(x, r.position.y), Vector2(x, r.end.y)]
		var rec := _r(str(leg["id"]), str(leg["id"]).replace("LEG_", "Legacy "),
				str(leg["cls"]), cl, 4)
		rec.notes = "legacy wb_kit rect migrated to graph (P04 §61)"
		out.append(rec)

	return out


static func roads_by_id() -> Dictionary:
	var m := {}
	for r: RoadRecord in roads():
		m[r.id] = r
	return m


static func bridge_by_id(id: String) -> Dictionary:
	for b: Dictionary in BRIDGES:
		if str(b["id"]) == id:
			return b
	return {}


static func tunnel_by_id(id: String) -> Dictionary:
	for t: Dictionary in TUNNELS:
		if str(t["id"]) == id:
			return t
	return {}
