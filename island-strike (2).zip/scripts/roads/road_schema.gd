class_name RoadSchema
extends Object
## MASTER ROAD SCHEMA (Reconstruction Prompt 04, Phase B).
## Single source of truth for road-class profiles: lanes, widths, speeds,
## grades, surfaces, policies, LOD and terrain-constraint mapping.
## The P03 terrain system is the grade authority — every class maps onto a
## Terrain.ROAD_GRADE_LIMITS key so is_road_viable() stays authoritative.
## Nothing in mesh building, lane graphs, collision or sidewalks may
## hard-code dimensions; they all read RoadDefinition records from here.

## --- Versioning (§57/§58) ---
const ROAD_SCHEMA_VERSION: int = 1
const ROAD_REVISION: String = "p04-r1"
## Terrain generation this schema was authored against. Compatibility is
## DETECTABLE: verify_terrain_contract() fingerprints the P03 river bed;
## drift means roads must be explicitly re-reviewed, never silently rebuilt.
const SOURCE_TERRAIN_REVISION: String = "p03-v2.5.1"

## --- Road classes (§5): 19 classes, shared RoadDefinition records ---
const CLASS_FREEWAY := "ROAD_FREEWAY"
const CLASS_PRIMARY_ARTERIAL := "ROAD_PRIMARY_ARTERIAL"
const CLASS_SECONDARY_ARTERIAL := "ROAD_SECONDARY_ARTERIAL"
const CLASS_URBAN_COLLECTOR := "ROAD_URBAN_COLLECTOR"
const CLASS_RESIDENTIAL := "ROAD_RESIDENTIAL"
const CLASS_INDUSTRIAL := "ROAD_INDUSTRIAL"
const CLASS_SERVICE := "ROAD_SERVICE"
const CLASS_ALLEY := "ROAD_ALLEY"
const CLASS_RURAL_ARTERIAL := "ROAD_RURAL_ARTERIAL"
const CLASS_RURAL_COLLECTOR := "ROAD_RURAL_COLLECTOR"
const CLASS_FARM := "ROAD_FARM"
const CLASS_DIRT := "ROAD_DIRT"
const CLASS_MOUNTAIN := "ROAD_MOUNTAIN"
const CLASS_COASTAL := "ROAD_COASTAL"
const CLASS_BRIDGE := "ROAD_BRIDGE"
const CLASS_TUNNEL := "ROAD_TUNNEL"
const CLASS_RAMP := "ROAD_RAMP"
const CLASS_FRONTAGE := "ROAD_FRONTAGE"
const CLASS_PARK_ACCESS := "ROAD_PARK_ACCESS"

const ALL_CLASSES: Array[String] = [
	CLASS_FREEWAY, CLASS_PRIMARY_ARTERIAL, CLASS_SECONDARY_ARTERIAL,
	CLASS_URBAN_COLLECTOR, CLASS_RESIDENTIAL, CLASS_INDUSTRIAL,
	CLASS_SERVICE, CLASS_ALLEY, CLASS_RURAL_ARTERIAL, CLASS_RURAL_COLLECTOR,
	CLASS_FARM, CLASS_DIRT, CLASS_MOUNTAIN, CLASS_COASTAL, CLASS_BRIDGE,
	CLASS_TUNNEL, CLASS_RAMP, CLASS_FRONTAGE, CLASS_PARK_ACCESS,
]

## --- Median types ---
const MEDIAN_NONE := "none"
const MEDIAN_PAINTED := "painted"
const MEDIAN_RAISED := "raised"
const MEDIAN_BARRIER := "barrier"

## --- Surface types ---
const SURF_ASPHALT := "asphalt"
const SURF_CONCRETE := "concrete"
const SURF_GRAVEL := "gravel"
const SURF_DIRT := "dirt"

## --- Terrain constraint keys (must exist in Terrain.ROAD_GRADE_LIMITS) ---
## freeway 4 / arterial 6 / collector 8 / local 10 / service 8 / rural 12 / trail 20

## --- Intersection node types (§20) ---
const JCT_SIGNAL := "SIGNAL"
const JCT_STOP := "STOP"
const JCT_YIELD := "YIELD"
const JCT_ROUNDABOUT := "ROUNDABOUT"
const JCT_MERGE := "MERGE"
const JCT_FORK := "FORK"
const JCT_FREEWAY_RAMP := "FREEWAY_RAMP"
const JCT_T_JUNCTION := "T_JUNCTION"
const JCT_CROSS := "CROSS"
const JCT_GRADE_SEPARATED := "GRADE_SEPARATED"
const JCT_DRIVEWAY_ACCESS := "DRIVEWAY_ACCESS"

const ALL_JUNCTION_TYPES: Array[String] = [
	JCT_SIGNAL, JCT_STOP, JCT_YIELD, JCT_ROUNDABOUT, JCT_MERGE, JCT_FORK,
	JCT_FREEWAY_RAMP, JCT_T_JUNCTION, JCT_CROSS, JCT_GRADE_SEPARATED,
	JCT_DRIVEWAY_ACCESS,
]

## --- Route profiles (§62) ---
const PROFILE_NORMAL := "NORMAL"
const PROFILE_FASTEST := "FASTEST"
const PROFILE_SHORT := "SHORT"
const PROFILE_EMERGENCY := "EMERGENCY"
const PROFILE_MISSION := "MISSION"
const PROFILE_PEDESTRIAN_FUTURE := "PEDESTRIAN_FUTURE"  # placeholder (§62)

const ALL_PROFILES: Array[String] = [
	PROFILE_NORMAL, PROFILE_FASTEST, PROFILE_SHORT, PROFILE_EMERGENCY,
	PROFILE_MISSION, PROFILE_PEDESTRIAN_FUTURE,
]

## --- Marking profiles (§39) — derived from lane/intersection data ---
const MARK_NONE := "none"
const MARK_CENTER_DASH := "center_dash"       # two-way undivided
const MARK_DOUBLE_CENTER := "double_center"   # two-way, no passing
const MARK_LANE_DIVIDER := "lane_divider"     # same-direction lanes
const MARK_EDGE_LINE := "edge_line"

## --- Route cost model (§25): deterministic static costs ---
## cost = length_m / class_factor + penalties. Higher factor = more attractive.
const COST_CLASS_FACTOR := {
	CLASS_FREEWAY: 1.6,
	CLASS_PRIMARY_ARTERIAL: 1.25,
	CLASS_SECONDARY_ARTERIAL: 1.1,
	CLASS_URBAN_COLLECTOR: 1.0,
	CLASS_INDUSTRIAL: 0.9,
	CLASS_COASTAL: 0.95,
	CLASS_RURAL_ARTERIAL: 1.05,
	CLASS_BRIDGE: 1.15,
	CLASS_TUNNEL: 1.1,
	CLASS_RAMP: 0.8,
	CLASS_FRONTAGE: 0.85,
	CLASS_RESIDENTIAL: 0.7,
	CLASS_SERVICE: 0.6,
	CLASS_RURAL_COLLECTOR: 0.85,
	CLASS_PARK_ACCESS: 0.55,
	CLASS_ALLEY: 0.45,
	CLASS_FARM: 0.4,
	CLASS_DIRT: 0.35,
	CLASS_MOUNTAIN: 0.6,
}
const COST_TURN_PENALTY_S := 6.0        # per signalized/stop junction crossed
const COST_TURN_PENALTY_MINOR := 2.0    # per uncontrolled junction
const COST_GRADE_PENALTY := 0.35        # per 1% of average segment grade
const COST_UTURN_PENALTY_S := 25.0
const COST_RESTRICTED_BLOCK := 1.0e9    # restricted roads: normal traffic barred
const COST_EMERGENCY_RESTRICTED := 0.0  # emergency profile may use restricted
## Profile multipliers on the class factor (FASTEST loves freeways, SHORT ignores class)
const PROFILE_FACTOR_BIAS := {
	PROFILE_NORMAL: 1.0,
	PROFILE_FASTEST: 2.0,   # factor^2 effect via squaring in RoadGraph
	PROFILE_SHORT: 0.0,     # pure distance
	PROFILE_EMERGENCY: 1.0,
	PROFILE_MISSION: 1.0,
}


## One authored road-class profile. All geometry/lane/collision systems read
## dimensions from here — never hard-code widths elsewhere (§31).
class RoadDefinition:
	var id: String = ""
	var display_name: String = ""
	var lane_count: int = 2            # total carriageway lanes (both directions)
	var lanes_per_direction: int = 1
	var lane_width: float = 3.5
	var shoulder_width: float = 1.0
	var median_type: String = MEDIAN_NONE
	var median_width: float = 0.0
	var speed_limit_kmh: float = 50.0
	var target_grade_pct: float = 3.0
	var max_grade_pct: float = 6.0
	var min_curve_radius: float = 60.0
	var surface_type: String = SURF_ASPHALT
	var divided: bool = false
	var traffic_allowed: bool = true
	var pedestrian_allowed: bool = true
	var emergency_allowed: bool = true
	var parking_allowed: bool = true
	var restricted: bool = false       # public traffic barred (military etc.)
	var sidewalk: bool = true
	var sidewalk_width: float = 2.2
	var curb: bool = true
	var curb_width: float = 0.35
	var lighting: bool = true
	var lamp_spacing_m: float = 35.0
	var drainage: String = "curb"      # curb | ditch | none
	var signage: bool = true
	var guardrail_profile: String = "auto"  # auto | always | never
	var lod_near: float = 220.0
	var lod_far: float = 1400.0
	var terrain_constraint: String = "local"  # key into Terrain.ROAD_GRADE_LIMITS
	var marking: String = MARK_CENTER_DASH

	## Full paved half-width of the carriageway (lanes + shoulders + median/2).
	func carriageway_half_width() -> float:
		return lanes_per_direction * lane_width * (2.0 if divided else 1.0) * 0.5 \
				+ shoulder_width + (median_width * 0.5 if divided else 0.0)

	## Outer half-width including curb + sidewalk when present (§31 contract).
	func total_half_width() -> float:
		var hw := carriageway_half_width()
		if curb:
			hw += curb_width
		if sidewalk:
			hw += sidewalk_width
		return hw

	func speed_limit_ms() -> float:
		return speed_limit_kmh / 3.6


static func _def(id: String, name: String) -> RoadDefinition:
	var d := RoadDefinition.new()
	d.id = id
	d.display_name = name
	return d


## The class registry (§5). Deterministic static data — no RNG.
static func class_registry() -> Dictionary:
	var reg := {}

	var f := _def(CLASS_FREEWAY, "Freeway")
	f.lane_count = 6; f.lanes_per_direction = 3; f.divided = true
	f.lane_width = 3.7; f.shoulder_width = 2.5
	f.median_type = MEDIAN_BARRIER; f.median_width = 4.0
	f.speed_limit_kmh = 105.0; f.target_grade_pct = 3.0; f.max_grade_pct = 4.0
	f.min_curve_radius = 320.0; f.surface_type = SURF_CONCRETE
	f.pedestrian_allowed = false; f.parking_allowed = false
	f.sidewalk = false; f.curb = false; f.drainage = "shoulder"
	f.lamp_spacing_m = 60.0; f.terrain_constraint = "freeway"
	f.guardrail_profile = "always"; f.lod_near = 320.0; f.lod_far = 2200.0
	f.marking = MARK_LANE_DIVIDER
	reg[CLASS_FREEWAY] = f

	var pa := _def(CLASS_PRIMARY_ARTERIAL, "Primary arterial")
	pa.lane_count = 4; pa.lanes_per_direction = 2
	pa.lane_width = 3.5; pa.shoulder_width = 0.8
	pa.median_type = MEDIAN_PAINTED; pa.median_width = 0.6
	pa.speed_limit_kmh = 65.0; pa.target_grade_pct = 4.0; pa.max_grade_pct = 6.0
	pa.min_curve_radius = 120.0; pa.sidewalk_width = 2.6
	pa.lamp_spacing_m = 32.0; pa.terrain_constraint = "arterial"
	pa.lod_near = 260.0; pa.lod_far = 1700.0
	reg[CLASS_PRIMARY_ARTERIAL] = pa

	var sa := _def(CLASS_SECONDARY_ARTERIAL, "Secondary arterial")
	sa.lane_count = 2; sa.lanes_per_direction = 1
	sa.lane_width = 3.4; sa.shoulder_width = 0.7
	sa.median_type = MEDIAN_PAINTED
	sa.speed_limit_kmh = 55.0; sa.target_grade_pct = 4.5; sa.max_grade_pct = 6.0
	sa.min_curve_radius = 80.0; sa.terrain_constraint = "arterial"
	sa.lod_near = 220.0; sa.lod_far = 1500.0
	reg[CLASS_SECONDARY_ARTERIAL] = sa

	var uc := _def(CLASS_URBAN_COLLECTOR, "Urban collector")
	uc.lane_count = 2; uc.lanes_per_direction = 1
	uc.lane_width = 3.3; uc.shoulder_width = 0.5
	uc.speed_limit_kmh = 45.0; uc.target_grade_pct = 5.0; uc.max_grade_pct = 8.0
	uc.min_curve_radius = 45.0; uc.terrain_constraint = "collector"
	reg[CLASS_URBAN_COLLECTOR] = uc

	var rs := _def(CLASS_RESIDENTIAL, "Residential street")
	rs.lane_count = 2; rs.lanes_per_direction = 1
	rs.lane_width = 3.1; rs.shoulder_width = 0.4
	rs.speed_limit_kmh = 35.0; rs.target_grade_pct = 6.0; rs.max_grade_pct = 10.0
	rs.min_curve_radius = 22.0; rs.sidewalk_width = 1.8
	rs.lamp_spacing_m = 45.0; rs.terrain_constraint = "local"
	rs.lod_near = 160.0; rs.lod_far = 900.0
	reg[CLASS_RESIDENTIAL] = rs

	var ind := _def(CLASS_INDUSTRIAL, "Industrial road")
	ind.lane_count = 2; ind.lanes_per_direction = 1
	ind.lane_width = 4.0; ind.shoulder_width = 1.2   # truck-compatible (§29)
	ind.speed_limit_kmh = 50.0; ind.target_grade_pct = 4.0; ind.max_grade_pct = 6.0
	ind.min_curve_radius = 60.0; ind.surface_type = SURF_CONCRETE
	ind.sidewalk_width = 1.6; ind.terrain_constraint = "service"
	reg[CLASS_INDUSTRIAL] = ind

	var svc := _def(CLASS_SERVICE, "Service road")
	svc.lane_count = 2; svc.lanes_per_direction = 1
	svc.lane_width = 3.0; svc.shoulder_width = 0.5
	svc.speed_limit_kmh = 40.0; svc.target_grade_pct = 5.0; svc.max_grade_pct = 8.0
	svc.min_curve_radius = 25.0; svc.sidewalk = false; svc.curb = false
	svc.drainage = "ditch"; svc.terrain_constraint = "service"
	svc.lod_near = 140.0; svc.lod_far = 800.0
	reg[CLASS_SERVICE] = svc

	var al := _def(CLASS_ALLEY, "Alley")
	al.lane_count = 1; al.lanes_per_direction = 1
	al.lane_width = 3.0; al.shoulder_width = 0.3
	al.speed_limit_kmh = 20.0; al.target_grade_pct = 6.0; al.max_grade_pct = 10.0
	al.min_curve_radius = 12.0; al.sidewalk = false; al.curb = false
	al.parking_allowed = false; al.lighting = false
	al.lod_near = 90.0; al.lod_far = 450.0
	reg[CLASS_ALLEY] = al

	var ra := _def(CLASS_RURAL_ARTERIAL, "Rural arterial")
	ra.lane_count = 2; ra.lanes_per_direction = 1
	ra.lane_width = 3.5; ra.shoulder_width = 1.2
	ra.speed_limit_kmh = 80.0; ra.target_grade_pct = 5.0; ra.max_grade_pct = 8.0
	ra.min_curve_radius = 110.0; ra.sidewalk = false; ra.curb = false
	ra.drainage = "ditch"; ra.lighting = false
	ra.terrain_constraint = "collector"; ra.lod_far = 1800.0
	ra.marking = MARK_DOUBLE_CENTER
	reg[CLASS_RURAL_ARTERIAL] = ra

	var rc := _def(CLASS_RURAL_COLLECTOR, "Rural collector")
	rc.lane_count = 2; rc.lanes_per_direction = 1
	rc.lane_width = 3.2; rc.shoulder_width = 0.9
	rc.speed_limit_kmh = 60.0; rc.target_grade_pct = 6.0; rc.max_grade_pct = 10.0
	rc.min_curve_radius = 55.0; rc.sidewalk = false; rc.curb = false
	rc.drainage = "ditch"; rc.lighting = false
	rc.terrain_constraint = "rural"; rc.lod_far = 1500.0
	reg[CLASS_RURAL_COLLECTOR] = rc

	var fm := _def(CLASS_FARM, "Farm track")
	fm.lane_count = 1; fm.lanes_per_direction = 1
	fm.lane_width = 3.4; fm.shoulder_width = 0.5
	fm.speed_limit_kmh = 40.0; fm.target_grade_pct = 8.0; fm.max_grade_pct = 12.0
	fm.min_curve_radius = 30.0; fm.surface_type = SURF_GRAVEL
	fm.sidewalk = false; fm.curb = false; fm.lighting = false
	fm.drainage = "ditch"; fm.terrain_constraint = "rural"
	fm.lod_near = 120.0; fm.lod_far = 700.0
	reg[CLASS_FARM] = fm

	var dt := _def(CLASS_DIRT, "Dirt road")
	dt.lane_count = 1; dt.lanes_per_direction = 1
	dt.lane_width = 3.0; dt.shoulder_width = 0.4
	dt.speed_limit_kmh = 35.0; dt.target_grade_pct = 10.0; dt.max_grade_pct = 16.0
	dt.min_curve_radius = 18.0; dt.surface_type = SURF_DIRT
	dt.sidewalk = false; dt.curb = false; dt.lighting = false
	dt.drainage = "ditch"; dt.terrain_constraint = "trail"
	dt.lod_near = 100.0; dt.lod_far = 600.0
	reg[CLASS_DIRT] = dt

	var mt := _def(CLASS_MOUNTAIN, "Mountain road")
	mt.lane_count = 2; mt.lanes_per_direction = 1
	mt.lane_width = 3.2; mt.shoulder_width = 0.6
	mt.speed_limit_kmh = 50.0; mt.target_grade_pct = 7.0; mt.max_grade_pct = 12.0
	mt.min_curve_radius = 24.0   # switchbacks/hairpins permitted (§67)
	mt.sidewalk = false; mt.curb = false; mt.lighting = false
	mt.drainage = "ditch"; mt.terrain_constraint = "trail"
	mt.guardrail_profile = "auto"; mt.lod_far = 1600.0
	reg[CLASS_MOUNTAIN] = mt

	var co := _def(CLASS_COASTAL, "Coastal road")
	co.lane_count = 2; co.lanes_per_direction = 1
	co.lane_width = 3.4; co.shoulder_width = 0.8
	co.speed_limit_kmh = 60.0; co.target_grade_pct = 5.0; co.max_grade_pct = 8.0
	co.min_curve_radius = 60.0; co.sidewalk = false; co.curb = false
	co.drainage = "ditch"; co.lighting = false
	co.terrain_constraint = "collector"; co.lod_far = 1700.0
	reg[CLASS_COASTAL] = co

	var br := _def(CLASS_BRIDGE, "Bridge deck")
	br.lane_count = 2; br.lanes_per_direction = 1
	br.lane_width = 3.5; br.shoulder_width = 0.8
	br.speed_limit_kmh = 65.0; br.target_grade_pct = 3.0; br.max_grade_pct = 6.0
	br.min_curve_radius = 120.0; br.surface_type = SURF_CONCRETE
	br.sidewalk = false; br.curb = false; br.drainage = "bridge"
	br.lighting = true; br.lamp_spacing_m = 45.0
	br.terrain_constraint = "arterial"; br.guardrail_profile = "always"
	br.lod_far = 2400.0   # bridges are landmarks (§16) — visible far
	reg[CLASS_BRIDGE] = br

	var tn := _def(CLASS_TUNNEL, "Tunnel bore")
	tn.lane_count = 2; tn.lanes_per_direction = 1
	tn.lane_width = 3.5; tn.shoulder_width = 0.8
	tn.speed_limit_kmh = 60.0; tn.target_grade_pct = 3.0; tn.max_grade_pct = 6.0
	tn.min_curve_radius = 100.0; tn.surface_type = SURF_CONCRETE
	tn.sidewalk = false; tn.curb = false; tn.drainage = "curb"
	tn.lighting = true; tn.lamp_spacing_m = 25.0
	tn.terrain_constraint = "arterial"; tn.lod_far = 900.0
	reg[CLASS_TUNNEL] = tn

	var rp := _def(CLASS_RAMP, "Highway ramp")
	rp.lane_count = 1; rp.lanes_per_direction = 1
	rp.lane_width = 3.6; rp.shoulder_width = 1.0
	rp.speed_limit_kmh = 55.0; rp.target_grade_pct = 4.0; rp.max_grade_pct = 7.0
	rp.min_curve_radius = 55.0; rp.surface_type = SURF_ASPHALT
	rp.sidewalk = false; rp.curb = false; rp.drainage = "shoulder"
	rp.terrain_constraint = "arterial"; rp.guardrail_profile = "always"
	rp.lod_near = 200.0; rp.lod_far = 1400.0
	reg[CLASS_RAMP] = rp

	var fr := _def(CLASS_FRONTAGE, "Frontage road")
	fr.lane_count = 2; fr.lanes_per_direction = 1
	fr.lane_width = 3.2; fr.shoulder_width = 0.6
	fr.speed_limit_kmh = 45.0; fr.target_grade_pct = 5.0; fr.max_grade_pct = 8.0
	fr.min_curve_radius = 40.0; fr.sidewalk_width = 1.8
	fr.terrain_constraint = "collector"
	fr.lod_near = 160.0; fr.lod_far = 1000.0
	reg[CLASS_FRONTAGE] = fr

	var pk := _def(CLASS_PARK_ACCESS, "Park access road")
	pk.lane_count = 2; pk.lanes_per_direction = 1
	pk.lane_width = 3.0; pk.shoulder_width = 0.5
	pk.speed_limit_kmh = 30.0; pk.target_grade_pct = 6.0; pk.max_grade_pct = 10.0
	pk.min_curve_radius = 20.0; pk.surface_type = SURF_GRAVEL
	pk.sidewalk = false; pk.curb = false; pk.lighting = false
	pk.drainage = "ditch"; pk.terrain_constraint = "local"
	pk.lod_near = 120.0; pk.lod_far = 700.0
	reg[CLASS_PARK_ACCESS] = pk
	return reg


static func get_def(class_id: String) -> RoadDefinition:
	return class_registry()[class_id]


## Terrain-compatibility fingerprint (§58): cheap deterministic checksum of the
## P03 river-bed contract. If the terrain changes materially this drifts and
## road compatibility is DETECTABLE instead of silently assumed.
static func terrain_fingerprint() -> int:
	var levels: PackedFloat64Array = WorldTerrain.river_bed_levels()
	var acc: int = 0
	for i in range(levels.size()):
		acc = (acc * 31 + int(round(levels[i] * 100.0))) & 0x7FFFFFFF
	return acc
