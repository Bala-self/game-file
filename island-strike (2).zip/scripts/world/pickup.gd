extends Area3D
const EconomyRes := preload("res://scripts/core/economy.gd")
## Pickup: money or ammo dropped by defeated NPCs. Magnet-free, touch to collect.

var kind: String = "money"
var amount: int = 50
var _spin: float = 0.0


static func create(p_kind: String, p_amount: int) -> Area3D:
	var a = Area3D.new()
	a.set_script(load("res://scripts/world/pickup.gd"))
	a.set("kind", p_kind)
	a.set("amount", p_amount)
	return a


func _ready() -> void:
	collision_layer = 16
	collision_mask = 2
	monitoring = true
	var col = CollisionShape3D.new()
	var s = SphereShape3D.new()
	s.radius = 0.9
	col.shape = s
	add_child(col)
	var mesh_inst = MeshInstance3D.new()
	var bm = BoxMesh.new()
	bm.size = Vector3(0.45, 0.45, 0.45)
	var m = StandardMaterial3D.new()
	if kind == "money":
		m.albedo_color = Color(0.95, 0.8, 0.2)
		m.emission_enabled = true
		m.emission = Color(0.6, 0.45, 0.05)
	else:
		m.albedo_color = Color(0.3, 0.7, 0.35)
		m.emission_enabled = true
		m.emission = Color(0.1, 0.4, 0.1)
	bm.material = m
	mesh_inst.mesh = bm
	add_child(mesh_inst)
	body_entered.connect(_on_body)


func _process(delta: float) -> void:
	_spin += delta * 2.4
	rotate_y(delta * 2.4)


func _on_body(body: Node3D) -> void:
	if not body.is_in_group("player"):
		return
	if kind == "money":
		EconomyRes.earn(amount, "pickup")
		GameState.notify("+$%d" % amount)
	elif kind == "ammo":
		var player = get_tree().get_first_node_in_group("player")
		if player and player.pistol:
			player.pistol.add_ammo(amount)
			GameState.notify("+%d ammo" % amount)
	var snd = AudioStreamPlayer.new()
	snd.stream = load("res://assets/audio/pickup.wav")
	snd.volume_db = -6.0
	get_tree().current_scene.add_child(snd)
	snd.play()
	var t = get_tree().create_timer(0.4)
	t.timeout.connect(snd.queue_free)
	set_deferred("monitoring", false)
	queue_free()
