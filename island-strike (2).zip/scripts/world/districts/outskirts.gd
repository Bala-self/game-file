class_name WBDOutskirts
extends Object
## Outskirt transition strips bridging suburbs/farmland/industrial edges.

const K := preload("res://scripts/world/wb_kit.gd")
const A := preload("res://scripts/world/wb_arch.gd")

static func _build_outskirts(root: Node3D) -> void:
	# workshops / small commerce along the south link road — block transition
	# Fixed: avoid road at x=173 (industrial access) — use road_point_free check
	var count: int = 0
	for i in range(7):
		var p: Vector2 = Vector2(90 + i * 26.0, 128.0)
		if not K._road_point_free(p, 10.0):
			continue
		if count >= 3:
			break
		var age_choices: Array = ["new", "middle", "old"]
		var age: String = age_choices[i % 3]
		A._building(root, p, Vector3(12, 5, 9),
				{"style": "plaster", "ground": "shop", "name": "OutskirtShop", "age": age, "ac": 1}, K.rng_global)
		K._box(root, Vector3(1.2, 1.0, 0.8), p + Vector2(0, -5), 1.0, Color(0.3, 0.35, 0.28), false, "OutDumpster")
		count += 1
	# storage sheds at the farmland shoulder — rural block
	for i in range(4):
		var p: Vector2 = Vector2(-160 + i * 40.0, 120.0)
		K._box(root, Vector3(10, 4.5, 8), p, 4.5, Color(0.55, 0.5, 0.42), true, "OutskirtShed")
		K._box(root, Vector3(11, 1.0, 9), p, 5.2, Color(0.4, 0.3, 0.2), false)
		K._box(root, Vector3(0.8, 0.8, 0.8), p + Vector2(5, 2), 0.8, Color(0.8, 0.7, 0.35), true, "HayBale")
	# Dirt lots and abandoned car
	K._decal_box(root, Vector3(20, 0.05, 15), Vector2(0, 130), 0.05, Color(0.5, 0.45, 0.35), "DirtLot")
	K._box(root, Vector3(2.0, 0.85, 4.4), Vector2(5, 132), 0.85, Color(0.35, 0.32, 0.30), true, "AbandonedCar")
	# Utility — power lines along outskirts
	for px in range(-100, 200, 30):
		K._box(root, Vector3(0.3, 6, 0.3), Vector2(px, 145), 6.0, Color(0.45, 0.42, 0.38), false, "PowerPole")
		if px < 170:
			K._box(root, Vector3(30, 0.15, 0.15), Vector2(px+15, 145), 7.5, Color(0.25, 0.25, 0.26), false, "PowerLine")


## Facade helper: adds window bands (emissive at night) + rooftop machinery.
