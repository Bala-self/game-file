class_name WBDInteriors
extends Object
## Fixed enterable interiors: downtown storefronts, harbor office, warehouse + hidden.

const K := preload("res://scripts/world/wb_kit.gd")
const A := preload("res://scripts/world/wb_arch.gd")

static func _build_interiors(root: Node3D) -> void:
	var kits: Array = ["shop", "bar", "shop", "office", "house", "bar", "medical", "school"]
	var spots: Array = [
		[Vector2(-253, -160), 3], [Vector2(-253, -200), 3], [Vector2(-253, -240), 3],
		[Vector2(-281, -160), 1], [Vector2(-281, -200), 1], [Vector2(-281, -240), 1],
		[Vector2(-200, -140), 0], [Vector2(-180, -140), 0],
	]
	for i in range(spots.size()):
		var xz: Vector2 = spots[i][0]
		var kit: String = kits[i % kits.size()]
		A._build_interior_building(root, xz, Vector2(10, 8), 4.5, Color(0.5, 0.42, 0.36),
				kit, "Store", spots[i][1])
		K._decal_box(root, Vector3(3.4, 0.8, 0.2), xz + (Vector2(-5.3, 0) if spots[i][1] == 3
				else Vector2(5.3, 0)), 4.0, Color(0.9, 0.6, 0.15), "StoreSign")
	A._build_interior_building(root, Vector2(-560, 230), Vector2(8, 6), 3.6,
			Color(0.55, 0.58, 0.62), "office", "HarborOffice", 3)
	A._build_interior_building(root, Vector2(420, 270), Vector2(24, 16), 8.0,
			Color(0.45, 0.42, 0.4), "warehouse", "Warehouse", 3)
	# Hidden interiors — speakeasy bar behind downtown, abandoned house
	A._build_interior_building(root, Vector2(-340, -150), Vector2(8, 6), 3.2,
			Color(0.35, 0.28, 0.22), "bar", "Speakeasy", 1)
	K._decal_box(root, Vector3(0.8, 1.8, 0.2), Vector2(-336, -150), 1.8, Color(0.15, 0.12, 0.10), "HiddenDoor")
	A._build_interior_building(root, Vector2(-380, 200), Vector2(9, 7), 4.5,
			Color(0.45, 0.42, 0.38), "house", "AbandonedHouse", 0)
	K._box(root, Vector3(1.2, 0.8, 1.2), Vector2(-378, 198), 0.8, Color(0.2, 0.42, 0.2), false, "Overgrowth")
	A._build_interior_building(root, Vector2(100, -180), Vector2(7, 6), 3.0,
			Color(0.6, 0.6, 0.62), "house", "Garage", 2)
