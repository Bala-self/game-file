class_name WBDSuburbs
extends Object
## Suburban residential fabric (house palette, gardens, interiors).

const K := preload("res://scripts/world/wb_kit.gd")
const A := preload("res://scripts/world/wb_arch.gd")

static func _build_suburbs(root: Node3D, rng: RandomNumberGenerator) -> void:
	var placed: int = 0
	for i in range(60):
		if placed >= 22:
			break
		var xz = Vector2(rng.randf_range(-90, 235), rng.randf_range(-250, -95))
		if not K._road_point_free(xz, 14.0):
			continue
		var near_service: bool = false
		for s: Vector2 in [Vector2(K.GAS_SPOT.x, K.GAS_SPOT.z), K.SCHOOL_SPOT, K.HOSPITAL_SPOT]:
			if xz.distance_to(s) < 22.0:
				near_service = true
		if near_service:
			continue
		var col: Color = K.HOUSE_PALETTE[placed % K.HOUSE_PALETTE.size()]
		var age_choices: Array = ["new", "middle", "old"]
		var age: String = age_choices[rng.randi() % age_choices.size()]
		if placed % 2 == 1:
			var hbody = A._build_interior_building(root, xz, Vector2(9, 7), 5.5, col,
					"house", "House", 0)
			hbody.set_meta("kind", "house")
			hbody.set_meta("age", age)
			A._building_detail(root, Vector3(9, 5.5, 7), xz, 5.5, 1)
		else:
			var body = K._box(root, Vector3(9, 5.5, 7), xz, 5.5, col)
			K._box(root, Vector3(10, 2.2, 8), xz, 7.7, Color(0.45, 0.28, 0.2), false)
			K._box(root, Vector3(1.4, 2.4, 0.2), xz + Vector2(0, 3.6), 2.4, Color(0.35, 0.25, 0.15), false)
			A._building_detail(root, Vector3(9, 5.5, 7), xz, 5.5, 1)
			body.set_meta("kind", "house")
			body.set_meta("age", age)
		# Residential details — yards, fences, driveways, mailboxes, backyard
		if rng.randf() < 0.6:
			K._bush(root, xz + Vector2(rng.randf_range(-6, 6), 7.0), rng)
		# Driveway
		K._decal_box(root, Vector3(3.2, 0.05, 6.0), xz + Vector2(0, 6.5), 0.05, Color(0.5, 0.5, 0.52), "Driveway")
		# Mailbox (suburbs signature)
		K._box(root, Vector3(0.3, 1.1, 0.25), xz + Vector2(3.5, 6.0), 1.1, Color(0.2, 0.25, 0.55), false, "Mailbox")
		# Fence segments — back and sides
		for fx in [-4.5, 4.5]:
			K._box(root, Vector3(0.15, 1.0, 7.0), xz + Vector2(fx, -1.0), 1.0, Color(0.85, 0.82, 0.75), false, "Fence")
		K._box(root, Vector3(9.0, 1.0, 0.15), xz + Vector2(0, -4.5), 1.0, Color(0.85, 0.82, 0.75), false, "Fence")
		# Backyard — grill, patio
		if rng.randf() < 0.4:
			K._box(root, Vector3(0.8, 0.6, 0.6), xz + Vector2(-2, -5), 0.6, Color(0.15, 0.15, 0.16), false, "Grill")
			K._decal_box(root, Vector3(4, 0.05, 4), xz + Vector2(0, -5), 0.05, Color(0.55, 0.52, 0.48), "Patio")
		# Trash bins
		K._box(root, Vector3(0.6, 0.8, 0.6), xz + Vector2(4, -3), 0.8, Color(0.25, 0.28, 0.25), false, "TrashBin")
		placed += 1
	# Suburbs block — cul-de-sac and park
	var cul_xz: Vector2 = Vector2(50, -180)
	K._decal_box(root, Vector3(18, 0.06, 18), cul_xz, 0.06, Color(0.45, 0.45, 0.48), "CulDeSac")
	# Street light at cul-de-sac
	K._box(root, Vector3(0.2, 4.5, 0.2), cul_xz + Vector2(0, 8), 4.5, Color(0.5, 0.5, 0.52), false, "CulLight")
