class_name WBDPark
extends Object
## Central park: lawns, oaks, bushes, rocks, pond, paths.

const K := preload("res://scripts/world/wb_kit.gd")
const A := preload("res://scripts/world/wb_arch.gd")

static func _build_park(root: Node3D, rng: RandomNumberGenerator) -> void:
	K._decal_box(root, Vector3(150, 0.04, 170), Vector2(-20, 30), 0.035, Color(0.35, 0.58, 0.3), "Park")
	# audit #22: the pond is now a proper lake — bed, water, stone rim and a
	# walkable wooden footbridge (named LakeBridge for QA). Geometry only:
	# world_data contract untouched.
	K._decal_box(root, Vector3(46, 0.04, 46), Vector2(-30, 40), 0.05,
			Color(0.42, 0.38, 0.3), "LakeBed")
	K._cyl(root, 19.0, 0.5, Vector2(-30, 40), 0.34, Color(0.2, 0.38, 0.52), false, 24)
	for st in range(10):
		var ang = TAU * float(st) / 10.0
		K._box(root, Vector3(1.7, 1.0, 1.3),
				Vector2(-30, 40) + Vector2(cos(ang), sin(ang)) * 20.6, 0.5,
				Color(0.45, 0.44, 0.42), true, "LakeRock")
	# footbridge across the lake on the E-W axis (steps at both ends)
	K._box(root, Vector3(46, 0.25, 2.6), Vector2(-30, 40), 0.95,
			Color(0.5, 0.38, 0.24), true, "LakeBridge")
	for rz in [-1.15, 1.15]:
		K._box(root, Vector3(46, 0.09, 0.09), Vector2(-30, 40 + rz), 1.55,
				Color(0.42, 0.32, 0.2), false, "LakeRail")
	for px in [-50, -38, -22, -10]:
		for pz in [-1.15, 1.15]:
			K._box(root, Vector3(0.14, 1.4, 0.14), Vector2(float(px), 40 + pz), 1.45,
					Color(0.45, 0.35, 0.22), false, "LakePost")
	for sgn in [-1, 1]:
		for i in range(2):
			K._box(root, Vector3(2.6, 0.22, 2.6),
					Vector2(-30 + sgn * (23.0 + i * 1.0), 40), 0.68 - i * 0.3,
					Color(0.5, 0.38, 0.24), true, "LakeStep")
	for i in range(10):
		var txz = Vector2(rng.randf_range(-90, 50), rng.randf_range(-50, 110))
		if K._road_point_free(txz, 8.0) and txz.distance_to(Vector2(-30, 40)) > 24.0:
			K._oak(root, txz, rng)  # keeps clear of the lake
	for i in range(4):
		K._box(root, Vector3(2.4, 0.8, 2.4), Vector2(-60 + i * 30, 90), 0.8, Color(0.5, 0.5, 0.48))
	# park benches
	for i in range(5):
		K._box(root, Vector3(2.2, 0.5, 0.7), Vector2(-70 + i * 32, 55), 0.55,
				Color(0.5, 0.36, 0.22), false, "Bench")
	# scattered rocks and bushes
	for i in range(12):
		var rxz = Vector2(rng.randf_range(-95, 55), rng.randf_range(-55, 115))
		if K._road_point_free(rxz, 8.0) and rxz.distance_to(Vector2(-30, 40)) > 23.0:
			if rng.randf() < 0.5:
				K._rock(root, rxz, rng)
			else:
				K._bush(root, rxz, rng)
