class_name WBEnv
extends Object
## Environment, ground slab, ocean and service points (shop/gas/
## safehouse/property anchors).

const K := preload("res://scripts/world/wb_kit.gd")
const A := preload("res://scripts/world/wb_arch.gd")
const WorldTerrain := preload("res://scripts/world/terrain.gd")

static func _setup_environment(root: Node3D) -> void:
	var env: Environment = Environment.new()
	var sky_mat: ProceduralSkyMaterial = ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.24, 0.47, 0.75)
	sky_mat.sky_horizon_color = Color(0.68, 0.75, 0.82)
	# Round 11: BELOW-HORIZON sky band — the procedural sky's lower hemisphere
	# renders wherever no geometry covers the lower half of the view (open sea
	# west of the marina): dark slate matches deep water; was near-white and
	# read as an endless white plain (rendered, qa_marina.png).
	sky_mat.ground_bottom_color = Color(0.09, 0.12, 0.14)
	sky_mat.ground_horizon_color = Color(0.68, 0.75, 0.82)
	# Round 10 E3: star cover - alpha driven by the night factor in game.gd
	sky_mat.sky_cover = load("res://assets/textures/stars.png")
	var sky: Sky = Sky.new()
	sky.sky_material = sky_mat
	env.background_mode = Environment.BG_SKY
	# Round 11: filmic tonemap — highlights roll off instead of clipping
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	# Round 11: Compatibility's sky ambient injects near-full sky radiance;
	# grounding it keeps bright surfaces from clipping (measured ladder:
	# ambient 0 -> pixel 0.32; ambient 0.35 -> 1.0 clip)
	env.ambient_light_sky_contribution = 0.45
	env.ambient_light_energy = 1.0
	env.fog_enabled = true
	env.fog_density = 0.0035
	env.fog_light_color = Color(0.75, 0.8, 0.85)
	var we: WorldEnvironment = WorldEnvironment.new()
	we.environment = env
	we.name = "WorldEnv"
	root.add_child(we)

	var sun: DirectionalLight3D = DirectionalLight3D.new()
	sun.name = "Sun"
	sun.rotation_degrees = Vector3(-52, 35, 0)
	sun.light_energy = 1.2
	sun.shadow_enabled = true
	# Round 11: shadow distance capped — the shadow pass re-draws every caster
	# in range; 140 m covers all near-field shadows without doubling the cost
	# of the whole mid-map (measured: draw calls scale with this directly).
	sun.directional_shadow_max_distance = 140.0
	sun.shadow_blur = 1.2
	root.add_child(sun)

## Round 10 E1: world-space grass variation - two greens + dry/dirt patches
## from deterministic value noise (visual only; same geometry as before).
const GRASS_SHADER := """
shader_type spatial;
uniform vec3 horizon_col : source_color = vec3(0.55, 0.63, 0.72);
varying vec3 v_w;
void vertex() { v_w = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz; }
float hash21(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float vnoise(vec2 p) {
	vec2 i = floor(p); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);
	return mix(mix(hash21(i), hash21(i + vec2(1.0, 0.0)), f.x),
			mix(hash21(i + vec2(0.0, 1.0)), hash21(i + vec2(1.0, 1.0)), f.x), f.y);
}
void fragment() {
	float n1 = vnoise(v_w.xz * 0.045);
	float n2 = vnoise(v_w.xz * 0.012);
	vec3 grass = mix(vec3(0.30, 0.47, 0.23), vec3(0.40, 0.58, 0.31), n1);
	grass = mix(grass, vec3(0.48, 0.53, 0.28), smoothstep(0.60, 0.85, n2));
	// Round 11: same manual haze as the ocean — the island lawn seen at
	// grazing angle from the shore clipped toward white (Compatibility
	// renders no filmic rolloff); far grass now eases into the horizon tone.
	float dist = length(v_w - CAMERA_POSITION_WORLD);
	float haze = clamp((dist - 200.0) / 800.0, 0.0, 1.0);
	grass = mix(grass, horizon_col, haze * haze * (3.0 - 2.0 * haze));
	ALBEDO = grass;
	ROUGHNESS = 1.0;
}
"""

## Round 10 E2: ocean wave shader - GPU vertex bob + shore foam band where
## the water meets the sand rect (deterministic phase from world position).
const OCEAN_SHADER := """
shader_type spatial;
render_mode blend_mix, cull_disabled, specular_schlick_ggx, fog_disabled;
uniform vec4 base_col : source_color = vec4(0.09, 0.30, 0.47, 0.88);
uniform vec4 foam_col : source_color = vec4(0.92, 0.96, 0.97, 0.9);
uniform vec3 horizon_col : source_color = vec3(0.55, 0.63, 0.72);
varying vec3 v_w;
varying float v_shore;
void vertex() {
	vec3 w = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	float wave = sin(w.x * 0.10 + TIME * 1.4) * 0.13
			+ sin(w.z * 0.085 - TIME * 1.8) * 0.11
			+ sin((w.x + w.z) * 0.045 + TIME * 0.8) * 0.09;
	vec3 p = VERTEX;
	p.y += wave;
	VERTEX = p;
	v_w = (MODEL_MATRIX * vec4(p, 1.0)).xyz;
	float dx = max(abs(v_w.x) - 560.0, 0.0);
	float dz = max(abs(v_w.z) - 450.0, 0.0);
	v_shore = 1.0 - clamp(length(vec2(dx, dz)) / 70.0, 0.0, 1.0);
}
void fragment() {
	float foam = v_shore * v_shore * (0.55 + 0.45 * sin(TIME * 2.2 + v_w.x * 0.2 + v_w.z * 0.17));
	vec3 col = mix(base_col.rgb, foam_col.rgb, clamp(foam, 0.0, 1.0));
	// Round 11: scene fog saturates over open sea into a near-white plain
	// (rendered, qa_marina.png) — fog is disabled on this material and the
	// horizon haze is blended manually so the sea keeps its color near shore
	// and merges into the sky exactly at the horizon.
	float dist = length(v_w - CAMERA_POSITION_WORLD);
	// keep deep blue until 250 m, then ease to the horizon tone over ~1 km
	float haze = clamp((dist - 250.0) / 900.0, 0.0, 1.0);
	col = mix(col, horizon_col, haze * haze * (3.0 - 2.0 * haze));
	ALBEDO = col;
	ALPHA = mix(base_col.a, foam_col.a, clamp(foam, 0.0, 1.0));
	ROUGHNESS = 0.5;
	METALLIC = 0.0;
	SPECULAR = 0.25;
}
"""

static func _build_ground(root: Node3D) -> void:
	# Round 11: sand darkened — 0.82 albedo + full sun + ambient clipped to
	# white in linear tonemap (rendered: the whole shore read as a white plain)
	K._box(root, Vector3(K.SAND.size.x, 4.0, K.SAND.size.y), K.SAND.get_center(), 0.0,
			Color(0.64, 0.58, 0.44), true, "GroundSand")
	var grass = K._decal_box(root, Vector3(K.ISLAND.size.x, 0.03, K.ISLAND.size.y),
			K.ISLAND.get_center(), 0.02, Color(0.42, 0.62, 0.34), "GrassBase")
	var gm = Shader.new()
	gm.code = GRASS_SHADER
	var gmat = ShaderMaterial.new()
	gmat.shader = gm
	grass.material_override = gmat  # Round 10 E1
	K._decal_box(root, Vector3(300, 0.04, 330), Vector2(-255, -120), 0.03,
			Color(0.55, 0.56, 0.56), "DowntownConcrete")
	K._decal_box(root, Vector3(K.FARM.size.x, 0.04, K.FARM.size.y), K.FARM.get_center(), 0.03,
			Color(0.6, 0.55, 0.3), "FarmSoil")

static func _build_water(root: Node3D) -> void:
	var water = MeshInstance3D.new()
	water.name = "Ocean"
	var mesh: PlaneMesh = PlaneMesh.new()
	mesh.size = Vector2(6000, 6000)
	var om = Shader.new()
	om.code = OCEAN_SHADER
	var m = ShaderMaterial.new()
	m.shader = om  # Round 10 E2: waves + shore foam
	mesh.material = m
	water.mesh = mesh
	water.position = Vector3(0, K.WATER_Y, 0)
	root.add_child(water)
	# static offshore boat prop (marina)
	var hull = K._box(root, Vector3(2.4, 1.6, 7.0), Vector2(-600, 205), 0.2,
			Color(0.9, 0.9, 0.95), false, "BoatHull")
	var cabin = K._box(root, Vector3(1.8, 1.0, 2.2), Vector2(-600, 207), 1.4,
			Color(0.75, 0.78, 0.85), false, "BoatCabin")
	hull.add_to_group("props")
	cabin.add_to_group("props")

## P03 §10: inland water surfaces. The ocean plane only exists at WATER_Y, so
## the river (carved far above sea level in the highlands) and the lake need
## their own surface meshes. Visual only — no collision (P08 owns interaction).
static func _build_inland_water(root: Node3D) -> void:
	var mat = StandardMaterial3D.new()
	mat.albedo_color = Color(0.16, 0.34, 0.44, 0.9)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.roughness = 0.12
	mat.metallic = 0.15
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	# --- river: strip along the authored polyline, 4 subdivisions per reach ---
	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var left: Array[Vector3] = []
	var right: Array[Vector3] = []
	var pts: Array = WorldTerrain.river_centerline(4)
	for p: Dictionary in pts:
		var c: Vector3 = p["center"]
		var n: Vector2 = p["side"]
		var w: float = float(p["half_w"]) * 0.85  # stay inside the bank line
		left.append(Vector3(c.x - n.x * w, float(p["level"]) + 0.03, c.z - n.y * w))
		right.append(Vector3(c.x + n.x * w, float(p["level"]) + 0.03, c.z + n.y * w))
	for i in range(left.size() - 1):
		st.add_vertex(left[i])
		st.add_vertex(right[i])
		st.add_vertex(right[i + 1])
		st.add_vertex(left[i])
		st.add_vertex(right[i + 1])
		st.add_vertex(left[i + 1])
	st.generate_normals()
	var river = MeshInstance3D.new()
	river.name = "RiverWater"
	river.mesh = st.commit()
	river.material_override = mat
	root.add_child(river)
	# --- lake: fan disc clipped to the shoreline (terrain < water level) ---
	var lt = SurfaceTool.new()
	lt.begin(Mesh.PRIMITIVE_TRIANGLES)
	var lv: float = TerrainAuthoring.LAKE_LEVEL_M + 0.03
	var c := TerrainAuthoring.LAKE_CENTER
	for k in range(32):
		var a0: float = TAU * float(k) / 32.0
		var a1: float = TAU * float(k + 1) / 32.0
		var r0: float = _shore_radius(c, a0, lv)
		var r1: float = _shore_radius(c, a1, lv)
		if r0 <= 0.0 or r1 <= 0.0:
			continue
		lt.add_vertex(Vector3(c.x, lv, c.y))
		lt.add_vertex(Vector3(c.x + cos(a0) * r0, lv, c.y + sin(a0) * r0))
		lt.add_vertex(Vector3(c.x + cos(a1) * r1, lv, c.y + sin(a1) * r1))
	lt.generate_normals()
	var lake = MeshInstance3D.new()
	lake.name = "LakeWater"
	lake.mesh = lt.commit()
	lake.material_override = mat
	root.add_child(lake)


## First radius along `ang` from the lake center where terrain rises through
## the water level (fan edge), capped at 1.4x lake radius. -1 if never.
static func _shore_radius(c: Vector2, ang: float, level: float) -> float:
	var r: float = 20.0
	while r < TerrainAuthoring.LAKE_RADIUS_M * 1.4:
		var h: float = WorldTerrain.height_at(c.x + cos(ang) * r, c.y + sin(ang) * r)
		if h > level:
			return r - 10.0
		r += 10.0
	return -1.0


static func _build_service_points(root: Node3D) -> void:
	# Weapon shop: distinct storefront + sign at K.SHOP_SPOT
	var s: Vector2 = Vector2(K.SHOP_SPOT.x, K.SHOP_SPOT.z)
	A._build_interior_building(root, s + Vector2(0, -8), Vector2(14, 12), 7.0, Color(0.35, 0.3, 0.42), "shop", "GunShop", 0)
	K._decal_box(root, Vector3(6, 1.2, 0.2), s + Vector2(0, -2.1), 5.6, Color(0.9, 0.75, 0.1), "ShopSign")
	var shop_light = OmniLight3D.new()
	shop_light.light_color = Color(1, 0.8, 0.4)
	shop_light.omni_range = 9.0
	shop_light.light_energy = 1.2
	shop_light.position = Vector3(s.x, 4.0, s.y)
	shop_light.add_to_group("street_lamps")
	root.add_child(shop_light)
	# Safehouse: house + door marker at K.SAFEHOUSE_SPOT
	var sh: Vector2 = Vector2(K.SAFEHOUSE_SPOT.x, K.SAFEHOUSE_SPOT.z)
	A._build_interior_building(root, sh + Vector2(0, -7), Vector2(12, 10), 6.0, Color(0.75, 0.65, 0.5), "house", "Safehouse", 0)
	K._box(root, Vector3(13, 1.6, 11), sh + Vector2(0, -7), 7.6, Color(0.4, 0.28, 0.2), false)
	K._decal_box(root, Vector3(1.6, 2.6, 0.2), sh, 2.6, Color(0.3, 0.2, 0.12), "SafehouseDoor")


## Round 10 E5: MultiMesh grass tufts — two crossed quads, one shared mesh,
## deterministic scatter (park + farmland, 600 instances, budget-safe).
const TUFT_SHADER := """
shader_type spatial;
render_mode cull_disabled;
varying float v_h;
void vertex() {
	v_h = VERTEX.y;
	float ph = float(INSTANCE_ID) * 1.37;
	VERTEX.x += sin(TIME * 1.7 + ph) * VERTEX.y * 0.22;
	VERTEX.z += cos(TIME * 1.3 + ph) * VERTEX.y * 0.16;
}
void fragment() {
	ALBEDO = mix(vec3(0.30, 0.50, 0.22), vec3(0.48, 0.66, 0.32), v_h * 1.4);
	ROUGHNESS = 1.0;
}
"""

static func _tuft_mesh() -> ArrayMesh:
	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var q: float = 0.55  # tuft width
	var h: float = 0.55
	for ang in [0.0, PI / 2.0]:
		var dx = cos(ang) * q * 0.5
		var dz = sin(ang) * q * 0.5
		var bl: Vector3 = Vector3(-dx, 0, -dz)
		var br: Vector3 = Vector3(dx, 0, dz)
		var tl: Vector3 = Vector3(-dx * 0.4, h, -dz * 0.4)
		var tr: Vector3 = Vector3(dx * 0.4, h, dz * 0.4)
		for tri in [[bl, br, tr], [bl, tr, tl]]:
			st.add_vertex(tri[0])
			st.add_vertex(tri[1])
			st.add_vertex(tri[2])
	return st.commit()

static func _build_vegetation(root: Node3D) -> void:
	# Ecological layers — ground cover + shrubs + trees + canopy, not just grass
	var mesh = _tuft_mesh()
	var shader = Shader.new()
	shader.code = TUFT_SHADER
	var mat = ShaderMaterial.new()
	mat.shader = shader
	var rng = RandomNumberGenerator.new()
	rng.seed = 19041604
	# Ground cover — grass tufts (park + farmland + forest floor)
	for field in [[Rect2(-95, -55, 150, 170), 300, Vector2(-30, 40), 24.0],
			[Rect2(-400, 140, 280, 160), 300, Vector2.ZERO, 0.0],
			[Rect2(-200, -450, 400, 150), 250, Vector2.ZERO, 0.0]]: # forest floor north
		var rect: Rect2 = field[0]
		var mm: MultiMesh = MultiMesh.new()
		mm.transform_format = MultiMesh.TRANSFORM_3D
		mm.mesh = mesh
		var placed: Array[Transform3D] = []
		while placed.size() < int(field[1]):
			var p: Vector3 = Vector3(
					rng.randf_range(rect.position.x, rect.end.x), 0.0,
					rng.randf_range(rect.position.y, rect.end.y))
			if field[3] > 0.0 \
					and Vector2(p.x, p.z).distance_to(field[2]) < field[3]:
				continue
			# Check road free
			if not K._road_point_free(Vector2(p.x, p.z), 3.0):
				continue
			var t = Transform3D(Basis(Vector3.UP, rng.randf_range(0.0, TAU))
					.scaled(Vector3.ONE * rng.randf_range(0.7, 1.4)), p)
			placed.append(t)
		mm.instance_count = placed.size()
		for i in range(placed.size()):
			mm.set_instance_transform(i, placed[i])
		var mmi = MultiMeshInstance3D.new()
		mmi.name = "GrassField"
		mmi.add_to_group("grass_fields")
		mmi.multimesh = mm
		mmi.material_override = mat
		mmi.position = Vector3.ZERO
		root.add_child(mmi)
	# Shrub layer — bushes scattered in park, suburbs, industrial edges
	for i in range(25):
		var pxz = Vector2(rng.randf_range(-120, 60), rng.randf_range(-80, 120))
		if K._road_point_free(pxz, 5.0):
			K._bush(root, pxz, rng)
	for i in range(15):
		var pxz = Vector2(rng.randf_range(-400, -100), rng.randf_range(100, 300))
		if K._road_point_free(pxz, 5.0):
			K._bush(root, pxz, rng)
	# Tree layer — oaks in park, pines north, palms beach
	for i in range(12):
		var pxz = Vector2(rng.randf_range(-90, 50), rng.randf_range(-50, 110))
		if K._road_point_free(pxz, 8.0) and pxz.distance_to(Vector2(-30,40)) > 24.0:
			K._oak(root, pxz, rng)
	for i in range(18):
		var pxz = Vector2(rng.randf_range(-300, 300), rng.randf_range(-500, -300))
		if K._road_point_free(pxz, 9.0):
			var h = WorldTerrain.height_at(pxz.x, pxz.y)
			if h > 8.0:
				K._pine(root, pxz, rng)
	# Canopy layer — clusters for forest density north
	for i in range(8):
		var cluster_x = rng.randf_range(-250, 250)
		var cluster_z = rng.randf_range(-480, -320)
		for j in range(5):
			var pxz = Vector2(cluster_x + rng.randf_range(-15,15), cluster_z + rng.randf_range(-15,15))
			if K._road_point_free(pxz, 7.0):
				K._pine(root, pxz, rng)

## Round 10 E6: landmarks — rotating ferris wheel (Beachfront) and a radio
## tower with a blinking beacon (Industrial ridge).
static func _build_landmarks(root: Node3D) -> void:
	# ferris wheel: A-frame + axle + spinning 12 m wheel of gondolas
	var wxz: Vector2 = Vector2(-505, -40)
	K._box(root, Vector3(0.8, 9.0, 0.8), wxz + Vector2(-3.2, 0), 4.5,
			Color(0.75, 0.3, 0.25), true, "FerrisLeg")
	K._box(root, Vector3(0.8, 9.0, 0.8), wxz + Vector2(3.2, 0), 4.5,
			Color(0.75, 0.3, 0.25), true, "FerrisLeg")
	var axle = MeshInstance3D.new()
	var am = CylinderMesh.new()
	am.top_radius = 0.3
	am.bottom_radius = 0.3
	am.height = 6.4
	am.material = StandardMaterial3D.new()
	am.material.albedo_color = Color(0.55, 0.55, 0.58)
	am.material.metallic = 0.7
	axle.mesh = am
	axle.rotation_degrees = Vector3(0, 0, 90)
	axle.position = Vector3(wxz.x, 8.6, wxz.y)
	root.add_child(axle)
	var spinner = Node3D.new()
	spinner.name = "FerrisWheel"
	spinner.position = Vector3(wxz.x, 8.6, wxz.y)
	spinner.add_to_group("ferris")
	var struct_mat = StandardMaterial3D.new()
	struct_mat.albedo_color = Color(0.85, 0.45, 0.3)
	for i in range(4):
		var spoke = MeshInstance3D.new()
		var sm = BoxMesh.new()
		sm.size = Vector3(0.22, 12.4, 0.22)
		sm.material = struct_mat
		spoke.mesh = sm
		spoke.rotation_degrees = Vector3(0, 0, 45.0 * float(i))
		spinner.add_child(spoke)
	for i in range(8):
		var ang = TAU * float(i) / 8.0
		var g = MeshInstance3D.new()
		var gm = BoxMesh.new()
		gm.size = Vector3(1.1, 1.3, 1.0)
		var gmat = StandardMaterial3D.new()
		gmat.albedo_color = Color.from_hsv(float(i) / 8.0, 0.6, 0.85)
		gm.material = gmat
		g.mesh = gm
		g.position = Vector3(0, cos(ang) * -6.2, sin(ang) * 6.2)
		spinner.add_child(g)
	root.add_child(spinner)
	# radio tower + beacon (Industrial ridge, away from gang core)
	var txz: Vector2 = Vector2(420, 275)
	var h: float = 0.0
	for seg in [[1.8, 9.0], [1.3, 8.0], [0.8, 6.0]]:
		var tw: float = seg[0]
		var th: float = seg[1]
		var tm = StandardMaterial3D.new()
		tm.albedo_color = Color(0.45, 0.48, 0.52)
		tm.metallic = 0.6
		var tower = MeshInstance3D.new()
		var tbm = BoxMesh.new()
		tbm.size = Vector3(tw, th, tw)
		tbm.material = tm
		tower.mesh = tbm
		h += th * 0.5
		tower.position = Vector3(txz.x, h, txz.y)
		h += th * 0.5
		root.add_child(tower)
	var beacon = MeshInstance3D.new()
	var bbm = BoxMesh.new()
	bbm.size = Vector3(0.7, 0.7, 0.7)
	var bmat = StandardMaterial3D.new()
	bmat.albedo_color = Color(1, 0.15, 0.1)
	bmat.emission_enabled = true
	bmat.emission = Color(1, 0.1, 0.05)
	bmat.emission_energy_multiplier = 2.0
	bbm.material = bmat
	beacon.mesh = bbm
	beacon.name = "RadioBeacon"
	beacon.position = Vector3(txz.x, h + 0.4, txz.y)
	beacon.set_meta("beacon_mat", bmat)
	beacon.add_to_group("beacon")
	root.add_child(beacon)

## Round 10 E7: park creek — ribbon from the park's north edge feeding the
## lake, with a waterfall pouring over the north rim (particles + foam).
static func _build_creek(root: Node3D) -> void:
	var wmat = StandardMaterial3D.new()
	wmat.albedo_color = Color(0.2, 0.45, 0.6, 0.8)
	wmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	wmat.roughness = 0.1
	wmat.metallic = 0.2
	var segs: Array = [[-34, -50, 12.0], [-31, -39, 12.0], [-30, -28, 11.0],
			[-30, -17, 10.0], [-30, -6, 10.0], [-30, 5, 10.0]]
	for s in segs:
		var c = MeshInstance3D.new()
		var cm = BoxMesh.new()
		cm.size = Vector3(3.2, 0.1, s[2])
		cm.material = wmat
		c.mesh = cm
		c.name = "Creek"
		c.add_to_group("creek")
		c.position = Vector3(s[0], 0.3, s[1] + s[2] * 0.5)
		root.add_child(c)
	# waterfall: rock lip + falling spray + foam patch on the lake
	K._box(root, Vector3(4.0, 1.4, 1.4), Vector2(-30, 17), 1.4,
			Color(0.45, 0.44, 0.42), true, "CreekLip")
	var fall = GPUParticles3D.new()
	fall.name = "Waterfall"
	fall.amount = 34
	fall.lifetime = 0.85
	fall.emitting = true
	fall.position = Vector3(-30, 1.5, 16.2)
	var fp = ParticleProcessMaterial.new()
	fp.direction = Vector3(0, -1, 0.4)
	fp.initial_velocity_min = 1.0
	fp.initial_velocity_max = 2.0
	fp.gravity = Vector3(0, -9.8, 0)
	fp.scale_min = 0.25
	fp.scale_max = 0.6
	fp.color = Color(0.85, 0.93, 0.97, 0.8)
	fall.process_material = fp
	var fq = QuadMesh.new()
	fq.size = Vector2(0.3, 0.3)
	fall.draw_pass_1 = fq
	root.add_child(fall)
	var foam = K._decal_box(root, Vector3(5.0, 0.05, 3.0), Vector2(-30, 12), 0.37,
			Color(0.9, 0.95, 0.97), "LakeFoam")
	foam.get_active_material(0).transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	foam.get_active_material(0).albedo_color.a = 0.65


## Round 10 E8: perimeter guardrails (decorative — no collision change) and
## night cat-eye studs on the two main avenues (shared emissive material,
## driven by the night factor in game.gd).
static func _build_road_protection(root: Node3D) -> void:
	var rail_mat = StandardMaterial3D.new()
	rail_mat.albedo_color = Color(0.62, 0.64, 0.66)
	rail_mat.metallic = 0.7
	rail_mat.roughness = 0.4
	# N and S perimeter: rails outside both asphalt edges
	for zr in [-318.0, 318.0]:
		var rail = MeshInstance3D.new()
		var rm = BoxMesh.new()
		rm.size = Vector3(824, 0.4, 0.28)
		rm.material = rail_mat
		rail.mesh = rm
		rail.name = "Guardrail"
		rail.add_to_group("guardrails")
		rail.position = Vector3(0, 0.5, zr)
		root.add_child(rail)
	for xr in [-418.0, 418.0]:
		var rail2 = MeshInstance3D.new()
		var rm2 = BoxMesh.new()
		rm2.size = Vector3(0.28, 0.4, 624)
		rm2.material = rail_mat
		rail2.mesh = rm2
		rail2.name = "Guardrail"
		rail2.add_to_group("guardrails")
		rail2.position = Vector3(xr, 0.5, 0)
		root.add_child(rail2)
	# cat-eye studs: MultiMesh along the two main avenue centerlines
	var stud_mat = StandardMaterial3D.new()
	stud_mat.albedo_color = Color(0.9, 0.88, 0.7)
	stud_mat.emission_enabled = true
	stud_mat.emission = Color(1.0, 0.95, 0.7)
	stud_mat.emission_energy_multiplier = 0.0  # night-driven in game.gd
	var mm: MultiMesh = MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	var stud = BoxMesh.new()
	stud.size = Vector3(0.16, 0.06, 0.16)
	stud.material = stud_mat
	mm.mesh = stud
	var pts: Array[Transform3D] = []
	var x: float = -400.0
	while x <= 400.0:
		pts.append(Transform3D(Basis(), Vector3(x, 0.09, -60.0)))
		x += 20.0
	var z: float = -300.0
	while z <= 300.0:
		pts.append(Transform3D(Basis(), Vector3(-267.0, 0.09, z)))
		z += 20.0
	mm.instance_count = pts.size()
	for i in range(pts.size()):
		mm.set_instance_transform(i, pts[i])
	var mmi = MultiMeshInstance3D.new()
	mmi.name = "RoadStuds"
	mmi.multimesh = mm
	mmi.set_meta("stud_mat", stud_mat)
	mmi.add_to_group("night_studs")
	root.add_child(mmi)

## Mountain Environment — rock debris, cliff faces, trails, switchbacks, waterfalls, viewpoints, cabins
static func _build_mountain_details(root: Node3D, rng: RandomNumberGenerator) -> void:
	# North mountains: x -400..400, z -500..-300
	var mountain_rect: Rect2 = Rect2(-450, -500, 900, 200)
	var rng_m = RandomNumberGenerator.new()
	rng_m.seed = 7717
	
	# Rock debris + cliff faces
	for i in range(40):
		var x = rng_m.randf_range(mountain_rect.position.x, mountain_rect.end.x)
		var z = rng_m.randf_range(mountain_rect.position.y, mountain_rect.end.y)
		var h = WorldTerrain.height_at(x, z)
		if h < 10.0:
			continue
		# Rock debris
		var rock_size = rng_m.randf_range(0.8, 2.5)
		var rock = MeshInstance3D.new()
		var sm = SphereMesh.new()
		sm.radius = rock_size
		sm.height = rock_size * 1.2
		sm.material = K._mat(Color(0.5, 0.5, 0.48))
		rock.mesh = sm
		rock.position = Vector3(x, h + rock_size*0.3, z)
		rock.rotation_degrees = Vector3(rng_m.randf()*20, rng_m.randf()*360, rng_m.randf()*20)
		rock.visibility_range_end = 400.0
		rock.add_to_group("veg")
		root.add_child(rock)
	
	# Cliff faces — north edge
	for i in range(8):
		var x = -400.0 + i * 100.0
		var z: float = -480.0
		var h = WorldTerrain.height_at(x, z)
		if h < 20.0:
			continue
		K._box(root, Vector3(12, h*0.6, 3), Vector2(x, z), h*0.6, Color(0.45, 0.43, 0.40), true, "CliffFace")
	
	# Mountain trails — hiking trails
	for i in range(3):
		var trail_x = -300.0 + i * 300.0
		for j in range(10):
			var z = -480.0 + j * 18.0
			var x = trail_x + sin(z*0.02)*10.0
			var h = WorldTerrain.height_at(x, z)
			if h < 5.0:
				continue
			K._decal_box(root, Vector3(2.5, 0.05, 2.5), Vector2(x, z), h+0.05, Color(0.55, 0.50, 0.42), "Trail")
	
	# Switchback roads — mountain road
	var switchback_points: Array[Vector2] = []
	for i in range(12):
		var z = -480.0 + i * 15.0
		var x = sin(i*0.8)*60.0
		switchback_points.append(Vector2(x, z))
	for i in range(switchback_points.size()-1):
		var p1: Vector2 = switchback_points[i]
		var p2: Vector2 = switchback_points[i+1]
		var center = (p1 + p2) * 0.5
		var length = p1.distance_to(p2)
		var angle = atan2(p2.y - p1.y, p2.x - p1.x)
		var h1 = WorldTerrain.height_at(p1.x, p1.y)
		var h2 = WorldTerrain.height_at(p2.x, p2.y)
		var avg_h = (h1 + h2) * 0.5
		var road = MeshInstance3D.new()
		var rm = BoxMesh.new()
		rm.size = Vector3(length, 0.08, 4.5)
		rm.material = K._mat(Color(0.28, 0.27, 0.26))
		road.mesh = rm
		road.position = Vector3(center.x, avg_h+0.08, center.y)
		road.rotation.y = -angle
		root.add_child(road)
		# Guardrails for mountain road
		if i % 2 == 0:
			K._decal_box(root, Vector3(length, 0.4, 0.25), center, avg_h+0.4, Color(0.65, 0.65, 0.67), "MtnGuardrail")
	
	# Small waterfalls — mountain streams
	for i in range(3):
		var x = -200.0 + i * 200.0
		var z: float = -420.0
		var h = WorldTerrain.height_at(x, z)
		if h < 15.0:
			continue
		var fall = GPUParticles3D.new()
		fall.name = "MtnWaterfall%d"%i
		fall.amount = 20
		fall.lifetime = 0.7
		fall.emitting = true
		fall.position = Vector3(x, h+1.0, z)
		var fp = ParticleProcessMaterial.new()
		fp.direction = Vector3(0, -1, 0.3)
		fp.initial_velocity_min = 0.8
		fp.initial_velocity_max = 1.5
		fp.gravity = Vector3(0, -9.8, 0)
		fp.scale_min = 0.2
		fp.scale_max = 0.5
		fp.color = Color(0.85, 0.93, 0.97, 0.8)
		fall.process_material = fp
		var fq = QuadMesh.new()
		fq.size = Vector2(0.25, 0.25)
		fall.draw_pass_1 = fq
		root.add_child(fall)
	
	# Viewpoints — mountain peak
	var peak_x: float = 0.0
	var peak_z: float = -480.0
	var peak_h = WorldTerrain.height_at(peak_x, peak_z)
	if peak_h > 20.0:
		K._box(root, Vector3(6, 0.5, 6), Vector2(peak_x, peak_z), peak_h+0.5, Color(0.55, 0.55, 0.58), true, "Viewpoint")
		K._box(root, Vector3(0.2, 1.2, 3), Vector2(peak_x, peak_z+2), peak_h+1.2, Color(0.65, 0.65, 0.67), false, "ViewpointRail")
		# Binoculars prop
		K._box(root, Vector3(0.5, 0.8, 0.5), Vector2(peak_x, peak_z), peak_h+1.3, Color(0.15, 0.15, 0.18), false, "Binoculars")
	
	# Cabins — forest cabin
	for i in range(2):
		var cx = -350.0 + i * 700.0
		var cz: float = -400.0
		var ch = WorldTerrain.height_at(cx, cz)
		if ch < 8.0:
			continue
		A._build_interior_building(root, Vector2(cx, cz), Vector2(8, 7), 4.0, Color(0.45, 0.32, 0.22), "house", "MtnCabin%d"%i, 0)
		K._box(root, Vector3(0.8, 2.5, 0.8), Vector2(cx+3, cz), ch+2.5, Color(0.35, 0.25, 0.18), false, "CabinChimney")
	
	# Utility structures — radio, power
	K._box(root, Vector3(1.0, 12, 1.0), Vector2(100, -450), WorldTerrain.height_at(100,-450)+12, Color(0.5, 0.5, 0.52), false, "MtnUtility")
	K._box(root, Vector3(0.5, 0.5, 8), Vector2(100, -450), WorldTerrain.height_at(100,-450)+12, Color(0.6, 0.2, 0.2), false, "MtnPowerLine")
