class_name WBDBeach
extends Object
## Beachfront: sand dressing, palms, rocks, volleyball, lifeguard props.

const K := preload("res://scripts/world/wb_kit.gd")
const A := preload("res://scripts/world/wb_arch.gd")

static func _build_beach(root: Node3D, rng: RandomNumberGenerator) -> void:
	for i in range(22):
		var pxz = Vector2(rng.randf_range(-540, -470), rng.randf_range(-420, 420))
		K._palm(root, pxz, rng)
	K._decal_box(root, Vector3(6, 0.08, 300), Vector2(-465, 0), 0.08, Color(0.55, 0.42, 0.28), "Boardwalk")
	var lxz: Vector2 = Vector2(-530, -250)
	K._cyl(root, 2.6, 14.0, lxz, 14.0, Color(0.92, 0.92, 0.9))
	K._cyl(root, 2.6, 4.0, lxz, 18.0, Color(0.8, 0.2, 0.2))
	K._cyl(root, 2.2, 3.0, lxz, 21.0, Color(0.95, 0.9, 0.6))
	var lamp = OmniLight3D.new()
	lamp.light_color = Color(1.0, 0.9, 0.6)
	lamp.omni_range = 40.0
	lamp.light_energy = 2.5
	lamp.position = Vector3(lxz.x, 22.0, lxz.y)
	lamp.add_to_group("beacons")
	root.add_child(lamp)
	for pz: float in [180.0, 230.0]:
		K._box(root, Vector3(60, 0.8, 6), Vector2(-590, pz), 0.4, Color(0.5, 0.38, 0.25))
		for px: float in [-560.0, -580.0, -610.0]:
			K._box(root, Vector3(0.5, 3.0, 0.5), Vector2(px, pz), 0.0, Color(0.42, 0.32, 0.2), false)
	# yachts moored at the piers (marina identity)
	for y_i in range(3):
		var yxz: Vector2 = Vector2(-606 + (y_i % 2) * 22, 196 + y_i * 26)
		var hull = K._box(root, Vector3(3.2, 2.0, 11.0), yxz, 0.5, Color(0.94, 0.94, 0.97), false, "Yacht")
		K._box(root, Vector3(2.4, 1.4, 4.2), yxz + Vector2(0, -0.6), 2.6, Color(0.8, 0.84, 0.9), false)
		hull.set_meta("kind", "yacht")
	# fuel dock
	K._box(root, Vector3(3.0, 0.6, 3.0), Vector2(-588, 205), 1.0, Color(0.85, 0.3, 0.2), false, "FuelDock")
	K._box(root, Vector3(0.3, 1.8, 0.3), Vector2(-588, 205), 2.8, Color(0.7, 0.7, 0.72), false)
	# beach umbrellas + rocks
	for i in range(8):
		var uxz = Vector2(rng.randf_range(-520, -480), rng.randf_range(-200, 200))
		K._cyl(root, 0.06, 2.2, uxz, 2.2, Color(0.8, 0.8, 0.8), false, 6)
		var um = MeshInstance3D.new()
		var cone = CylinderMesh.new()
		cone.top_radius = 0.1
		cone.bottom_radius = 1.8
		cone.height = 0.7
		cone.material = K._mat(Color.from_hsv(rng.randf(), 0.6, 0.9))
		um.mesh = cone
		um.position = Vector3(uxz.x, 2.3, uxz.y)
		root.add_child(um)
	for i in range(10):
		var rxz = Vector2(rng.randf_range(-560, -460), rng.randf_range(-430, 430))
		if K._road_point_free(rxz, 6.0):
			K._rock(root, rxz, rng)
