class_name WBRoads
extends Object
## Road network dressing: asphalt, sidewalks, stop lines, bus stops,
## district signs, street trees, utility poles, drains, signals,
## freeway medians, signs, guardrails, furniture, crossings, lamps.

const K := preload("res://scripts/world/wb_kit.gd")
const A := preload("res://scripts/world/wb_arch.gd")
const S := preload("res://scripts/world/districts/streetscape.gd")

static func _build_roads(root: Node3D) -> void:
	for idx in range(K.ROADS.size()):
		var r: Rect2 = K.ROADS[idx]
		# Road condition variation — not every road new (realism trick)
		var condition: String = _road_condition(idx)
		var base_color: Color = Color(0.22, 0.22, 0.24)
		match condition:
			"new": base_color = Color(0.22, 0.22, 0.24)
			"good": base_color = Color(0.24, 0.24, 0.26)
			"aged": base_color = Color(0.26, 0.26, 0.28)  # slight discoloration
			"patched": base_color = Color(0.28, 0.27, 0.26)  # patchwork
			"damaged": base_color = Color(0.30, 0.28, 0.26)  # damaged plaster analogy
			"dirt": base_color = Color(0.35, 0.32, 0.28)
		K._decal_box(root, Vector3(r.size.x, 0.05, r.size.y),
				r.get_center(), 0.05, base_color, "Road")
		# edge lines + center dashes
		var horizontal = r.size.x > r.size.y
		var length = r.size.x if horizontal else r.size.y
		var n = int(length / 10.0)
		for i in range(n):
			var off = -length * 0.5 + 5.0 + i * 10.0
			if horizontal:
				K._decal_box(root, Vector3(4, 0.06, 0.35),
						Vector2(r.position.x + off + 2.0, r.get_center().y), 0.06,
						Color(0.85, 0.8, 0.4), "Dash")
			else:
				K._decal_box(root, Vector3(0.35, 0.06, 4),
						Vector2(r.get_center().x, r.position.y + off + 2.0), 0.06,
						Color(0.85, 0.8, 0.4), "Dash")
		# solid white edge lines
		if horizontal:
			var e1 = K._decal_box(root, Vector3(length, 0.06, 0.25), r.get_center(), 0.061,
					Color(0.9, 0.9, 0.9), "Edge")
			e1.position.z = r.position.y + 1.0
			var e2 = K._decal_box(root, Vector3(length, 0.06, 0.25), r.get_center(), 0.061,
					Color(0.9, 0.9, 0.9), "Edge")
			e2.position.z = r.end.y - 1.0
		else:
			var e1 = K._decal_box(root, Vector3(0.25, 0.06, length), r.get_center(), 0.061,
					Color(0.9, 0.9, 0.9), "Edge")
			e1.position.x = r.position.x + 1.0
			var e2 = K._decal_box(root, Vector3(0.25, 0.06, length), r.get_center(), 0.061,
					Color(0.9, 0.9, 0.9), "Edge")
			e2.position.x = r.end.x - 1.0
		# Age details — cracks, patches, manholes, drainage following terrain
		_build_road_age_details(root, r, idx, condition)
	for r: Rect2 in K.DIRT_ROADS:
		K._decal_box(root, Vector3(r.size.x, 0.05, r.size.y), r.get_center(), 0.045,
				Color(0.5, 0.42, 0.28), "DirtRoad")
		_build_dirt_road_details(root, r)

static func _road_condition(idx: int) -> String:
	# Realism: different roads different ages
	match idx:
		0, 1, 4, 5: return "new"  # perimeter + main E-W new
		2, 3, 6, 7: return "good"  # N-S good
		8, 9, 10: return "aged"  # industrial + downtown local aged
		11, 12, 13: return "patched"  # airport + beach patched
		_: return "good"

static func _build_road_age_details(root: Node3D, r: Rect2, idx: int, condition: String) -> void:
	var rng = RandomNumberGenerator.new()
	rng.seed = 20260915 + idx * 7919
	var horizontal = r.size.x > r.size.y
	var length = r.size.x if horizontal else r.size.y
	# Cracks — aged/patched/damaged roads
	if condition in ["aged", "patched", "damaged"]:
		var crack_count = 2 if condition == "aged" else 4 if condition == "patched" else 6
		for i in range(crack_count):
			var off = rng.randf_range(-length*0.45, length*0.45)
			var xz = Vector2(r.get_center().x + (off if horizontal else rng.randf_range(-2,2)),
					r.get_center().y + (rng.randf_range(-2,2) if horizontal else off))
			var crack_len = rng.randf_range(1.5, 4.0)
			var crack_w: float = 0.08
			if horizontal:
				K._decal_box(root, Vector3(crack_len, 0.061, crack_w), xz, 0.061, Color(0.15, 0.15, 0.16), "Crack")
			else:
				K._decal_box(root, Vector3(crack_w, 0.061, crack_len), xz, 0.061, Color(0.15, 0.15, 0.16), "Crack")
	# Patches — patched roads
	if condition == "patched":
		for i in range(2):
			var off = rng.randf_range(-length*0.4, length*0.4)
			var xz: Vector2 = Vector2(r.get_center().x + (off if horizontal else 0), r.get_center().y + (0 if horizontal else off))
			var patch_size: Vector3 = Vector3(6, 0.062, 4) if horizontal else Vector3(4, 0.062, 6)
			K._decal_box(root, patch_size, xz, 0.062, Color(0.30, 0.30, 0.32), "Patch")
	# Manholes — every road
	var manhole_count = int(length / 80.0)
	for i in range(manhole_count):
		var off = -length*0.4 + i * 80.0 + rng.randf_range(-10,10)
		var xz: Vector2 = Vector2(r.get_center().x + (off if horizontal else 0), r.get_center().y + (0 if horizontal else off))
		K._cyl(root, 0.45, 0.06, xz, 0.06, Color(0.18, 0.18, 0.19), false, 12)
	# Drainage — follows terrain (natural drainage)
	if idx % 2 == 0:
		var drain_xz: Vector2 = Vector2(r.get_center().x, r.position.y - 1.0) if horizontal else Vector2(r.position.x - 1.0, r.get_center().y)
		K._decal_box(root, Vector3(2, 0.05, 0.5) if horizontal else Vector3(0.5, 0.05, 2), drain_xz, 0.055, Color(0.25, 0.25, 0.27), "Drainage")

static func _build_dirt_road_details(root: Node3D, r: Rect2) -> void:
	var rng = RandomNumberGenerator.new()
	rng.seed = 7717 + int(r.position.x)
	# Erosion channels, exposed soil, grass between cracks
	for i in range(3):
		var xz = Vector2(r.get_center().x + rng.randf_range(-r.size.x*0.4, r.size.x*0.4), r.get_center().y)
		K._decal_box(root, Vector3(2, 0.046, 1), xz, 0.046, Color(0.45, 0.38, 0.25), "Erosion")


## Sidewalks hug each road OUTSIDE its asphalt; segments BREAK where a
## perpendicular road crosses (no more sidewalk stripes over junction asphalt).

static func _build_sidewalks(root: Node3D) -> void:
	K.sidewalk_rects.clear()
	var sw_color: Color = Color(0.62, 0.62, 0.6)
	for r: Rect2 in K.ROADS:
		var horizontal = r.size.x > r.size.y
		for side in [-1.0, 1.0]:
			var breaks: Array[float] = []
			for v: Rect2 in K.ROADS:
				if v == r:
					continue
				if horizontal:
					# perpendicular vertical road crossing this road's band?
					if v.position.y < r.end.y + 7.0 and v.end.y > r.position.y - 7.0 \
							and v.position.x < r.end.x and v.end.x > r.position.x:
						breaks.append(v.position.x - 9.0)
						breaks.append(v.end.x + 9.0)
				else:
					if v.position.x < r.end.x + 7.0 and v.end.x > r.position.x - 7.0 \
							and v.position.y < r.end.y and v.end.y > r.position.y:
						breaks.append(v.position.y - 9.0)
						breaks.append(v.end.y + 9.0)
			breaks.sort()
			var lo: float = r.position.x if horizontal else r.position.y
			var hi: float = r.end.x if horizontal else r.end.y
			# clamp outer ends inside the road span
			var segs: Array = []
			var cur = lo
			for i in range(0, breaks.size() - 1, 2):
				var b0: float = clampf(breaks[i], lo, hi)
				var b1: float = clampf(breaks[i + 1], lo, hi)
				if b0 > cur:
					segs.append([cur, b0])
				cur = maxf(cur, b1)
			if cur < hi:
				segs.append([cur, hi])
			for seg: Array in segs:
				var seg_len: float = seg[1] - seg[0]
				if seg_len < 4.0:
					continue  # sliver between junctions: skip
				var mid: float = (seg[0] + seg[1]) * 0.5
				var rect: Rect2
				if horizontal:
					var cy = r.position.y - 3.0 if side < 0 else r.end.y + 3.0
					K._decal_box(root, Vector3(seg_len, 0.12, 5.0), Vector2(mid, cy), 0.12,
							sw_color, "Sidewalk")
					rect = Rect2(mid - seg_len * 0.5, cy - 2.5, seg_len, 5.0)
				else:
					var cx = r.position.x - 3.0 if side < 0 else r.end.x + 3.0
					K._decal_box(root, Vector3(5.0, 0.12, seg_len), Vector2(cx, mid), 0.12,
							sw_color, "Sidewalk")
					rect = Rect2(cx - 2.5, mid - seg_len * 0.5, 5.0, seg_len)
				K.sidewalk_rects.append(rect)


## Stop lines ahead of every signalized crosswalk (2 per light).

static func _build_stop_lines(root: Node3D) -> void:
	for lt: Vector2 in K.TRAFFIC_LIGHTS:
		for side in [-1.0, 1.0]:
			K._decal_box(root, Vector3(12, 0.06, 0.5),
					Vector2(lt.x, lt.y + side * 13.6), 0.062, Color(0.9, 0.9, 0.9), "StopLine")


## Bus stops: shelter + bench + sign pole on primary road edges.

static func _build_bus_stops(root: Node3D) -> void:
	for bxz: Vector2 in [Vector2(-200, -49), Vector2(150, -49), Vector2(-366, 20),
			Vector2(74, -200)]:
		K._box(root, Vector3(5.0, 0.15, 2.2), bxz, 0.15, Color(0.5, 0.52, 0.54), false,
				"BusStopPad")
		K._box(root, Vector3(4.6, 0.2, 1.8), bxz + Vector2(0, -0.2), 2.6,
				Color(0.25, 0.45, 0.6), false, "BusStopRoof")
		for px in [-2.0, 2.0]:
			K._box(root, Vector3(0.15, 2.5, 0.15), bxz + Vector2(px, -0.9), 2.5,
					Color(0.3, 0.32, 0.35), false, "BusStopPole")
		K._box(root, Vector3(4.4, 0.9, 0.15), bxz + Vector2(0, -1.0), 1.0,
				Color(0.35, 0.38, 0.42), false, "BusStopBack")
		K._box(root, Vector3(2.4, 0.5, 0.5), bxz + Vector2(0, -1.6), 0.55,
				Color(0.6, 0.45, 0.3), false, "BusStopBench")
		K._box(root, Vector3(0.12, 3.0, 0.12), bxz + Vector2(3.2, 0), 3.0,
				Color(0.4, 0.42, 0.45), false, "BusStopSignPost")
		K._decal_box(root, Vector3(0.9, 0.9, 0.06), bxz + Vector2(3.2, 0), 3.2,
				Color(0.15, 0.5, 0.85), "BusStopSign")


## District boundary signs on primary roads at district edges.

static func _build_district_signs(root: Node3D) -> void:
	var entries: Array = [
		[Vector2(-90, -84), "DOWNTOWN", Color(0.2, 0.45, 0.8)],
		[Vector2(160, -75), "INDUSTRIAL", Color(0.6, 0.45, 0.15)],
		[Vector2(-200, 180), "FARMLAND", Color(0.35, 0.6, 0.2)],
		[Vector2(280, -300), "AIRPORT", Color(0.3, 0.35, 0.55)],
		[Vector2(-380, 140), "MARINA", Color(0.15, 0.5, 0.6)],
		[Vector2(80, -296), "MILITARY", Color(0.55, 0.3, 0.25)],
	]
	for e: Array in entries:
		var p: Vector2 = e[0]
		K._box(root, Vector3(0.12, 2.8, 0.12), p, 2.8, Color(0.5, 0.5, 0.53), false,
				"DistrictSignPost")
		var plate = K._decal_box(root, Vector3(3.2, 0.8, 0.06), p, 3.3, e[2], "DistrictSign")
		plate.position.y = 2.9


## Downtown street trees in planters along the main E-W sidewalk.

static func _build_street_trees(root: Node3D) -> void:
	var kit: Dictionary = S.KITS["Downtown"]
	for i in range(10):
		var x = -390.0 + i * 26.0
		if x > -170.0 and x < -140.0:
			continue  # keep the downtown local junction clear
		var p: Vector2 = Vector2(x, -77.0)
		K._box(root, Vector3(1.6, 0.5, 1.6), p, 0.5, kit.planter, true, "Planter")
		var trunk = K._cyl(root, 0.14, 2.2, p, 2.7, kit.trunk, false, 8)
		trunk.get_child(0).visibility_range_end = 280.0
		var crown = MeshInstance3D.new()
		var sm = SphereMesh.new()
		sm.radius = 1.5
		sm.height = 3.0
		var cm = StandardMaterial3D.new()
		cm.albedo_color = kit.crown
		sm.material = cm
		crown.mesh = sm
		crown.position = Vector3(p.x, 4.2, p.y)
		crown.visibility_range_end = 280.0
		crown.add_to_group("veg")
		root.add_child(crown)


## Suburban utility poles with crossarms along the N-S avenue.

static func _build_utility_poles(root: Node3D) -> void:
	for i in range(8):
		var p: Vector2 = Vector2(74, -240.0 + i * 20.0)
		var pole = K._cyl(root, 0.16, 7.5, p, 7.5, Color(0.42, 0.34, 0.26), false, 8)
		pole.get_child(0).visibility_range_end = 320.0
		K._box(root, Vector3(2.2, 0.14, 0.14), p, 7.2, Color(0.4, 0.32, 0.24), false,
				"Crossarm")


## Drainage gutters along downtown curbs (visual storm channels).

static func _build_drains(root: Node3D) -> void:
	for i in range(6):
		var x = -390.0 + i * 44.0
		K._decal_box(root, Vector3(30, 0.05, 0.5), Vector2(x, -75.0), 0.055,
				S.KITS["Downtown"].gutter, "Gutter")
		K._decal_box(root, Vector3(30, 0.05, 0.5), Vector2(x, -45.0), 0.055,
				S.KITS["Downtown"].gutter, "Gutter")


## ---------------- coast, landmarks, offshore, rail (map upgrade batch) ------
## Rocky islet + lighthouse: primary maritime landmark, visible from marina,
## beach and open water. Lamp glows at night via streetlight-style emission.

static func _build_traffic_lights(root: Node3D) -> void:
	for lt: Vector2 in K.TRAFFIC_LIGHTS:
		# pole at NE corner of intersection
		var pole_xz = lt + Vector2(11, 11)
		K._box(root, Vector3(0.3, 6.5, 0.3), pole_xz, 6.5, Color(0.25, 0.25, 0.28), true, "TLSignalPole")
		# head: 3 lamps facing the intersection (red top, yellow, green)
		var head = Node3D.new()
		head.name = "TrafficLight"
		head.add_to_group("traffic_lights")
		head.position = Vector3(pole_xz.x, 5.2, pole_xz.y)
		head.set_meta("xz", lt)
		var housing = MeshInstance3D.new()
		var hm = BoxMesh.new()
		hm.size = Vector3(0.5, 1.5, 0.3)
		hm.material = K._mat(Color(0.12, 0.12, 0.14))
		housing.mesh = hm
		housing.position.y = 0.6
		head.add_child(housing)
		var colors: Array = [Color(0.9, 0.15, 0.1), Color(0.95, 0.8, 0.1), Color(0.15, 0.9, 0.2)]
		for i in range(3):
			var l = MeshInstance3D.new()
			var lm = BoxMesh.new()
			lm.size = Vector3(0.3, 0.3, 0.1)
			var mat = StandardMaterial3D.new()
			mat.albedo_color = colors[i].darkened(0.75)
			mat.emission_enabled = true
			mat.emission = colors[i]
			mat.emission_energy_multiplier = 0.0
			mat.set_meta("base_color", colors[i])
			lm.material = mat
			l.mesh = lm
			l.position = Vector3(0, 1.0 - i * 0.45, -0.2)
			head.add_child(l)
		root.add_child(head)


## Freeway median barriers: collidable concrete segments along the perimeter
## centerlines, with gaps where junctions/connections cross.

static func _build_freeway_medians(root: Node3D) -> void:
	# per side: [axis ranges] and junction gaps (measured coordinates)
	var sides: Array = [
		{"rect": K.ROADS[0], "gaps": [-260.0, 60.0, 310.0]},   # N
		{"rect": K.ROADS[1], "gaps": [-380.0, 180.0]},         # S
		{"rect": K.ROADS[2], "gaps": [-60.0, 150.0]},          # W
		{"rect": K.ROADS[3], "gaps": [-221.0, -60.0]},         # E
	]
	for s: Dictionary in sides:
		var r: Rect2 = s["rect"]
		var horizontal: bool = r.size.x > r.size.y
		var lo: float = (r.position.x if horizontal else r.position.y) + 28.0
		var hi: float = (r.end.x if horizontal else r.end.y) - 28.0
		var cuts: Array = []
		for g: float in s["gaps"]:
			cuts.append(clampf(g - 16.0, lo, hi))
			cuts.append(clampf(g + 16.0, lo, hi))
		cuts.sort()
		var cur = lo
		var spans: Array = []
		for i in range(0, cuts.size() - 1, 2):
			if cuts[i] > cur:
				spans.append([cur, cuts[i]])
			cur = maxf(cur, cuts[i + 1])
		if cur < hi:
			spans.append([cur, hi])
		for span: Array in spans:
			var length: float = span[1] - span[0]
			if length < 8.0:
				continue
			var mid: float = (span[0] + span[1]) * 0.5
			var center: Vector2
			var size3: Vector3
			if horizontal:
				center = Vector2(mid, r.get_center().y)
				size3 = Vector3(length, 1.0, 0.8)
			else:
				center = Vector2(r.get_center().x, mid)
				size3 = Vector3(0.8, 1.0, length)
			var m = K._box(root, size3, center, 1.0, Color(0.55, 0.55, 0.58), true, "Median")
			m.get_child(0).visibility_range_end = 500.0

static func _build_road_signs(root: Node3D) -> void:
	# speed limit signs along the perimeter
	var spots: Array = [Vector2(-380, -296), Vector2(0, -296), Vector2(380, -296),
			Vector2(-380, 290), Vector2(0, 290), Vector2(380, 290)]
	for i in range(spots.size()):
		var s: Vector2 = spots[i]
		K._box(root, Vector3(0.12, 2.6, 0.12), s, 2.6, Color(0.6, 0.6, 0.62), false, "SignPost")
		var sign = K._decal_box(root, Vector3(1.0, 1.0, 0.06), s + Vector2(0, 0), 3.4,
				Color(0.9, 0.9, 0.92), "SpeedSign")
		sign.position.y = 3.4 - 0.5

static func _build_guardrails(root: Node3D) -> void:
	# guardrail segments along outer perimeter edges
	for x in range(-400, 401, 40):
		K._decal_box(root, Vector3(36, 0.5, 0.3), Vector2(x, -330), 0.75, Color(0.7, 0.7, 0.72), "Rail")
		K._decal_box(root, Vector3(36, 0.5, 0.3), Vector2(x, 330), 0.75, Color(0.7, 0.7, 0.72), "Rail")
	for z in range(-300, 301, 40):
		K._decal_box(root, Vector3(0.3, 0.5, 36), Vector2(-440, z), 0.75, Color(0.7, 0.7, 0.72), "Rail")
		K._decal_box(root, Vector3(0.3, 0.5, 36), Vector2(440, z), 0.75, Color(0.7, 0.7, 0.72), "Rail")

static func _build_street_furniture(root: Node3D, rng: RandomNumberGenerator) -> void:
	# benches, hydrants, dumpsters, bus stops near downtown sidewalks
	var hydrants: Array = [Vector2(-280, -80), Vector2(66, -80), Vector2(-280, 130), Vector2(66, 130)]
	for h: Vector2 in hydrants:
		K._cyl(root, 0.22, 0.8, h, 0.8, Color(0.8, 0.15, 0.1), false, 8)
	for i in range(6):
		var bxz: Vector2 = Vector2(-350 + i * 60, -80)
		K._box(root, Vector3(2.2, 0.5, 0.7), bxz, 0.55, Color(0.5, 0.36, 0.22), false, "Bench")
	for i in range(5):
		var dxz: Vector2 = Vector2(-360 + i * 85, 130)
		K._box(root, Vector3(1.6, 1.2, 1.0), dxz, 1.2, Color(0.25, 0.4, 0.3), false, "Dumpster")
	# bus stops: pole + shelter
	for b: Vector2 in [Vector2(-220, -78), Vector2(100, 292), Vector2(-440, 60)]:
		K._box(root, Vector3(0.15, 3.0, 0.15), b, 3.0, Color(0.5, 0.5, 0.55), false, "BusPole")
		K._box(root, Vector3(4.0, 0.15, 1.6), b, 3.1, Color(0.85, 0.3, 0.25), false, "BusSign")
	# vending machines against downtown storefronts
	for v: Vector2 in [Vector2(-305, -176), Vector2(-110, -176)]:
		K._box(root, Vector3(1.0, 2.0, 0.7), v, 2.0, Color(0.85, 0.55, 0.1), false, "Vending")

static func _build_crosswalks(root: Node3D) -> void:
	for lt: Vector2 in K.TRAFFIC_LIGHTS:
		for side in [-1.0, 1.0]:
			var cz: float = lt.y + side * 10.5
			for i in range(6):
				var stripe_x = lt.x - 6.0 + i * 2.4
				var st = K._decal_box(root, Vector3(1.2, 0.06, 3.2), Vector2(stripe_x, cz), 0.062,
						Color(0.92, 0.92, 0.9), "Crosswalk")
				st.position.y = 0.058

static func _build_lamps(root: Node3D) -> void:
	var spots: Array = []
	for r: Rect2 in K.ROADS:
		var horizontal = r.size.x > r.size.y
		var count: int = 3
		for i in range(count):
			var t = (i + 0.5) / count
			var xz: Vector2
			if horizontal:
				xz = Vector2(r.position.x + r.size.x * t, r.position.y - 9.0)
			else:
				xz = Vector2(r.position.x - 9.0, r.position.y + r.size.y * t)
			spots.append(xz)
	var idx: int = 0
	for xz: Vector2 in spots:
		idx += 1
		if idx % 2 == 0:
			continue
		K._box(root, Vector3(0.25, 6.0, 0.25), xz, 6.0, Color(0.3, 0.3, 0.33), false)
		var head = K._box(root, Vector3(1.2, 0.3, 0.5), xz + Vector2(0.5, 0), 6.1,
				Color(0.9, 0.85, 0.6), false)
		var light = OmniLight3D.new()
		light.omni_range = 13.0
		light.light_energy = 0.0
		light.light_color = Color(1.0, 0.85, 0.55)
		light.position = Vector3(xz.x + 0.5, 5.6, xz.y)
		light.add_to_group("street_lamps")
		head.add_child(light)
