class_name WBDFarmland
extends Object
## Farmland: crop rows, barns, silos, fences, oaks.

const K := preload("res://scripts/world/wb_kit.gd")
const A := preload("res://scripts/world/wb_arch.gd")

static func _build_farmland(root: Node3D, rng: RandomNumberGenerator) -> void:
	for i in range(4):
		K._decal_box(root, Vector3(56, 0.06, 26), Vector2(-350 + (i % 2) * 90, 170 + (i / 2) * 70),
				0.06, Color(0.45 + 0.1 * (i % 2), 0.55, 0.25), "CropField")
	K._box(root, Vector3(16, 8, 11), Vector2(-230, 230), 8.0, Color(0.6, 0.25, 0.2))
	K._box(root, Vector3(17, 1.5, 12), Vector2(-230, 230), 9.5, Color(0.35, 0.2, 0.15), false)
	K._cyl(root, 3.0, 12.0, Vector2(-214, 238), 12.0, Color(0.8, 0.8, 0.78))
	K._box(root, Vector3(0.8, 18.0, 0.8), Vector2(-390, 250), 18.0, Color(0.85, 0.85, 0.85), false)
	var mill = Node3D.new()
	mill.name = "WindmillBlades"
	mill.position = Vector3(-390, 17.5, 250)
	for b in range(3):
		var blade = MeshInstance3D.new()
		var bm = BoxMesh.new()
		bm.size = Vector3(0.5, 7.0, 0.2)
		bm.material = K._mat(Color(0.9, 0.9, 0.92))
		blade.mesh = bm
		blade.rotation_degrees = Vector3(0, 0, 120.0 * b)
		blade.position = Vector3(0, 3.0, 0).rotated(Vector3(0, 0, 1), deg_to_rad(120.0 * b))
		mill.add_child(blade)
	root.add_child(mill)
	# hay bales + fence line
	for i in range(6):
		var hxz = Vector2(rng.randf_range(-390, -250), rng.randf_range(160, 290))
		if K._road_point_free(hxz, 8.0):
			K._cyl(root, 0.9, 1.4, hxz, 1.4, Color(0.8, 0.7, 0.35), false, 10)
	for fx in range(12):
		K._box(root, Vector3(0.25, 1.3, 0.25), Vector2(-400 + fx * 12, 300), 1.3,
				Color(0.55, 0.42, 0.28), false, "FencePost")