class_name WBDMilitary
extends Object
## Military base: walls, barracks, watchtowers, pine screens.

const K := preload("res://scripts/world/wb_kit.gd")
const A := preload("res://scripts/world/wb_arch.gd")

static func _build_military(root: Node3D, rng: RandomNumberGenerator) -> void:
	var wall_col: Color = Color(0.4, 0.42, 0.38)
	var bx: float = 90.0
	var bz: float = -300.0
	# Perimeter walls with gate
	K._box(root, Vector3(160, 4, 2), Vector2(bx, bz - 35), 4.0, wall_col)
	K._box(root, Vector3(2, 4, 70), Vector2(bx - 80, bz), 4.0, wall_col)
	K._box(root, Vector3(2, 4, 70), Vector2(bx + 80, bz), 4.0, wall_col)
	K._box(root, Vector3(70, 4, 2), Vector2(bx - 45, bz + 35), 4.0, wall_col)
	K._box(root, Vector3(70, 4, 2), Vector2(bx + 45, bz + 35), 4.0, wall_col)
	# Gate
	K._box(root, Vector3(0.4, 4, 0.4), Vector2(bx-4, bz+35), 4.0, Color(0.6, 0.6, 0.62), false, "GatePost")
	K._box(root, Vector3(0.4, 4, 0.4), Vector2(bx+4, bz+35), 4.0, Color(0.6, 0.6, 0.62), false, "GatePost")
	K._box(root, Vector3(8, 0.6, 0.3), Vector2(bx, bz+35), 3.5, Color(0.7, 0.15, 0.15), false, "GateBar")
	# Barracks
	K._box(root, Vector3(30, 7, 12), Vector2(bx - 40, bz - 10), 7.0, Color(0.45, 0.48, 0.4))
	K._box(root, Vector3(26, 9, 18), Vector2(bx + 40, bz - 10), 9.0, Color(0.42, 0.45, 0.4))
	A._build_interior_building(root, Vector2(bx-40, bz-10), Vector2(14, 8), 5.0, Color(0.5, 0.52, 0.48), "office", "BarracksA", 0)
	A._build_interior_building(root, Vector2(bx+40, bz-10), Vector2(12, 10), 6.0, Color(0.48, 0.50, 0.46), "office", "BarracksB", 0)
	for tx: float in [bx - 78.0, bx + 78.0]:
		K._box(root, Vector3(1.2, 12.0, 1.2), Vector2(tx, bz + 34), 12.0, Color(0.35, 0.3, 0.25))
		K._box(root, Vector3(4, 3, 4), Vector2(tx, bz + 34), 15.0, Color(0.4, 0.42, 0.38))
		# Searchlight
		var light: SpotLight3D = SpotLight3D.new()
		light.light_color = Color(1, 1, 0.9)
		light.spot_range = 60.0
		light.spot_angle = 20.0
		light.light_energy = 1.5
		light.position = Vector3(tx, 15.5, bz+34)
		light.rotation_degrees = Vector3(-35, 0, 0)
		light.add_to_group("street_lamps")
		root.add_child(light)
	K._cyl(root, 0.8, 20.0, Vector2(bx, bz - 30), 20.0, Color(0.6, 0.6, 0.65))
	var dish = MeshInstance3D.new()
	var dm = SphereMesh.new()
	dm.radius = 3.0
	dm.height = 3.0
	dm.material = K._mat(Color(0.75, 0.75, 0.78))
	dish.mesh = dm
	dish.position = Vector3(bx, 21.5, bz - 30)
	root.add_child(dish)
	# Helipad
	K._decal_box(root, Vector3(18, 0.08, 18), Vector2(bx, bz+10), 0.08, Color(0.35, 0.36, 0.38), "Helipad")
	K._decal_box(root, Vector3(10, 0.09, 10), Vector2(bx, bz+10), 0.09, Color(0.9, 0.2, 0.2), "HelipadH")
	# Military vehicles (static props)
	K._box(root, Vector3(3.5, 2.2, 6.0), Vector2(bx-20, bz+15), 2.2, Color(0.35, 0.40, 0.30), true, "MilTruck")
	K._box(root, Vector3(2.8, 2.0, 4.5), Vector2(bx+20, bz+15), 2.0, Color(0.32, 0.35, 0.28), true, "MilJeep")
	# Ammo crates
	for i in range(4):
		K._box(root, Vector3(1.2, 0.8, 0.8), Vector2(bx-50+i*3, bz), 0.8, Color(0.45, 0.42, 0.32), true, "AmmoCrate")
	# Pine screens + sandbags
	for i in range(18):
		var pxz = Vector2(rng.randf_range(-70, 250), rng.randf_range(-345, -255))
		if K._road_point_free(pxz, 8.0):
			K._pine(root, pxz, rng)
			if i % 4 == 0:
				K._box(root, Vector3(0.9, 0.8, 0.6), pxz + Vector2(1,0), 0.8, Color(0.6, 0.56, 0.44), false, "Sandbag")
