class_name WBDIndustrial
extends Object
## Industrial zone: warehouses, tanks, containers, silos.

const K := preload("res://scripts/world/wb_kit.gd")
const A := preload("res://scripts/world/wb_arch.gd")

static func _build_industrial(root: Node3D, rng: RandomNumberGenerator) -> void:
	for wx: float in [160.0, 240.0, 320.0, 390.0]:
		var age_choices: Array = ["middle", "old", "abandoned"]
		var age: String = age_choices[rng.randi() % age_choices.size()] if wx > 300 else "middle"
		K._box(root, Vector3(34, 13, 20), Vector2(wx, 110), 13.0, Color(0.5, 0.48, 0.45))
		K._box(root, Vector3(35, 1.5, 21), Vector2(wx, 110), 14.5, Color(0.4, 0.4, 0.42), false)
		A._building_detail(root, Vector3(34, 13, 20), Vector2(wx, 110), 13.0, 3)
		# Industrial detail — loading docks, forklift, pallets, pipes
		K._box(root, Vector3(3.5, 1.2, 2.0), Vector2(wx, 98), 1.2, Color(0.35, 0.35, 0.38), true, "LoadingDock")
		K._box(root, Vector3(1.2, 0.3, 0.9), Vector2(wx+2, 98), 0.3, Color(0.55, 0.45, 0.32), false, "Pallet")
		K._box(root, Vector3(0.15, 0.15, 20.0), Vector2(wx, 120), 10.0, Color(0.5, 0.5, 0.52), false, "Pipe")
		# Security fence around industrial
		if wx == 160.0:
			for fz in range(80, 140, 10):
				K._box(root, Vector3(0.15, 2.2, 2.0), Vector2(wx-18, fz), 2.2, Color(0.6, 0.6, 0.62), false, "IndFence")
	for i in range(14):
		var cxz = Vector2(rng.randf_range(140, 400), rng.randf_range(160, 290))
		if K._road_point_free(cxz, 9.0):
			var col: Color = K.CONTAINER_COLORS[i % K.CONTAINER_COLORS.size()]
			K._box(root, Vector3(6.1, 2.6, 2.5), cxz, 2.6, col)
			if i % 3 == 0:
				K._box(root, Vector3(6.1, 2.6, 2.5), cxz + Vector2(0, 2.8), 5.2, col.darkened(0.1))
	K._box(root, Vector3(2, 22, 2), Vector2(415, 150), 22.0, Color(0.8, 0.35, 0.2))
	K._box(root, Vector3(2, 22, 2), Vector2(415, 190), 22.0, Color(0.8, 0.35, 0.2))
	K._box(root, Vector3(2, 2, 60), Vector2(415, 170), 23.0, Color(0.8, 0.35, 0.2), false)
	for sx: float in [200.0, 230.0, 260.0]:
		K._cyl(root, 5.0, 16.0, Vector2(sx, 250), 16.0, Color(0.75, 0.75, 0.72))
	# Industrial vertical — smokestacks with smoke
	for sx: float in [180.0, 380.0]:
		var stack = K._cyl(root, 1.2, 28.0, Vector2(sx, 220), 28.0, Color(0.35, 0.34, 0.32))
		var smoke = GPUParticles3D.new()
		smoke.amount = 12
		smoke.lifetime = 2.0
		smoke.emitting = true
		smoke.position = Vector3(sx, 28.5, 220)
		var pmat = ParticleProcessMaterial.new()
		pmat.direction = Vector3(0, 1, 0)
		pmat.initial_velocity_min = 1.0
		pmat.initial_velocity_max = 2.0
		pmat.gravity = Vector3(0, 0.5, 0)
		pmat.scale_min = 0.8
		pmat.scale_max = 1.5
		pmat.color = Color(0.3, 0.3, 0.3, 0.5)
		smoke.process_material = pmat
		var qm = QuadMesh.new()
		qm.size = Vector2(0.8, 0.8)
		smoke.draw_pass_1 = qm
		root.add_child(smoke)
	# Hidden — underground bunker entrance (industrial)
	K._box(root, Vector3(3, 0.4, 3), Vector2(410, 230), 0.4, Color(0.25, 0.25, 0.26), true, "BunkerHatch")
	K._decal_box(root, Vector3(0.8, 1.8, 0.2), Vector2(410, 231.5), 1.8, Color(0.15, 0.15, 0.16), "BunkerDoor")
