class_name WBDAirport
extends Object
## Airport: runway, taxiway, terminal, hangar, aprons.

const K := preload("res://scripts/world/wb_kit.gd")
const A := preload("res://scripts/world/wb_arch.gd")

static func _build_airport(root: Node3D, rng: RandomNumberGenerator) -> void:
	K._decal_box(root, Vector3(190, 0.05, 20), Vector2(330, -280), 0.05, Color(0.25, 0.25, 0.27), "Runway")
	K._decal_box(root, Vector3(190, 0.06, 4), Vector2(330, -260), 0.06, Color(0.35, 0.35, 0.38), "Taxiway")
	for i in range(11):
		K._decal_box(root, Vector3(8, 0.06, 0.6), Vector2(240 + i * 20, -280), 0.06,
				Color(0.9, 0.9, 0.9), "RunwayMark")
	# Terminal
	K._box(root, Vector3(44, 9, 16), Vector2(330, -245), 9.0, Color(0.55, 0.65, 0.75))
	A._building_detail(root, Vector3(44, 9, 16), Vector2(330, -245), 9.0, 2)
	A._build_interior_building(root, Vector2(330, -245), Vector2(20, 12), 6.0, Color(0.7, 0.72, 0.78), "office", "Terminal", 0)
	K._cyl(root, 2.4, 26.0, Vector2(295, -245), 26.0, Color(0.7, 0.7, 0.72))
	K._box(root, Vector3(8, 4, 8), Vector2(295, -245), 30.0, Color(0.3, 0.4, 0.5), false)
	# Hangars
	for hx: float in [260.0, 400.0]:
		K._box(root, Vector3(30, 11, 20), Vector2(hx, -250), 11.0, Color(0.58, 0.6, 0.62))
		K._box(root, Vector3(28, 0.6, 18), Vector2(hx, -235), 0.6, Color(0.35, 0.35, 0.38), true, "HangarDoor")
	# Luggage carts, fuel truck, windsock detail
	var px: Vector2 = Vector2(360, -280)
	K._cyl(root, 1.6, 18.0, px, 3.4, Color(0.9, 0.9, 0.92)).rotation_degrees = Vector3(0, 0, 90)
	K._box(root, Vector3(16, 0.5, 2.6), px, 3.0, Color(0.85, 0.85, 0.88), false)
	K._box(root, Vector3(0.4, 4.0, 3.0), px + Vector2(-8.4, 0), 5.6, Color(0.85, 0.85, 0.88), false)
	K._box(root, Vector3(4, 1.8, 2.2), Vector2(340, -265), 1.8, Color(0.85, 0.8, 0.3), true, "LuggageCart")
	K._box(root, Vector3(3.5, 2.0, 5.0), Vector2(350, -265), 2.0, Color(0.9, 0.9, 0.92), true, "FuelTruck")
	# Runway lights
	for i in range(10):
		var lx = 245.0 + i * 20.0
		K._box(root, Vector3(0.3, 0.2, 0.3), Vector2(lx, -290), 0.2, Color(0.9, 0.9, 0.7), false, "RunwayLight")
		K._box(root, Vector3(0.3, 0.2, 0.3), Vector2(lx, -270), 0.2, Color(0.9, 0.9, 0.7), false, "RunwayLight")
	# Airport fence
	for fx in range(240, 420, 15):
		K._box(root, Vector3(0.15, 2.2, 2.0), Vector2(fx, -310), 2.2, Color(0.6, 0.6, 0.62), false, "AirportFence")
