class_name WorldContract
extends Object
## WorldContract — AUTHORITATIVE spatial contract for the 3 km-radius circular
## world (Reconstruction Program, Prompt 01).
##
## This script is the SINGLE source of truth for the world envelope of the
## reconstruction target. No other script may duplicate these radius/center
## constants; consumers must query this contract. The legacy rectangular
## contract (wb_kit.ISLAND 900x700 m, wb_kit.SAND) remains the ACTIVE build
## contract until Prompt 02 migrates WorldBuilder — see
## docs/reconstruction/V2_4_1_EVIDENCE_RECONCILIATION.md and
## docs/reconstruction/02_RECONSTRUCTION_BLUEPRINT.md. Nothing in this file
## mutates or replaces existing systems: it is additive.
##
## Contract (locked, Prompt 01):
##   - world center: (0, 0) XZ — matches the current island rect, which is
##     already centered on the origin (wb_kit.ISLAND = Rect2(-450,-350,900,700)
##     -> center (0,0)). Verified against source, not assumed.
##   - playable radius: 3000 m; diameter 6000 m; envelope: CIRCLE, inclusive.
##   - mathematical circle area: pi * 3000^2 = 28.274 km^2 (reference value;
##     the authored LAND area will be smaller once coast/water carve-outs are
##     designed in Prompt 03 — the circle is the envelope, not a fill target).
##   - the hard gameplay boundary must be physically stable and visually
##     believable; water/coast may render beyond the boundary.
##   - all world systems must use ONE boundary query (this file).
##
## Zones (radial classification only — terrain HEIGHT remains owned by
## scripts/world/terrain.gd; this contract classifies by radius):
##   CORE_LAND : dist <= LAND_RADIUS (2700 m) — authored land.
##   COAST_BAND: LAND_RADIUS < dist <= RADIUS (3000 m) — beaches, cliffs,
##               shallows; visually believable transition zone.
##   WATER     : dist > RADIUS — open ocean beyond the playable envelope.
##
## Spatial partitioning (specification lives in the blueprint doc):
##   - coarse LOGICAL SECTORS ("macro"): 500 m cells, clipped by the circle.
##     Deterministic IDs ("M_<x>_<z>", Vector2i = floor(pos / 500)); regions,
##     districts, sim tiers, budgets and save partitioning attach here.
##   - fine STREAMING SECTORS ("micro"): 125 m cells — the basic streaming /
##     ownership unit (Prompt 02 contract). Deterministic IDs ("S_<x>_<z>").
##     48 x 48 micro positions cover the 6000 m bounding square; only
##     circle-valid sectors are usable.

## --- Envelope constants (the ONLY place these numbers exist) ---
const CENTER_XZ := Vector2(0.0, 0.0)
const RADIUS_M := 3000.0
const DIAMETER_M := 6000.0
const RADIUS_SQ := RADIUS_M * RADIUS_M

## Bands
const LAND_RADIUS_M := 2700.0          # authored land out to here
const SOFT_MARGIN_M := 250.0           # soft-boundary warning band inside edge
const ROAD_LIMIT_RADIUS_M := 2900.0    # legal road area (hard edge minus 100 m)
const SOFT_RADIUS_M := RADIUS_M - SOFT_MARGIN_M   # 2750 m

## Partitioning
const SECTOR_M := 500.0                # coarse logical sectors (macro)
const MICRO_SECTOR_M := 125.0          # fine streaming sectors (Prompt 02)
const MACRO_GRID_SPAN := 12            # 12 x 500 m = 6000 m bounding square
const MICRO_GRID_SPAN := 48            # 48 x 125 m = 6000 m bounding square
## Legacy alias (P01 called the fine grid "cells"); kept so no consumer breaks.
const CELL_M := MICRO_SECTOR_M

## --- World schema / identity (Prompt 02 §12: versioned world spatial schema) ---
const WORLD_ID := "island_strike_world"
const SCHEMA_VERSION := 2              # world_data["world"]["schema_version"]
const WORLD_REVISION := 2              # bump on any spatial contract change
const WORLD_SEED := 20260915           # single deterministic world seed (P02 §7)

## Streaming/debug-only AABB that fully contains the playable circle.
## Never use this for gameplay boundary tests — use is_playable().
const WORLD_BOUNDS_AABB := AABB(Vector3(-3000.0, -500.0, -3000.0),
		Vector3(6000.0, 1500.0, 6000.0))

## Zone labels (radial classification hook for terrain/water work, Prompt 03)
const ZONE_CORE := "CORE_LAND"
const ZONE_COAST := "COAST_BAND"
const ZONE_WATER := "WATER"


## --- Distance helpers ---

static func dist_to_center_xz(v: Vector2) -> float:
	var d: Vector2 = v - CENTER_XZ
	return d.length()


static func dist_to_center(p: Vector3) -> float:
	return dist_to_center_xz(Vector2(p.x, p.z))


## P02 §3 naming aliases (same authority, friendlier names for consumers).
static func is_inside_world(v: Vector2) -> bool:
	return is_playable(Vector3(v.x, 0.0, v.y))


static func is_inside_world_3d(p: Vector3) -> bool:
	return is_playable(p)


static func clamp_to_world(v: Vector2, inset_m: float = 10.0) -> Vector2:
	return clamp_to_playable(v, inset_m)


static func macro_sector_of(v: Vector2) -> Vector2i:
	return world_to_sector(v)


static func sector_of(v: Vector2) -> Vector2i:
	return micro_sector_of(v)


## --- Boundary queries (the ONE authoritative API) ---

## Playable envelope test. Inclusive at exactly RADIUS_M. Non-finite input is
## never playable. Y is irrelevant to the envelope test (terrain owns height).
static func is_playable(p: Vector3) -> bool:
	if not is_finite(p.x) or not is_finite(p.z):
		return false
	var dx: float = p.x - CENTER_XZ.x
	var dz: float = p.z - CENTER_XZ.y
	return dx * dx + dz * dz <= RADIUS_SQ


## Soft-boundary test: inside the playable circle but within SOFT_MARGIN_M of
## the hard edge (2750–3000 m band). Gameplay/UI systems use this to warn or
## gently steer the player long before the hard boundary.
static func is_soft_boundary(p: Vector3) -> bool:
	if not is_playable(p):
		return false
	var d: float = dist_to_center(p)
	return d > SOFT_RADIUS_M


## Legal road area test: the road graph must stay inside this radius except
## for explicitly authored offshore/bridge transitions (those must be flagged
## per-edge in the road data, never inferred).
static func is_legal_road_area(p: Vector3) -> bool:
	if not is_finite(p.x) or not is_finite(p.z):
		return false
	var dx: float = p.x - CENTER_XZ.x
	var dz: float = p.z - CENTER_XZ.y
	return dx * dx + dz * dz <= ROAD_LIMIT_RADIUS_M * ROAD_LIMIT_RADIUS_M


## Radial zone classification hook (see class docs; terrain height still owned
## by WorldTerrain).
static func classify_zone(p: Vector3) -> String:
	if not is_finite(p.x) or not is_finite(p.z):
		return ZONE_WATER
	var d: float = dist_to_center(p)
	if d <= LAND_RADIUS_M:
		return ZONE_CORE
	if d <= RADIUS_M:
		return ZONE_COAST
	return ZONE_WATER


## Pull an XZ point back inside the playable circle with a safety inset.
## Deterministic; used for spawn sanitization and debug teleport clamps.
static func clamp_to_playable(v: Vector2, inset_m: float = 10.0) -> Vector2:
	var rel: Vector2 = v - CENTER_XZ
	var d: float = rel.length()
	var limit: float = RADIUS_M - inset_m
	if not is_finite(rel.x) or not is_finite(rel.y) or d <= limit or d == 0.0:
		if not is_finite(rel.x) or not is_finite(rel.y):
			return CENTER_XZ
		return v
	return CENTER_XZ + rel.normalized() * limit


## --- Sector indexing (500 m coarse grid clipped by the circle) ---

static func world_to_sector(v: Vector2) -> Vector2i:
	return Vector2i(int(floorf(v.x / SECTOR_M)), int(floorf(v.y / SECTOR_M)))


static func world_to_sector3(p: Vector3) -> Vector2i:
	return world_to_sector(Vector2(p.x, p.z))


## Sector center in world space (deterministic).
static func sector_to_world(s: Vector2i) -> Vector2:
	return CENTER_XZ + (Vector2(s) + Vector2(0.5, 0.5)) * SECTOR_M


## A sector is valid when its CENTER lies inside the playable circle. This
## keeps the active-sector set strictly inside the envelope while still
## covering every playable point (a point on the edge belongs to a sector
## whose center is <= RADIUS away — max overshoot is half a cell diagonal).
static func sector_is_valid(s: Vector2i) -> bool:
	return dist_to_center_xz(sector_to_world(s)) <= RADIUS_M


## Deterministic ordered list of every valid sector (sorted by y, then x).
static func valid_sector_ids() -> Array[Vector2i]:
	var out: Array[Vector2i] = []
	var n: int = int(ceil(RADIUS_M / SECTOR_M)) + 1
	for sy in range(-n, n + 1):
		for sx in range(-n, n + 1):
			var s := Vector2i(sx, sy)
			if sector_is_valid(s):
				out.append(s)
	return out


## Stable linear index for a valid sector (streaming/save partition keys).
## Returns -1 for invalid sectors.
static func sector_index(s: Vector2i) -> int:
	if not sector_is_valid(s):
		return -1
	var ids: Array[Vector2i] = valid_sector_ids()
	return ids.find(s)


static func sector_count() -> int:
	return valid_sector_ids().size()


## --- Micro streaming sectors (125 m) — the P02 streaming/ownership unit ---

static func micro_sector_of(v: Vector2) -> Vector2i:
	return Vector2i(int(floorf(v.x / MICRO_SECTOR_M)), int(floorf(v.y / MICRO_SECTOR_M)))


static func micro_sector_of3(p: Vector3) -> Vector2i:
	return micro_sector_of(Vector2(p.x, p.z))


static func micro_sector_to_world(s: Vector2i) -> Vector2:
	return CENTER_XZ + (Vector2(s) + Vector2(0.5, 0.5)) * MICRO_SECTOR_M


static func micro_sector_is_valid(s: Vector2i) -> bool:
	return dist_to_center_xz(micro_sector_to_world(s)) <= RADIUS_M


## Deterministic ordered list of every circle-valid micro sector.
static func micro_sector_ids() -> Array[Vector2i]:
	var out: Array[Vector2i] = []
	var n: int = MICRO_GRID_SPAN / 2
	for sy in range(-n, n + 1):
		for sx in range(-n, n + 1):
			var s := Vector2i(sx, sy)
			if micro_sector_is_valid(s):
				out.append(s)
	return out


static func micro_sector_count() -> int:
	return micro_sector_ids().size()


## Macro (500 m) sector that contains a micro sector (4x4 micro per macro).
static func macro_of_micro(s: Vector2i) -> Vector2i:
	return world_to_sector(micro_sector_to_world(s))


## --- Deterministic sector IDs (serialization-safe, P02 §6) ---

static func macro_id(m: Vector2i) -> String:
	return "M_%d_%d" % [m.x, m.y]


static func micro_id(s: Vector2i) -> String:
	return "S_%d_%d" % [s.x, s.y]


## --- Deterministic seed derivation chain (P02 §7) ---
## GLOBAL_WORLD_SEED -> macro seed -> micro sector seed -> subsystem seed.
## Pure 64-bit integer mixing: deterministic across sessions/platforms (no
## runtime object hashes, no unseeded RNG).

static func _mix(a: int, b: int, c: int) -> int:
	var h: int = WORLD_SEED ^ (a * 0x27D4EB2D) ^ (b * 0x165667B1) \
			^ (c * 0x9E3779B1) ^ (WORLD_REVISION * 0x85EBCA77)
	h = (h ^ (h >> 15)) * 0x2545F491
	h = h ^ (h >> 13)
	h = (h * 0xC2B2AE35) ^ (h >> 16)
	return h & 0x7FFFFFFF


static func macro_seed(m: Vector2i) -> int:
	return _mix(m.x, m.y, 1)


static func micro_seed(s: Vector2i) -> int:
	return _mix(s.x, s.y, 2)


## Subsystem seed: distinct deterministic stream per subsystem within a sector
## (e.g. 0=dressing, 1=peds, 2=traffic, 3=events).
static func subsystem_seed(s: Vector2i, subsystem: int) -> int:
	return _mix(s.x * 131 + s.y, subsystem, 3)


## --- Legacy alias: P01 "cell" API (same thing as micro sectors) ---

static func world_to_cell(v: Vector2) -> Vector2i:
	return micro_sector_of(v)


static func cell_to_world(c: Vector2i) -> Vector2:
	return micro_sector_to_world(c)


static func cell_is_valid(c: Vector2i) -> bool:
	return micro_sector_is_valid(c)


## --- Contract accessors + normalization + projection (P02 §3/§19) ---

static func world_radius() -> float:
	return RADIUS_M


static func world_diameter() -> float:
	return DIAMETER_M


static func world_center() -> Vector2:
	return CENTER_XZ


## dist/RADIUS: 0 at center, 1.0 exactly on the boundary. NaN-safe (NaN in -> -1).
static func normalized_radius(v: Vector2) -> float:
	var d: float = dist_to_center_xz(v)
	if not is_finite(d):
		return -1.0
	return d / RADIUS_M


## Clamp a full 3D position into the playable circle (Y preserved).
static func clamp_position_to_world(p: Vector3, inset_m: float = 10.0) -> Vector3:
	var xz: Vector2 = clamp_to_playable(Vector2(p.x, p.z), inset_m)
	return Vector3(xz.x, p.y, xz.y)


## Map projection API (single authority; UI must never hold world-size consts):
## world XZ -> unit-disk coords [-1,1] -> minimap px.
static func world_to_map_norm(v: Vector2) -> Vector2:
	return (v - CENTER_XZ) / RADIUS_M


static func world_to_map(v: Vector2, map_radius_px: float) -> Vector2:
	return world_to_map_norm(v) * map_radius_px


static func map_to_world(map_pos: Vector2, map_radius_px: float) -> Vector2:
	if map_radius_px <= 0.0:
		return CENTER_XZ
	return CENTER_XZ + (map_pos / map_radius_px) * RADIUS_M


## Schema record embedded in world_data["world"] (P02 §12). Units explicit.
static func schema_dict() -> Dictionary:
	return {
		"id": WORLD_ID,
		"schema_version": SCHEMA_VERSION,
		"revision": WORLD_REVISION,
		"seed": WORLD_SEED,
		"center_xz_m": [CENTER_XZ.x, CENTER_XZ.y],
		"radius_m": RADIUS_M,
		"diameter_m": DIAMETER_M,
		"land_radius_m": LAND_RADIUS_M,
		"road_limit_radius_m": ROAD_LIMIT_RADIUS_M,
		"macro_sector_m": SECTOR_M,
		"micro_sector_m": MICRO_SECTOR_M,
		"coordinate_system": "right-handed; XZ ground plane; Y elevation; origin at world center",
	}


## --- Reference metrics ---

## Mathematical circle area in km^2 (envelope reference, not authored land).
static func envelope_area_km2() -> float:
	return PI * (RADIUS_M * RADIUS_M) / 1_000_000.0


## Self-check used by tests: returns {ok, ...measured values...}.
static func validate() -> Dictionary:
	var center_ok: bool = dist_to_center(Vector3(CENTER_XZ.x, 0.0, CENTER_XZ.y)) == 0.0
	var diameter_ok: bool = is_equal_approx(DIAMETER_M, RADIUS_M * 2.0)
	var edge_in: bool = is_playable(Vector3(RADIUS_M, 0.0, 0.0))
	var edge_out: bool = not is_playable(Vector3(RADIUS_M + 0.01, 0.0, 0.0))
	var aabb_ok: bool = true
	for p in [Vector3(-RADIUS_M, 0, -RADIUS_M), Vector3(RADIUS_M, 0, RADIUS_M)]:
		if not WORLD_BOUNDS_AABB.has_point(p):
			aabb_ok = false
	var sectors: int = sector_count()
	return {
		"ok": center_ok and diameter_ok and edge_in and edge_out and aabb_ok and sectors > 0,
		"center_ok": center_ok,
		"diameter_ok": diameter_ok,
		"edge_inclusive_ok": edge_in,
		"edge_exclusive_ok": edge_out,
		"aabb_contains_circle_ok": aabb_ok,
		"sector_count": sectors,
		"envelope_area_km2": envelope_area_km2(),
	}
