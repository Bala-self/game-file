class_name TerrainChunks
## P03 §18/§19: sector-aligned terrain chunking with LOD and streamed
## collision. The height field (WorldTerrain.height_at) stays the single
## source of truth; chunks are pure derivations — no authored heights here.
##
## Layout: 250 m chunks on the world grid, 12x12 quads each (169 verts,
## ~20.8 m spacing). Chunks derive vertex colors from the surface mask, use
## one shared vertex-color material, and carry a concave collision body that
## streams ON only near the player (no far full-collision, §19). Meshes cap
## draw distance via visibility_range_end (4200 m mountain / 1700 m plain).
##
## Chunk bodies are EXCLUDED from the tile streamer (a 250 m body spans up
## to four 125 m sectors — tile ownership would flicker it); collision is
## distance-streamed here instead. Deterministic: no RNG anywhere.

const CHUNK_M := 250.0
const QUADS := 12
const VERTS_SIDE := QUADS + 1
const GRID_RANGE := 12            # gx/gz in [-12, 11]
const DEEP_SKIP_M := 2.0          # skip chunks entirely below SEA - 2
const SAND_UNDERLAY_Y := -0.25    # hidden inside the legacy sand skirt
const COLLISION_RANGE_M := 700.0  # body collision streams on inside this
const VIS_FAR_M := 4200.0         # mountain LOD draw cap
const VIS_NEAR_M := 1700.0        # plain LOD draw cap

const COL_WATER := Color(0.20, 0.32, 0.38)
const COL_SAND := Color(0.72, 0.66, 0.50)
const COL_URBAN := Color(0.46, 0.48, 0.44)
const COL_GRASS := Color(0.40, 0.55, 0.32)
const COL_FOREST := Color(0.24, 0.40, 0.22)
const COL_FIELD := Color(0.55, 0.52, 0.30)
const COL_DRY := Color(0.58, 0.52, 0.34)
const COL_FOOTHILL := Color(0.44, 0.47, 0.34)
const COL_ROCK := Color(0.45, 0.43, 0.40)
const COL_MOUNTAIN := Color(0.55, 0.54, 0.52)
const COL_WET := Color(0.30, 0.38, 0.28)
const COL_MUD := Color(0.42, 0.36, 0.27)
const COL_IND := Color(0.47, 0.46, 0.43)

static var _material: StandardMaterial3D = null


static func _shared_material() -> StandardMaterial3D:
	if _material == null:
		_material = StandardMaterial3D.new()
		_material.vertex_color_use_as_albedo = true
		_material.roughness = 0.92
		_material.metallic = 0.0
	return _material


## Per-vertex surface color (mirrors WorldTerrain.surface_class_at but uses
## grid-derived slope so the build stays inside budget).
static func _vertex_color(h: float, slope_pct: float, x: float, z: float,
		in_sand: bool) -> Color:
	if in_sand:
		return COL_SAND
	if h < TerrainAuthoring.SEA_LEVEL_M + 0.05:
		return COL_WATER
	var p := Vector2(x, z)
	var r: float = p.length()
	if WorldTerrain._river_dist(x, z) < WorldTerrain._river_width_at(x, z) + 8.0:
		return COL_MUD
	if p.distance_to(TerrainAuthoring.LAKE_CENTER) < TerrainAuthoring.LAKE_RADIUS_M * 1.2:
		return COL_WET if h < TerrainAuthoring.LAKE_LEVEL_M + 1.5 else COL_GRASS
	var a_deg: float = WorldTerrain._bearing_deg(x, z)
	if r > TerrainAuthoring.land_end_r(a_deg) - 200.0 and h < TerrainAuthoring.SEA_LEVEL_M + 3.0:
		return COL_ROCK if slope_pct > 45.0 else COL_SAND
	if r <= TerrainAuthoring.PLATFORM_RADIUS_M + 40.0:
		return COL_URBAN
	if h < TerrainAuthoring.SEA_LEVEL_M + 0.8 and slope_pct < 10.0 \
			and a_deg > 50.0 and a_deg < 110.0:
		return COL_WET
	var dtype: String = WorldSectorRegistry.district_type_of(
			WorldSectorRegistry.district_at_xz(p))
	if slope_pct > 60.0:
		return COL_ROCK
	match dtype:
		"mountain_wild":
			if h > 150.0: return COL_MOUNTAIN
			if h > 60.0: return COL_FOOTHILL
			return COL_GRASS
		"affluent_hills":
			return COL_ROCK if slope_pct > 50.0 else COL_FOOTHILL
		"farmland":
			return COL_FOREST if WorldTerrain._fbm(x * 1.7, z * 1.7) > 0.45 else COL_FIELD
		"rural_dry":
			return COL_DRY
		"port_industrial", "heavy_industrial", "airport", "military":
			return COL_IND
		"beach_resort":
			return COL_SAND if h < 12.0 else COL_GRASS
		"park_water":
			return COL_GRASS
	return COL_GRASS


## Build all chunks under `root`. Returns stats for gates/docs.
static func build(root: Node3D) -> Dictionary:
	var t0: int = Time.get_ticks_msec()
	var holder := Node3D.new()
	holder.name = "TerrainChunks"
	root.add_child(holder)
	var WB := preload("res://scripts/world/wb_kit.gd")
	var sand_rect: Rect2 = WB.SAND
	var chunks := 0
	var verts := 0
	var tris := 0
	var skipped_water := 0
	var skipped_sand := 0
	var max_h := -1e9
	for gx in range(-GRID_RANGE, GRID_RANGE):
		for gz in range(-GRID_RANGE, GRID_RANGE):
			var origin := Vector2(float(gx) * CHUNK_M, float(gz) * CHUNK_M)
			var res: Dictionary = _build_chunk(holder, origin, sand_rect)
			match String(res.get("state", "skip")):
				"built":
					chunks += 1
					verts += int(res["verts"])
					tris += int(res["tris"])
					max_h = maxf(max_h, float(res["max_h"]))
				"water": skipped_water += 1
				"sand": skipped_sand += 1
	var streamer := ChunkCollisionStreamer.new()
	streamer.name = "ChunkCollisionStreamer"
	holder.add_child(streamer)
	var ms: int = Time.get_ticks_msec() - t0
	return {"chunks": chunks, "verts": verts, "tris": tris,
			"skipped_water": skipped_water, "skipped_sand": skipped_sand,
			"max_h": max_h, "build_ms": ms}


static func _build_chunk(holder: Node3D, origin: Vector2, sand_rect: Rect2) -> Dictionary:
	var step: float = CHUNK_M / float(QUADS)
	var hs: PackedFloat64Array = PackedFloat64Array()
	hs.resize(VERTS_SIDE * VERTS_SIDE)
	var all_wet := true
	var all_sand := true
	var chunk_max_h := -1e9
	for iz in range(VERTS_SIDE):
		for ix in range(VERTS_SIDE):
			var x: float = origin.x + float(ix) * step
			var z: float = origin.y + float(iz) * step
			var h: float = WorldTerrain.height_at(x, z)
			var in_sand: bool = sand_rect.has_point(Vector2(x, z))
			if in_sand:
				h = SAND_UNDERLAY_Y  # underlay: hidden inside the sand skirt
			hs[iz * VERTS_SIDE + ix] = h
			if not in_sand:
				all_sand = false
			if h >= TerrainAuthoring.SEA_LEVEL_M - DEEP_SKIP_M:
				all_wet = false
			chunk_max_h = maxf(chunk_max_h, h)
	if all_sand:
		return {"state": "sand"}   # legacy sand box already covers this
	if all_wet:
		return {"state": "water"}  # open sea floor: the ocean plane suffices
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for iz in range(VERTS_SIDE):
		for ix in range(VERTS_SIDE):
			var x: float = origin.x + float(ix) * step
			var z: float = origin.y + float(iz) * step
			var h: float = hs[iz * VERTS_SIDE + ix]
			var slope: float = _grid_slope_pct(hs, ix, iz, origin, step)
			st.set_color(_vertex_color(h, slope, x, z,
					sand_rect.has_point(Vector2(x, z))))
			st.add_vertex(Vector3(x, h, z))
	var quad_tris := 0
	for iz in range(QUADS):
		for ix in range(QUADS):
			if not _quad_in_world(origin, ix, iz, step):
				continue
			var a: int = iz * VERTS_SIDE + ix
			var b: int = a + 1
			var c: int = a + VERTS_SIDE
			var d: int = c + 1
			st.add_index(a); st.add_index(c); st.add_index(b)
			st.add_index(b); st.add_index(c); st.add_index(d)
			quad_tris += 2
	if quad_tris == 0:
		return {"state": "water"}
	st.generate_normals()
	st.index()
	var mesh: ArrayMesh = st.commit()
	var gx: int = int(round(origin.x / CHUNK_M))
	var gz: int = int(round(origin.y / CHUNK_M))
	# body sits at the chunk CENTER (geometry stays world-spaced, children
	# offset by -center) so distance streaming measures from the right point
	var center := Vector3(origin.x + CHUNK_M * 0.5, 0.0, origin.y + CHUNK_M * 0.5)
	var body := StaticBody3D.new()
	body.name = "TerrainBody_T_%d_%d" % [gx, gz]
	body.position = center
	var col := CollisionShape3D.new()
	col.shape = mesh.create_trimesh_shape()
	col.position = -center
	body.add_child(col)
	var mi := MeshInstance3D.new()
	mi.name = "TerrainChunk_T_%d_%d" % [gx, gz]
	mi.position = -center
	mi.mesh = mesh
	mi.material_override = _shared_material()
	mi.visibility_range_end = VIS_FAR_M if chunk_max_h > 60.0 else VIS_NEAR_M
	mi.visibility_range_fade_mode = GeometryInstance3D.VISIBILITY_RANGE_FADE_SELF
	body.add_child(mi)
	holder.add_child(body)
	# groups AFTER tree entry (add_to_group before add_child fails silently)
	body.add_to_group("terrain_chunks")
	mi.add_to_group("terrain_chunks")
	return {"state": "built", "verts": VERTS_SIDE * VERTS_SIDE,
			"tris": quad_tris, "max_h": chunk_max_h}


## Central-difference slope from the built grid (cheap stand-in for the
## per-vertex slope_at query, same math at the grid's own resolution).
static func _grid_slope_pct(hs: PackedFloat64Array, ix: int, iz: int,
		origin: Vector2, step: float) -> float:
	var ix0: int = maxi(ix - 1, 0)
	var ix1: int = mini(ix + 1, VERTS_SIDE - 1)
	var iz0: int = maxi(iz - 1, 0)
	var iz1: int = mini(iz + 1, VERTS_SIDE - 1)
	var dx: float = (hs[iz * VERTS_SIDE + ix1] - hs[iz * VERTS_SIDE + ix0]) \
			/ (float(ix1 - ix0) * step)
	var dz: float = (hs[iz1 * VERTS_SIDE + ix] - hs[iz0 * VERTS_SIDE + ix]) \
			/ (float(iz1 - iz0) * step)
	return Vector2(dx, dz).length() * 100.0


static func _quad_in_world(origin: Vector2, ix: int, iz: int, step: float) -> bool:
	for cz in range(2):
		for cx in range(2):
			var x: float = origin.x + float(ix + cx) * step
			var z: float = origin.y + float(iz + cz) * step
			if not WorldContract.is_playable(Vector3(x, 0.0, z)):
				return false
	return true


## Distance-streamed chunk collision: bodies inside COLLISION_RANGE_M of the
## player keep collision; everything further is layer-0 (no far full-collision
## anywhere in the world, §19). Ticks on physics frames; cheap (430 checks).
class ChunkCollisionStreamer:
	extends Node
	var _bodies: Array[StaticBody3D] = []
	var _on: Array[bool] = []
	var _player: Node3D = null

	func _ready() -> void:
		for n: Node in get_tree().get_nodes_in_group("terrain_chunks"):
			if n is StaticBody3D:
				_bodies.append(n)
				_on.append(true)

	func _physics_process(_d: float) -> void:
		if _player == null or not is_instance_valid(_player):
			var pl: Array[Node] = get_tree().get_nodes_in_group("player")
			_player = pl[0] as Node3D if pl.size() > 0 else null
			if _player == null:
				return
		var pp: Vector3 = _player.global_position
		var lim: float = COLLISION_RANGE_M * COLLISION_RANGE_M
		for i in range(_bodies.size()):
			var b: StaticBody3D = _bodies[i]
			if not is_instance_valid(b):
				continue
			var want: bool = b.global_position.distance_squared_to(
					Vector3(pp.x, b.global_position.y, pp.z)) <= lim
			if want != _on[i]:
				b.collision_layer = 1 if want else 0
				_on[i] = want
