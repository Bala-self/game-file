class_name BuildingKit
extends Object
## Round 13 — 10 realistic building designs (Blender set mirror, game-side).
## The authored GLBs live in assets/models/buildings/ (building_01..10.glb,
## exported from Blender 4.2 via tools/buildings/building_set.py). This kit
## rebuilds the same 10 designs procedurally in Godot and UPGRADES existing
## world content. Strictly additive: no world_data changes, no qa_rects,
## no dt_heights; new physics limited to 5 bodies total; everything tagged
## into bk_* groups for smoke gates. Deterministic (own fixed-seed RNG).

const K := preload("res://scripts/world/wb_kit.gd")

## Designs authored in the Blender set (id -> GLB name), 1:1 with exports.
const DESIGNS: Dictionary = {
	"suburban_house": "BUILDING_01_SUBURBAN_HOUSE",
	"modern_apartment": "BUILDING_02_MODERN_APARTMENT",
	"small_shop": "BUILDING_03_SMALL_SHOP",
	"motel": "BUILDING_04_MOTEL",
	"industrial_warehouse": "BUILDING_05_INDUSTRIAL_WAREHOUSE",
	"office_building": "BUILDING_06_OFFICE_BUILDING",
	"gas_station": "BUILDING_07_GAS_STATION",
	"small_clinic": "BUILDING_08_SMALL_CLINIC",
	"police_station": "BUILDING_09_POLICE_STATION",
	"abandoned_building": "BUILDING_10_ABANDONED_BUILDING",
}


static func upgrade(root: Node3D) -> void:
	var rng: RandomNumberGenerator = RandomNumberGenerator.new()
	rng.seed = 20260919  # building set is deterministic like the island
	_up_suburban_houses(root)
	_up_apartment(root)
	_up_shop_shutters(root)
	_up_motel(root)
	_up_warehouse_dock(root)
	_up_office(root)
	_up_gas_station(root)
	_up_clinic(root)
	_up_police_station(root)
	_up_abandoned(root, rng)
	print("BUILDING_KIT: 10-design upgrade pass applied")


## Local helper: K._box + rotation (visual-only). Keeps K._box contract clean.
static func _boxr(root: Node3D, size: Vector3, xz: Vector2, top_y: float,
		color: Color, rot_deg: Vector3, label: String) -> Node3D:
	var b: Node3D = K._box(root, size, xz, top_y, color, false, label)
	b.rotation_degrees = rot_deg
	return b


## 01 — Suburban House: porch + garage + gable roof + props on 4 houses.
static func _up_suburban_houses(root: Node3D) -> void:
	var houses: Array = []
	for n: Node in root.find_children("*", "StaticBody3D", true, false):
		if n.has_meta("kind") and str(n.get_meta("kind")) == "house":
			houses.append(n)
	houses.sort_custom(func(a: Node3D, c: Node3D) -> bool:
		return a.position.x < c.position.x)
	var done: int = 0
	for h: Node3D in houses:
		if done >= 4:
			break
		var hxz: Vector2 = Vector2(h.position.x, h.position.z)
		# porch: slab, two posts, shed roof
		K._box(root, Vector3(4.2, 0.22, 2.0), hxz + Vector2(0, 4.6), 0.22,
				Color(0.62, 0.60, 0.57), false, "PorchSlab%d" % done)
		K._box(root, Vector3(0.16, 2.3, 0.16), hxz + Vector2(-1.8, 5.4), 2.4,
				Color(0.88, 0.88, 0.86), false, "PorchPost%d_a" % done)
		K._box(root, Vector3(0.16, 2.3, 0.16), hxz + Vector2(1.8, 5.4), 2.4,
				Color(0.88, 0.88, 0.86), false, "PorchPost%d_b" % done)
		var proof: Node3D = _boxr(root, Vector3(4.6, 0.12, 2.4), hxz + Vector2(0, 4.7),
				2.85, Color(0.38, 0.28, 0.20), Vector3(10, 0, 0),
				"PorchRoof%d" % done)
		proof.add_to_group("bk_suburban")
		# garage: volume + flat roof + ribbed door
		var gx: Vector2 = hxz + Vector2(7.5, -1.0)
		var collide_garage: bool = K._road_point_free(gx, 5.0)
		K._box(root, Vector3(6.0, 3.0, 6.0), gx, 3.0, Color(0.82, 0.78, 0.70),
				collide_garage, "HouseGarage%d" % done)
		K._box(root, Vector3(6.4, 0.2, 6.4), gx, 3.3, Color(0.40, 0.30, 0.24),
				false, "GarageRoof%d" % done)
		for s: int in range(5):
			_boxr(root, Vector3(2.6, 0.38, 0.06), gx + Vector2(0, 3.05),
					3.25 - s * 0.42, Color(0.85, 0.85, 0.87), Vector3.ZERO,
					"GarageSlat%d_%d" % [done, s])
		# gable roof planes on the house mass
		_boxr(root, Vector3(9.8, 0.14, 4.4), hxz + Vector2(0, 2.0), 6.9,
				Color(0.42, 0.28, 0.20), Vector3(-33, 0, 0),
				"GableRoof%d_a" % done)
		var roof_b: Node3D = _boxr(root, Vector3(9.8, 0.14, 4.4), hxz + Vector2(0, -2.0),
				6.9, Color(0.42, 0.28, 0.20), Vector3(33, 0, 0),
				"GableRoof%d_b" % done)
		roof_b.add_to_group("bk_suburban")
		# AC unit + electrical box + trash bin
		K._box(root, Vector3(0.9, 0.7, 0.9), hxz + Vector2(-5.4, 2.0), 0.45,
				Color(0.85, 0.86, 0.87), false, "HouseAC%d" % done)
		K._box(root, Vector3(0.5, 0.7, 0.22), hxz + Vector2(5.05, -3.2), 1.35,
				Color(0.18, 0.19, 0.2), false, "HouseElec%d" % done)
		var bin_body: Node3D = K._box(root, Vector3(0.64, 0.85, 0.64),
				hxz + Vector2(8.6, 1.6), 0.85, Color(0.18, 0.19, 0.2), false,
				"HouseBin%d" % done)
		bin_body.add_to_group("bk_suburban")
		done += 1


## 02 — Modern Apartment: 4 floors, glass bands, balconies, parking pad.
static func _up_apartment(root: Node3D) -> void:
	var spots: Array = [Vector2(210, -112), Vector2(215, -128), Vector2(202, -140)]
	var xz: Vector2 = spots[0]
	for c: Vector2 in spots:
		if K._road_point_free(c, 17.0):
			xz = c
			break
	var W: float = 22.0
	var D: float = 16.0
	var FH: float = 3.0
	var concrete: Color = Color(0.62, 0.61, 0.58)
	# main volume is ONE physics body; everything else visual-only
	var main: Node3D = K._box(root, Vector3(W, FH * 4.0 + 0.3, D), xz,
			FH * 4.0 + 0.3, concrete, true, "ApartmentMain")
	main.add_to_group("bk_apartment")
	var glass: Color = Color(0.16, 0.24, 0.30)
	for f: int in range(4):
		var z0: float = f * FH
		K._box(root, Vector3(W - 1.0, FH - 1.3, 0.1), xz + Vector2(0, D / 2),
				z0 + 2.1, glass, false, "AptGlassF%d" % f)
		K._box(root, Vector3(W - 1.0, 0.1, FH - 1.3), xz + Vector2(0, D / 2),
				z0 + 1.45, concrete, false, "AptBandF%d" % f)
		for bx: float in [-7.5, -2.5, 2.5, 7.5]:
			K._box(root, Vector3(3.0, 0.15, 1.6), xz + Vector2(bx, D / 2 + 0.9),
					z0 + 0.85, Color(0.55, 0.54, 0.52), false,
					"AptBalcony%d_%d" % [f, int(bx)])
			K._box(root, Vector3(3.0, 1.0, 0.06), xz + Vector2(bx, D / 2 + 1.65),
					z0 + 1.35, Color(0.18, 0.19, 0.2), false,
					"AptRail%d_%d" % [f, int(bx)])
	K._box(root, Vector3(4.0, 2.2, 3.2), xz + Vector2(-6, 0), FH * 4.0 + 1.4,
			concrete, false, "AptBulkhead")
	_ac(root, xz + Vector2(6.5, -2.0), FH * 4.0 + 0.3, "AptHVAC")
	K._box(root, Vector3(16.0, 0.06, 5.0), xz + Vector2(0, D / 2 + 5.5), 0.06,
			Color(0.16, 0.16, 0.17), false, "AptParkingPad")
	for wx: float in [-4.0, 4.0]:
		K._box(root, Vector3(1.8, 0.12, 0.15), xz + Vector2(wx, D / 2 + 4.4), 0.12,
				Color(0.05, 0.05, 0.05), false, "AptWheelStop%d" % int(wx))
	K._box(root, Vector3(2.2, 2.4, 0.1), xz + Vector2(0, D / 2 + 0.06), 1.45,
			glass, false, "AptLobbyDoor")


## 03 — Small Shop: signage band + roller shutters on the 3 row stores.
static func _up_shop_shutters(root: Node3D) -> void:
	var fronts: Array = [Vector2(-253, -157), Vector2(-253, -197), Vector2(-253, -237)]
	for i: int in range(fronts.size()):
		var xz: Vector2 = fronts[i]
		K._box(root, Vector3(5.0, 0.9, 0.14), xz + Vector2(5.3, 0), 3.9,
				Color(0.65, 0.14, 0.12), false, "ShopSignBand%d" % i)
		for s: int in range(6):
			var slat: Node3D = _boxr(root, Vector3(2.4, 0.06, 0.28),
					xz + Vector2(5.3, 0), 2.15 - s * 0.31,
					Color(0.85, 0.85, 0.87), Vector3.ZERO,
					"Shutter%d_%d" % [i, s])
			slat.add_to_group("bk_shutter")
		_boxr(root, Vector3(2.6, 0.2, 0.25), xz + Vector2(5.3, 0), 2.35,
				Color(0.75, 0.76, 0.78), Vector3.ZERO, "ShutterBox%d" % i)


## 04 — Motel: 2 floors, external walkway, 6 unit doors, pylon sign, stalls.
static func _up_motel(root: Node3D) -> void:
	var spots: Array = [Vector2(-84, 66), Vector2(-104, 72), Vector2(-64, 74)]
	var xz: Vector2 = spots[0]
	for c: Vector2 in spots:
		if K._road_point_free(c, 21.0):
			xz = c
			break
	var W: float = 21.0
	var D: float = 7.0
	var plaster: Color = Color(0.80, 0.74, 0.62)
	var main: Node3D = K._box(root, Vector3(W, 6.2, D), xz, 6.2, plaster, true,
			"MotelMain")
	main.add_to_group("bk_motel")
	for f: int in range(2):
		var z0: float = f * 3.1
		K._box(root, Vector3(W, 0.18, 2.0), xz + Vector2(0, D / 2 + 0.9),
				z0 + 0.31, Color(0.58, 0.58, 0.56), false, "MotelWalkway%d" % f)
		K._box(root, Vector3(W, 1.0, 0.06), xz + Vector2(0, D / 2 + 1.85),
				z0 + 0.95, Color(0.18, 0.19, 0.2), false, "MotelRail%d" % f)
		for u: int in range(6):
			var dr: Node3D = K._box(root, Vector3(0.95, 2.1, 0.08),
					xz + Vector2(-7.5 + u * 3.0, D / 2 + 0.04), z0 + 1.3,
					Color(0.34, 0.22, 0.13), false, "MotelDoor%d_%d" % [f, u])
			dr.add_to_group("bk_motel_door")
			K._box(root, Vector3(1.2, 1.1, 0.06),
					xz + Vector2(-6.0 + u * 3.0, D / 2 + 0.04), z0 + 1.7,
					Color(0.2, 0.3, 0.34), false, "MotelWin%d_%d" % [f, u])
	K._box(root, Vector3(0.35, 5.0, 0.35), xz + Vector2(-W / 2 - 3.0, D / 2 + 4.0),
			2.5, Color(0.18, 0.19, 0.2), false, "MotelSignPole")
	K._box(root, Vector3(2.6, 1.6, 0.5), xz + Vector2(-W / 2 - 3.0, D / 2 + 4.0),
			5.6, Color(0.65, 0.14, 0.12), false, "MotelSignCab")
	K._box(root, Vector3(W + 10.0, 0.05, 7.0), xz + Vector2(0, D / 2 + 7.0), 0.05,
			Color(0.16, 0.16, 0.17), false, "MotelParking")
	for i: int in range(7):
		K._box(root, Vector3(0.12, 4.2, 0.03),
				xz + Vector2(-W / 2 + 3.0 + i * 3.0, D / 2 + 7.0), 0.08,
				Color(0.9, 0.9, 0.88), false, "MotelStall%d" % i)


## 05 — Industrial Warehouse: loading dock + bumpers + dock door + vents.
static func _up_warehouse_dock(root: Node3D) -> void:
	var wh: Node3D = root.get_node_or_null("WarehouseFloor")
	if wh == null:
		return
	var wxz: Vector2 = Vector2(wh.position.x, wh.position.z)
	var xz: Vector2 = wxz + Vector2(-6, -10.5)
	if not K._road_point_free(xz, 8.0):
		xz = wxz + Vector2(6, -10.5)
	var dock: Node3D = K._box(root, Vector3(12.0, 1.1, 4.0), xz, 1.1,
			Color(0.62, 0.61, 0.58), true, "WarehouseDock")
	dock.add_to_group("bk_dock")
	for bx: float in [-4.4, 0.0, 4.4]:
		K._box(root, Vector3(0.4, 0.5, 0.3), xz + Vector2(bx, -1.9), 0.85,
				Color(0.05, 0.05, 0.05), false, "DockBumper%d" % int(bx))
	for s: int in range(6):
		_boxr(root, Vector3(3.0, 0.4, 0.07), xz + Vector2(0, -2.0),
				4.85 - s * 0.5, Color(0.85, 0.85, 0.87), Vector3.ZERO,
				"DockDoorSlat%d" % s)
	for vx: float in [-8.0, 0.0, 8.0]:
		K._box(root, Vector3(1.2, 0.9, 1.2), wxz + Vector2(vx, 3.0), 8.45,
				Color(0.18, 0.19, 0.2), false, "RoofVent%d" % int(vx))
		K._box(root, Vector3(1.5, 0.15, 1.5), wxz + Vector2(vx, 3.0), 8.95,
				Color(0.85, 0.86, 0.87), false, "VentCowl%d" % int(vx))


## 06 — Office Building: glass lobby, canopy, rooftop chillers + antenna on a Twin.
static func _up_office(root: Node3D) -> void:
	var twin: Node3D = null
	for n: Node in root.find_children("*", "StaticBody3D", true, false):
		if String(n.name).begins_with("Twin"):
			twin = n
			break
	if twin == null:
		return
	var xz: Vector2 = Vector2(twin.position.x, twin.position.z)
	K._box(root, Vector3(5.0, 2.6, 0.1), xz + Vector2(0, 9.05), 1.6,
			Color(0.16, 0.24, 0.30), false, "OfficeLobbyGlass")
	var canopy: Node3D = K._box(root, Vector3(7.0, 0.22, 2.8), xz + Vector2(0, 10.4),
			3.3, Color(0.18, 0.19, 0.2), false, "OfficeCanopy")
	canopy.add_to_group("bk_office")
	for px: float in [-2.8, 2.8]:
		K._box(root, Vector3(0.08, 1.3, 0.08), xz + Vector2(px, 11.6), 3.9,
				Color(0.18, 0.19, 0.2), false, "OfficeCanopyRod%d" % int(px))
	_ac(root, xz + Vector2(-4.0, -3.0), 62.2, "OfficeChiller1")
	_ac(root, xz + Vector2(4.0, -3.0), 62.2, "OfficeChiller2")
	var mast: Node3D = K._box(root, Vector3(0.12, 5.0, 0.12), xz + Vector2(0, -6.0),
			64.5, Color(0.18, 0.19, 0.2), false, "OfficeMast")
	mast.add_to_group("bk_office_hvac")


## 07 — Gas Station: price sign, tank covers, pump screens (canopy already shipped).
static func _up_gas_station(root: Node3D) -> void:
	var g: Vector2 = Vector2(K.GAS_SPOT.x, K.GAS_SPOT.z)
	K._box(root, Vector3(0.3, 4.0, 0.3), g + Vector2(-14.0, -7.0), 2.0,
			Color(0.18, 0.19, 0.2), false, "GasPricePole")
	var price: Node3D = K._box(root, Vector3(2.2, 2.6, 0.35), g + Vector2(-14.0, -7.0),
			5.2, Color(0.88, 0.88, 0.86), false, "GasPriceBox")
	price.add_to_group("bk_gas_price")
	for tx: float in [-2.0, 2.0]:
		K._box(root, Vector3(1.1, 0.12, 1.1), g + Vector2(tx, -8.5), 0.12,
				Color(0.18, 0.19, 0.2), false, "GasTankCover%d" % int(tx))
	for px: float in [-3.0, 3.0]:
		K._box(root, Vector3(0.5, 0.4, 0.08), g + Vector2(px, -1.35), 1.35,
				Color(0.16, 0.24, 0.30), false, "PumpScreen%d" % int(px))


## 08 — Small Clinic: ramp + rails + cross sign + emergency pad near the hospital.
static func _up_clinic(root: Node3D) -> void:
	var spots: Array = [Vector2(K.HOSPITAL_SPOT.x + 24.0, K.HOSPITAL_SPOT.y + 2.0),
			Vector2(K.HOSPITAL_SPOT.x + 24.0, K.HOSPITAL_SPOT.y - 12.0),
			Vector2(K.HOSPITAL_SPOT.x - 24.0, K.HOSPITAL_SPOT.y + 2.0)]
	var xz: Vector2 = spots[0]
	for c: Vector2 in spots:
		if K._road_point_free(c, 13.0):
			xz = c
			break
	var W: float = 20.0
	var D: float = 15.0
	var plaster: Color = Color(0.86, 0.85, 0.80)
	var main: Node3D = K._box(root, Vector3(W, 3.4, D), xz, 3.4, plaster, true,
			"ClinicMain")
	main.add_to_group("bk_clinic")
	K._box(root, Vector3(6.0, 0.8, 0.12), xz + Vector2(0, D / 2 + 0.06), 3.0,
			Color(0.88, 0.88, 0.86), false, "ClinicSignBand")
	K._box(root, Vector3(0.5, 1.6, 0.1), xz + Vector2(3.2, D / 2 + 0.08), 3.0,
			Color(0.85, 0.15, 0.15), false, "ClinicCrossV")
	K._box(root, Vector3(1.6, 0.5, 0.1), xz + Vector2(3.2, D / 2 + 0.08), 3.0,
			Color(0.85, 0.15, 0.15), false, "ClinicCrossH")
	_boxr(root, Vector3(2.4, 0.15, 4.2), xz + Vector2(-2.5, D / 2 + 2.2), 0.45,
			Color(0.62, 0.61, 0.58), Vector3(13, 0, 0), "ClinicRamp")
	for rx: float in [-3.7, -1.3]:
		K._box(root, Vector3(0.07, 0.9, 4.2), xz + Vector2(rx, D / 2 + 2.2), 0.9,
				Color(0.18, 0.19, 0.2), false, "ClinicRampRail%d" % int(rx))
	K._box(root, Vector3(6.0, 0.06, 5.0), xz + Vector2(W / 2 + 3.5, 0), 0.06,
			Color(0.16, 0.16, 0.17), false, "ClinicEmergencyPad")
	K._box(root, Vector3(5.0, 0.2, 3.0), xz + Vector2(W / 2 + 1.8, 0), 3.2,
			Color(0.88, 0.88, 0.86), false, "ClinicCanopy")
	for py: float in [-1.2, 1.2]:
		K._box(root, Vector3(0.25, 3.1, 0.25), xz + Vector2(W / 2 + 3.0, py), 1.6,
				Color(0.18, 0.19, 0.2), false, "ClinicCanopyCol%d" % int(py))
	K._box(root, Vector3(4.0, 1.0, 0.9), xz + Vector2(0, D / 2 - 2.5), 0.65,
			Color(0.34, 0.22, 0.13), false, "ClinicReception")


## 09 — Police Station: 3-bay garage + steps + canopy + blue band + comms mast.
static func _up_police_station(root: Node3D) -> void:
	var ps: Node3D = root.get_node_or_null("PoliceStationFloor")
	if ps == null:
		return
	var xz: Vector2 = Vector2(ps.position.x, ps.position.z)
	var gx: Vector2 = xz + Vector2(-16.0, 0.0)
	if not K._road_point_free(gx, 8.0):
		gx = xz + Vector2(16.0, 0.0)
	var garage: Node3D = K._box(root, Vector3(10.0, 4.6, 9.0), gx, 4.6,
			Color(0.62, 0.61, 0.58), true, "PoliceGarage")
	garage.add_to_group("bk_police_garage")
	for bi: int in range(3):
		var by: float = -2.8 + bi * 2.8
		for s: int in range(6):
			var slat: Node3D = _boxr(root, Vector3(0.07, 0.38, 2.4),
					gx + Vector2(-5.05, by), 4.15 - s * 0.42,
					Color(0.85, 0.85, 0.87), Vector3(0, 90, 0),
					"BayDoor%d_%d" % [bi, s])
			slat.add_to_group("bk_police_baydoor")
	K._box(root, Vector3(3.6, 0.35, 1.2), xz + Vector2(0, 10.9), 0.35,
			Color(0.55, 0.54, 0.52), false, "PoliceSteps")
	var canopy: Node3D = K._box(root, Vector3(4.5, 0.22, 2.2), xz + Vector2(0, 11.4),
			3.3, Color(0.18, 0.19, 0.2), false, "PoliceCanopy")
	canopy.add_to_group("bk_police_garage")
	K._box(root, Vector3(27.0, 0.7, 0.1), xz + Vector2(0, 10.17), 6.2,
			Color(0.15, 0.30, 0.55), false, "PoliceBlueBand")
	K._box(root, Vector3(0.12, 5.5, 0.12), xz + Vector2(8.0, -6.0), 13.2,
			Color(0.18, 0.19, 0.2), false, "PoliceMast")


## 10 — Abandoned Building: boarded windows, rubble, overgrowth, broken roofline.
static func _up_abandoned(root: Node3D, rng: RandomNumberGenerator) -> void:
	var ab: Node3D = root.get_node_or_null("AbandonedHouseFloor")
	if ab == null:
		return
	var xz: Vector2 = Vector2(ab.position.x, ab.position.z)
	K._box(root, Vector3(9.6, 0.2, 3.0), xz + Vector2(1.0, -1.2), 5.9,
			Color(0.30, 0.28, 0.25), false, "AbandonedBrokenRoof")
	for i: int in range(3):
		for p: int in range(3):
			var rot: Vector3 = Vector3(0, 7.0, 0) if p % 2 == 0 else Vector3(0, -7.0, 0)
			var plank: Node3D = _boxr(root, Vector3(1.7, 0.06, 0.26),
					xz + Vector2(-2.6 + i * 2.6, 3.65), 1.25 + p * 0.42,
					Color(0.22, 0.15, 0.10), rot, "BoardWin%d_%d" % [i, p])
			plank.add_to_group("bk_boarded")
	for i: int in range(7):
		K._box(root, Vector3(rng.randf_range(0.3, 0.8), rng.randf_range(0.2, 0.5),
						rng.randf_range(0.3, 0.7)),
				xz + Vector2(rng.randf_range(-4.5, 4.5), rng.randf_range(4.6, 6.2)),
				rng.randf_range(0.15, 0.4), Color(0.42, 0.40, 0.36), false,
				"Rubble%d" % i)
	for i: int in range(4):
		K._bush(root, xz + Vector2(rng.randf_range(-4.0, 4.0), -4.8), rng)


## shared: rooftop HVAC unit (visual) tagged for the office/HVAC gate
static func _ac(root: Node3D, xz: Vector2, top_y: float, label: String) -> Node3D:
	var g: Node3D = K._box(root, Vector3(2.2, 1.0, 1.4), xz, top_y + 0.5,
			Color(0.85, 0.86, 0.87), false, label)
	K._box(root, Vector3(0.9, 0.25, 0.9), xz, top_y + 1.1,
			Color(0.18, 0.19, 0.2), false, label + "Fan")
	g.add_to_group("bk_office_hvac")
	return g
