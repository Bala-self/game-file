class_name WorldTerrain
extends Object
## Terrain service — Hybrid Realistic Mode (Staged Lock)
## Implements: flat for city/downtown/airport (preserve), hills/mountains north zone only
## Per user choice: hybrid — flat city + mountain hills north
## Height field is single source of truth — every system must ask height_at()
## Deep fix: explicit typing for all vars — no `:=` inferring Variant (warning treated as error)

const SEED: int = 7717
const AMPLITUDE: float = 18.0
const FREQ: float = 1.0 / 130.0
const MOUNTAIN_AMPLITUDE: float = 85.0
const HILL_AMPLITUDE: float = 28.0

static var activate: bool = false
static var active_zone: Rect2 = Rect2()

const FLAT_DISTRICTS: Array[Rect2] = [
	Rect2(-410, -280, 260, 210),
	Rect2(-100, -260, 340, 170),
	Rect2(-70, -350, 330, 100),
	Rect2(240, -320, 210, 80),
	Rect2(140, 60, 310, 240),
	Rect2(-410, 140, 300, 160),
	Rect2(-95, -55, 150, 170),
]

static func _hash2(ix: int, iz: int, oct: int) -> float:
	var k: int = int(SEED + ix * 374761393 + iz * 668265263 + oct * 2654435761)
	k = (k ^ (k >> 13)) * 1274126177
	return float((k ^ (k >> 16)) & 0xFFFF) / 65535.0

static func _noise2(x: float, z: float) -> float:
	var h: float = 0.0
	var amp: float = 1.0
	var fr: float = FREQ
	for o: int in range(3):
		var xf: float = x * fr
		var zf: float = z * fr
		var xi: int = floori(xf)
		var zi: int = floori(zf)
		var tx: float = xf - float(xi)
		var tz: float = zf - float(zi)
		var sx: float = tx * tx * (3.0 - 2.0 * tx)
		var sz: float = tz * tz * (3.0 - 2.0 * tz)
		var v00: float = _hash2(xi, zi, o)
		var v10: float = _hash2(xi + 1, zi, o)
		var v01: float = _hash2(xi, zi + 1, o)
		var v11: float = _hash2(xi + 1, zi + 1, o)
		h += amp * lerpf(lerpf(v00, v10, sx), lerpf(v01, v11, sx), sz)
		amp *= 0.5
		fr *= 2.0
	return h - 0.875

static func _is_flat_zone(x: float, z: float) -> bool:
	var p: Vector2 = Vector2(x, z)
	for r: Rect2 in FLAT_DISTRICTS:
		if r.has_point(p):
			return true
	return false

static func _mountain_mask(x: float, z: float) -> float:
	var north_factor: float = 0.0
	if z < -350.0:
		north_factor = 1.0
	elif z < -300.0:
		north_factor = clampf((-300.0 - z) / 50.0, 0.0, 1.0) * 1.0
	elif z < -220.0:
		north_factor = clampf((-220.0 - z) / 80.0, 0.0, 1.0) * 0.35
	else:
		north_factor = 0.0
	var ridge: float = sin(x * 0.008) * 0.15 + cos(x * 0.003) * 0.1
	north_factor = clampf(north_factor + ridge * north_factor, 0.0, 1.2)
	return north_factor

static func _river_carve(x: float, z: float) -> float:
	var river_x: float = -50.0 + sin(z * 0.01) * 80.0
	# Deep fix: abs() returns Variant -> use absf() for float explicit
	var dist_to_river: float = absf(x - river_x)
	if dist_to_river > 25.0:
		return 0.0
	var depth_factor: float = clampf((-z + 350.0) / 700.0, 0.2, 1.0)
	# Deep fix: explicit float type, no Variant inference
	var carve: float = (1.0 - dist_to_river / 25.0) * 4.0 * depth_factor
	return carve

## P02 terrain domain contract: the playable world is the WorldContract
## circle. Outside it, height_at returns a controlled deep-water value
## (below wb_kit.WATER_Y) so no system can read out-of-world terrain as
## flat playable land. Inside the circle, behavior is unchanged.
const OUT_OF_WORLD_Y := -3.0

## P02 chunk helper: which 125 m streaming sector a terrain sample belongs to
## (terrain chunk generation becomes sector-aware in P03; the query lands now
## so nothing grows a second coordinate scheme).
static func chunk_sector_of(x: float, z: float) -> Vector2i:
	return WorldContract.micro_sector_of(Vector2(x, z))

## Clip a build zone to the world circle's bounding box (Rect2 stays the zone
## API; this guarantees no zone can extend past the playable domain).
static func zone_clipped_to_world(zone: Rect2) -> Rect2:
	var lim: float = WorldContract.RADIUS_M
	var b := Rect2(Vector2(-lim, -lim), Vector2(lim * 2.0, lim * 2.0))
	return zone.intersection(b)

static func height_at(x: float, z: float) -> float:
	if not WorldContract.is_playable(Vector3(x, 0.0, z)):
		return OUT_OF_WORLD_Y
	# P03 dispatch. Order is contractual:
	#  1. legacy activated hybrid zone — kept BIT-IDENTICAL (terrain_test
	#     determinism gate h=21.3151 and patch-agreement gate lock this path);
	#  2. legacy flat districts — exactly 0.0;
	#  3. the P03 macro field, whose urban platform also returns exactly 0.0
	#     for r <= 700 m, so the flat contract over the legacy island holds.
	if activate and active_zone.has_point(Vector2(x, z)):
		return _legacy_zone_height(x, z)
	if _is_flat_zone(x, z):
		return 0.0
	return _road_corridor_blend(Vector2(x, z), _macro_height(x, z))


## --- P04 §79: authored road corridors (data in TA.ROAD_CORRIDORS) ---
## Blends a deterministic, grade-capped band into the macro field so the
## authored mountain roads sit on drivable ground. This is authored terrain
## data, not runtime deformation: the same input always yields the same
## output, and nothing here is driven by vehicle/agent state.
static var _corridor_cache: Array = []


static func _ensure_corridor_cache() -> void:
	if not _corridor_cache.is_empty():
		return
	# 1) weld corridor points across corridors into one node graph (shared
	#    junctions like (330,-2150) must have ONE elevation, else the blend
	#    field gets a cliff where two corridors meet).
	var nodes: Array = []          # Vector2
	var node_h: PackedFloat64Array = PackedFloat64Array()
	var edges: Array = []          # [ai, bi, cap]
	var per_corridor_idx: Array = []
	for c: Dictionary in TA.ROAD_CORRIDORS:
		var pts: Array = c["pts"]
		var g: float = float(c["grade"])
		var idxs: Array = []
		for p: Vector2 in pts:
			var found: int = -1
			for ni in range(nodes.size()):
				if (nodes[ni] as Vector2).distance_to(p) < 2.0:
					found = ni
					break
			if found < 0:
				nodes.append(p)
				node_h.append(_macro_height(p.x, p.y))
				found = nodes.size() - 1
			idxs.append(found)
		for i in range(idxs.size() - 1):
			var cap: float = (nodes[idxs[i]] as Vector2) \
					.distance_to(nodes[idxs[i + 1]] as Vector2) * g
			edges.append([idxs[i], idxs[i + 1], cap])
		per_corridor_idx.append(idxs)
	# 2) deterministic Gauss-Seidel relaxation over grade constraints:
	#    the profile stays as close to raw terrain as the caps allow, and
	#    every corridor edge is legal in both directions (fixed point).
	# Alternating-direction Gauss-Seidel: forward sweeps propagate
	# constraints along edge order, backward sweeps propagate against it.
	# One clamp per edge per sweep keeps the fixed point stable (clamping
	# both ends in one sweep re-steepens the previous edge). 32 sweeps
	# cover the longest coupled chain (descent -> junction -> sentinel).
	for _pass in range(32):
		var forward: bool = (_pass % 2) == 0
		var n_e: int = edges.size()
		for k in range(n_e):
			var e: Array = edges[k] if forward else edges[n_e - 1 - k]
			var ai: int = e[0]
			var bi: int = e[1]
			var cap2: float = e[2]
			if forward:
				if node_h[bi] > node_h[ai] + cap2:
					node_h[bi] = node_h[ai] + cap2
				elif node_h[bi] < node_h[ai] - cap2:
					node_h[bi] = node_h[ai] - cap2
			else:
				if node_h[ai] > node_h[bi] + cap2:
					node_h[ai] = node_h[bi] + cap2
				elif node_h[ai] < node_h[bi] - cap2:
					node_h[ai] = node_h[bi] - cap2
	# 3) publish per-corridor profiles from the shared node solution
	for ci in range(TA.ROAD_CORRIDORS.size()):
		var c2: Dictionary = TA.ROAD_CORRIDORS[ci]
		var idxs2: Array = per_corridor_idx[ci]
		var elev := PackedFloat64Array()
		elev.resize(idxs2.size())
		for i in range(idxs2.size()):
			elev[i] = node_h[idxs2[i]]
		_corridor_cache.append({"pts": c2["pts"], "elev": elev,
				"half_w": float(c2["half_w"]), "blend": float(c2["blend"])})


static func _road_corridor_blend(p: Vector2, h: float) -> float:
	if not TA.ROAD_CORRIDOR_BOUNDS.has_point(p):
		return h
	_ensure_corridor_cache()
	# Accumulate every corridor that reaches this point and weight-blend
	# them. Overlapping corridors (V1 x V2 x Sentinel share junctions) must
	# average, otherwise the last one wins and the blend field develops a
	# cliff where two corridors cross.
	var acc: float = 0.0
	var wsum: float = 0.0
	for c: Dictionary in _corridor_cache:
		var pts: Array = c["pts"]
		var elev: PackedFloat64Array = c["elev"]
		var best_d: float = 1e9
		var t_best: float = 0.0
		var seg_best: int = 0
		for i in range(pts.size() - 1):
			var a: Vector2 = pts[i]
			var b: Vector2 = pts[i + 1]
			var ab: Vector2 = b - a
			var denom: float = maxf(ab.length_squared(), 0.0001)
			var t: float = clampf((p - a).dot(ab) / denom, 0.0, 1.0)
			var d: float = (p - a.lerp(b, t)).length()
			if d < best_d:
				best_d = d
				t_best = t
				seg_best = i
		var hw: float = c["half_w"]
		var reach: float = hw + c["blend"]
		if best_d >= reach:
			continue
		var target: float = lerpf(elev[seg_best], elev[seg_best + 1], t_best)
		var w: float = 1.0 - smoothstep(hw, reach, best_d)
		acc += target * w
		wsum += w
	if wsum > 0.0:
		h = lerpf(h, acc / wsum, clampf(wsum, 0.0, 1.0))
	return h


## Legacy hybrid zone formula — frozen (Prompt 03 refactor moved it verbatim;
## determinism value 21.3151 at (-300,-400) is a locked CI gate).
static func _legacy_zone_height(x: float, z: float) -> float:
	if _is_flat_zone(x, z):
		return 0.0
	if not active_zone.has_point(Vector2(x, z)):
		return 0.0
	var base_noise: float = _noise2(x, z)
	var mountain: float = _mountain_mask(x, z)
	var river: float = _river_carve(x, z)
	var edge: float = 30.0
	var dxl: float = clampf((x - active_zone.position.x) / edge, 0.0, 1.0)
	var dxr: float = clampf((active_zone.end.x - x) / edge, 0.0, 1.0)
	var dzl: float = clampf((z - active_zone.position.y) / edge, 0.0, 1.0)
	var dzr: float = clampf((active_zone.end.y - z) / edge, 0.0, 1.0)
	var mask: float = minf(minf(dxl, dxr), minf(dzl, dzr))
	var height: float = 0.0
	if mountain > 0.7:
		height = base_noise * MOUNTAIN_AMPLITUDE * mountain + mountain * 35.0
	elif mountain > 0.1:
		height = base_noise * HILL_AMPLITUDE * mountain + mountain * 12.0
	else:
		height = base_noise * 2.5 * mask
	height -= river
	height *= mask
	return clampf(height, -6.0, 120.0)

## Round 12 Phase 08: river current — gentle flow along the carved channel.
## Tangent of river_x(z) = -50 + sin(z*0.01)*80; strength fades to zero at
## 22 m from the channel centre. Zero outside the river band.
static func river_current_at(pos: Vector3) -> Vector3:
	var river_x: float = -50.0 + sin(pos.z * 0.01) * 80.0
	var dist: float = absf(pos.x - river_x)
	if dist > 22.0:
		return Vector3.ZERO
	var strength: float = (1.0 - dist / 22.0) * 0.9
	var tangent: Vector3 = Vector3(cos(pos.z * 0.01) * 0.8, 0.0, 1.0).normalized()
	return tangent * strength


static func build_patch(root: Node3D) -> Node:
	if not activate or active_zone.size == Rect2().size:
		return null
	var size: Vector2 = active_zone.size
	var steps: int = maxi(maxi(int(size.x / 6.0), int(size.y / 6.0)), 12)
	var verts: PackedVector3Array = PackedVector3Array()
	var uvs: PackedVector2Array = PackedVector2Array()
	for zz: int in range(steps + 1):
		for xx: int in range(steps + 1):
			var fx: float = float(xx) / float(steps)
			var fz: float = float(zz) / float(steps)
			var wx: float = active_zone.position.x + fx * size.x
			var wz: float = active_zone.position.y + fz * size.y
			verts.append(Vector3(fx * size.x - size.x * 0.5, height_at(wx, wz), fz * size.y - size.y * 0.5))
			uvs.append(Vector2(fx, fz))
	var st: SurfaceTool = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for zz: int in range(steps):
		for xx: int in range(steps):
			var a: int = zz * (steps + 1) + xx
			st.add_index(a)
			st.add_index(a + steps + 1)
			st.add_index(a + 1)
			st.add_index(a + 1)
			st.add_index(a + steps + 1)
			st.add_index(a + steps + 2)
	for i: int in range(verts.size()):
		st.set_uv(uvs[i])
		st.add_vertex(verts[i])
	var arr_mesh: ArrayMesh = st.commit()
	var mat: ShaderMaterial = ShaderMaterial.new()
	mat.shader = _grass_shader()
	var mi: MeshInstance3D = MeshInstance3D.new()
	mi.name = "TerrainPatch_Hybrid"
	mi.mesh = arr_mesh
	mi.material_override = mat
	mi.position = Vector3(active_zone.position.x + size.x * 0.5, 0.0, active_zone.position.y + size.y * 0.5)
	mi.visibility_range_end = 800.0
	var body: StaticBody3D = StaticBody3D.new()
	body.name = "TerrainBody"
	var cs: CollisionShape3D = CollisionShape3D.new()
	var shape: ConcavePolygonShape3D = ConcavePolygonShape3D.new()
	shape.set_faces(arr_mesh.get_faces())
	cs.shape = shape
	body.add_child(cs)
	mi.add_child(body)
	root.add_child(mi)
	print("TERRAIN_HYBRID: built patch %s steps %d verts %d maxH %.1f" % [str(active_zone), steps, verts.size(), _max_height_in_zone()])
	return mi

static func _max_height_in_zone() -> float:
	var max_h: float = 0.0
	for x: int in range(-400, 400, 50):
		for z: int in range(-500, -200, 50):
			var h: float = height_at(float(x), float(z))
			if h > max_h:
				max_h = h
	return max_h

static func _grass_shader() -> Shader:
	var shader: Shader = Shader.new()
	shader.code = """
shader_type spatial;
uniform vec2 world_offset;
void fragment() {
	vec2 world_uv = UV * 12.0 + world_offset;
	float n = fract(sin(dot(world_uv, vec2(12.9898, 78.233))) * 43758.5453);
	vec3 green1 = vec3(0.22, 0.48, 0.22);
	vec3 green2 = vec3(0.18, 0.42, 0.18);
	vec3 dry = vec3(0.55, 0.52, 0.38);
	vec3 col = mix(green1, green2, n);
	col = mix(col, dry, smoothstep(0.7, 0.85, n) * 0.35);
	ALBEDO = col;
	ROUGHNESS = 0.92;
}
"""
	return shader
# =====================================================================
# P03 MASTER TERRAIN FIELD — deterministic macro geography over the full
# 3 km circle. Composition (P03 §5): regional blend + mountain system +
# valleys + river carve + coastal shaping + platform blend + detail noise.
# All authored data lives in TerrainAuthoring; district wedges come from
# the same JSON the registry parses (terrain <-> registry coherence).
# =====================================================================

const TA := preload("res://scripts/world/terrain_authoring.gd")

## decorrelated detail fbm (oct offset keeps it distinct from legacy _noise2)
static func _fbm(x: float, z: float) -> float:
	var h: float = 0.0
	var amp: float = 1.0
	var fr: float = 1.0 / 240.0
	var tot: float = 0.0
	for o: int in range(3):
		var xf: float = x * fr
		var zf: float = z * fr
		var xi: int = floori(xf)
		var zi: int = floori(zf)
		var tx: float = xf - float(xi)
		var tz: float = zf - float(zi)
		var sx: float = tx * tx * (3.0 - 2.0 * tx)
		var sz: float = tz * tz * (3.0 - 2.0 * tz)
		var v00: float = _hash2(xi, zi, 64 + o)
		var v10: float = _hash2(xi + 1, zi, 64 + o)
		var v01: float = _hash2(xi, zi + 1, 64 + o)
		var v11: float = _hash2(xi + 1, zi + 1, 64 + o)
		h += amp * lerpf(lerpf(v00, v10, sx), lerpf(v01, v11, sx), sz)
		tot += amp
		amp *= 0.5
		fr *= 2.1
	return (h / tot) * 2.0 - 1.0


static func _bearing_deg(x: float, z: float) -> float:
	var a: float = rad_to_deg(atan2(z, x))
	if a < 0.0:
		a += 360.0
	return a


## Point-segment distance (XZ).
static func _seg_dist(p: Vector2, a: Vector2, b: Vector2) -> float:
	var ab: Vector2 = b - a
	var l2: float = ab.length_squared()
	if l2 <= 0.0001:
		return p.distance_to(a)
	var t: float = clampf((p - a).dot(ab) / l2, 0.0, 1.0)
	return p.distance_to(a + ab * t)


static func _poly_dist(p: Vector2, pts: Array) -> float:
	var d: float = 1e9
	for i in range(pts.size() - 1):
		d = minf(d, _seg_dist(p, pts[i], pts[i + 1]))
	return d


## Smooth angular weight for a wedge [lo, hi) with gaussian-ish edges.
static func _wedge_weight(a_deg: float, lo: float, hi: float, edge: float) -> float:
	# Edge convention: weight is 1.0 inside the wedge and falls to 0.0 across
	# `edge` degrees OUTSIDE each boundary. (Phase F QA: the lo-side blend was
	# originally inverted — 0 at the boundary rising outward — producing a hard
	# weight jump at every wedge lo edge, e.g. elev 19.2->12.3 across 350.0 deg.)
	var inside: float
	if lo <= hi:
		inside = 1.0 if (a_deg >= lo and a_deg < hi) else 0.0
		if a_deg < lo:
			inside = smoothstep(lo - edge, lo, a_deg)
		elif a_deg >= hi:
			inside = 1.0 - smoothstep(hi, hi + edge, a_deg)
	else:  # wraps 0
		if a_deg >= lo or a_deg < hi:
			inside = 1.0
		elif a_deg < lo:
			inside = smoothstep(lo - edge, lo, a_deg)
		else:
			inside = 1.0 - smoothstep(hi, hi + edge, a_deg)
	return inside


## Regional base elevation + relief via blended district profiles (§6/§44:
## angular blending — no hard wedge edges, no Cartesian splits).
static func _region_blend(x: float, z: float, r: float) -> Dictionary:
	var a: float = _bearing_deg(x, z)
	var table: Array = WorldSectorRegistry.district_table()
	# Weights WITHOUT the radial ramp (the ramp applies to the blended result:
	# including it inside the weights cancels it out and, combined with a
	# wsum threshold, creates the 0->70 m discontinuity found in Phase F QA).
	var wsum: float = 0.0
	var elev: float = 0.0
	var relief: float = 0.0
	for d: Dictionary in table:
		var wedge: Array = d.get("wedge_deg", [0.0, 0.0])
		var w: float = _wedge_weight(a, float(wedge[0]), float(wedge[1]), 14.0)
		if w <= 0.0:
			continue
		var prof: Dictionary = TA.profile_for_type(str(d.get("type", "")))
		wsum += w
		elev += w * float(prof["elev_m"])
		relief += w * float(prof["relief_m"])
	# constant-weight default member: guarantees wsum > 0 (no threshold, no
	# branch cliff) and pulls wedge seams toward neutral countryside
	var dp: Dictionary = TA.DEFAULT_PROFILE
	wsum += 0.12
	elev += 0.12 * float(dp["elev_m"])
	relief += 0.12 * float(dp["relief_m"])
	var radial: float = smoothstep(TA.REGION_R_START_M, TA.REGION_R_FULL_M, r)
	return {"elev": (elev / wsum) * radial, "relief": (relief / wsum) * radial}


## Mountain-system angular window weight × foothill radial ramp.
static func _mountain_weight(x: float, z: float, r: float) -> float:
	var a: float = _bearing_deg(x, z)
	var w: float = 0.0
	for d: Dictionary in WorldSectorRegistry.district_table():
		if str(d.get("type", "")) == "mountain_wild":
			var wedge: Array = d.get("wedge_deg", [0.0, 0.0])
			w = maxf(w, _wedge_weight(a, float(wedge[0]), float(wedge[1]), 20.0))
	return w * smoothstep(TA.FOOTHILL_R0, TA.FOOTHILL_R1, r)


static var _river_bed: PackedFloat64Array = PackedFloat64Array()
static var _river_guard := false


## Monotonic river-bed elevations at the control points (Phase F QA found the
## raw bed RISES downstream 5.2->13.7 m — no continuous water surface is
## possible on that). Built once from the pre-river field: bed_i =
# min(field_i - RIVER_DEPTH, bed_{i-1} - 1.0) — >=1 m drop per reach.
static func _ensure_river_bed() -> void:
	if _river_bed.size() > 0:
		return
	_river_guard = true
	var prev: float = 1e9
	for pt: Vector2 in TA.RIVER_PTS:
		var raw: float = _macro_height(pt.x, pt.y) - TA.RIVER_DEPTH_M
		var v: float = minf(raw, prev - 1.0)
		_river_bed.append(v)
		prev = v
	_river_guard = false


## Bed elevation at p via the shared arc-length projection (C0 along path).
static func _river_bed_interp(p: Vector2) -> float:
	_ensure_river_bed()
	var u: float = _river_project(p)["u"]
	var n: int = TA.RIVER_PTS.size()
	var total: float = 0.0
	for i in range(n - 1):
		total += TA.RIVER_PTS[i].distance_to(TA.RIVER_PTS[i + 1])
	var target: float = u * total
	var cum: float = 0.0
	for i in range(n - 1):
		var len: float = TA.RIVER_PTS[i].distance_to(TA.RIVER_PTS[i + 1])
		if cum + len >= target or i == n - 2:
			var t: float = clampf((target - cum) / maxf(len, 0.001), 0.0, 1.0)
			return lerpf(_river_bed[i], _river_bed[i + 1], t)
		cum += len
	return _river_bed[n - 1]


static func _macro_height(x: float, z: float) -> float:
	var p := Vector2(x, z)
	var r: float = p.length()
	if r <= TA.PLATFORM_RADIUS_M:
		# urban platform: exact flat contract (legacy marina basin excepted:
		# the boats are moored in water INSIDE the platform radius)
		return _carve_basins(0.0, p)
	var blend: Dictionary = _region_blend(x, z, r)
	var h: float = float(blend["elev"])
	# mountain system: ridges + peaks - valleys, confined by the window
	var mw: float = _mountain_weight(x, z, r)
	if mw > 0.001:
		var madd: float = 0.0
		for ridge: Dictionary in TA.RIDGES:
			var d: float = _poly_dist(p, ridge["pts"])
			madd += float(ridge["amp_m"]) * exp(-pow(d / float(ridge["width_m"]), 2.0))
		for peak: Dictionary in TA.PEAKS:
			var dp: float = p.distance_to(peak["c"])
			madd += float(peak["amp_m"]) * exp(-pow(dp / float(peak["rad_m"]), 2.0))
		var vcut: float = 0.0
		for valley: Dictionary in TA.VALLEYS:
			var dv: float = _poly_dist(p, valley["pts"])
			vcut += float(valley["depth_m"]) * exp(-pow(dv / float(valley["width_m"]), 2.0))
		h += (maxf(madd - vcut, 0.0)) * mw
	# detail noise scaled by regional relief
	h += _fbm(x, z) * float(blend["relief"]) * 0.5
	# lake basin: flat floor under the water level, soft blended rim
	var ld: float = p.distance_to(TA.LAKE_CENTER)
	if ld < TA.LAKE_RADIUS_M * 1.35:
		var wl: float = 1.0 - smoothstep(TA.LAKE_RADIUS_M * 0.85, TA.LAKE_RADIUS_M * 1.2, ld)
		h = lerpf(h, minf(h, TA.LAKE_FLOOR_M), wl)
	# river carve: cap to the monotonic bed (channel) + floodplain terrace.
	# _river_guard skips this block while the bed table is being built.
	if not _river_guard:
		var rd: float = _river_dist(x, z)
		var rw: float = _river_width_at(x, z)
		if rd < rw * 2.6:
			var bed: float = _river_bed_interp(p)
			# channel + floodplain terrace as ONE target surface, then blend
			# back to natural terrain across the outer floodplain edge.
			# (Phase F QA: a bare min() cap left a flat bench 9 m below the
			# surroundings with a cliff at rd = 2.6w wherever the monotonic
			# bed runs under higher ground.)
			var ch: float = bed + TA.RIVER_DEPTH_M * smoothstep(0.0, rw, rd) \
					- 1.1 * (1.0 - smoothstep(rw, rw * 2.6, rd))
			var blend_back: float = 1.0 - smoothstep(rw * 1.6, rw * 2.6, rd)
			h = lerpf(h, minf(h, ch), blend_back)
	# coastal shaping: authored land-end per bearing (bay punched inside)
	var a_deg: float = _bearing_deg(x, z)
	var le: float = TA.land_end_r(a_deg)
	if r > le - 80.0:
		var bay_w: float = TA._bay_weight(a_deg)
		# Phase F QA: fixed-width transitions turned high terrain meeting the
		# shore into 250 m vertical walls. Scale the transition with the local
		# relief so mountains descend fjord-like; beaches/cliffs keep their
		# authored widths (their terrain is low, so the term is negligible).
		var trans: float = lerpf(TA.coast_trans_m(a_deg) + maxf(h, 0.0) * 2.2,
				900.0 + maxf(h, 0.0) * 1.0, bay_w)
		var depth: float = lerpf(16.0, TA.BAY_MAX_DEPTH_M + 2.0, bay_w)
		var seabed: float = lerpf(TA.SEA_LEVEL_M - 0.4, -depth, smoothstep(le, le + trans, r))
		# the bay keeps its crisp authored shore (+30 m); land coasts use the
		# relief-scaled window so mountains descend gradually instead of
		# dropping 250 m across 110 m (Phase F QA, gates 12/21 + waterline)
		var wc: float = smoothstep(le - 80.0, lerpf(le + trans, le + 30.0, bay_w), r)
		h = lerpf(h, seabed, wc)
	# platform handover: C1-continuous (smoothstep has zero slope at both ends)
	var t: float = smoothstep(TA.PLATFORM_RADIUS_M, TA.PLATFORM_BLEND_OUT_M, r)
	h = lerpf(0.0, h, t)
	# legacy-compat water carves (marina basins + east harbor) — applied
	# AFTER the blend so the blend cannot lift them back above sea level
	h = _carve_basins(h, p)
	# soft knee at the contract max: a hard clamp carved a circular terrace
	# rim into Sentinel Peak (45 m neighborhood deviation). The knee keeps
	# the ceiling contractual while staying C1 (summit reads ~300 m).
	# smooth-min against the ceiling: h' = min(h, MAX) - k*ln(1+e^(-|h-MAX|/k))
	# (the earlier variant had the knee sign inverted — it RAISED everything
	# above 215 m toward 320 and shattered continuity; caught by gate 12)
	if h > TA.WORLD_MAX_HEIGHT_M - TA.MAX_KNEE_M * 3.0:
		var k: float = TA.MAX_KNEE_M
		h = minf(h, TA.WORLD_MAX_HEIGHT_M) \
				- k * log(1.0 + exp(-absf(h - TA.WORLD_MAX_HEIGHT_M) / k))
	return clampf(h, TA.WORLD_MIN_HEIGHT_M, TA.WORLD_MAX_HEIGHT_M)


## Marina basins + east harbor (authored in TerrainAuthoring). Continuous:
## each floor fades to the untouched height across its rim smoothstep.
static func _carve_basins(h: float, p: Vector2) -> float:
	for b: Dictionary in TA.MARINA_BASINS:
		var d: float = p.distance_to(b["c"])
		var w: float = 1.0 - smoothstep(float(b["r"]) * 0.55, float(b["r"]), d)
		h = lerpf(h, minf(h, float(b["floor"])), w)
	var eh: Dictionary = TA.EAST_HARBOR
	var q: Vector2 = (p - eh["c"]) / Vector2(float(eh["rx"]), float(eh["ry"]))
	var qd: float = q.length()
	var w2: float = 1.0 - smoothstep(0.72, 1.0, qd)
	if w2 > 0.0:
		var di: float = p.distance_to(eh["islet_c"])
		var floor: float = lerpf(float(eh["islet_floor"]), float(eh["floor"]),
				smoothstep(float(eh["islet_r"]) * 0.45, float(eh["islet_r"]) * 1.8, di))
		h = lerpf(h, minf(h, floor), w2)
	return h


## --- River helpers (authored path; data lives in TerrainAuthoring) ---
## All three use ONE projection: nearest point on the polyline, expressed as
## arc-length u in [0,1]. (Phase F QA: per-node / per-segment nearest lookups
## jump at Voronoi boundaries — up to 9 m steps — arc-length u is C0.)

static func _river_project(p: Vector2) -> Dictionary:
	var best_d: float = 1e9
	var best_u: float = 0.0
	var cum: float = 0.0
	var total: float = 0.0
	for i in range(TA.RIVER_PTS.size() - 1):
		total += TA.RIVER_PTS[i].distance_to(TA.RIVER_PTS[i + 1])
	for i in range(TA.RIVER_PTS.size() - 1):
		var a: Vector2 = TA.RIVER_PTS[i]
		var b: Vector2 = TA.RIVER_PTS[i + 1]
		var ab: Vector2 = b - a
		var l2: float = ab.length_squared()
		var len: float = sqrt(l2)
		var t: float = 0.0 if l2 <= 0.0001 else clampf((p - a).dot(ab) / l2, 0.0, 1.0)
		var d: float = p.distance_to(a + ab * t)
		if d < best_d:
			best_d = d
			best_u = (cum + t * len) / maxf(total, 0.001)
		cum += len
	return {"dist": best_d, "u": best_u}


static func _river_dist(x: float, z: float) -> float:
	return _river_project(Vector2(x, z))["dist"]


## Width grows downstream with arc length (continuous along the path).
static func _river_width_at(x: float, z: float) -> float:
	var u: float = _river_project(Vector2(x, z))["u"]
	return lerpf(TA.RIVER_WIDTH_START_M, TA.RIVER_WIDTH_END_M, u)


# =====================================================================
# P03 QUERY API — slope / water / coast / surface / ground resolution.
# Every system asks these; nobody re-implements terrain math (§22).
# =====================================================================

static func slope_at(x: float, z: float) -> float:
	# gradient magnitude via central differences (2 m arm)
	var dx: float = (height_at(x + 2.0, z) - height_at(x - 2.0, z)) / 4.0
	var dz: float = (height_at(x, z + 2.0) - height_at(x, z - 2.0)) / 4.0
	return Vector2(dx, dz).length()


static func grade_percent(x: float, z: float) -> float:
	return slope_at(x, z) * 100.0


static func normal_at(x: float, z: float) -> Vector3:
	var dx: float = (height_at(x + 2.0, z) - height_at(x - 2.0, z)) / 4.0
	var dz: float = (height_at(x, z + 2.0) - height_at(x, z - 2.0)) / 4.0
	return Vector3(-dx, 1.0, -dz).normalized()


const ROAD_GRADE_LIMITS := {
	"freeway": 4.0, "arterial": 6.0, "collector": 8.0, "local": 10.0,
	"rural": 12.0, "service": 8.0, "trail": 20.0,
}


static func is_road_viable(x: float, z: float, road_class: String = "local") -> bool:
	if not WorldContract.is_playable(Vector3(x, 0.0, z)):
		return false
	if height_at(x, z) < TA.SEA_LEVEL_M + 0.35:
		return false  # water / intertidal
	var lim: float = float(ROAD_GRADE_LIMITS.get(road_class, 10.0))
	return grade_percent(x, z) <= lim


## Direction (unit XZ) of the lowest grade among 8 neighbors at 25 m.
static func nearest_low_grade_direction(x: float, z: float) -> Vector2:
	var best := Vector2(1, 0)
	var bg: float = 1e9
	for i in range(8):
		var ang: float = TAU * float(i) / 8.0
		var dir := Vector2(cos(ang), sin(ang))
		var g: float = absf(height_at(x + dir.x * 25.0, z + dir.y * 25.0) - height_at(x, z)) / 25.0
		if g < bg:
			bg = g
			best = dir
	return best


static func is_water_position(x: float, z: float) -> bool:
	return height_at(x, z) < TA.SEA_LEVEL_M - 0.05


## Depth below sea level (0 when above water).
static func water_depth_at(x: float, z: float) -> float:
	return maxf(0.0, TA.SEA_LEVEL_M - height_at(x, z))


## Deterministic bounded distance-to-water search (16 rays, 20 m steps,
## 600 m cap). -1 when no water within 600 m.
static func distance_to_water(x: float, z: float) -> float:
	if is_water_position(x, z):
		return 0.0
	for i in range(16):
		var ang: float = TAU * float(i) / 16.0
		var dir := Vector2(cos(ang), sin(ang))
		for s in range(1, 31):
			var px: float = x + dir.x * float(s) * 20.0
			var pz: float = z + dir.y * float(s) * 20.0
			if not WorldContract.is_playable(Vector3(px, 0.0, pz)):
				break
			if is_water_position(px, pz):
				return float(s) * 20.0
	return -1.0


## Shoreline classification for the P08 coast rebuild (§8/§24).
static func coast_class_at(x: float, z: float) -> String:
	var h: float = height_at(x, z)
	if h < TA.SEA_LEVEL_M - 0.05:
		return "OPEN_WATER"
	var a_deg: float = _bearing_deg(x, z)
	var le: float = TA.land_end_r(a_deg)
	var r: float = Vector2(x, z).length()
	var g: float = grade_percent(x, z)
	if _river_dist(x, z) < _river_width_at(x, z) + 12.0:
		if r > le - 350.0:
			return "RIVER_MOUTH"
		return "RIVERBANK"
	if h < TA.SEA_LEVEL_M + 0.7 and g < 12.0 and r > le - 420.0:
		if a_deg > 55.0 and a_deg < 105.0:
			return "WETLAND"
		return "MARSH"
	if r <= le - 260.0:
		return "INLAND"
	# legacy engineered waterfront (harbor/marina district from wb_kit)
	if x > -430.0 and x < -120.0 and z > -300.0 and z < 260.0 and r < 760.0:
		return "ENGINEERED_SEAWALL" if z < -60.0 else "MARINA"
	if g > 45.0:
		return "CLIFF"
	if g <= 15.0:
		return "NATURAL_BEACH"
	return "ROCKY_SHORE"


## Continuous surface mask class (§16/§17) — deterministic from field state.
static func surface_class_at(x: float, z: float) -> String:
	var h: float = height_at(x, z)
	if h < TA.SEA_LEVEL_M - 0.05:
		return "WATER"
	var r: float = Vector2(x, z).length()
	var g: float = grade_percent(x, z)
	var a_deg: float = _bearing_deg(x, z)
	var le: float = TA.land_end_r(a_deg)
	if r <= TA.PLATFORM_RADIUS_M + 40.0:
		return "URBAN_LOWLAND"
	if _river_dist(x, z) < _river_width_at(x, z) + 8.0:
		return "RIVERBANK"
	if r > le - 200.0 and h < TA.SEA_LEVEL_M + 3.0:
		return "CLIFF" if g > 45.0 else "BEACH"
	if h < TA.SEA_LEVEL_M + 0.8 and g < 10.0 and a_deg > 50.0 and a_deg < 110.0:
		return "WETLAND"
	if g > 60.0:
		return "ROCK"
	# elevation-band precedence: measured height outranks the district label
	# (the registry assigns the far NW coast strip to beach_resort by
	# priority, but a 320 m summit there is mountain whatever the label)
	if h > 150.0:
		return "MOUNTAIN"
	if h > 60.0:
		return "FOOTHILL"
	var dtype: String = WorldSectorRegistry.district_type_of(
			WorldSectorRegistry.district_at_xz(Vector2(x, z)))
	match dtype:
		"mountain_wild":
			if h > 150.0: return "MOUNTAIN"
			if h > 60.0: return "FOOTHILL"
			return "RURAL_GRASS"
		"affluent_hills":
			return "ROCK" if g > 50.0 else "SUBURBAN_HILL"
		"farmland":
			if _fbm(x * 1.7, z * 1.7) > 0.45 and g < 22.0:
				return "FOREST"
			return "FARM_FIELD"
		"rural_dry":
			return "RURAL_GRASS" if g < 35.0 else "ROCK"
		"port_industrial", "heavy_industrial", "airport", "military":
			return "INDUSTRIAL_FLAT"
		"beach_resort":
			return "BEACH" if h < 12.0 else "COASTAL_URBAN"
		"park_water":
			return "PARKLAND"
		"downtown", "historic_dense", "entertainment":
			return "URBAN_LOWLAND" if r < 1150.0 else "SUBURBAN_HILL"
	return "RURAL_GRASS"


static func elevation_band_at(x: float, z: float) -> String:
	var h: float = height_at(x, z)
	if h < TA.SEA_LEVEL_M:
		return "below_sea"
	if h < 10.0:
		return "coastal_0_10"
	if h < 60.0:
		return "lowland_10_60"
	if h < 150.0:
		return "highland_60_150"
	return "mountain_150_plus"


## Ground-resolution utility for spawn/positioning systems (§40).
static func resolve_to_ground(x: float, z: float) -> Dictionary:
	var h: float = height_at(x, z)
	return {
		"x": x, "z": z, "ground_y": h,
		"normal": normal_at(x, z),
		"slope_deg": rad_to_deg(atan(slope_at(x, z))),
		"sector": WorldContract.micro_id(WorldContract.micro_sector_of(Vector2(x, z))),
		"surface": surface_class_at(x, z),
		"water": h < TA.SEA_LEVEL_M - 0.05,
	}


## --- Inland water surface (§10): level of the water that VISUALLY covers
## river/lake cells (the ocean plane only exists at SEA_LEVEL). ---

static func has_inland_water(x: float, z: float) -> bool:
	var p := Vector2(x, z)
	if p.distance_to(TA.LAKE_CENTER) < TA.LAKE_RADIUS_M * 1.18:
		return true
	return _river_dist(x, z) < _river_width_at(x, z) * 1.05


static func water_level_at(x: float, z: float) -> float:
	if is_water_position(x, z):
		return TA.SEA_LEVEL_M
	var p := Vector2(x, z)
	if p.distance_to(TA.LAKE_CENTER) < TA.LAKE_RADIUS_M * 1.18:
		return TA.LAKE_LEVEL_M
	if _river_dist(x, z) < _river_width_at(x, z) * 1.05:
		return _river_bed_interp(p) + 0.9
	return -INF


## River bed elevations (read-only view for tests/docs).
static func river_bed_levels() -> PackedFloat64Array:
	_ensure_river_bed()
	return _river_bed


## Centerline sample points for water-surface builders: each authored reach
## subdivided `sub` times. Per point: center, unit side vector (XZ), half
## width, and the water level for that station.
static func river_centerline(sub: int) -> Array:
	var out: Array = []
	var pts: Array = TA.RIVER_PTS
	for i in range(pts.size() - 1):
		var a: Vector2 = pts[i]
		var b: Vector2 = pts[i + 1]
		var dir: Vector2 = (b - a).normalized()
		var side := Vector2(-dir.y, dir.x)
		for s in range(sub + 1):
			if s == sub and i < pts.size() - 2:
				continue  # shared junction belongs to the next reach
			var t: float = float(s) / float(sub)
			var p: Vector2 = a.lerp(b, t)
			out.append({
				"center": Vector3(p.x, 0.0, p.y),
				"side": side,
				"half_w": _river_width_at(p.x, p.y) * 0.5,
				"level": maxf(TA.SEA_LEVEL_M + 0.05, _river_bed_interp(p) + 0.9),
			})
	return out
