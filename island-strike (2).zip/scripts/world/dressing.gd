class_name WBDressing
extends Object
## Round 12 "Next Level" world dressing pass (Phases 09/11/13/14/15/16/17).
## Strictly ADDITIVE on top of the locked build order: visual/ambience nodes
## only, zero new physics bodies except the clock-tower shaft (1 StaticBody),
## zero world_data changes, fully deterministic (own fixed-seed RNG).
## Called once from WorldBuilder.build() after lamps; never touches QA registries.

const K := preload("res://scripts/world/wb_kit.gd")
const WBTerrain := preload("res://scripts/world/terrain.gd")

const AVENUE_XS: Array = [-267.0, 53.0, -410.0]  # N-S avenues (matches game._is_ns_road)
const DASH_STEP := 14.0
const HYDRANT_SPOTS: Array = [
	Vector2(-259.5, -120.0), Vector2(-274.5, -180.0), Vector2(-259.5, -260.0),
	Vector2(60.5, -80.0), Vector2(45.5, -160.0), Vector2(60.5, -240.0),
	Vector2(-402.5, -60.0), Vector2(-417.5, -140.0), Vector2(-402.5, -220.0),
	Vector2(-259.5, 40.0), Vector2(60.5, 20.0), Vector2(-417.5, 10.0),
]
const BIN_SPOTS: Array = [
	Vector2(-240.0, -150.0), Vector2(-294.0, -210.0), Vector2(74.0, -100.0),
	Vector2(32.0, -220.0), Vector2(-390.0, -80.0), Vector2(-430.0, -180.0),
	Vector2(-240.0, 20.0), Vector2(74.0, 0.0),
]
const FLOWER_COLORS: Array = [
	Color(0.95, 0.35, 0.45), Color(0.98, 0.85, 0.25), Color(0.85, 0.4, 0.9),
	Color(0.98, 0.98, 0.95), Color(0.95, 0.55, 0.2),
]


static func build(root: Node3D) -> void:
	var rng: RandomNumberGenerator = RandomNumberGenerator.new()
	rng.seed = 20260919  # dressing is part of the deterministic island
	var districts: Dictionary = K.DISTRICTS
	_lane_dashes(root)
	_welcome_gantry(root)
	_hydrants_and_bins(root)
	_flower_patches(root, districts.get("Park", Rect2()), rng)
	_clock_tower(root, districts.get("Downtown", Rect2()))
	_rooftop_layer(root)
	_hidden_stashes(root)
	print("DRESSING: lane_dashes/hydrants/bins/flowers/clock/roofs/lights/escapes/stashes built")


## Phase 09: painted center-line dashes along the three N-S avenues,
## skipping intersections. One MultiMesh = one node for the whole island.
static func _lane_dashes(root: Node3D) -> void:
	var mm: MultiMesh = MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	var dash: BoxMesh = BoxMesh.new()
	dash.size = Vector3(0.35, 0.04, 2.6)
	var mat: StandardMaterial3D = StandardMaterial3D.new()
	mat.albedo_color = Color(0.92, 0.9, 0.75)
	dash.material = mat
	mm.mesh = dash
	var xforms: Array[Transform3D] = []
	for ax: float in AVENUE_XS:
		var z: float = -430.0
		while z <= 430.0:
			if _on_ew_road(Vector2(ax, z)):
				z += DASH_STEP
				continue
			xforms.append(Transform3D(Basis.IDENTITY,
					Vector3(ax, 0.06, z)))
			z += DASH_STEP
	mm.instance_count = xforms.size()
	for i in range(xforms.size()):
		mm.set_instance_transform(i, xforms[i])
	var mmi: MultiMeshInstance3D = MultiMeshInstance3D.new()
	mmi.name = "LaneDashes"
	mmi.multimesh = mm
	mmi.add_to_group("lane_dashes")
	root.add_child(mmi)


static func _on_ew_road(xz: Vector2) -> bool:
	for r: Rect2 in K.ROADS:
		if xz.x > r.position.x - 8.0 and xz.x < r.end.x + 8.0 \
				and xz.y > r.position.y - 8.0 and xz.y < r.end.y + 8.0:
			return true
	return false


## Phase 10: welcome gantry over the avenue by the player spawn approach.
static func _welcome_gantry(root: Node3D) -> void:
	var base: Vector2 = Vector2(-267, 90)
	K._box(root, Vector3(0.8, 9.0, 0.8), base + Vector2(-7, 0), 9.0,
			Color(0.25, 0.27, 0.3), false, "GantryPostL")
	K._box(root, Vector3(0.8, 9.0, 0.8), base + Vector2(7, 0), 9.0,
			Color(0.25, 0.27, 0.3), false, "GantryPostR")
	var beam: Node3D = K._box(root, Vector3(16, 1.4, 1.0), base, 9.6,
			Color(0.16, 0.4, 0.2), false, "WelcomeGantry")
	beam.add_to_group("welcome_gantry")
	var sign_l: Label3D = Label3D.new()
	sign_l.text = "WELCOME TO ISLAND STRIKE"
	sign_l.font_size = 220
	sign_l.pixel_size = 0.01
	sign_l.modulate = Color(1.0, 0.95, 0.7)
	sign_l.outline_size = 24
	sign_l.position = Vector3(base.x, 8.4, base.y)
	sign_l.rotation_degrees = Vector3(0, 90, 0)
	root.add_child(sign_l)


## Phase 13: hydrants + litter bins along avenue sidewalks (visual-only).
static func _hydrants_and_bins(root: Node3D) -> void:
	for i in range(HYDRANT_SPOTS.size()):
		var h: Node3D = K._box(root, Vector3(0.36, 0.85, 0.36),
				HYDRANT_SPOTS[i], 0.85, Color(0.8, 0.12, 0.1), false,
				"Hydrant%d" % i)
		h.add_to_group("street_furniture")
		var cap: Node3D = K._box(root, Vector3(0.5, 0.12, 0.5),
				HYDRANT_SPOTS[i], 0.9, Color(0.7, 0.1, 0.09), false,
				"HydrantCap%d" % i)
		cap.add_to_group("street_furniture")
	for i in range(BIN_SPOTS.size()):
		var b: Node3D = K._box(root, Vector3(0.6, 1.0, 0.6),
				BIN_SPOTS[i], 1.0, Color(0.2, 0.32, 0.24), false,
				"LitterBin%d" % i)
		b.add_to_group("street_furniture")


## Phase 14: flower patches in the Park (join "veg" so LOW quality culls them).
static func _flower_patches(root: Node3D, park: Rect2, rng: RandomNumberGenerator) -> void:
	if park.size == Vector2.ZERO:
		return
	for i in range(12):
		var pxz: Vector2 = Vector2(
				rng.randf_range(park.position.x + 6.0, park.end.x - 6.0),
				rng.randf_range(park.position.y + 6.0, park.end.y - 6.0))
		var col: Color = FLOWER_COLORS[i % FLOWER_COLORS.size()]
		for j in range(7):
			var off: Vector2 = Vector2(rng.randf_range(-2.2, 2.2),
					rng.randf_range(-2.2, 2.2))
			var f: Node3D = K._box(root, Vector3(0.16, 0.22, 0.16),
					pxz + off, 0.22, col, false, "Flower%d_%d" % [i, j])
			f.add_to_group("flowers")
			f.add_to_group("veg")


## Phase 15: landmark clock tower in the downtown plaza.
static func _clock_tower(root: Node3D, dt: Rect2) -> void:
	var candidates: Array = [Vector2(-236, -122), Vector2(-236, -128),
			Vector2(-300, -120), Vector2(-236, -132)]
	var spot: Vector2 = candidates[0]
	for c: Vector2 in candidates:
		if not _on_ew_road(c):
			spot = c
			break
	K._box(root, Vector3(4.4, 1.0, 4.4), spot, 1.0, Color(0.45, 0.42, 0.4),
			true, "ClockPlaza")  # plaza pad (the one new StaticBody)
	K._box(root, Vector3(2.6, 14.0, 2.6), spot, 15.0, Color(0.52, 0.48, 0.44),
			false, "ClockShaft")
	K._box(root, Vector3(3.4, 0.5, 3.4), spot, 15.4, Color(0.4, 0.37, 0.34),
			false, "ClockCornice")
	for face: int in range(4):
		var off: Vector3 = [Vector3(1.34, 0, 0), Vector3(-1.34, 0, 0),
				Vector3(0, 0, 1.34), Vector3(0, 0, -1.34)][face]
		var clock: Node3D = K._box(root, Vector3(0.08, 1.5, 1.5),
				spot, 14.0, Color(0.96, 0.94, 0.86), false,
				"ClockFace%d" % face)
		clock.position += off
		if face < 2:
			clock.rotation_degrees = Vector3(0, 90 * (1 if face == 0 else -1), 0)
		else:
			clock.rotation_degrees = Vector3(0, 0 if face == 2 else 180, 0)
	var spire: Node3D = K._box(root, Vector3(1.2, 2.2, 1.2), spot, 16.6,
			Color(0.3, 0.28, 0.26), false, "ClockSpire")
	spire.add_to_group("landmark_clock")


## Phase 11/16: rooftop water towers on the 3 tallest downtown towers,
## aircraft-warning lights on the top 2 (join "beacons" — animated free),
## fire-escape zigzags on 2 tower flanks.
static func _rooftop_layer(root: Node3D) -> void:
	# Rooftop candidates: collidable box buildings inside the Downtown rect
	# whose roof is >= 30 m — covers the landmark tower AND the tall DTowers
	# (auto-renamed siblings make name prefixes unreliable; geometry is the
	# stable contract). Roof height = center.y + half the box shape height.
	var dt: Rect2 = K.DISTRICTS.get("Downtown", Rect2())
	var towers: Array = []
	for n: Node in root.find_children("*", "StaticBody3D", true, false):
		var b: Node3D = n as Node3D
		if b.position.y < 30.0:
			continue
		if not dt.has_point(Vector2(b.position.x, b.position.z)):
			continue
		var top: float = b.position.y
		for c: Node in b.get_children():
			if c is CollisionShape3D and (c as CollisionShape3D).shape is BoxShape3D:
				top = b.position.y + ((c as CollisionShape3D).shape as BoxShape3D).size.y * 0.5
		b.set_meta("roof_top", top)
		towers.append(b)
	towers.sort_custom(func(a: Node3D, b: Node3D) -> bool:
		return float(a.get_meta("roof_top")) > float(b.get_meta("roof_top")))
	for i in range(mini(3, towers.size())):
		var t: Node3D = towers[i]
		var top: float = float(t.get_meta("roof_top"))
		var tank: Node3D = K._box(root, Vector3(2.4, 2.6, 2.4),
				Vector2(t.position.x, t.position.z), top + 3.4,
				Color(0.45, 0.3, 0.2), false, "WaterTower%d" % i)
		tank.add_to_group("water_towers")
		K._box(root, Vector3(0.3, 1.4, 0.3), Vector2(t.position.x + 0.8, t.position.z + 0.8),
				top + 0.7, Color(0.3, 0.2, 0.15), false, "TowerLeg%d_a" % i)
		K._box(root, Vector3(0.3, 1.4, 0.3), Vector2(t.position.x - 0.8, t.position.z - 0.8),
				top + 0.7, Color(0.3, 0.2, 0.15), false, "TowerLeg%d_b" % i)
	for i in range(mini(2, towers.size())):
		var t2: Node3D = towers[i]
		var top2: float = float(t2.get_meta("roof_top"))
		var lamp: OmniLight3D = OmniLight3D.new()
		lamp.name = "AircraftWarning%d" % i
		lamp.light_color = Color(1.0, 0.15, 0.1)
		lamp.light_energy = 2.0
		lamp.omni_range = 9.0
		lamp.shadow_enabled = false
		lamp.position = Vector3(t2.position.x, top2 + 1.2, t2.position.z)
		lamp.add_to_group("beacons")
		root.add_child(lamp)
		var bulb: Node3D = K._box(root, Vector3(0.3, 0.3, 0.3),
				Vector2(t2.position.x, t2.position.z), top2 + 1.2,
				Color(1.0, 0.2, 0.15), false, "WarningBulb%d" % i)
		bulb.add_to_group("beacons_bulb")
	for i in range(mini(2, towers.size())):
		var t3: Node3D = towers[i]
		var top3: float = float(t3.get_meta("roof_top"))
		for lvl: int in range(4):
			var esc: Node3D = K._box(root, Vector3(0.18, 0.1, 3.2),
					Vector2(t3.position.x + 12.2, t3.position.z - 8.0 + lvl * 4.0),
					top3 - 2.0 - lvl * 3.0, Color(0.2, 0.2, 0.22),
					false, "FireEscape%d_%d" % [i, lvl])
			esc.add_to_group("fire_escapes")


## Phase 17: hidden cash stashes (session pickups, not world_data collectibles).
static func _hidden_stashes(root: Node3D) -> void:
	var spots: Array = [
		Vector3(-332, 1.0, -153),  # speakeasy alley, behind the hidden door
		Vector3(-60, WBTerrain.height_at(-60, -390) + 0.9, -390),  # mountain ridge
	]
	for i in range(spots.size()):
		var p: Area3D = load("res://scripts/world/pickup.gd").create("money", 150)
		p.position = spots[i]
		p.name = "HiddenStash%d" % (i + 1)
		p.add_to_group("stash")
		root.add_child(p)
