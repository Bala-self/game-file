class_name TerrainAuthoring
extends Object
## TerrainAuthoring — authored macro-geography data for the 6 km world
## (Reconstruction Prompt 03). Single home of the elevation contract, region
## relief profiles, ridge/peak/valley axes, the river path, the west bay and
## the authored coastline. WorldTerrain evaluates this data into a continuous
## deterministic height field; WorldSectorRegistry stays the metadata owner;
## WorldBuilder orchestrates. No RNG anywhere — pure data + pure math.
##
## Coordinate/bearing convention: bearing_deg = atan2(z, x) in [0,360),
## 0=+X (east), 90=+Z (south), 180=-X (west), 270=-Z (north).

const K := preload("res://scripts/world/wb_kit.gd")

## --- Elevation contract (P03 §7) ---
## SEA_LEVEL is wb_kit.WATER_Y itself (one literal, one authority).
const SEA_LEVEL_M: float = K.WATER_Y                    # -1.3
const WORLD_MIN_HEIGHT_M := -18.0                       # near-shore seabed floor
const WORLD_MAX_HEIGHT_M := 320.0
const MAX_KNEE_M := 35.0          # soft-ceiling knee width                       # hard field clamp
const PLATFORM_RADIUS_M := 700.0                        # exact-flat urban platform
const PLATFORM_BLEND_OUT_M := 1150.0                    # smoothstep end into natural field
const URBAN_MAX_GRADE_PCT := 5.0
const COAST_SLOPE_RANGE_DEG := [2.0, 8.0]               # sandy beach band
const RURAL_SLOPE_MAX_DEG := 22.0
const MOUNTAIN_SLOPE_MAX_DEG := 55.0

## --- District-type relief profiles (blend targets at full radial weight) ---
## elev_m: target base elevation; relief_m: procedural detail amplitude.
const TYPE_PROFILE := {
	"downtown":          {"elev_m": 0.0,   "relief_m": 0.3},
	"historic_dense":    {"elev_m": 2.0,   "relief_m": 0.6},
	"entertainment":     {"elev_m": 3.0,   "relief_m": 0.8},
	"beach_resort":      {"elev_m": 6.0,   "relief_m": 3.0},
	"port_industrial":   {"elev_m": 4.0,   "relief_m": 1.2},
	"heavy_industrial":  {"elev_m": 10.0,  "relief_m": 3.0},
	"military":          {"elev_m": 18.0,  "relief_m": 6.0},
	"airport":           {"elev_m": 5.0,   "relief_m": 1.0},
	"farmland":          {"elev_m": 35.0,  "relief_m": 10.0},
	"rural_dry":         {"elev_m": 70.0,  "relief_m": 16.0},
	"mountain_wild":     {"elev_m": 55.0,  "relief_m": 26.0},
	"affluent_hills":    {"elev_m": 80.0,  "relief_m": 20.0},
	"park_water":        {"elev_m": 8.0,   "relief_m": 3.0},
}
const DEFAULT_PROFILE := {"elev_m": 12.0, "relief_m": 4.0}

## Radial weight: districts ramp from r_start to r_full (smoothstep), so the
## platform blend (700->1150) hands over to gradually-strengthening regional
## terrain — no wedge edges, no hard Cartesian splits (P03 §44).
const REGION_R_START_M := 900.0
const REGION_R_FULL_M := 1900.0

## --- Mountain system (authored axes; P03 §12) ---
## Foothill ramp scales ridge/peak amplitude with radius (gradual rise).
const FOOTHILL_R0 := 1250.0
const FOOTHILL_R1 := 2050.0
## Ridge axes: polylines [Vector2...], gaussian width_m, amplitude_m.
const RIDGES := [
	{"pts": [Vector2(-1500, -1650), Vector2(-700, -2050), Vector2(250, -2300), Vector2(1050, -2050)],
			"width_m": 430.0, "amp_m": 85.0},
	{"pts": [Vector2(-1150, -2250), Vector2(-100, -2600), Vector2(850, -2450)],
			"width_m": 380.0, "amp_m": 105.0},
]
## Peaks: deterministic anchors (limited number, landmark value).
const PEAKS := [
	{"c": Vector2(-700, -2280), "rad_m": 340.0, "amp_m": 125.0},   # west massif
	{"c": Vector2(120, -2520),  "rad_m": 380.0, "amp_m": 160.0},   # highest — Sentinel Peak
	{"c": Vector2(950, -2230),  "rad_m": 320.0, "amp_m": 118.0},   # east massif
	{"c": Vector2(-1520, -1900), "rad_m": 280.0, "amp_m": 78.0},   # NW foothill peak
	{"c": Vector2(620, -1720),  "rad_m": 260.0, "amp_m": 62.0},    # foothill knob
	{"c": Vector2(-210, -1520), "rad_m": 240.0, "amp_m": 44.0},    # city-facing overlook hill
]
## Valley corridors (carved between ridges; readable drainage, P03 §11).
const VALLEYS := [
	{"pts": [Vector2(-1250, -1980), Vector2(-250, -2260), Vector2(680, -2080)],
			"width_m": 300.0, "depth_m": 55.0},
	{"pts": [Vector2(220, -1560), Vector2(330, -2100), Vector2(300, -2450)],
			"width_m": 250.0, "depth_m": 40.0},
]

## --- River (authored path; source in the north valleys -> SE sea) ---
const RIVER_PTS := [Vector2(480, -2280), Vector2(640, -1700), Vector2(760, -1100),
		Vector2(960, -600), Vector2(1250, -150), Vector2(1500, 350),
		Vector2(1700, 900), Vector2(1900, 1420), Vector2(2050, 1850)]
const RIVER_WIDTH_START_M := 8.0
const RIVER_WIDTH_END_M := 26.0
const RIVER_DEPTH_M := 2.6
## Bridge anchors for Prompt 04 (road crossings; data, not geometry yet).
const RIVER_BRIDGE_ANCHORS := [Vector2(760, -1100), Vector2(1250, -150), Vector2(1700, 900)]

## --- Lake (Lakelands park_water district; river passes through it) ---
const LAKE_CENTER := Vector2(1620, 950)
const LAKE_RADIUS_M := 340.0
const LAKE_LEVEL_M := 4.0      # inflow rapid ~1.1 m, outlet fall ~3.2 m
const LAKE_FLOOR_M := 2.5      # flat basin floor (level - 1.5)

## --- West bay (keeps the legacy beachfront/offshore-islet composition) ---
const BAY_CENTER_DEG := 183.0
const BAY_HALF_WIDTH_DEG := 24.0     # smooth gaussian edges
const BAY_SHORE_R_M := 760.0         # land ends here inside the bay
const BAY_MAX_DEPTH_M := 9.0

## --- Legacy-compatibility water carves (P03 Phase F). The platform disc and
## regional field would otherwise dry out two legacy water features:
##  * the harbor marina where both drivable boats are moored (-582/-572, ~230)
##  * the "offshore island" swim destination at (700, 0)
## These are engineered/natural basins carved AFTER the platform blend, so
## both stay exactly where legacy content expects them. ---
const MARINA_BASINS := [
	{"c": Vector2(-620, 210), "r": 150.0, "floor": -2.6},
	{"c": Vector2(-790, 215), "r": 130.0, "floor": -3.0},  # ties into the bay
]
const EAST_HARBOR := {
	"c": Vector2(880, 0), "rx": 300.0, "ry": 280.0, "floor": -3.2,
	"islet_c": Vector2(700, 0), "islet_r": 90.0, "islet_floor": -1.6,
}

## --- Authored coastline (land_end radius per bearing, deterministic) ---
const COAST_BASE_R_M := 2620.0
const COAST_VAR1_M := 150.0   # 3-lobe variation
const COAST_VAR2_M := 55.0    # 7-lobe detail (Phase F QA: 90 made le() swing 24 m/deg)
const COAST_PHASE1 := 1.7
const COAST_PHASE2 := 0.3
const CLIFF_WINDOW := [118.0, 160.0]  # SW cliff coast (bearing deg)
const CLIFF_TRANS_M := 70.0           # steep transition -> cliff faces
const BEACH_TRANS_M := 330.0          # gentle transition -> sandy beach


## Authored land-end radius for a bearing (coastline shape authority).
static func land_end_r(bearing_deg: float) -> float:
	var a: float = deg_to_rad(bearing_deg)
	var le: float = COAST_BASE_R_M + COAST_VAR1_M * sin(a * 3.0 + COAST_PHASE1) \
			+ COAST_VAR2_M * sin(a * 7.0 + COAST_PHASE2)
	# the bay punches the coastline inward on its bearing window
	var bay_w: float = _bay_weight(bearing_deg)
	if bay_w > 0.0:
		le = lerpf(le, BAY_SHORE_R_M, bay_w)
	return clampf(le, 700.0, 2860.0)


## Smooth west-bay angular weight (0 outside, 1 deep inside the bay).
static func _bay_weight(bearing_deg: float) -> float:
	var d: float = absf(angle_diff_deg(bearing_deg, BAY_CENTER_DEG))
	if d >= BAY_HALF_WIDTH_DEG + 10.0:
		return 0.0
	return 1.0 - smoothstep(BAY_HALF_WIDTH_DEG - 8.0, BAY_HALF_WIDTH_DEG + 10.0, d)


static func angle_diff_deg(a: float, b: float) -> float:
	var d: float = fmod(a - b + 540.0, 360.0) - 180.0
	return d


## Coastal transition width (cliff window -> short & steep, else beachy).
static func coast_trans_m(bearing_deg: float) -> float:
	var lo: float = CLIFF_WINDOW[0]
	var hi: float = CLIFF_WINDOW[1]
	var d: float = absf(angle_diff_deg(bearing_deg, (lo + hi) * 0.5))
	var half: float = (hi - lo) * 0.5
	if d >= half + 12.0:
		return BEACH_TRANS_M
	return lerpf(BEACH_TRANS_M, CLIFF_TRANS_M,
			1.0 - smoothstep(half - 10.0, half + 12.0, d))


## Profile lookup for a district type.
static func profile_for_type(t: String) -> Dictionary:
	return TYPE_PROFILE.get(t, DEFAULT_PROFILE)


## =====================================================================
## P04 §79 — AUTHORED ROAD CORRIDORS (intentional terrain blending data)
## =====================================================================
## The mountain roads ride the P03 valleys, but the valley floors still
## carry 25-66% local gradient (noise + valley walls). These corridors are
## AUTHORED flatten/blend bands: deterministic, data-declared, applied in
## WorldTerrain.height_at as a final pass. This is the §79-sanctioned way
## to make terrain road-compatible — explicit authoring data, never hidden
## runtime deformation. Corridors avoid the peaks (Sentinel 297 m gate),
## ridges' crests off-road, the river and all coastlines.
const ROAD_CORRIDORS: Array = [
	{"id": "MTN_V1_MAIN_01", "grade": 0.12, "half_w": 20.0, "blend": 60.0,
		"pts": [Vector2(330, -2150), Vector2(250, -2190), Vector2(0, -2240),
				Vector2(-250, -2260), Vector2(-400, -2230), Vector2(-650, -2160)]},
	{"id": "MTN_V1_DESCENT_01", "grade": 0.12, "half_w": 17.0, "blend": 55.0,
		"pts": [Vector2(-650, -2160), Vector2(-750, -2050), Vector2(-900, -2100),
				Vector2(-1000, -2000), Vector2(-850, -1950), Vector2(-1050, -1900),
				Vector2(-1250, -1980)]},
	{"id": "MTN_V2_01", "grade": 0.12, "half_w": 17.0, "blend": 50.0,
		"pts": [Vector2(320, -1520), Vector2(280, -1700), Vector2(280, -1850),
				Vector2(310, -2000), Vector2(330, -2150)]},
	{"id": "MTN_SENTINEL_01", "grade": 0.12, "half_w": 15.0, "blend": 45.0,
		"pts": [Vector2(-250, -2260), Vector2(-330, -2330), Vector2(-300, -2430),
				Vector2(-170, -2470), Vector2(-60, -2430), Vector2(0, -2350)]},
	{"id": "MIL_PUBLIC_01", "grade": 0.12, "half_w": 14.0, "blend": 40.0,
		"pts": [Vector2(280, -1850), Vector2(150, -1950), Vector2(50, -2050),
				Vector2(-50, -2150)]},
]

## Cheap reject bounds for the corridor pass (all corridors live here).
const ROAD_CORRIDOR_BOUNDS := Rect2(Vector2(-1350, -2560), Vector2(1780, 1080))
