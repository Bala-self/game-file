extends Node3D
const EconomyRes := preload("res://scripts/core/economy.gd")
## Street Race activity: 8 glowing checkpoints on downtown roads.
## Drive through the start ring to begin, chain all rings before the timer
## runs out, earn $400. Best time persists in stats.

signal race_started
signal race_finished(won: bool, time: float)

const CP_POS: Array[Vector3] = [
	Vector3(-260, 1.2, -74), Vector3(-60, 1.2, -74), Vector3(46, 1.2, -160),
	Vector3(46, 1.2, -300), Vector3(-140, 1.2, -300), Vector3(-267, 1.2, -240),
	Vector3(-267, 1.2, -100), Vector3(-380, 1.2, -74),
]
const TIME_LIMIT := 110.0
const REWARD := 400

var active: bool = false
var cp_index: int = 0
var time_left = TIME_LIMIT
var markers: Array[Node3D] = []
var _areas: Array[Area3D] = []
var _hud_tick: float = 0.0


func _ready() -> void:
	add_to_group("race")
	for i in range(CP_POS.size()):
		var marker = Node3D.new()
		marker.position = CP_POS[i]
		# glowing ring gate
		var ring = MeshInstance3D.new()
		var tm: TorusMesh = TorusMesh.new()
		tm.inner_radius = 4.4
		tm.outer_radius = 5.2
		var m = StandardMaterial3D.new()
		m.albedo_color = Color(0.2, 0.9, 1.0) if i > 0 else Color(0.25, 1.0, 0.35)
		m.emission_enabled = true
		m.emission = m.albedo_color
		m.emission_energy_multiplier = 1.6
		tm.material = m
		ring.mesh = tm
		ring.rotation_degrees = Vector3(90, 0, 0)  # stand upright across the road
		marker.add_child(ring)
		var area = Area3D.new()
		area.collision_layer = 0
		area.collision_mask = 8  # player-driven cars
		var cs = CollisionShape3D.new()
		var ss = SphereShape3D.new()
		ss.radius = 5.5
		cs.shape = ss
		area.add_child(cs)
		marker.add_child(area)
		_areas.append(area)
		markers.append(marker)
		add_child(marker)
	_areas[0].body_entered.connect(func(_b: Node3D) -> void: _on_gate(0))
	for i in range(1, CP_POS.size()):
		var idx = i
		_areas[i].body_entered.connect(func(_b: Node3D) -> void: _on_gate(idx))
	_set_marker_visibility()


func _process(delta: float) -> void:
	if not active:
		return
	time_left -= delta
	_hud_tick -= delta
	if _hud_tick <= 0.0:
		_hud_tick = 0.1
		get_tree().call_group("hud", "set_race_text",
				"RACE %d/%d   %ds" % [cp_index + 1, CP_POS.size(), int(ceil(time_left))])
	if time_left <= 0.0:
		_fail()


func _on_gate(entered_idx: int = 0) -> void:
	var player = get_tree().get_first_node_in_group("player")
	if player == null or player.driving_car == null:
		return  # must be driving to race
	if not active:
		if entered_idx == 0:
			_start()
		return
	if entered_idx == cp_index:
		cp_index += 1
		GameState.notify("Checkpoint %d/%d" % [cp_index, CP_POS.size()])
		GameState.vibrate(0.2, 0.3, 0.1)
		_set_marker_visibility()
		if cp_index >= CP_POS.size():
			_finish()


func _start() -> void:
	active = true
	cp_index = 1
	time_left = TIME_LIMIT
	_set_marker_visibility()
	GameState.notify("RACE STARTED! Hit every ring before time runs out!")
	race_started.emit()


func _finish() -> void:
	active = false
	var t = TIME_LIMIT - time_left
	var best: float = GameState.stats.get("race_best", 0.0)
	if best == 0.0 or t < best:
		GameState.stats["race_best"] = snappedf(t, 0.1)
	EconomyRes.earn(REWARD, "race_reward")
	var bus: Node = get_tree().root.get_node_or_null("EventBus")
	if bus != null:
		bus.record("MISSION_COMPLETED", {"id": "street_race"})
	GameState.notify("RACE WON! +$%d (%.1fs%s)" % [REWARD, t,
			", new best!" if snappedf(t, 0.1) == GameState.stats["race_best"] else ""])
	get_tree().call_group("hud", "set_race_text", "")
	_set_marker_visibility()
	race_finished.emit(true, t)


func _fail() -> void:
	active = false
	cp_index = 0
	time_left = TIME_LIMIT
	GameState.notify("Race failed — out of time. Re-enter the green ring to retry.")
	get_tree().call_group("hud", "set_race_text", "")
	_set_marker_visibility()
	race_finished.emit(false, TIME_LIMIT)


## Green ring = start / next target; dim the rest.
func _set_marker_visibility() -> void:
	for i in range(markers.size()):
		var ring: MeshInstance3D = markers[i].get_child(0)
		var mat: StandardMaterial3D = (ring.mesh as TorusMesh).material
		if not active:
			mat.emission_energy_multiplier = 1.6 if i == 0 else 0.25
			mat.albedo_color.a = 1.0 if i == 0 else 0.4
		elif i == cp_index:
			mat.emission_energy_multiplier = 2.2
			mat.albedo_color.a = 1.0
		else:
			mat.emission_energy_multiplier = 0.15
			mat.albedo_color.a = 0.25
