class_name WBArch
extends Object
## Modular architecture kit: data-driven building constructor, facades,
## enterable interior shells, furniture kits, parking ramps.

const K := preload("res://scripts/world/wb_kit.gd")


static func _building(root: Node3D, xz: Vector2, size: Vector3, spec: Dictionary = {},
		rng: RandomNumberGenerator = null) -> StaticBody3D:
	var style: String = spec.get("style", "concrete")
	var ground: String = spec.get("ground", "plain")
	var roof: String = spec.get("roof", "parapet")
	var namep: String = spec.get("name", "Building")
	var age: String = spec.get("age", "middle")  # new/middle/old/abandoned — realism
	var palette: Dictionary = {
		"concrete": Color(0.62, 0.61, 0.58), "brick": Color(0.48, 0.3, 0.24),
		"plaster": Color(0.78, 0.72, 0.62), "glass": Color(0.3, 0.42, 0.52),
	}
	var col: Color = palette.get(style, palette["concrete"])
	if rng:
		col = col.lightened(rng.randf() * 0.1 - 0.03)
	# Building Age System — powerful realism technique
	match age:
		"new":
			col = col.lightened(0.08)  # clean walls, new pavement, modern windows
		"middle":
			col = col.darkened(0.02)  # slight discoloration, minor cracks
		"old":
			col = col.darkened(0.12)  # damaged plaster, rust, dirty walls, replaced windows
			col = Color(col.r * 0.92, col.g * 0.88, col.b * 0.82)  # yellowed
		"abandoned":
			col = col.darkened(0.22)  # broken windows, vegetation growth, graffiti, damaged doors
			col = Color(col.r * 0.85, col.g * 0.82, col.b * 0.78)
	var body = K._box(root, size, xz, size.y, col, true, namep)
	K._box(root, Vector3(size.x + 1.2, 0.3, size.z + 1.2), xz, 0.3, Color(0.3, 0.3, 0.32),
			true, namep + "Base")
	_building_detail(root, size, xz, size.y)
	if ground == "shop":
		K._decal_box(root, Vector3(size.x * 0.7, 1.6, 0.15), xz + Vector2(0, size.z / 2 + 0.02),
				2.2, Color(0.25, 0.45, 0.55), namep + "Storefront")
		K._box(root, Vector3(size.x * 0.75, 0.15, 1.4), xz + Vector2(0, size.z / 2 + 0.6), 2.75,
				Color(0.75, 0.3, 0.25), false, namep + "Awning")
	if spec.has("sign"):
		var sc: Color = spec.get("sign_color", Color(0.9, 0.6, 0.15))
		K._decal_box(root, Vector3(minf(size.x * 0.6, 7.0), 0.9, 0.2),
				xz + Vector2(0, size.z / 2 + 0.05), minf(size.y - 1.0, 4.6), sc, namep + "Sign")
	if roof == "parapet":
		for sx in [-1.0, 1.0]:
			K._box(root, Vector3(size.x, 0.7, 0.3), xz + Vector2(0, sx * (size.z / 2 - 0.15)),
					size.y + 0.7, col.darkened(0.15), true, namep + "Parapet")
			K._box(root, Vector3(0.3, 0.7, size.z), xz + Vector2(sx * (size.x / 2 - 0.15), 0),
					size.y + 0.7, col.darkened(0.15), true, namep + "Parapet")
	var ac_n: int = spec.get("ac", 2)
	for i in range(ac_n):
		var off: Vector2 = Vector2((i % 2 - 0.5) * size.x * 0.4, ((i / 2) % 2 - 0.5) * size.z * 0.4)
		var ac_col: Color = Color(0.65, 0.66, 0.68)
		if age == "old":
			ac_col = Color(0.55, 0.50, 0.45)  # rust
		elif age == "abandoned":
			ac_col = Color(0.45, 0.40, 0.38)  # broken equipment
		var ac = K._box(root, Vector3(1.2, 0.8, 1.2), xz + off, size.y + 0.8,
				ac_col, true, namep + "AC")
		ac.get_child(0).visibility_range_end = 260.0
	var ant = K._box(root, Vector3(0.12, 3.0, 0.12), xz + Vector2(size.x * 0.3, 0),
			size.y + 3.0, Color(0.75, 0.75, 0.78), false, namep + "Antenna")
	ant.get_child(0).visibility_range_end = 300.0
	# Back alley realism — don't only design main road view
	if rng and size.x > 8.0 and size.z > 8.0:
		_build_back_alley(root, xz, size, age, rng, namep)
	# Age details — graffiti, broken windows, vegetation growth for abandoned
	if age == "abandoned":
		_build_abandoned_details(root, xz, size, rng, namep)
	elif age == "old":
		_build_old_details(root, xz, size, rng, namep)
	K.qa_rects.append(Rect2(xz - Vector2(size.x, size.z) * 0.5, Vector2(size.x, size.z)))
	return body

static func _build_back_alley(root: Node3D, xz: Vector2, size: Vector3, age: String, rng: RandomNumberGenerator, namep: String) -> void:
	if rng == null:
		return
	# Back alley: dumpsters, delivery doors, pipes, AC compressors, electrical boxes, pallets, cardboard, service vehicles, security cameras
	var back_z = xz + Vector2(0, -size.z/2 - 1.5)
	K._box(root, Vector3(1.6, 1.2, 1.0), back_z + Vector2(-size.x*0.2, 0), 1.2, Color(0.25, 0.4, 0.3), false, namep+"Dumpster")
	K._box(root, Vector3(0.3, 2.0, 0.8), back_z + Vector2(size.x*0.15, 0), 2.0, Color(0.45, 0.35, 0.25), false, namep+"DeliveryDoor")
	K._box(root, Vector3(0.15, 0.15, size.x*0.4), back_z + Vector2(0, 0.5), size.y*0.6, Color(0.5, 0.5, 0.52), false, namep+"Pipe")
	K._box(root, Vector3(0.8, 0.6, 0.5), back_z + Vector2(size.x*0.25, 0.8), 0.6, Color(0.6, 0.6, 0.62), false, namep+"EBox")
	if rng.randf() > 0.5:
		K._box(root, Vector3(1.2, 0.3, 0.9), back_z + Vector2(-size.x*0.1, 0.5), 0.3, Color(0.55, 0.45, 0.32), false, namep+"Pallet")
	# Security camera
	K._box(root, Vector3(0.25, 0.25, 0.4), xz + Vector2(size.x*0.4, size.z*0.3), size.y - 0.5, Color(0.15, 0.15, 0.18), false, namep+"SecCam")

static func _build_old_details(root: Node3D, xz: Vector2, size: Vector3, rng: RandomNumberGenerator, namep: String) -> void:
	# Old: damaged plaster, rust, dirty walls, replaced windows, patchwork repairs
	if rng == null:
		var _rng_fb: RandomNumberGenerator = RandomNumberGenerator.new()
		_rng_fb.seed = int(xz.x * 1000 + xz.y * 1000) + 54321
		rng = _rng_fb
	for i in range(2):
		var off: Vector2 = Vector2(rng.randf_range(-size.x*0.3, size.x*0.3), rng.randf_range(-size.z*0.3, size.z*0.3))
		K._decal_box(root, Vector3(1.2, 1.0, 0.06), xz + off, size.y*0.6, Color(0.35, 0.32, 0.28), namep+"Patch%d"%i)
	# Rust streak
	K._decal_box(root, Vector3(0.3, size.y*0.5, 0.06), xz + Vector2(size.x*0.2, 0), size.y*0.5, Color(0.55, 0.35, 0.22), namep+"Rust")

static func _build_abandoned_details(root: Node3D, xz: Vector2, size: Vector3, rng: RandomNumberGenerator, namep: String) -> void:
	if rng == null:
		return
	# Abandoned: broken windows, vegetation growth, graffiti, damaged doors, debris
	K._decal_box(root, Vector3(size.x*0.5, 1.2, 0.06), xz + Vector2(0, size.z/2+0.05), size.y*0.7, Color(0.85, 0.2, 0.6), namep+"Graffiti")
	# Broken window (dark)
	K._decal_box(root, Vector3(1.5, 1.2, 0.06), xz + Vector2(-size.x*0.2, size.z/2+0.06), size.y*0.5, Color(0.05, 0.05, 0.08), namep+"BrokenWin")
	# Vegetation growth
	K._box(root, Vector3(0.8, 0.6, 0.8), xz + Vector2(size.x*0.4, -size.z*0.3), 0.6, Color(0.2, 0.42, 0.2), false, namep+"Overgrowth")
	# Debris
	K._box(root, Vector3(0.6, 0.3, 0.9), xz + Vector2(-size.x*0.3, -size.z*0.4), 0.3, Color(0.45, 0.42, 0.38), false, namep+"Debris")


## ---------------- enterable interiors (modular kit) ----------------
## Hollow building: floor, 4 walls (one with a 3.2 m doorway), roof, warm
## interior light, and a furnished kit. door_side: 0=+z 1=+x 2=-z 3=-x.
## Fixed enterable interiors: downtown storefronts, harbor office, warehouse.

static func _building_detail(parent: Node3D, size: Vector3, xz: Vector2, height: float,
		floors := 0) -> void:
	var fl = floors if floors > 0 else maxi(2, int(height / 3.5))
	var band_h: float = 0.9
	if K.WINDOW_MATERIAL == null:
		var wm = StandardMaterial3D.new()
		wm.albedo_color = Color(0.16, 0.2, 0.26)
		wm.emission_enabled = true
		wm.emission = Color(1.0, 0.85, 0.45)
		wm.emission_energy_multiplier = 0.0  # driven by game.gd day/night
		K.WINDOW_MATERIAL = wm
	var win_mat = K.WINDOW_MATERIAL
	for side in range(4):
		var band = MeshInstance3D.new()
		var bm = BoxMesh.new()
		var wide = size.x if side < 2 else size.z
		bm.size = Vector3(wide * 0.86, band_h * fl * 0.55, 0.1)
		bm.material = win_mat
		band.mesh = bm
		var off = size.z * 0.5 + 0.06 if side < 2 else size.x * 0.5 + 0.06
		var off2 = size.x * 0.5 + 0.06 if side < 2 else size.z * 0.5 + 0.06
		match side:
			0: band.position = Vector3(xz.x, height * 0.55, xz.y - off2)
			1: band.position = Vector3(xz.x, height * 0.55, xz.y + off2)
			2: band.position = Vector3(xz.x - off, height * 0.55, xz.y)
			3: band.position = Vector3(xz.x + off, height * 0.55, xz.y)
		if side >= 2:
			band.rotation_degrees = Vector3(0, 90, 0)
		parent.add_child(band)
	# rooftop machinery
	if height > 20.0:
		K._box(parent, Vector3(3, 1.6, 2.2), xz + Vector2(size.x * 0.2, size.z * 0.15),
				height + 1.6, Color(0.45, 0.45, 0.48), false, "HVAC")
		K._box(parent, Vector3(1.2, 2.8, 1.2), xz + Vector2(-size.x * 0.25, -size.z * 0.2),
				height + 2.8, Color(0.5, 0.5, 0.52), false, "Antenna")

static func _build_interior_building(root: Node3D, center: Vector2, size: Vector2, height: float,
		wall_color: Color, kit: String, bname: String, door_side := 0) -> StaticBody3D:
	var t: float = 0.4
	var floor_col: Color = Color(0.42, 0.34, 0.26)
	if kit in ["medical", "office"]:
		floor_col = Color(0.6, 0.62, 0.65)
	var floor_body = K._box(root, Vector3(size.x, 0.3, size.y), center, 0.3, floor_col, true,
			bname + "Floor")
	floor_body.set_meta("interior", kit)
	var lintel_col = wall_color.darkened(0.1)
	# back wall (-z)
	K._box(root, Vector3(size.x, height, t), center + Vector2(0, -size.y / 2 + t / 2), height,
			wall_color, true, bname + "WallB")
	# left/right walls (-x / +x)
	for sx in [-1.0, 1.0]:
		var side = 1 if sx > 0.0 else 3
		if door_side == side:
			var half = size.y / 2.0
			var seg = (half - 1.6) / 2.0 + 0.0
			var seg_len = half - 1.6
			var off = (half + 1.6) / 2.0
			for sgn in [-1.0, 1.0]:
				K._box(root, Vector3(t, height, seg_len), center + Vector2(sx * (size.x / 2 - t / 2),
						sgn * off), height, wall_color, true, bname + "WallX")
			K._box(root, Vector3(t, height - 3.0, 3.2), center + Vector2(sx * (size.x / 2 - t / 2), 0),
					height, lintel_col, true, bname + "Lintel")
		else:
			K._box(root, Vector3(t, height, size.y), center + Vector2(sx * (size.x / 2 - t / 2), 0),
					height, wall_color, true, bname + "WallX")
	# front wall (+z), possibly the doorway
	var front_pos = center + Vector2(0, size.y / 2 - t / 2)
	if door_side == 0:
		var half = size.x / 2.0
		var seg_len = half - 1.6
		var off = (half + 1.6) / 2.0
		for sgn in [-1.0, 1.0]:
			K._box(root, Vector3(seg_len, height, t), front_pos + Vector2(sgn * off, 0), height,
					wall_color, true, bname + "WallF")
		K._box(root, Vector3(3.2, height - 3.0, t), front_pos, height, lintel_col, true,
				bname + "Lintel")
	else:
		K._box(root, Vector3(size.x, height, t), front_pos, height, wall_color, true, bname + "WallF")
	# roof
	K._box(root, Vector3(size.x, 0.4, size.y), center, height + 0.4, wall_color.darkened(0.25),
			true, bname + "Roof")
	# warm interior light (cheap: no shadows)
	var light = OmniLight3D.new()
	light.light_color = Color(1.0, 0.9, 0.75)
	light.omni_range = maxf(size.x, size.y) * 0.9
	light.light_energy = 1.15
	light.shadow_enabled = false
	light.position = Vector3(center.x, height - 0.8, center.y)
	root.add_child(light)
	_kit_props(root, kit, center, size, height)
	return floor_body


## Furniture kits — collidable props, culled beyond 160 m.

static func _kit_props(root: Node3D, kit: String, c: Vector2, size: Vector2, height: float) -> void:
	var prop_range: float = 160.0
	var wood: Color = Color(0.45, 0.32, 0.2)
	var dark: Color = Color(0.2, 0.2, 0.24)
	match kit:
		"shop":
			_counter_prop(root, Vector3(4, 1.0, 1.2), c + Vector2(0, -size.y / 4), wood, prop_range)
			for sx in [-1.0, 1.0]:
				var shelf = K._box(root, Vector3(1.0, 2.4, 3.2), c + Vector2(sx * size.x / 4,
						-size.y / 2 + 2.0), 2.4, Color(0.5, 0.4, 0.28), true, "Shelf")
				shelf.get_child(0).visibility_range_end = prop_range
			_counter_prop(root, Vector3(0.5, 0.4, 0.4), c + Vector2(0, -size.y / 4), dark, prop_range)
		"house":
			_counter_prop(root, Vector3(2.0, 0.55, 1.5), c + Vector2(-size.x / 4, -size.y / 4),
					Color(0.7, 0.7, 0.75), prop_range)  # bed
			_counter_prop(root, Vector3(1.6, 0.8, 0.9), c + Vector2(size.x / 4, 0), wood, prop_range)
			_counter_prop(root, Vector3(1.6, 0.4, 0.5), c + Vector2(0, size.y / 2 - 1.4), wood, prop_range)
			_counter_prop(root, Vector3(1.4, 0.9, 0.3), c + Vector2(0, size.y / 2 - 1.4), dark, prop_range)
		"office":
			for dx in [-1.0, 1.0]:
				for dz in [-1.0, 1.0]:
					_counter_prop(root, Vector3(1.4, 0.75, 0.7),
							c + Vector2(dx * size.x / 5, dz * size.y / 5), wood, prop_range)
					K._cyl(root, 0.25, 0.5, c + Vector2(dx * size.x / 5, dz * size.y / 5 + 0.8),
							0.5, dark, true, 8)
			_counter_prop(root, Vector3(0.8, 1.8, 0.5), c + Vector2(-size.x / 2 + 1.0,
					-size.y / 2 + 1.0), Color(0.45, 0.45, 0.5), prop_range)
		"school":
			for i in range(6):
				var dx = (i % 3 - 1) * 2.2
				var dz = (i / 3) * 2.0 - 1.0
				_counter_prop(root, Vector3(1.2, 0.7, 0.6), c + Vector2(dx, dz), wood, prop_range)
			_counter_prop(root, Vector3(2.0, 0.8, 0.8), c + Vector2(0, size.y / 2 - 1.6), wood, prop_range)
		"medical":
			_counter_prop(root, Vector3(3.0, 1.0, 1.0), c + Vector2(0, size.y / 2 - 2.0),
					Color(0.8, 0.82, 0.85), prop_range)
			for i in range(3):
				_counter_prop(root, Vector3(2.0, 0.6, 0.9), c + Vector2(-size.x / 4 + i * size.x / 4,
						-size.y / 2 + 1.4), Color(0.92, 0.93, 0.95), prop_range)
		"warehouse":
			for i in range(6):
				var dx = (i % 3 - 1) * 2.4
				var dz = (i / 3) * 2.6 - 1.3
				_counter_prop(root, Vector3(1.4, 1.4, 1.4), c + Vector2(dx, dz),
						Color(0.62, 0.5, 0.32), prop_range)
		"bar":
			_counter_prop(root, Vector3(4.5, 1.1, 1.2), c + Vector2(0, -size.y / 4), wood, prop_range)
			_counter_prop(root, Vector3(3.0, 2.2, 0.5), c + Vector2(0, -size.y / 2 + 0.8),
					Color(0.35, 0.25, 0.18), prop_range)
			for sx in [-1.0, 1.0]:
				K._cyl(root, 0.5, 0.75, c + Vector2(sx * size.x / 4, size.y / 5), 0.75, dark, true, 10)

static func _counter_prop(root: Node3D, size: Vector3, xz: Vector2, col: Color,
		prop_range: float) -> void:
	var b = K._box(root, size, xz, size.y, col, true, "Prop")
	b.get_child(0).visibility_range_end = prop_range


## Zebra crossings at every signalized intersection.

static func _ramp(root: Node3D, center: Vector2, length: float, rise: float, width: float,
		color: Color, base_y := 0.0) -> void:
	var body = StaticBody3D.new()
	body.name = "Ramp"
	var mesh_inst = MeshInstance3D.new()
	var mesh = BoxMesh.new()
	var slope_len = sqrt(length * length + rise * rise)
	mesh.size = Vector3(slope_len, 0.5, width)
	mesh.material = K._mat(color.darkened(0.05))
	mesh_inst.mesh = mesh
	body.add_child(mesh_inst)
	var shape = CollisionShape3D.new()
	var bs = BoxShape3D.new()
	bs.size = Vector3(slope_len, 0.5, width)
	shape.shape = bs
	body.add_child(shape)
	body.collision_layer = 1
	var ang = atan2(rise, length)
	body.position = Vector3(center.x, base_y + rise * 0.5, center.y)
	body.rotation = Vector3(0, -PI / 2.0, -ang)
	root.add_child(body)
