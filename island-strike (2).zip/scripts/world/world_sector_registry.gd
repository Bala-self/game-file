class_name WorldSectorRegistry
extends Object
## WorldSectorRegistry — deterministic sector metadata service (Prompt 02).
##
## Macro (500 m) + micro (125 m) records derived from WorldContract geometry.
## District assignment reads the authoritative design table from
## res://data/reconstruction/island_target_districts.json (parsed once,
## cached) — the JSON is the source of truth; this file adds no competing
## district data. Region classification follows the Prompt 02 §10 skeleton.
##
## Everything here is pure math + cached lookups: no scene access, no RNG,
## deterministic across sessions (records carry generation seeds derived
## through WorldContract's seed chain).
##
## Record contract (P02 §6) — micro record fields:
##   id, macro_id, grid_x, grid_z, center_x, center_z, bounds,
##   circle_intersection, region_id, district_id, biome_id, density_class,
##   road_class, terrain_class, population_class, traffic_class,
##   stream_state, generation_seed, revision, version
## stream_state defaults to "UNLOADED" (Streamer owns live state transitions).

const DISTRICTS_JSON := "res://data/reconstruction/island_target_districts.json"
const RECORD_VERSION := 1

## region ids (P02 §10 architectural categories)
const REGION_CORE := "core_urban"
const REGION_INNER := "inner_urban_ring"
const REGION_COASTAL := "coastal"
const REGION_HILLS := "hills_mountains"
const REGION_INDUSTRIAL := "industrial"
const REGION_RURAL := "rural"
const REGION_SPECIAL := "special_infrastructure"

## terrain class per district type (P03 replaces with measured terrain data)
const TERRAIN_BY_TYPE := {
	"airport": "flat_grass_asphalt", "port_industrial": "flat_concrete",
	"military": "flat_dirt", "beach_resort": "sand_dunes",
	"downtown": "flat_urban", "historic_dense": "flat_urban",
	"entertainment": "flat_urban", "heavy_industrial": "flat_gravel",
	"rural_dry": "dry_scrub", "mountain_wild": "mountain",
	"affluent_hills": "rolling", "park_water": "lake_plains",
	"farmland": "fields",
}
const DENSITY_BY_TYPE := {
	"downtown": "high", "historic_dense": "high", "entertainment": "high",
	"beach_resort": "medium", "port_industrial": "medium",
	"heavy_industrial": "low", "affluent_hills": "low", "airport": "low",
	"military": "low", "farmland": "low", "park_water": "low",
	"rural_dry": "low", "mountain_wild": "minimal",
}

static var _districts: Array = []          # parsed, priority-sorted
static var _districts_loaded := false
static var _micro_cache: Dictionary = {}   # Vector2i -> record
static var _macro_cache: Dictionary = {}   # Vector2i -> record
static var _ids_cache: Array = []          # ordered valid micro ids
static var _ids_ready := false


## --- district table (JSON = single source of truth) ---

static func _ensure_districts() -> void:
	if _districts_loaded:
		return
	_districts_loaded = true
	_districts = []
	if not FileAccess.file_exists(DISTRICTS_JSON):
		push_warning("WorldSectorRegistry: district table missing: %s" % DISTRICTS_JSON)
		return
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(DISTRICTS_JSON))
	if not (parsed is Dictionary) or not parsed.has("districts"):
		push_warning("WorldSectorRegistry: district table malformed")
		return
	var arr: Array = parsed["districts"]
	arr.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		return int(a.get("priority", 0)) > int(b.get("priority", 0)))
	_districts = arr


## Wedge test with wrap support (camp_halberd spans 350->20 deg).
static func _angle_deg(v: Vector2) -> float:
	var a: float = rad_to_deg(atan2(v.y, v.x))
	if a < 0.0:
		a += 360.0
	return a


static func _in_wedge(v: Vector2, wedge: Array) -> bool:
	if wedge.size() != 2:
		return false
	var a: float = _angle_deg(v)
	var lo: float = float(wedge[0])
	var hi: float = float(wedge[1])
	if lo <= hi:
		return a >= lo and a < hi
	return a >= lo or a < hi  # wraps through 0


## District assignment: highest-priority wedge containing the point (by radius
## band + angle), per the JSON assignment_rule. "" when unassigned.
static func district_at_xz(xz: Vector2) -> String:
	_ensure_districts()
	var r: float = WorldContract.dist_to_center_xz(xz)
	for d: Dictionary in _districts:
		if r >= float(d.get("r_min_m", 0.0)) and r <= float(d.get("r_max_m", 0.0)) \
				and _in_wedge(xz, d.get("wedge_deg", [])):
			return str(d.get("id", ""))
	if r > 2400.0:
		return "coast_band"  # default secondary per JSON
	return ""


static func district_type_of(id: String) -> String:
	_ensure_districts()
	for d: Dictionary in _districts:
		if str(d.get("id", "")) == id:
			return str(d.get("type", ""))
	return ""


## Legacy Rect2 adapter (P02 §11): same behavior NPC/HUD code has today, in
## one place. Consumers migrate here; the Rect2 dict stays the data.
static func legacy_district_at_xz(xz: Vector2, districts: Dictionary) -> String:
	for dname: String in districts:
		if (districts[dname] as Rect2).has_point(xz):
			return dname
	return ""


## Region classification (P02 §10 skeleton).
static func region_of_xz(xz: Vector2) -> String:
	var dist: String = district_at_xz(xz)
	var r: float = WorldContract.dist_to_center_xz(xz)
	var t: String = district_type_of(dist)
	if t == "airport" or t == "military":
		return REGION_SPECIAL
	if r >= 2400.0:
		return REGION_COASTAL
	if t == "mountain_wild" or t == "affluent_hills":
		return REGION_HILLS
	if t == "port_industrial" or t == "heavy_industrial":
		return REGION_INDUSTRIAL
	if t == "farmland" or t == "rural_dry" or t == "park_water":
		return REGION_RURAL
	if r < 900.0:
		return REGION_CORE
	return REGION_INNER


## --- records ---

static func micro_record(s: Vector2i) -> Dictionary:
	if _micro_cache.has(s):
		return _micro_cache[s]
	var center: Vector2 = WorldContract.micro_sector_to_world(s)
	var valid: bool = WorldContract.micro_sector_is_valid(s)
	var dist: String = district_at_xz(center)
	var dtype: String = district_type_of(dist)
	var rec: Dictionary = {
		"id": WorldContract.micro_id(s),
		"macro_id": WorldContract.macro_id(WorldContract.macro_of_micro(s)),
		"grid_x": s.x,
		"grid_z": s.y,
		"center_x": center.x,
		"center_z": center.y,
		"bounds": {"x": center.x - WorldContract.MICRO_SECTOR_M * 0.5,
				"z": center.y - WorldContract.MICRO_SECTOR_M * 0.5,
				"w": WorldContract.MICRO_SECTOR_M, "h": WorldContract.MICRO_SECTOR_M},
		"circle_intersection": valid,
		"region_id": region_of_xz(center) if valid else "",
		"district_id": dist if valid else "",
		"biome_id": TERRAIN_BY_TYPE.get(dtype, "plains") if valid else "ocean",
		"density_class": DENSITY_BY_TYPE.get(dtype, "low") if valid else "none",
		"road_class": "urban_grid" if region_of_xz(center) in [REGION_CORE, REGION_INNER] \
				else ("rural" if valid else "none"),
		"terrain_class": TERRAIN_BY_TYPE.get(dtype, "plains") if valid else "ocean",
		"population_class": DENSITY_BY_TYPE.get(dtype, "low") if valid else "none",
		"traffic_class": DENSITY_BY_TYPE.get(dtype, "low") if valid else "none",
		"stream_state": "UNLOADED",
		"generation_seed": WorldContract.micro_seed(s),
		"revision": WorldContract.WORLD_REVISION,
		"version": RECORD_VERSION,
	}
	_micro_cache[s] = rec
	return rec


static func macro_record(m: Vector2i) -> Dictionary:
	if _macro_cache.has(m):
		return _macro_cache[m]
	var center: Vector2 = WorldContract.sector_to_world(m)
	var valid: bool = WorldContract.sector_is_valid(m)
	var rec: Dictionary = {
		"id": WorldContract.macro_id(m),
		"grid_x": m.x,
		"grid_z": m.y,
		"center_x": center.x,
		"center_z": center.y,
		"bounds": {"x": center.x - WorldContract.SECTOR_M * 0.5,
				"z": center.y - WorldContract.SECTOR_M * 0.5,
				"w": WorldContract.SECTOR_M, "h": WorldContract.SECTOR_M},
		"circle_intersection": valid,
		"region_id": region_of_xz(center) if valid else "",
		"district_id": district_at_xz(center) if valid else "",
		"generation_seed": WorldContract.macro_seed(m),
		"revision": WorldContract.WORLD_REVISION,
		"version": RECORD_VERSION,
	}
	_macro_cache[m] = rec
	return rec


static func valid_micro_ids() -> Array:
	if not _ids_ready:
		_ids_cache = WorldContract.micro_sector_ids()
		_ids_ready = true
	return _ids_cache


## Counts for metrics logging (P02 §26).
static func counts() -> Dictionary:
	return {
		"macro_valid": WorldContract.sector_count(),
		"micro_valid": valid_micro_ids().size(),
		"macro_grid": "%dx%d" % [WorldContract.MACRO_GRID_SPAN, WorldContract.MACRO_GRID_SPAN],
		"micro_grid": "%dx%d" % [WorldContract.MICRO_GRID_SPAN, WorldContract.MICRO_GRID_SPAN],
	}


## --- P03 terrain metadata delegation (§32: registry owns metadata,
## WorldTerrain owns the continuous field; no terrain math lives here) ---

static func district_table() -> Array:
	_ensure_districts()
	return _districts


static func terrain_class_at(xz: Vector2) -> String:
	return WorldTerrain.surface_class_at(xz.x, xz.y)


static func terrain_profile_for_sector(s: Vector2i) -> Dictionary:
	var c: Vector2 = WorldContract.micro_sector_to_world(s)
	var rec: Dictionary = micro_record(s)
	return {
		"sector_id": rec["id"],
		"terrain_class": WorldTerrain.surface_class_at(c.x, c.y),
		"elevation_m": WorldTerrain.height_at(c.x, c.y),
		"grade_pct": WorldTerrain.grade_percent(c.x, c.y),
		"elevation_band": WorldTerrain.elevation_band_at(c.x, c.y),
	}


static func water_state_for_sector(s: Vector2i) -> String:
	var c: Vector2 = WorldContract.micro_sector_to_world(s)
	var h: float = WorldTerrain.height_at(c.x, c.y)
	if h < TerrainAuthoring.SEA_LEVEL_M - 0.05:
		return "water"
	if h < TerrainAuthoring.SEA_LEVEL_M + 3.0:
		return "coastal"
	return "dry"


static func dominant_slope_class(s: Vector2i) -> String:
	var c: Vector2 = WorldContract.micro_sector_to_world(s)
	var g: float = WorldTerrain.grade_percent(c.x, c.y)
	if g < 3.0: return "flat"
	if g < 8.0: return "gentle"
	if g < 20.0: return "moderate"
	if g < 45.0: return "steep"
	return "extreme"


static func elevation_band(s: Vector2i) -> String:
	var c: Vector2 = WorldContract.micro_sector_to_world(s)
	return WorldTerrain.elevation_band_at(c.x, c.y)


## Test hook: drop caches (records are pure derivations; safe to rebuild).
static func invalidate() -> void:
	_micro_cache.clear()
	_macro_cache.clear()
	_ids_cache = []
	_ids_ready = false
	_districts = []
	_districts_loaded = false


## Self-check for tests (P02 §24 sector gates ride on this too).
static func validate() -> Dictionary:
	var c: Dictionary = counts()
	var ids: Array = valid_micro_ids()
	var containment_ok := true
	var center_ok := true
	for sid_v: Variant in ids:
		var s: Vector2i = sid_v
		var rec: Dictionary = micro_record(s)
		var m: Vector2i = WorldContract.macro_of_micro(s)
		# containment invariant: the macro CELL bounds must contain the micro
		# center (edge macros legitimately intersect the circle even when their
		# center falls outside it — center-validity is a streaming budget rule,
		# not a containment rule)
		var mb: Rect2 = Rect2(Vector2(float(m.x), float(m.y)) * WorldContract.SECTOR_M,
				Vector2(WorldContract.SECTOR_M, WorldContract.SECTOR_M))
		var ctr := Vector2(rec["center_x"], rec["center_z"])
		if str(rec["macro_id"]) != WorldContract.macro_id(m) or not mb.has_point(ctr):
			containment_ok = false
		if WorldContract.micro_sector_of(ctr) != s:
			center_ok = false
	var district_ok: bool = district_at_xz(Vector2(-800.0, 800.0)) != ""  # SW urban
	var seed_ok: bool = WorldContract.micro_seed(Vector2i(3, 4)) \
			== WorldContract.micro_seed(Vector2i(3, 4)) \
			and WorldContract.micro_seed(Vector2i(3, 4)) \
			!= WorldContract.micro_seed(Vector2i(4, 3))
	return {
		"ok": containment_ok and center_ok and district_ok and seed_ok \
				and int(c["macro_valid"]) > 0 and int(c["micro_valid"]) > 0,
		"macro_containment_ok": containment_ok,
		"micro_center_ok": center_ok,
		"district_lookup_ok": district_ok,
		"seed_determinism_ok": seed_ok,
		"counts": c,
	}
