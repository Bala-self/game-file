extends Control
## Main menu: title screen with New Game / Continue / Settings / Quit.

var settings_panel: Control
var buttons: VBoxContainer


func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	# Sky gradient background
	var bg: TextureRect = TextureRect.new()
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	var grad: Gradient = Gradient.new()
	grad.colors = PackedColorArray([Color(0.05, 0.09, 0.2), Color(0.35, 0.22, 0.3), Color(0.95, 0.55, 0.25)])
	grad.offsets = PackedFloat32Array([0.0, 0.65, 1.0])
	var gt: GradientTexture2D = GradientTexture2D.new()
	gt.gradient = grad
	gt.fill_from = Vector2(0, 0)
	gt.fill_to = Vector2(0, 1)
	bg.texture = gt
	bg.stretch_mode = TextureRect.STRETCH_SCALE
	add_child(bg)

	# Sea horizon band
	var sea: ColorRect = ColorRect.new()
	sea.color = Color(0.1, 0.3, 0.42)
	sea.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	sea.anchor_top = 0.72
	add_child(sea)

	var box: VBoxContainer = VBoxContainer.new()
	box.set_anchors_preset(Control.PRESET_CENTER)
	box.position -= Vector2(170, 220)
	box.custom_minimum_size = Vector2(340, 0)
	box.add_theme_constant_override("separation", 12)
	add_child(box)

	var title: Label = Label.new()
	title.text = "ISLAND STRIKE"
	title.add_theme_font_size_override("font_size", 62)
	title.add_theme_color_override("font_color", Color(1, 0.95, 0.85))
	title.add_theme_color_override("font_outline_color", Color(0.1, 0.1, 0.2))
	title.add_theme_constant_override("outline_size", 12)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(title)

	var subtitle: Label = Label.new()
	subtitle.text = "An open-world island sandbox"
	subtitle.add_theme_font_size_override("font_size", 18)
	subtitle.add_theme_color_override("font_color", Color(0.9, 0.85, 0.8))
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(subtitle)

	var spacer: Control = Control.new()
	spacer.custom_minimum_size = Vector2(0, 26)
	box.add_child(spacer)

	buttons = VBoxContainer.new()
	buttons.add_theme_constant_override("separation", 10)
	box.add_child(buttons)

	_btn("New Game", _new_game)
	var cont = _btn("Continue", _continue)
	cont.disabled = not SaveSystem.has_save()
	_btn("Settings", _open_settings)
	_btn("Quit", func() -> void: get_tree().quit())

	var version: Label = Label.new()
	version.text = "v1.0  -  built with Godot 4"
	version.add_theme_font_size_override("font_size", 14)
	version.add_theme_color_override("font_color", Color(1, 1, 1, 0.6))
	version.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	version.position = Vector2(-170, -30)
	add_child(version)

	settings_panel = load("res://scripts/ui/settings_panel.gd").create(_close_settings)
	settings_panel.visible = false
	settings_panel.set_anchors_preset(Control.PRESET_CENTER)
	add_child(settings_panel)

	(cont as Button).grab_focus()


func _btn(text: String, action: Callable) -> Button:
	var b: Button = Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 46)
	b.pressed.connect(func() -> void:
		_click()
		action.call())
	buttons.add_child(b)
	return b


func _click() -> void:
	var snd = AudioStreamPlayer.new()
	snd.stream = load("res://assets/audio/click.wav")
	snd.volume_db = -8.0
	add_child(snd)
	snd.play()
	var t = get_tree().create_timer(0.25)
	t.timeout.connect(snd.queue_free)


func _new_game() -> void:
	GameState.money = 500
	GameState.set_wanted(0)
	GameState.day_time = 9.0
	GameState.set_raining(false)
	GameState.collected.clear()
	GameState.stats = {"kills": 0, "cars_entered": 0, "distance_m": 0.0, "race_best": 0.0}
	GameState.pending_load = false
	get_tree().change_scene_to_file("res://scenes/game/game.tscn")


func _continue() -> void:
	GameState.pending_load = true
	get_tree().change_scene_to_file("res://scenes/game/game.tscn")


func _open_settings() -> void:
	buttons.visible = false
	settings_panel.visible = true


func _close_settings() -> void:
	GameState.save_settings()
	settings_panel.visible = false
	buttons.visible = true


func _unhandled_input(event: InputEvent) -> void:
	if settings_panel and settings_panel.visible and event.is_action_pressed("ui_cancel"):
		_close_settings()
