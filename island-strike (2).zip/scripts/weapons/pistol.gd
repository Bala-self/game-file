extends Node3D
## ISLAND STRIKE — Advanced Weapon System v2.1
## 6-weapon data-driven framework + GTA-style switch state machine
## Roles: Viper-9 compact pistol (fast accurate), Raven-45 heavy pistol (slow powerful),
##        SMG, Kestrel-556 rifle (balanced), Shotgun classic, Mammoth-12 tactical shotgun (close)
## Implements: WeaponManager, WeaponInventory, WeaponSwitcher, Fire/Recoil/Reload/Anim/Audio/VFX

## Weapon Data — data-driven, not hardcoded logic (Section 7) — single source WeaponData
const WEAPONS := WeaponData.WEAPONS
const RANGE := 180.0

# Weapon State Machine (Section 13)
enum State { HOLSTERED, EQUIP, READY, AIM, FIRE, RECOVER, RELOAD, LOWER, UNEQUIP, SWITCH, RAISE }
var state: int = State.READY
var weapon_id: String = "pistol"
var ammo: Dictionary = {
	"pistol": [12, 72], "viper9": [15, 90], "raven45": [8, 48], "smg": [30, 90],
	"kestrel556": [30, 120], "shotgun": [6, 24], "mammoth12": [8, 32]
}
var owned_weapons: Dictionary = {"pistol": true}
var in_hand: bool = false
var vis_raise: float = 0.0
var cooldown: float = 0.0
var reloading: bool = false
var _fire_prev: bool = false
var player: CharacterBody3D
var muzzle: Node3D
var audio: AudioStreamPlayer3D

# Advanced Switch System (Section 8-17)
var switch_timer: float = 0.0
var switch_target_id: String = ""
var last_weapon_id: String = "pistol"
var weapon_wheel_active: bool = false
var switch_lock: float = 0.0  # prevents shooting during transition
var recoil_accum: float = 0.0
var crosshair_expand: float = 0.0
# Round 12 Phase 03: bloom heat — per-shot spread growth with data-driven decay
var bloom_accum: float = 0.0
var _sec_tap_t: float = 0.0  # double-tap window for quick swap (Phase 04)

static func create(owner_player: CharacterBody3D) -> Node3D:
	var w: Node3D = Node3D.new()
	w.name = "WeaponSystem"
	w.set_script(load("res://scripts/weapons/pistol.gd"))
	w.set("player", owner_player)
	return w

func _cfg() -> Dictionary:
	return WEAPONS.get(weapon_id, WEAPONS["pistol"])

func mag_size() -> int:
	return int(_cfg()["mag"])

func mag() -> int:
	return ammo.get(weapon_id, [0,0])[0]

func reserve() -> int:
	return ammo.get(weapon_id, [0,0])[1]

func weapon_name() -> String:
	return str(_cfg()["name"])

func _ready() -> void:
	# Visual — distinct per category (fictional, game-original, mechanically believable)
	var body: MeshInstance3D = MeshInstance3D.new()
	var bm: BoxMesh = BoxMesh.new()
	var cfg: Dictionary = _cfg()
	var cat: String = str(cfg["category"])
	match cat:
		"pistol":
			bm.size = Vector3(0.08, 0.12, 0.32) if weapon_id == "pistol" else Vector3(0.09, 0.14, 0.36)
		"smg":
			bm.size = Vector3(0.09, 0.15, 0.42)
		"rifle":
			bm.size = Vector3(0.10, 0.16, 0.68)
		"shotgun":
			bm.size = Vector3(0.12, 0.18, 0.72) if weapon_id == "mammoth12" else Vector3(0.11, 0.16, 0.62)
		_:
			bm.size = Vector3(0.08, 0.14, 0.34)
	var mat: StandardMaterial3D = StandardMaterial3D.new()
	match weapon_id:
		"pistol": mat.albedo_color = Color(0.11, 0.11, 0.12) # Classic pistol
		"viper9": mat.albedo_color = Color(0.12, 0.12, 0.13) # Viper-9 polymer
		"raven45": mat.albedo_color = Color(0.18, 0.16, 0.15) # Raven heavier metal+polymer
		"smg": mat.albedo_color = Color(0.15, 0.15, 0.16)
		"kestrel556": mat.albedo_color = Color(0.22, 0.22, 0.20) # Kestrel receiver+handguard
		"shotgun": mat.albedo_color = Color(0.20, 0.18, 0.16)
		"mammoth12": mat.albedo_color = Color(0.25, 0.23, 0.20) # Mammoth larger/heavier
		_: mat.albedo_color = Color(0.15, 0.15, 0.16)
	mat.metallic = 0.3
	mat.roughness = 0.7
	bm.material = mat
	body.mesh = bm
	body.position = Vector3(0, -0.02, -0.09) if in_hand else Vector3(0.34, 1.25, -0.35)
	body.name = "Body"
	add_child(body)

	muzzle = Node3D.new()
	muzzle.position = Vector3(0, 0.03, -0.30) if in_hand else Vector3(0.34, 1.32, -0.55)
	muzzle.name = "Muzzle"
	add_child(muzzle)

	audio = AudioStreamPlayer3D.new()
	audio.stream = load("res://assets/audio/shoot.wav")
	audio.volume_db = -2.0
	audio.max_distance = 120.0
	add_child(audio)

	GameState.ammo_changed.emit(mag(), reserve())
	GameState.weapon_changed.emit(weapon_name())

# Weapon Wheel + Fast Switch + State Machine
func _process(delta: float) -> void:
	cooldown -= delta
	vis_raise = maxf(0.0, vis_raise - delta)
	recoil_accum = maxf(0.0, recoil_accum - delta * 3.5)
	crosshair_expand = maxf(0.0, crosshair_expand - delta * 4.0)
	bloom_accum = maxf(0.0, bloom_accum - delta * float(_cfg().get("bloom_decay", 0.03)))
	switch_lock = maxf(0.0, switch_lock - delta)
	_sec_tap_t = maxf(0.0, _sec_tap_t - delta)

	# Switch state machine timing (Section 11 Quick Switch: 0.00 input → 0.05 lowering → 0.15 hidden → 0.20 selected → 0.30 appears → 0.40 ready)
	if state in [State.LOWER, State.UNEQUIP, State.EQUIP, State.SWITCH]:
		switch_timer -= delta
		if switch_timer <= 0.0:
			_advance_switch_state()

	if reloading and state != State.RELOAD:
		state = State.RELOAD

	if player == null or player.driving_car != null or not player.input_enabled or player.health <= 0:
		_fire_prev = false
		if weapon_wheel_active:
			_close_weapon_wheel()
		return

	_handle_weapon_wheel_input()
	_handle_fast_switch_input()
	_handle_fire_input(delta)

func _handle_weapon_wheel_input() -> void:
	# Hold LB/L1 → weapon wheel (time slows to 0.3x)
	var wheel_held: bool = Input.is_action_pressed("weapon_wheel")
	if wheel_held and not weapon_wheel_active and state == State.READY:
		_open_weapon_wheel()
	elif not wheel_held and weapon_wheel_active:
		_close_weapon_wheel()
		# Select based on right stick direction (if moved)
		var rs: Vector2 = Input.get_vector("look_left", "look_right", "look_up", "look_down")
		if rs.length() > 0.5:
			_select_by_direction(rs)

func _open_weapon_wheel() -> void:
	weapon_wheel_active = true
	Engine.time_scale = 0.3
	GameState.notify("Weapon Wheel: Use Right Stick to select, release LB to equip")
	# In real UI, show wheel HUD — for now notify

func _close_weapon_wheel() -> void:
	weapon_wheel_active = false
	Engine.time_scale = 1.0

func _select_by_direction(dir: Vector2) -> void:
	# Map stick direction to weapon categories (GTA style)
	# Up = rifle, Down = pistol, Left = shotgun, Right = smg/heavy
	var angle: float = dir.angle()
	var ids: Array = _owned_ids()
	if ids.is_empty():
		return
	# Simple: angle sectors
	var sector: int = int(round(angle / (PI/2)))
	sector = wrapi(sector, 0, ids.size())
	var target: String = ids[sector % ids.size()]
	_request_switch(target)

func _handle_fast_switch_input() -> void:
	if state != State.READY:
		return
	if Input.is_action_just_pressed("fast_next") or Input.is_action_just_pressed("next_weapon"):
		cycle_weapon(1)
	elif Input.is_action_just_pressed("fast_prev") or Input.is_action_just_pressed("prev_weapon"):
		cycle_weapon(-1)
	elif Input.is_action_just_pressed("primary_weapon"):
		# Primary = rifle if owned, else first owned
		if owned_weapons.get("kestrel556", false):
			_request_switch("kestrel556")
		elif owned_weapons.get("smg", false):
			_request_switch("smg")
	elif Input.is_action_just_pressed("secondary_weapon"):
		# Phase 04 quick swap: second tap within the window toggles to the
		# previously equipped weapon (fast-hands deploy).
		if _sec_tap_t > 0.0:
			_sec_tap_t = 0.0
			quick_swap()
			return
		_sec_tap_t = 0.25
		# Secondary = pistol
		if owned_weapons.get("pistol", false):
			_request_switch("pistol")
		elif owned_weapons.get("raven45", false):
			_request_switch("raven45")


func _handle_fire_input(delta: float) -> void:
	if state != State.READY and state != State.AIM:
		return
	if switch_lock > 0.0:
		return
	var fire_pressed: bool = Input.is_action_pressed("fire")
	var trigger: bool = fire_pressed if bool(_cfg()["auto"]) else (fire_pressed and not _fire_prev)
	if trigger and cooldown <= 0.0:
		if mag() <= 0:
			_start_reload()
		else:
			_fire()
	_fire_prev = fire_pressed
	if Input.is_action_just_pressed("reload") and mag() < mag_size() and reserve() > 0:
		_start_reload()

func _owned_ids() -> Array:
	var out: Array = []
	for id: String in WEAPONS.keys():
		if owned_weapons.get(id, false):
			out.append(id)
	return out

# Advanced Switch System (Section 8-17)
func cycle_weapon(dir := 1) -> void:
	if state != State.READY:
		return
	if reloading:
		# Can reload cancel? Yes for pistol/smg, No for shotgun/rifle (Section 14)
		var can_cancel: bool = weapon_id in ["pistol", "viper9", "raven45", "smg"]
		if not can_cancel:
			GameState.notify("Finish reload first")
			return
		_cancel_reload()
	var ids: Array = _owned_ids()
	if ids.size() <= 1:
		GameState.notify("No other weapons owned — visit gun shop")
		return
	var i: int = ids.find(weapon_id)
	for step in range(1, ids.size() + 1):
		var cand: String = ids[wrapi(i + dir * step, 0, ids.size())]
		if owned_weapons.get(cand, false):
			_request_switch(cand)
			return

func _request_switch(target_id: String) -> void:
	if target_id == weapon_id or target_id == "":
		return
	if not owned_weapons.get(target_id, false):
		return
	if state != State.READY:
		return
	# Smart switching: check can_switch (Section 8)
	if not _can_switch():
		return
	last_weapon_id = weapon_id
	switch_target_id = target_id
	state = State.LOWER
	switch_timer = 0.05  # 0.05s lowering begins
	# Phase 02: data-driven deploy — 0.40 s at deploy_mult 1.0 (contract),
	# scaled per weapon (viper 0.34 s fast hands, mammoth 0.50 s heavy)
	switch_lock = 0.40 * float(WeaponData.get_cfg(target_id).get("deploy_mult", 1.0))
	# Exit aim if aiming (Section 16)
	if player and player.aiming:
		player.aiming = false
	GameState.notify("Switching to %s..." % WEAPONS[target_id]["name"])
	# Lower animation
	vis_raise = 0.0

## Phase 04: quick swap to the previous weapon at 0.8x deploy cost.
func quick_swap() -> void:
	if state != State.READY or reloading:
		return
	var target: String = last_weapon_id
	if target == weapon_id or not owned_weapons.get(target, false):
		return
	_request_switch(target)
	switch_lock = 0.40 * 0.8 * float(WeaponData.get_cfg(target).get("deploy_mult", 1.0))
	GameState.notify("Quick swap: %s" % str(WeaponData.get_cfg(target)["name"]))


func _advance_switch_state() -> void:
	match state:
		State.LOWER:
			state = State.UNEQUIP
			switch_timer = 0.10  # 0.05→0.15 hidden
			visible = false
		State.UNEQUIP:
			# Unequip current, select new
			weapon_id = switch_target_id
			_update_visual()
			state = State.EQUIP
			switch_timer = 0.10  # 0.15→0.25? Actually 0.20 selected, 0.30 appears
		State.EQUIP:
			state = State.RAISE if true else State.READY
			switch_timer = maxf(0.05, 0.15 * float(WeaponData.get_cfg(weapon_id).get("deploy_mult", 1.0)))
			visible = true
		State.RAISE:
			state = State.READY
			switch_timer = 0.0
			switch_target_id = ""
			switch_lock = 0.0
			GameState.weapon_changed.emit(weapon_name())
			emit_ammo()
			GameState.notify("Equipped: " + weapon_name())
			_fire_prev = true  # require re-press after switch (prevent exploit)
		State.SWITCH:
			state = State.READY

func _can_switch() -> bool:
	# Check if switching allowed (not during certain actions)
	if reloading and weapon_id in ["shotgun", "mammoth12", "kestrel556"]:
		return false  # heavy weapons must finish reload
	if player and player.has_method("is_sprinting"):
		# Allow switch while sprinting (Section 15) — continue sprint, raise when appropriate
		return true
	return true

func _cancel_reload() -> void:
	reloading = false
	state = State.READY

func _update_visual() -> void:
	var body: MeshInstance3D = get_node_or_null("Body") as MeshInstance3D
	if body == null:
		return
	var cfg: Dictionary = _cfg()
	var cat: String = str(cfg["category"])
	var bm: BoxMesh = body.mesh as BoxMesh
	if bm == null:
		return
	match cat:
		"pistol":
			bm.size = Vector3(0.08, 0.12, 0.32) if weapon_id == "pistol" else Vector3(0.09, 0.14, 0.36)
		"smg":
			bm.size = Vector3(0.09, 0.15, 0.42)
		"rifle":
			bm.size = Vector3(0.10, 0.16, 0.68)
		"shotgun":
			bm.size = Vector3(0.12, 0.18, 0.72) if weapon_id == "mammoth12" else Vector3(0.11, 0.16, 0.62)
	var mat: StandardMaterial3D = bm.material as StandardMaterial3D
	if mat:
		match weapon_id:
			"pistol": mat.albedo_color = Color(0.11, 0.11, 0.12)
			"viper9": mat.albedo_color = Color(0.12, 0.12, 0.13)
			"raven45": mat.albedo_color = Color(0.18, 0.16, 0.15)
			"smg": mat.albedo_color = Color(0.15, 0.15, 0.16)
			"kestrel556": mat.albedo_color = Color(0.22, 0.22, 0.20)
			"shotgun": mat.albedo_color = Color(0.20, 0.18, 0.16)
			"mammoth12": mat.albedo_color = Color(0.25, 0.23, 0.20)
			_: mat.albedo_color = Color(0.15, 0.15, 0.16)

func next_unowned() -> String:
	for id: String in WEAPONS.keys():
		if not owned_weapons.get(id, false):
			return id
	return ""

func buy_next_weapon() -> bool:
	var id: String = next_unowned()
	if id == "":
		GameState.notify("You own every weapon")
		return false
	var price: int = int(WEAPONS[id]["price"])
	if not GameState.try_spend(price):
		GameState.notify("Not enough cash for %s ($%d)" % [WEAPONS[id]["name"], price])
		return false
	# Round 14 STAGE 01: purchase recorded on the event bus ledger
	var bus: Node = get_tree().root.get_node_or_null("EventBus")
	if bus != null:
		bus.record("ITEM_PURCHASED", {"item": id, "price": price,
				"balance": GameState.money})
	owned_weapons[id] = true
	# Init ammo if new
	if not ammo.has(id):
		ammo[id] = [int(WEAPONS[id]["mag"]), int(WEAPONS[id]["reserve_max"])]
	GameState.notify("%s purchased (-$%d)" % [WEAPONS[id]["name"], price])
	return true

# Fire System with Recoil Layers (Section 18) + Accuracy System (Section 19)
func _fire() -> void:
	if switch_lock > 0.0:
		return
	ammo[weapon_id][0] -= 1
	var cfg: Dictionary = _cfg()
	cooldown = float(cfg["cooldown"])
	vis_raise = 0.35
	recoil_accum += float(cfg["recoil"])
	crosshair_expand += float(cfg["recoil"]) * 2.0
	# Phase 03 bloom heat: per-shot growth, capped at 5 shots' worth
	bloom_accum = minf(bloom_accum + float(cfg.get("bloom_per_shot", 0.006)),
			float(cfg.get("bloom_per_shot", 0.006)) * 5.0)
	GameState.ammo_changed.emit(mag(), reserve())

	var cam: Camera3D = get_viewport().get_camera_3d()
	if cam == null:
		return
	var origin: Vector3 = cam.global_position
	var dir: Vector3 = -cam.global_basis.z

	# Accuracy System (Section 19): Base + Stance + Movement + Aim + Recoil Recovery + Condition
	var base_acc: float = float(cfg["accuracy"])
	var stance_mod: float = 1.0
	if player:
		if player.has_method("is_crouching") and player.crouching:
			stance_mod = 1.15  # crouching more accurate
		elif player.has_method("is_sprinting") and player.velocity.length() > 5.0:
			stance_mod = 0.7  # sprinting less accurate
	var move_mod: float = 1.0
	if player:
		var spd: float = Vector2(player.velocity.x, player.velocity.z).length()
		if spd > 4.0:
			move_mod = 0.8
		elif spd < 0.5:
			move_mod = 1.1
	var aim_mod: float = 1.8 if player and player.aiming else 1.0
	var recoil_mod: float = clampf(1.0 - recoil_accum * 0.5, 0.6, 1.0)
	var final_acc: float = base_acc * stance_mod * move_mod * aim_mod * recoil_mod

	# Spread based on accuracy
	var spread: float = float(cfg["spread_aim"] if player and player.aiming else cfg["spread_hip"])
	spread *= (2.0 - final_acc)  # lower accuracy = more spread
	spread += recoil_accum * 0.02
	spread += bloom_accum  # sustained fire blooms the cone

	dir = (dir + Vector3(randf() - 0.5, randf() - 0.5, randf() - 0.5) * spread).normalized()

	var to: Vector3 = origin + dir * float(cfg["range"])
	var q: PhysicsRayQueryParameters3D = PhysicsRayQueryParameters3D.create(origin, to, 1 | 4 | 8)
	q.exclude = [player.get_rid()]
	var hit: Dictionary = player.get_world_3d().direct_space_state.intersect_ray(q)

	var end: Vector3 = to
	if hit:
		end = hit["position"]
		var collider: Object = hit["collider"]
		if collider != null and collider.has_method("take_damage"):
			var dist: float = origin.distance_to(end)
			# Phase 02: data-driven smoothstep falloff (per-weapon start/end/floor)
			var falloff: float = WeaponData.falloff_mult(cfg, dist)
			var dmg: int = int(int(cfg["damage"]) * falloff)
			if weapon_id == "mammoth12":
				# 8 pellets, each ~10 dmg close, total 80, but we do single ray for simplicity with high dmg
				dmg = int(dmg * 1.2)
			collider.take_damage(dmg, player.global_position, player)

	_spawn_tracer(muzzle.global_position, end, cfg)
	_spawn_flash(cfg)
	_spawn_smoke(cfg)
	_play_fire_sound(cfg)
	_apply_recoil(cfg)

	GameState.vibrate(0.3, 0.5, 0.08)
	GameState.commit_crime(0, player.global_position)

func _apply_recoil(cfg: Dictionary) -> void:
	# Recoil System — multiple layers (Section 18): Camera kick + Weapon kick + Player anim + Crosshair + Sound + Muzzle
	var recoil: float = float(cfg["recoil"])
	# Camera kick
	if player:
		player.pitch = clampf(player.pitch + recoil, -1.1, 1.25)
		# Weapon kick handled via vis_raise + body position
	# Different recoil curves per weapon (Section 18)
	match weapon_id:
		"pistol": # Classic pistol: ↑────↓
			recoil_accum += recoil * 0.8
		"viper9": # Viper-9: ↑────↓ fast recovery
			recoil_accum += recoil * 0.8
		"raven45": # Raven: ↑↑ higher kick + slower recovery
			recoil_accum += recoil * 1.5
		"smg": # SMG: ↑↑↗↑↗ random horizontal
			recoil_accum += recoil * 1.0
			if player:
				player.yaw += randf_range(-0.01, 0.01)
		"kestrel556": # Rifle: ↑↑↗↑↗ climb
			recoil_accum += recoil * 1.2
			if player:
				player.yaw += randf_range(-0.015, 0.015)
		"shotgun", "mammoth12": # Shotgun: ↑↑─────↓ heavy then drop
			recoil_accum += recoil * 2.0

func _spawn_tracer(from: Vector3, to: Vector3, cfg: Dictionary) -> void:
	var dist: float = from.distance_to(to)
	if dist < 0.5:
		return
	var tracer: MeshInstance3D = MeshInstance3D.new()
	var mesh: CylinderMesh = CylinderMesh.new()
	mesh.top_radius = 0.012 if cfg["category"] != "shotgun" else 0.02
	mesh.bottom_radius = 0.012 if cfg["category"] != "shotgun" else 0.02
	mesh.height = dist
	var m: StandardMaterial3D = StandardMaterial3D.new()
	m.albedo_color = Color(1.0, 0.9, 0.4) if weapon_id != "mammoth12" else Color(1.0, 0.7, 0.3)
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mesh.material = m
	tracer.mesh = mesh
	get_tree().current_scene.add_child(tracer)
	tracer.global_position = (from + to) * 0.5
	tracer.look_at(to)
	tracer.rotate_object_local(Vector3(1, 0, 0), PI / 2)
	var tw: Tween = tracer.create_tween()
	tw.tween_property(tracer, "transparency", 1.0, 0.09 if cfg["category"] != "shotgun" else 0.12)
	tw.tween_callback(tracer.queue_free)

func _spawn_flash(cfg: Dictionary) -> void:
	var flash: OmniLight3D = OmniLight3D.new()
	flash.light_color = Color(1.0, 0.8, 0.4) if weapon_id != "raven45" else Color(1.0, 0.6, 0.3)
	flash.omni_range = 7.0 if cfg["category"] == "pistol" else 9.0 if cfg["category"] == "rifle" else 11.0
	flash.light_energy = 3.5 if cfg["category"] != "shotgun" else 5.5
	flash.position = muzzle.global_position
	get_tree().current_scene.add_child(flash)
	var tw: Tween = flash.create_tween()
	tw.tween_property(flash, "light_energy", 0.0, 0.06 if cfg["category"] != "shotgun" else 0.1)
	tw.tween_callback(flash.queue_free)

func _spawn_smoke(cfg: Dictionary) -> void:
	# Muzzle smoke — short and controlled (Section 21)
	var smoke: GPUParticles3D = GPUParticles3D.new()
	smoke.amount = 6 if cfg["category"] == "pistol" else 12
	smoke.lifetime = 0.3
	smoke.emitting = true
	smoke.position = muzzle.global_position
	var pmat: ParticleProcessMaterial = ParticleProcessMaterial.new()
	pmat.direction = Vector3(0, 0, -1)
	pmat.spread = 15.0
	pmat.initial_velocity_min = 0.5
	pmat.initial_velocity_max = 1.5
	pmat.gravity = Vector3(0, 0.5, 0)
	smoke.process_material = pmat
	get_tree().current_scene.add_child(smoke)
	var t: SceneTreeTimer = get_tree().create_timer(0.5)
	t.timeout.connect(smoke.queue_free)

func _play_fire_sound(cfg: Dictionary) -> void:
	# Sound Design — multiple sounds per weapon (Section 20)
	# Fire + Mechanical action + Magazine + Reload + Equip + Unequip + Empty click + Impact
	# For now fire sound with pitch variation per weapon
	var base_pitch: float = 1.0
	match weapon_id:
		"pistol": base_pitch = 1.05  # Classic
		"viper9": base_pitch = 1.1  # Viper-9 fast high
		"raven45": base_pitch = 0.85  # Raven heavy low
		"smg": base_pitch = 1.2
		"kestrel556": base_pitch = 0.95
		"shotgun": base_pitch = 0.8
		"mammoth12": base_pitch = 0.7  # Mammoth heavy low
		_: base_pitch = 1.0
	audio.pitch_scale = base_pitch + randf_range(-0.08, 0.08)
	audio.play()

func _start_reload() -> void:
	if reserve() <= 0:
		GameState.notify("Out of %s ammo — downed police drop ammo" % weapon_name())
		# Empty click sound
		var click: AudioStreamPlayer = AudioStreamPlayer.new()
		click.stream = load("res://assets/audio/click.wav")
		add_child(click)
		click.play()
		var t: SceneTreeTimer = get_tree().create_timer(0.5)
		t.timeout.connect(click.queue_free)
		return
	if state == State.RELOAD:
		return
	reloading = true
	state = State.RELOAD
	var snd: AudioStreamPlayer = AudioStreamPlayer.new()
	snd.stream = load("res://assets/audio/reload.wav")
	add_child(snd)
	snd.play()
	var rt: float = float(_cfg()["reload_time"])
	# Tactical vs empty reload (Section 17)
	var is_empty: bool = mag() == 0
	if is_empty:
		rt += 0.3  # empty reload slower
	var t: SceneTreeTimer = get_tree().create_timer(rt)
	t.timeout.connect(func() -> void:
		var need: int = mag_size() - mag()
		var take: int = mini(need, reserve())
		ammo[weapon_id][0] += take
		ammo[weapon_id][1] -= take
		reloading = false
		state = State.READY
		emit_ammo()
		snd.queue_free()
		GameState.notify("%s reloaded" % weapon_name())
	)

func add_ammo(n: int) -> void:
	ammo[weapon_id][1] += n
	emit_ammo()

func emit_ammo() -> void:
	GameState.ammo_changed.emit(mag(), reserve())

# Smart Switching (Section 12)
func smart_select_for_distance(dist: float) -> String:
	# Enemy far → rifle, close → shotgun, no ammo → next available
	if dist > 80.0 and owned_weapons.get("kestrel556", false) and ammo["kestrel556"][0] > 0:
		return "kestrel556"
	elif dist < 15.0 and owned_weapons.get("mammoth12", false) and ammo["mammoth12"][0] > 0:
		return "mammoth12"
	elif dist < 15.0 and owned_weapons.get("shotgun", false) and ammo["shotgun"][0] > 0:
		return "shotgun"
	elif owned_weapons.get("pistol", false) and ammo["pistol"][0] > 0:
		return "pistol"
	else:
		for id: String in WEAPONS.keys():
			if owned_weapons.get(id, false) and ammo.get(id, [0,0])[0] > 0:
				return id
		return weapon_id