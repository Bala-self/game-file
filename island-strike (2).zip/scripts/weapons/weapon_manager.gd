class_name WeaponManager
extends Object
## WeaponManager — orchestrates Data + Inventory + Controller + Save/Load
## Dependency map:
## Weapon
##  ├── Player
##  ├── Input (via controller)
##  ├── Save (via inventory to_save/from_save)
##  ├── UI (GameState signals ammo_changed, weapon_changed)
##  └── Audio/VFX (controller spawns)

var inventory: WeaponInventory
var data: WeaponData

func _init() -> void:
	inventory = WeaponInventory.new()
	data = WeaponData.new()

func get_current_cfg() -> Dictionary:
	return WeaponData.get_cfg(inventory.current_id)

func switch_to(id: String) -> bool:
	if not inventory.is_owned(id):
		return false
	inventory.current_id = id
	GameState.weapon_changed.emit(WeaponData.get_cfg(id)["name"])
	return true

func cycle(dir: int) -> String:
	var ids = inventory.owned_ids()
	if ids.size() <= 1:
		return inventory.current_id
	var i = ids.find(inventory.current_id)
	var next_id: String = ids[wrapi(i + dir, 0, ids.size())]
	inventory.current_id = next_id
	GameState.weapon_changed.emit(WeaponData.get_cfg(next_id)["name"])
	return next_id
