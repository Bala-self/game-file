class_name WeaponInventory
extends Object
## WeaponInventory — owns ammo + ownership, save v3 compatible
## Preserves existing save format: {"owned": [ids], "ammo": {id: [mag, reserve]}, "current": id}

var ammo: Dictionary = {}
var owned: Dictionary = {}
var current_id: String = "pistol"

func _init() -> void:
	# Default pools from WeaponData
	for id: String in WeaponData.all_ids():
		var cfg = WeaponData.get_cfg(id)
		ammo[id] = [int(cfg["mag"]), int(cfg["reserve_max"])]
	owned = {"pistol": true}
	current_id = "pistol"

func mag(id: String) -> int:
	return int(ammo.get(id, [0,0])[0])

func reserve(id: String) -> int:
	return int(ammo.get(id, [0,0])[1])

func mag_size(id: String) -> int:
	return int(WeaponData.get_cfg(id)["mag"])

func is_owned(id: String) -> bool:
	return bool(owned.get(id, false))

func owned_ids() -> Array:
	var out: Array = []
	for k: String in owned.keys():
		if owned[k]:
			out.append(k)
	return out

func add_ammo(id: String, n: int) -> void:
	if ammo.has(id):
		ammo[id][1] += n

func consume_mag(id: String, n: int = 1) -> bool:
	if not ammo.has(id):
		return false
	if ammo[id][0] < n:
		return false
	ammo[id][0] -= n
	return true

func reload(id: String) -> void:
	if not ammo.has(id):
		return
	var need = mag_size(id) - mag(id)
	var take = mini(need, reserve(id))
	ammo[id][0] += take
	ammo[id][1] -= take

func buy(id: String) -> bool:
	if not WeaponData.is_valid(id):
		return false
	if is_owned(id):
		return false
	var price = WeaponData.price_of(id)
	if not GameState.try_spend(price):
		return false
	owned[id] = true
	if not ammo.has(id):
		var cfg = WeaponData.get_cfg(id)
		ammo[id] = [int(cfg["mag"]), int(cfg["reserve_max"])]
	GameState.notify("%s purchased (-$%d)" % [WeaponData.get_cfg(id)["name"], price])
	return true

func next_unowned() -> String:
	for id: String in WeaponData.all_ids():
		if not is_owned(id):
			return id
	return ""

func to_save_dict() -> Dictionary:
	return {"owned": owned_ids(), "ammo": ammo.duplicate(true), "current": current_id}

func from_save_dict(d: Dictionary) -> void:
	# Preserve save v3 compat — tolerant
	owned = {"pistol": true}
	if d.get("owned", []) is Array:
		for wid: Variant in d["owned"]:
			var sid = str(wid)
			if WeaponData.is_valid(sid):
				owned[sid] = true
	if d.get("ammo", {}) is Dictionary:
		for k: String in (d["ammo"] as Dictionary).keys():
			if ammo.has(k) and d["ammo"][k] is Array:
				ammo[k] = [int(d["ammo"][k][0]), int(d["ammo"][k][1])]
	if d.get("current", "") != "" and is_owned(str(d["current"])):
		current_id = str(d["current"])
