class_name WeaponData
extends Object
## WeaponData Architecture — reusable data-driven definitions
## Migrates existing 3 weapons (pistol, SMG $800, shotgun $1200) + adds 4 fictional = 7 total
## Preserves save v3 compatibility: owned keys + ammo dict

const WEAPONS := {
	"pistol": {
		"id": "pistol", "name": "Pistol", "category": "pistol", "role": "Standard sidearm",
		"damage": 22, "cooldown": 0.18, "mag": 12, "reserve_max": 72,
		"spread_hip": 0.03, "spread_aim": 0.012, "reload_time": 1.1, "auto": false,
		"price": 0, "recoil": 0.02, "weight": 0.7, "mobility": 1.0, "range": 150.0,
		"accuracy": 0.90, "fire_rate": 333, "anim_set": "pistol", "sound_set": "pistol",
		"ads_fov": 50.0, "ads_move_mult": 0.65,
		"bloom_per_shot": 0.006, "bloom_decay": 0.030, "deploy_mult": 1.00,
		"falloff_start": 30.0, "falloff_end": 150.0, "min_dmg_pct": 0.40, "slot": 2,
		"desc": "Classic Pistol — original Island Strike sidearm, preserved for save compat"
	},
	"viper9": {
		"id": "viper9", "name": "Viper-9", "category": "pistol", "role": "Compact pistol / quick-draw",
		"damage": 28, "cooldown": 0.16, "mag": 15, "reserve_max": 90,
		"spread_hip": 0.025, "spread_aim": 0.01, "reload_time": 1.0, "auto": false,
		"price": 500, "recoil": 0.022, "weight": 0.8, "mobility": 1.0, "range": 180.0,
		"accuracy": 0.92, "fire_rate": 375, "anim_set": "pistol", "sound_set": "viper",
		"ads_fov": 52.0, "ads_move_mult": 0.70,
		"bloom_per_shot": 0.005, "bloom_decay": 0.035, "deploy_mult": 0.85,
		"falloff_start": 35.0, "falloff_end": 180.0, "min_dmg_pct": 0.45, "slot": 2,
		"desc": "G-01 Viper-9 — Fast, accurate, textured polymer frame, mag base, ejection-port detail"
	},
	"raven45": {
		"id": "raven45", "name": "Raven-45", "category": "pistol", "role": "Heavy pistol / power",
		"damage": 45, "cooldown": 0.32, "mag": 8, "reserve_max": 48,
		"spread_hip": 0.035, "spread_aim": 0.015, "reload_time": 1.3, "auto": false,
		"price": 600, "recoil": 0.055, "weight": 1.1, "mobility": 0.92, "range": 100.0,
		"accuracy": 0.88, "fire_rate": 188, "anim_set": "heavy_pistol", "sound_set": "raven",
		"ads_fov": 48.0, "ads_move_mult": 0.55,
		"bloom_per_shot": 0.010, "bloom_decay": 0.022, "deploy_mult": 1.15,
		"falloff_start": 25.0, "falloff_end": 100.0, "min_dmg_pct": 0.40, "slot": 2,
		"desc": "G-02 Raven-45 — Longer upper, heavier frame, metal+polymer, high kick + slow recovery"
	},
	"smg": {
		"id": "smg", "name": "SMG", "category": "smg", "role": "Close / auto",
		"damage": 14, "cooldown": 0.09, "mag": 30, "reserve_max": 120,
		"spread_hip": 0.045, "spread_aim": 0.02, "reload_time": 1.6, "auto": true,
		"price": 800, "recoil": 0.018, "weight": 1.0, "mobility": 0.95, "range": 120.0,
		"accuracy": 0.78, "fire_rate": 667, "anim_set": "smg", "sound_set": "smg",
		"ads_fov": 46.0, "ads_move_mult": 0.60,
		"bloom_per_shot": 0.004, "bloom_decay": 0.028, "deploy_mult": 1.00,
		"falloff_start": 25.0, "falloff_end": 120.0, "min_dmg_pct": 0.35, "slot": 1,
		"desc": "SMG — Fast fire, close range"
	},
	"kestrel556": {
		"id": "kestrel556", "name": "Kestrel-556", "category": "rifle", "role": "General-purpose primary",
		"damage": 32, "cooldown": 0.11, "mag": 30, "reserve_max": 150,
		"spread_hip": 0.04, "spread_aim": 0.015, "reload_time": 1.8, "auto": true,
		"price": 1500, "recoil": 0.035, "weight": 1.4, "mobility": 0.88, "range": 250.0,
		"accuracy": 0.85, "fire_rate": 545, "anim_set": "rifle", "sound_set": "kestrel",
		"ads_fov": 38.0, "ads_move_mult": 0.45,
		"bloom_per_shot": 0.006, "bloom_decay": 0.024, "deploy_mult": 1.10,
		"falloff_start": 60.0, "falloff_end": 250.0, "min_dmg_pct": 0.50, "slot": 1,
		"desc": "G-03 Kestrel-556 — Receiver+handguard+stock+grip+mag, rails, screws, wear"
	},
	"shotgun": {
		"id": "shotgun", "name": "Shotgun", "category": "shotgun", "role": "Classic close",
		"damage": 60, "cooldown": 0.75, "mag": 6, "reserve_max": 36,
		"spread_hip": 0.11, "spread_aim": 0.07, "reload_time": 2.2, "auto": false,
		"price": 1200, "recoil": 0.08, "weight": 1.5, "mobility": 0.85, "range": 35.0,
		"accuracy": 0.65, "fire_rate": 80, "anim_set": "shotgun", "sound_set": "shotgun",
		"ads_fov": 54.0, "ads_move_mult": 0.50,
		"bloom_per_shot": 0.012, "bloom_decay": 0.020, "deploy_mult": 1.20,
		"falloff_start": 8.0, "falloff_end": 26.0, "min_dmg_pct": 0.15, "slot": 1,
		"desc": "Classic Shotgun — Close-range, high spread"
	},
	"mammoth12": {
		"id": "mammoth12", "name": "Mammoth-12", "category": "shotgun", "role": "Tactical shotgun / close power",
		"damage": 85, "cooldown": 0.65, "mag": 8, "reserve_max": 40,
		"spread_hip": 0.13, "spread_aim": 0.09, "reload_time": 2.5, "auto": false,
		"price": 1800, "recoil": 0.11, "weight": 1.7, "mobility": 0.80, "range": 30.0,
		"accuracy": 0.60, "fire_rate": 92, "anim_set": "heavy_shotgun", "sound_set": "mammoth",
		"ads_fov": 54.0, "ads_move_mult": 0.45,
		"bloom_per_shot": 0.014, "bloom_decay": 0.018, "deploy_mult": 1.25,
		"falloff_start": 7.0, "falloff_end": 30.0, "min_dmg_pct": 0.15, "slot": 1,
		"desc": "G-04 Mammoth-12 — Visually larger/heavier, main body+front+grip, very high close dmg"
	},
}

static func get_cfg(id: String) -> Dictionary:
	return WEAPONS.get(id, WEAPONS["pistol"])

static func all_ids() -> Array:
	return WEAPONS.keys()

static func price_of(id: String) -> int:
	return int(WEAPONS.get(id, {}).get("price", 0))

static func is_valid(id: String) -> bool:
	return WEAPONS.has(id)


## ---- Round 12 extended ballistics/ergonomics API (additive, Phase 02) ----
## Damage falloff: 1.0 inside falloff_start, easing to min_dmg_pct at
## falloff_end (and beyond). Data-driven per weapon; replaces the hardcoded
## shotgun special-case in fire code.
static func falloff_mult(cfg: Dictionary, dist: float) -> float:
	var s: float = float(cfg.get("falloff_start", 30.0))
	var e: float = float(cfg.get("falloff_end", cfg.get("range", 120.0)))
	var mn: float = float(cfg.get("min_dmg_pct", 0.4))
	if dist <= s:
		return 1.0
	if dist >= e:
		return mn
	var u: float = (dist - s) / maxf(e - s, 0.001)
	var ease: float = u * u * (3.0 - 2.0 * u)  # smoothstep
	return 1.0 - (1.0 - mn) * ease


## Switch deploy time for one weapon, seconds — RAISE-stage duration =
## BASE_RAISE * deploy_mult (LOWER stays fixed 0.05 s; contract: default
## total 0.40 s at deploy_mult 1.0).
const BASE_RAISE := 0.35


static func deploy_time(id: String) -> float:
	return BASE_RAISE * float(get_cfg(id).get("deploy_mult", 1.0))


## Aim-down-sights camera FOV for one weapon.
static func ads_fov(id: String) -> float:
	return float(get_cfg(id).get("ads_fov", 48.0))


## Movement speed multiplier while aiming one weapon.
static func ads_move_mult(id: String) -> float:
	return float(get_cfg(id).get("ads_move_mult", 0.6))


## Weapon slot for wheel layout: 1 = primary, 2 = sidearm.
static func slot_of(id: String) -> int:
	return int(get_cfg(id).get("slot", 1))


## Contract validation: every weapon carries the full extended stat set with
## sane values. Used by weapon_system_test (Phase 02 gate).
static func validate_all() -> Dictionary:
	var problems: Array = []
	for id: String in WEAPONS:
		var c: Dictionary = WEAPONS[id]
		for k: String in ["ads_fov", "ads_move_mult", "bloom_per_shot", "bloom_decay",
				"deploy_mult", "falloff_start", "falloff_end", "min_dmg_pct", "slot"]:
			if not c.has(k):
				problems.append("%s missing %s" % [id, k])
		if c.get("ads_fov", 0) < 20.0 or c.get("ads_fov", 0) > 70.0:
			problems.append("%s ads_fov out of range" % id)
		if c.get("ads_move_mult", 0) <= 0.0 or c.get("ads_move_mult", 0) > 1.0:
			problems.append("%s ads_move_mult out of range" % id)
		if c.get("deploy_mult", 0) < 0.5 or c.get("deploy_mult", 0) > 1.5:
			problems.append("%s deploy_mult out of range" % id)
		if c.get("falloff_start", 0) >= c.get("falloff_end", 0):
			problems.append("%s falloff_start >= falloff_end" % id)
		if c.get("min_dmg_pct", 0) <= 0.0 or c.get("min_dmg_pct", 0) > 1.0:
			problems.append("%s min_dmg_pct out of range" % id)
		if int(c.get("slot", 0)) not in [1, 2]:
			problems.append("%s slot invalid" % id)
	return {"ok": problems.is_empty(), "problems": problems}
