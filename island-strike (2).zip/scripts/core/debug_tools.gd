class_name DebugTools
extends Object
## Debug framework — stats + command API (master plan §41).
## stats(): one dictionary for HUD/debug panels and tests.
## cmd(): teleport / set_time / set_wanted / give_money / give_weapon /
##        spawn_car / spawn_npc / set_weather. Every command is logged on
##        the EventBus (DEBUG_CMD) and returns "OK: ..." or "ERR: ...".

const BUS := preload("res://scripts/core/event_bus.gd")
const EconomyRes := preload("res://scripts/core/economy.gd")


static func _tree() -> SceneTree:
	var ml: MainLoop = Engine.get_main_loop()
	return ml as SceneTree


static func _gs() -> Node:
	var t: SceneTree = _tree()
	if t == null:
		return null
	return t.root.get_node_or_null("GameState")


static func _player() -> Node:
	var t: SceneTree = _tree()
	if t == null:
		return null
	return t.get_first_node_in_group("player")


static func _game() -> Node:
	var t: SceneTree = _tree()
	if t == null:
		return null
	return t.get_first_node_in_group("game")


## Live world/system snapshot for overlays and tests.
static func stats() -> Dictionary:
	var t: SceneTree = _tree()
	var gs: Node = _gs()
	var out: Dictionary = {
		"day_time": 12.0, "wanted": 0, "money": 0, "raining": false,
		"fps": Engine.get_frames_per_second(),
	}
	if gs != null:
		out["day_time"] = gs.get("day_time")
		out["wanted"] = int(gs.get("wanted"))
		out["money"] = int(gs.get("money"))
		out["raining"] = bool(gs.get("raining"))
	if t == null:
		return out
	out["civilians"] = t.get_nodes_in_group("civilians").size()
	out["cars"] = t.get_nodes_in_group("cars").size()
	out["police"] = t.get_nodes_in_group("police").size()
	out["gangs"] = t.get_nodes_in_group("gangs").size()
	var p: Node = _player()
	if p is Node3D:
		out["player_pos"] = (p as Node3D).global_position
	var bus: Node = t.root.get_node_or_null("EventBus")
	if bus != null:
		out["events"] = bus.tail(8)
	return out


## Command API. arg types: teleport Vector3, set_time float, set_wanted int,
## give_money int, give_weapon String, spawn_car/spawn_npc null,
## set_weather bool.
static func cmd(name: String, arg: Variant = null) -> String:
	var result: String = _dispatch(name, arg)
	var bus: Node = null
	var t: SceneTree = _tree()
	if t != null:
		bus = t.root.get_node_or_null("EventBus")
	if bus != null:
		bus.record("DEBUG_CMD", {"cmd": name, "arg": str(arg), "result": result})
	return result


static func _dispatch(name: String, arg: Variant) -> String:
	var t: SceneTree = _tree()
	if t == null or _gs() == null:
		return "ERR: no scene tree"
	match name:
		"teleport":
			var p: Node = _player()
			if p == null or not (p is Node3D) or not (arg is Vector3):
				return "ERR: teleport needs player + Vector3"
			(p as Node3D).global_position = arg
			if p is CharacterBody3D:
				(p as CharacterBody3D).velocity = Vector3.ZERO
			return "OK: teleported to %s" % [arg]
		"set_time":
			var gs_t: Node = _gs()
			gs_t.set("day_time", clampf(float(arg), 0.0, 23.99))
			gs_t.time_changed.emit(float(gs_t.get("day_time")))
			return "OK: time %.2f" % float(gs_t.get("day_time"))
		"set_wanted":
			_gs().set_wanted(int(arg))
			return "OK: wanted %d" % int(_gs().get("wanted"))
		"give_money":
			EconomyRes.earn(int(arg), "debug")
			return "OK: money %d" % int(_gs().get("money"))
		"give_weapon":
			var p2: Node = _player()
			if p2 == null:
				return "ERR: no player"
			var wpn: Node = p2.get("pistol")
			if wpn == null:
				return "ERR: no weapon system"
			var wid: String = str(arg)
			if not WeaponData.is_valid(wid):
				return "ERR: unknown weapon %s" % wid
			var owned: Dictionary = wpn.get("owned_weapons")
			owned[wid] = true
			var ammo: Dictionary = wpn.get("ammo")
			if not ammo.has(wid):
				ammo[wid] = [int(WeaponData.get_cfg(wid)["mag"]),
						int(WeaponData.get_cfg(wid)["reserve_max"])]
			wpn.set("owned_weapons", owned)
			wpn.set("ammo", ammo)
			return "OK: granted %s" % wid
		"spawn_car":
			var g: Node = _game()
			if g == null or not g.has_method("debug_spawn_car"):
				return "ERR: game spawner unavailable"
			g.debug_spawn_car()
			return "OK: car spawned"
		"spawn_npc":
			var g2: Node = _game()
			if g2 == null or not g2.has_method("debug_spawn_npc"):
				return "ERR: game spawner unavailable"
			g2.debug_spawn_npc()
			return "OK: npc spawned"
		"set_weather":
			_gs().set_raining(bool(arg))
			return "OK: raining %s" % str(bool(_gs().get("raining")))
		"toggle_world_grid":
			return _toggle_world_grid(t)
		_:
			return "ERR: unknown command %s" % name


## P02 §25 debug QA overlay: world circle, macro grid, micro grid around the
## player, player-sector highlight, center marker + a text snapshot. Not a
## permanent UI element — toggled on demand (dev/QA builds).
static func _toggle_world_grid(t: SceneTree) -> String:
	var host: Node = t.current_scene
	if host == null:
		host = t.root
	var existing: Node = host.get_node_or_null("WorldGridDebug")
	if existing != null:
		existing.free()
		return "OK: world grid off"
	var R: float = WorldContract.RADIUS_M
	var holder := Node3D.new()
	holder.name = "WorldGridDebug"
	var im := SurfaceTool.new()
	im.begin(Mesh.PRIMITIVE_LINES)
	var c_circ := Color(0.25, 0.85, 1.0, 0.9)
	var c_macro := Color(1.0, 0.75, 0.2, 0.55)
	var c_micro := Color(0.6, 0.6, 0.65, 0.5)
	var c_sel := Color(1.0, 0.95, 0.2, 0.95)
	# world circle (128 segments)
	for i in range(128):
		var a0: float = TAU * float(i) / 128.0
		var a1: float = TAU * float(i + 1) / 128.0
		im.set_color(c_circ)
		im.add_vertex(Vector3(cos(a0) * R, 3.0, sin(a0) * R))
		im.add_vertex(Vector3(cos(a1) * R, 3.0, sin(a1) * R))
	# macro grid (500 m), clipped to the circle
	var n: int = int(R / WorldContract.SECTOR_M)
	for k in range(-n, n + 1):
		var off: float = float(k) * WorldContract.SECTOR_M
		if absf(off) >= R:
			continue
		var half: float = sqrt(R * R - off * off)
		im.set_color(c_macro)
		im.add_vertex(Vector3(off, 2.5, -half))
		im.add_vertex(Vector3(off, 2.5, half))
		im.add_vertex(Vector3(-half, 2.5, off))
		im.add_vertex(Vector3(half, 2.5, off))
	# micro grid (125 m) around the player sector ±3
	var p: Node = _player()
	var ps := Vector2i.ZERO
	if p is Node3D:
		ps = WorldContract.micro_sector_of3((p as Node3D).global_position)
	var ms: float = WorldContract.MICRO_SECTOR_M
	for k in range(ps.x - 3, ps.x + 4):
		var x: float = float(k) * ms
		im.set_color(c_micro)
		im.add_vertex(Vector3(x, 2.0, float(ps.y - 3) * ms))
		im.add_vertex(Vector3(x, 2.0, float(ps.y + 4) * ms))
	for k2 in range(ps.y - 3, ps.y + 4):
		var z: float = float(k2) * ms
		im.add_vertex(Vector3(float(ps.x - 3) * ms, 2.0, z))
		im.add_vertex(Vector3(float(ps.x + 4) * ms, 2.0, z))
	# player sector highlight box
	im.set_color(c_sel)
	var bx: float = float(ps.x) * ms
	var bz: float = float(ps.y) * ms
	im.add_vertex(Vector3(bx, 2.2, bz)); im.add_vertex(Vector3(bx + ms, 2.2, bz))
	im.add_vertex(Vector3(bx + ms, 2.2, bz)); im.add_vertex(Vector3(bx + ms, 2.2, bz + ms))
	im.add_vertex(Vector3(bx + ms, 2.2, bz + ms)); im.add_vertex(Vector3(bx, 2.2, bz + ms))
	im.add_vertex(Vector3(bx, 2.2, bz + ms)); im.add_vertex(Vector3(bx, 2.2, bz))
	# world center cross
	im.set_color(c_circ)
	im.add_vertex(Vector3(-15, 3.0, 0)); im.add_vertex(Vector3(15, 3.0, 0))
	im.add_vertex(Vector3(0, 3.0, -15)); im.add_vertex(Vector3(0, 3.0, 15))
	# P03 §36 overlay: river centerline at its water level
	var c_river := Color(0.2, 0.5, 1.0, 0.95)
	var cl: Array = WorldTerrain.river_centerline(2)
	for ci in range(cl.size() - 1):
		var ca: Vector3 = cl[ci]["center"]
		var cb: Vector3 = cl[ci + 1]["center"]
		im.set_color(c_river)
		im.add_vertex(Vector3(ca.x, float(cl[ci]["level"]) + 1.0, ca.z))
		im.add_vertex(Vector3(cb.x, float(cl[ci + 1]["level"]) + 1.0, cb.z))
	var mi := MeshInstance3D.new()
	mi.mesh = im.commit()
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.vertex_color_use_as_albedo = true
	mi.material_override = mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	holder.add_child(mi)
	host.add_child(holder)
	# text snapshot (console; QA captures pair this with F3 debug overlay)
	var pos: Vector3 = (p as Node3D).global_position if p is Node3D else Vector3.ZERO
	var rec: Dictionary = WorldSectorRegistry.micro_record(ps)
	# P03 §36 terrain info block: elevation / slope / water level / classes /
	# chunk active-far state (the mesh above carries circle, sectors, river)
	var gg: Dictionary = WorldTerrain.resolve_to_ground(pos.x, pos.z)
	var wl: float = WorldTerrain.water_level_at(pos.x, pos.z)
	var coast: String = WorldTerrain.coast_class_at(pos.x, pos.z)
	var active := 0
	var total := 0
	for nd: Node in t.get_nodes_in_group("terrain_chunks"):
		if nd is StaticBody3D:
			total += 1
			if (nd as StaticBody3D).collision_layer != 0:
				active += 1
	var fmt: String = "OK: world grid on | pos %s | micro %s macro %s | nr %.3f" \
			+ " | region %s district %s | elev %.1f slope %.1f%% wl %.1f" \
			+ " | class %s coast %s | chunks %d/%d active"
	return fmt % [str(pos.snapped(Vector3(0.1, 0.1, 0.1))), WorldContract.micro_id(ps),
			str(rec["macro_id"]), WorldContract.normalized_radius(Vector2(pos.x, pos.z)),
			str(rec["region_id"]), str(rec["district_id"]),
			float(gg["ground_y"]), float(gg["slope_deg"]), wl,
			String(gg["surface"]), coast, active, total]
