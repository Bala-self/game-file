class_name Economy
extends Object
## Economy — centralized transaction layer (master plan §19).
## ALL money movement routes through here:
##   pay()    denied when short (shop purchases)
##   charge() clamps at zero (fines — preserves legacy add_money(-x) behavior)
##   earn()   rewards, income, pickups
## Every transaction is recorded on the EventBus with reason + balance.
## Direct GameState.money writes outside save-restore are prohibited.

const BUS := preload("res://scripts/core/event_bus.gd")


static func _gs() -> Node:
	var ml: MainLoop = Engine.get_main_loop()
	if ml is SceneTree:
		return (ml as SceneTree).root.get_node_or_null("GameState")
	return null


static func _bus() -> Node:
	var ml: MainLoop = Engine.get_main_loop()
	if ml is SceneTree:
		return (ml as SceneTree).root.get_node_or_null("EventBus")
	return null


## Denied-when-insufficient purchase. Returns true and deducts on success.
static func pay(amount: int, reason: String) -> bool:
	if amount <= 0:
		return false
	var gs: Node = _gs()
	if gs == null:
		return false
	if not gs.try_spend(amount):
		var b0: Node = _bus()
		if b0 != null:
			b0.record("TRANSACTION_DENIED", {"amount": amount, "reason": reason,
					"balance": int(gs.get("money"))})
		return false
	_log_tx(-amount, reason, int(gs.get("money")), false)
	return true


## Always-charges charge (fines): deducts min(amount, balance), returns the
## amount actually charged. Matches legacy clamp-at-zero fine behavior.
static func charge(amount: int, reason: String) -> int:
	var gs2: Node = _gs()
	if gs2 == null:
		return 0
	var actual: int = mini(maxi(amount, 0), int(gs2.get("money")))
	if actual > 0:
		gs2.add_money(-actual)
	_log_tx(-actual, reason, int(gs2.get("money")), true)
	return actual


## Income/reward path.
static func earn(amount: int, reason: String) -> void:
	if amount <= 0:
		return
	var gs3: Node = _gs()
	if gs3 == null:
		return
	gs3.add_money(amount)
	_log_tx(amount, reason, int(gs3.get("money")), false)


static func _log_tx(amount: int, reason: String, balance: int, clamped: bool) -> void:
	var b: Node = _bus()
	if b != null:
		b.record("TRANSACTION", {"amount": amount, "reason": reason,
				"balance": balance, "clamped": clamped})


## Ledger for QA: all TRANSACTION + TRANSACTION_DENIED entries.
static func transactions() -> Array:
	var out: Array = []
	var b: Node = _bus()
	if b == null:
		return out
	for e: Dictionary in b.log:
		var k: String = str(e.get("kind"))
		if k == "TRANSACTION" or k == "TRANSACTION_DENIED":
			out.append(e)
	return out
