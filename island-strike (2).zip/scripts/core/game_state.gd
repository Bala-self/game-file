extends Node
## Global game state: economy, wanted level, time, weather, settings, input map.

signal money_changed(amount: int)
signal wanted_changed(level: int)
signal time_changed(hours: float)
signal weather_changed(raining: bool)
signal notify_posted(text: String)
@warning_ignore("unused_signal")
signal ammo_changed(mag: int, reserve: int)
@warning_ignore("unused_signal")
signal player_health_changed(hp: int)
@warning_ignore("unused_signal")
signal player_damaged
signal prompt_changed(text: String)
@warning_ignore("unused_signal")
signal load_applied
signal crime_committed(severity: int, pos: Vector3)
@warning_ignore("unused_signal")
signal weapon_changed(weapon_name: String)
signal device_changed(device: String)

const DAY_LENGTH_SEC := 240.0  # real seconds per 24h day (matches shipped tuning measured in both recorded sessions)
const SAVE_PATH := "user://save_1.json"
const SETTINGS_PATH := "user://settings.json"
const SAVE_VERSION := 2

var money: int = 500
var wanted: int = 0
var day_time: float = 9.0  # 0..24 hours
var raining: bool = false
var heavy_rain: bool = false
var collected: Dictionary = {}  # collectible id -> true
var world_data: Dictionary = {}  # filled by game.gd via WorldBuilder
var pending_load: bool = false
var stats: Dictionary = {"kills": 0, "cars_entered": 0, "distance_m": 0.0, "race_best": 0.0}

var settings: Dictionary = {
	"sensitivity": 1.0,
	"invert_y": false,
	"invert_x": false,
	"volume": 0.8,
	"fullscreen": false,
	"vibration": 0.7,
	"deadzone": 0.2,
	"quality": "HIGH",
	"binds": {},  # audit #32: user key rebinds (action -> keycode int)
}
## Buyable properties (economy sink + daily income): door positions live in
## world_data["property_spots"].
const PROPERTIES := {
	"safehouse": {"name": "Downtown Safehouse", "price": 2500, "income": 0},
	"gas_station": {"name": "Gas Station", "price": 1500, "income": 0},
	"harbor_office": {"name": "Marina Office", "price": 1800, "income": 40},
	"warehouse": {"name": "Industrial Warehouse", "price": 3500, "income": 90},
}
var owned: Dictionary = {}
var last_device: String = "kb"  # "kb" | "controller" — drives contextual prompts
var world_flags: Dictionary = {}
var traffic_ns_green: bool = true
## D2 shutdown latch: set once by the pre-quit audio sweep; every per-frame
## audio restart site checks this so stopped streams stay stopped until exit.
var audio_shutdown: bool = false
var _tl_timer: float = 0.0
# Deep fix: cached player ref + group registry to avoid 32x get_nodes_in_group per frame
var _cached_player: Node3D = null
var _player_cache_t: float = 0.0
var _group_registry: Dictionary = {
	"civilians": [],
	"police": [],
	"gangs": [],
	"cars": [],
	"beach_npcs": [],
	"military": [],
	"commuters": [],
	"services": [],
}
var _registry_t: float = 0.0


func _enter_tree() -> void:
	# Determinism contract (v2.0 directive): fixed seed — identical world,
	# traffic and NPC layouts every run. Any layout-output change is breaking
	# and must be declared in the release report.
	seed(19041604)
	_setup_input()
	# audit #32: re-apply persisted rebinds (additive on top of defaults)
	for action: String in settings.get("binds", {}).keys():
		var kc = int(settings["binds"][action])
		if InputMap.has_action(action) and kc > 0:
			var ev: InputEventKey = InputEventKey.new()
			ev.keycode = kc as Key
			InputMap.action_add_event(action, ev)
	_load_settings()
	apply_settings()


# ------------------------------------------------------------------ economy
func add_money(v: int) -> void:
	money = maxi(0, money + v)
	money_changed.emit(money)


func try_spend(v: int) -> bool:
	if money < v:
		notify("Not enough money ($%d needed)" % v)
		return false
	money -= v
	money_changed.emit(money)
	return true


# ------------------------------------------------------------------- wanted
func add_wanted(v: int) -> void:
	set_wanted(wanted + v)


func set_wanted(v: int) -> void:
	v = clampi(v, 0, 5)
	if v != wanted:
		wanted = v
		wanted_changed.emit(wanted)


func commit_crime(severity: int, pos: Vector3) -> void:
	crime_committed.emit(severity, pos)


# --------------------------------------------------------------------- time
func advance_time(delta_hours: float) -> void:
	day_time = fmod(day_time + delta_hours, 24.0)
	time_changed.emit(day_time)


## Round 9 S9 (Phase 40 slice): formal sim LOD tiers T0-T4 by player distance.
## Route-critical classes (commuter/cop/service) hold T0; routine classes
## throttle think-rate and rig anim. At T4 the last directive keeps walking;
## decisions resume in range.
const SIM_TIERS := [
	{"name": "T0", "d": 20.0, "logic_hz": 60.0, "anim_hz": 60.0},
	{"name": "T1", "d": 40.0, "logic_hz": 60.0, "anim_hz": 60.0},
	{"name": "T2", "d": 90.0, "logic_hz": 10.0, "anim_hz": 15.0},
	{"name": "T3", "d": 150.0, "logic_hz": 2.0, "anim_hz": 0.0},
	{"name": "T4", "d": 1.0e9, "logic_hz": 0.0, "anim_hz": 0.0},
]


func sim_tier(dist: float) -> Dictionary:
	for t: Dictionary in SIM_TIERS:
		if dist <= float(t["d"]):
			return t
	return SIM_TIERS[4]


# Deep fix: cached player lookup — avoids get_first_node_in_group per NPC per think
# Re-resolves every 0.5s or when cached ref becomes invalid (respawn/load)
func get_player() -> Node3D:
	_player_cache_t -= 0.016
	if _cached_player != null and is_instance_valid(_cached_player) and _player_cache_t > 0.0:
		return _cached_player
	var tree = get_tree()
	if tree == null:
		return null
	_cached_player = tree.get_first_node_in_group("player") as Node3D
	_player_cache_t = 0.5
	return _cached_player

func invalidate_player_cache() -> void:
	_cached_player = null
	_player_cache_t = 0.0

# Deep fix: unified sidewalk point — deduplicates _random_sidewalk_point in game.gd + person.gd
# Single source of truth, district-aware, uses world_data roads
func get_random_sidewalk_point() -> Vector3:
	var roads: Array = world_data.get("roads", [])
	if roads.is_empty():
		return Vector3(5, 0, 0)
	var r: Rect2 = roads[randi() % roads.size()]
	var side = 1.0 if randf() < 0.5 else -1.0
	if r.size.x > r.size.y:
		return Vector3(randf_range(r.position.x, r.end.x), 0, r.position.y + 10.5 * side)
	return Vector3(r.position.x + 10.5 * side, 0, randf_range(r.position.y, r.end.y))

func get_scheduled_sidewalk_point() -> Vector3:
	# Delegates to person.gd schedule logic but kept here as fallback
	return get_random_sidewalk_point()

# Deep fix: group registry — batched get_nodes_in_group with 1s cache and invalid pruning
# Called by directors instead of direct get_nodes_in_group
func get_cached_group(name: String) -> Array:
	_registry_t -= 0.016
	if _registry_t <= 0.0 or _group_registry.get(name, []).is_empty():
		_refresh_registry()
		_registry_t = 1.0
	return _group_registry.get(name, [])

func _refresh_registry() -> void:
	var tree = get_tree()
	if tree == null:
		return
	for g in _group_registry.keys():
		var nodes = tree.get_nodes_in_group(g)
		# prune invalid
		var alive: Array = []
		for n in nodes:
			if is_instance_valid(n):
				alive.append(n)
		_group_registry[g] = alive

func register_spawn(group_name: String, node: Node) -> void:
	if _group_registry.has(group_name):
		_group_registry[group_name].append(node)

func unregister_despawn(group_name: String, node: Node) -> void:
	if _group_registry.has(group_name):
		_group_registry[group_name].erase(node)


## Round 9 S5: single-owner day phase (WorldSim delegates; NPC schedules use it).
func day_phase() -> String:
	if day_time < 6.0 or day_time >= 21.0:
		return "night"
	if day_time < 8.0:
		return "dawn"
	if day_time < 18.0:
		return "day"
	return "dusk"


func is_night() -> bool:
	return day_time < 6.5 or day_time > 19.0


## Round 12 Phase 19: rush-hour windows in game hours — 7:00–9:00 and
## 17:00–19:00. Drives the pedestrian surge and traffic pacing.
func is_rush_hour() -> bool:
	return (day_time >= 7.0 and day_time < 9.0) \
			or (day_time >= 17.0 and day_time < 19.0)


func clock_text() -> String:
	var h = int(day_time)
	var m = int(fmod(day_time, 1.0) * 60.0)
	return "%02d:%02d" % [h, m]


# ----------------------------------------------------------------- gameplay
func collect(id: String, reward: int) -> void:
	if collected.has(id):
		return
	collected[id] = true
	add_money(reward)
	notify("Collectible %s found! +$%d" % [id, reward])


## Buy a property. Returns false if broke or already owned.
func buy_property(id: String) -> bool:
	if not PROPERTIES.has(id) or owned.has(id):
		return false
	var price: int = PROPERTIES[id]["price"]
	if not try_spend(price):
		return false
	owned[id] = true
	notify("PROPERTY BOUGHT: %s (-$%d)" % [PROPERTIES[id]["name"], price])
	vibrate(0.2, 0.35, 0.15)
	return true


## Total daily income from owned income-properties.
func daily_income() -> int:
	var total: int = 0
	for id: String in owned:
		if PROPERTIES.has(id):
			total += int(PROPERTIES[id]["income"])
	return total


func _input(event: InputEvent) -> void:
	var dev: String = ""
	if event is InputEventKey or event is InputEventMouseButton or event is InputEventMouseMotion:
		dev = "kb"
	elif event is InputEventJoypadButton or event is InputEventJoypadMotion:
		dev = "controller"
	if dev != "" and dev != last_device:
		last_device = dev
		device_changed.emit(dev)


## Contextual prompt glyph: same action renders [E] on keyboard, [Y] on pad.
func ctx_prompt(action: String, text: String) -> String:
	var glyphs: Dictionary = {
		"interact": {"kb": "E", "controller": "Y"},
		"jump": {"kb": "SPACE", "controller": "A"},
		"sprint": {"kb": "SHIFT", "controller": "L3"},
		"crouch": {"kb": "CTRL", "controller": "R3"},
	}
	var g: String = glyphs.get(action, {}).get(last_device, "-")
	return "[%s] %s" % [g, text]


func notify(text: String) -> void:
	notify_posted.emit(text)


# Internal emit helpers — signals are emitted from other scripts via GameState.<signal>.emit()
# but Godot 4.5 marks them UNUSED if not emitted inside this file. These wrappers
# ensure intra-file emission so both Godot and gdlint see them as used.
func emit_ammo_changed(mag: int, reserve: int) -> void:
	ammo_changed.emit(mag, reserve)

func emit_player_health_changed(hp: int) -> void:
	player_health_changed.emit(hp)

func emit_player_damaged() -> void:
	player_damaged.emit()

func emit_load_applied() -> void:
	load_applied.emit()

func emit_weapon_changed(name: String) -> void:
	weapon_changed.emit(name)


func set_prompt(text: String) -> void:
	prompt_changed.emit(text)


func set_raining(v: bool) -> void:
	if raining != v:
		raining = v
		weather_changed.emit(v)
		notify("Rain is starting..." if v else "The rain cleared up.")


# ----------------------------------------------------------------- settings
## audit #32: additive key rebind — the default binding stays, the user key
## is added on top and persisted in settings["binds"].
func bind_key(action: String, keycode: Key) -> void:
	if not InputMap.has_action(action):
		return
	var ev: InputEventKey = InputEventKey.new()
	ev.keycode = keycode
	InputMap.action_add_event(action, ev)
	var binds: Dictionary = settings.get("binds", {})
	binds[action] = int(keycode)
	settings["binds"] = binds
	save_settings()
	notify("%s bound to %s" % [action, OS.get_keycode_string(keycode)])


func apply_settings() -> void:
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(settings.volume, 0.001)))
	if DisplayServer.get_name() != "headless":
		var mode = DisplayServer.WINDOW_MODE_FULLSCREEN if settings.fullscreen else DisplayServer.WINDOW_MODE_WINDOWED
		DisplayServer.window_set_mode(mode)
	# controller deadzone applied to gameplay actions
	var dz: float = clampf(settings.deadzone, 0.05, 0.5)
	for a in ["move_left", "move_right", "move_forward", "move_back",
			"look_left", "look_right", "look_up", "look_down", "fire", "aim"]:
		if InputMap.has_action(a):
			InputMap.action_set_deadzone(a, dz)


## Controller vibration helper (strength 0..1). Respects the vibration setting.
func vibrate(weak: float, strong: float, duration: float) -> void:
	var strength: float = settings.vibration
	if strength <= 0.0:
		return
	if Input.get_connected_joypads().is_empty():
		return
	Input.start_joy_vibration(0, weak * strength, strong * strength, duration)


## Call from game loop: cycles the global traffic-light phase.
func update_traffic_phase(delta: float) -> void:
	_tl_timer += delta
	if _tl_timer >= 9.0:
		_tl_timer = 0.0
		traffic_ns_green = not traffic_ns_green


func save_settings() -> void:
	var f = FileAccess.open(SETTINGS_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(settings))


func _load_settings() -> void:
	if not FileAccess.file_exists(SETTINGS_PATH):
		return
	var f = FileAccess.open(SETTINGS_PATH, FileAccess.READ)
	if f == null:
		return
	var parsed: Variant = JSON.parse_string(f.get_as_text())
	if parsed is Dictionary:
		for k: String in settings.keys():
			if parsed.has(k):
				settings[k] = parsed[k]


# -------------------------------------------------------------------- input
func _setup_input() -> void:
	# Keyboard / mouse — keep all existing for backward compat
	_keys("move_forward", [KEY_W, KEY_UP])
	_keys("move_back", [KEY_S, KEY_DOWN])
	_keys("move_left", [KEY_A, KEY_LEFT])
	_keys("move_right", [KEY_D, KEY_RIGHT])
	_keys("jump", [KEY_SPACE])
	_keys("sprint", [KEY_SHIFT])
	_keys("crouch", [KEY_CTRL, KEY_C])
	_keys("interact", [KEY_E, KEY_F])
	_keys("reload", [KEY_R])
	_keys("horn", [KEY_H])
	_mouse("fire", MOUSE_BUTTON_LEFT)
	_mouse("aim", MOUSE_BUTTON_RIGHT)
	_keys("save_game", [KEY_F5])  # kept per custom hybrid
	_keys("load_game", [KEY_F9])
	_keys("debug_toggle", [KEY_F3])
	_keys("weather_toggle", [KEY_T])
	_keys("debug_spawn_car", [KEY_F2])
	_keys("debug_spawn_npc", [KEY_F4])
	_keys("map", [KEY_TAB])
	_keys("phone", [KEY_P])  # Round 9 S8
	_keys("next_weapon", [KEY_Q])
	_mouse_wheel("next_weapon", MOUSE_BUTTON_WHEEL_UP)
	_mouse_wheel("prev_weapon", MOUSE_BUTTON_WHEEL_DOWN)
	# NEW — GTA hybrid extras
	_keys("weapon_wheel", [KEY_Q])  # hold Q for wheel on KB (LB on pad)
	_keys("fast_next", [KEY_E])  # fast next (D-Pad Right on pad)
	_keys("fast_prev", [KEY_Q])  # fast prev (D-Pad Left)
	_keys("primary_weapon", [KEY_1])
	_keys("secondary_weapon", [KEY_2])
	_keys("cover", [KEY_C])
	_keys("look_behind", [KEY_V])
	# Controller - left stick move, right stick look, face buttons — GTA hybrid custom
	_joy_axes("move_left", "move_right", JOY_AXIS_LEFT_X)
	_joy_axes("move_forward", "move_back", JOY_AXIS_LEFT_Y)
	_joy_axes("look_left", "look_right", JOY_AXIS_RIGHT_X)
	_joy_axes("look_up", "look_down", JOY_AXIS_RIGHT_Y)
	_joy_axis_trigger("fire", JOY_AXIS_TRIGGER_RIGHT)  # RT/R2
	_joy_axis_trigger("aim", JOY_AXIS_TRIGGER_LEFT)   # LT/L2
	_joy_button("jump", JOY_BUTTON_A)  # A = Jump/Climb + Handbrake context
	_joy_button("crouch", JOY_BUTTON_B)  # B = Crouch/Stealth
	_joy_button("interact", JOY_BUTTON_X)  # X = Enter/Exit Vehicle (Y in GTA, X in Island Strike)
	_joy_button("reload", JOY_BUTTON_Y)  # Y = Reload
	_joy_button("sprint", JOY_BUTTON_LEFT_STICK)  # L3 = Sprint on foot + Horn in vehicle (context)
	_joy_button("horn", JOY_BUTTON_LEFT_STICK)  # L3 = Horn (same button, vehicle context)
	_joy_button("weapon_wheel", JOY_BUTTON_LEFT_SHOULDER)  # LB/L1 = Weapon Wheel (hold)
	_joy_button("cover", JOY_BUTTON_RIGHT_SHOULDER)  # RB/R1 = Cover
	_joy_button("fast_next", JOY_BUTTON_DPAD_RIGHT)  # D-Pad Right = Next Weapon (fast)
	_joy_button("fast_prev", JOY_BUTTON_DPAD_LEFT)  # D-Pad Left = Prev Weapon (fast)
	_joy_button("primary_weapon", JOY_BUTTON_DPAD_UP)  # D-Pad Up = Phone (GTA) + Primary (hybrid) — phone gets priority
	_joy_button("secondary_weapon", JOY_BUTTON_DPAD_DOWN)  # D-Pad Down = Secondary / Character Switch roadmap
	_joy_button("phone", JOY_BUTTON_DPAD_UP)  # D-Pad Up = Phone (GTA)
	_joy_button("map", JOY_BUTTON_BACK)  # View/Select = Map
	_joy_button("look_behind", JOY_BUTTON_RIGHT_STICK)  # R3 = Look Behind
	# Keep old mappings for backward compat (DPAD_DOWN was next_weapon, now secondary)
	_joy_button("next_weapon", JOY_BUTTON_DPAD_RIGHT)
	_joy_button("prev_weapon", JOY_BUTTON_DPAD_LEFT)
	# Start button pauses
	if not InputMap.has_action("ui_cancel"):
		InputMap.add_action("ui_cancel")
	_joy_button("ui_cancel", JOY_BUTTON_START)


func _ensure(action: String) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)


func _keys(action: String, codes: Array) -> void:
	_ensure(action)
	for c: Key in codes:
		var ev: InputEventKey = InputEventKey.new()
		ev.physical_keycode = c
		InputMap.action_add_event(action, ev)


func _mouse_wheel(action: String, button: MouseButton) -> void:
	_ensure(action)
	var ev: InputEventMouseButton = InputEventMouseButton.new()
	ev.button_index = button
	ev.pressed = true
	InputMap.action_add_event(action, ev)


func _mouse(action: String, button: MouseButton) -> void:
	_ensure(action)
	var ev: InputEventMouseButton = InputEventMouseButton.new()
	ev.button_index = button
	InputMap.action_add_event(action, ev)


func _joy_button(action: String, button: JoyButton) -> void:
	_ensure(action)
	var ev: InputEventJoypadButton = InputEventJoypadButton.new()
	ev.button_index = button
	InputMap.action_add_event(action, ev)


func _joy_axes(neg_action: String, pos_action: String, axis: JoyAxis) -> void:
	_ensure(neg_action)
	_ensure(pos_action)
	var ev_neg: InputEventJoypadMotion = InputEventJoypadMotion.new()
	ev_neg.axis = axis
	ev_neg.axis_value = -1.0
	InputMap.action_add_event(neg_action, ev_neg)
	var ev_pos: InputEventJoypadMotion = InputEventJoypadMotion.new()
	ev_pos.axis = axis
	ev_pos.axis_value = 1.0
	InputMap.action_add_event(pos_action, ev_pos)


func _joy_axis_trigger(action: String, axis: JoyAxis) -> void:
	_ensure(action)
	var ev: InputEventJoypadMotion = InputEventJoypadMotion.new()
	ev.axis = axis
	ev.axis_value = 1.0
	InputMap.action_add_event(action, ev)
