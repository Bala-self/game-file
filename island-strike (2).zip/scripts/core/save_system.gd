extends Node
## Versioned JSON save/load to user://. Tolerant of missing optional fields.

const SAVE_VERSION := 3


func has_save() -> bool:
	return FileAccess.file_exists(GameState.SAVE_PATH)


## NOTE (audit #26): save is deliberately plain JSON for a single-player
## offline game (debuggability > tamper resistance); corruption is rejected
## at load. Integrity is NOT a security boundary.
func save_game() -> bool:
	var data: Dictionary = {
		"version": SAVE_VERSION,
		"money": GameState.money,
		"wanted": GameState.wanted,
		"day_time": GameState.day_time,
		"raining": GameState.raining,
		"collected": GameState.collected.keys(),
		"stats": GameState.stats,
		"owned": GameState.owned.keys(),
		"world_flags": GameState.world_flags,
		"delivery": _delivery_state(),
		"mission": _mission_state(),
		"missions_done": _missions_done(),
		"player": {},
		# P02 §13: world schema marker (additive key; old saves simply lack it)
		"world": {"schema": WorldContract.SCHEMA_VERSION,
				"revision": WorldContract.WORLD_REVISION,
				"radius_m": WorldContract.RADIUS_M},
	}
	var player = get_tree().get_first_node_in_group("player")
	if player and player.get("pistol") != null:
		var wp: Node = player.pistol
		data["weapons"] = {"owned": wp.owned_weapons.keys(), "ammo": wp.ammo,
				"current": wp.weapon_id}
	if player:
		data["player"] = {
			"pos": [player.global_position.x, player.global_position.y, player.global_position.z],
			"health": player.health,
			"yaw": player.yaw,
			"mag": player.pistol.mag() if player.pistol else 12,
			"reserve": player.pistol.reserve() if player.pistol else 48,
		}
	var f = FileAccess.open(GameState.SAVE_PATH + ".tmp", FileAccess.WRITE)
	if f == null:
		GameState.notify("Save failed: cannot write file")
		return false
	f.store_string(JSON.stringify(data))
	f.flush()
	f.close()
	# Master plan v2.1 §56: never risk a partial write of the main save.
	# Write tmp -> flush -> atomic rename; remove tmp on any failure.
	if DirAccess.rename_absolute(GameState.SAVE_PATH + ".tmp", GameState.SAVE_PATH) != OK:
		DirAccess.remove_absolute(GameState.SAVE_PATH + ".tmp")
		GameState.notify("Save failed: cannot replace file")
		return false
	GameState.notify("Game saved")
	return true


## Loads and applies state. Returns true on success.
## Per-version schema migration chain. Each step upgrades the payload one
## version. Never breaks older saves silently; returns migrated data.
func migrate(data: Dictionary, from_version: int) -> Dictionary:
	var d: Dictionary = data.duplicate(true)
	if from_version < 2:
		d["owned"] = []
		d["world_flags"] = {}
		d["version"] = 2
	if from_version < 3:
		d["delivery"] = {}  # v3: courier mid-mission state (Round 9 S3)
		d["version"] = 3
	return d


## P02 §13: spatial compatibility for every save generation. The world grew
## from a 900x700 m rect to a 3000 m radius circle AROUND THE SAME ORIGIN, so
## every legacy coordinate remains valid; only positions outside the new
## circle are clamped (and every clamp is recorded as a migration event).
## Player state and mission data are never touched. Idempotent: sanitizing an
## already-sanitized payload changes nothing.
func _sanitize_spatial(parsed: Dictionary) -> Dictionary:
	var player: Variant = parsed.get("player", {})
	if player is Dictionary and not (player as Dictionary).is_empty():
		var pos: Variant = (player as Dictionary).get("pos", null)
		if pos is Array and (pos as Array).size() >= 3:
			var p := Vector3(float(pos[0]), float(pos[1]), float(pos[2]))
			if not WorldContract.is_playable(p):
				var c: Vector3 = WorldContract.clamp_position_to_world(p)
				(player as Dictionary)["pos"] = [c.x, c.y, c.z]
				var bus: Node = get_node_or_null("/root/EventBus")
				if bus != null and bus.has_method("record"):
					bus.record("WORLD_MIGRATED", {"kind": "position_clamped",
							"from": [p.x, p.y, p.z], "to": [c.x, c.y, c.z]})
				GameState.notify("Save migrated: position clamped into world bounds")
	parsed["world"] = {"schema": WorldContract.SCHEMA_VERSION,
			"revision": WorldContract.WORLD_REVISION}
	return parsed


## v2.4: active mission snapshot + completed ids ({} / [] when none).
func _mission_state() -> Dictionary:
	var mm: Node = get_tree().get_first_node_in_group("mission_manager")
	if mm and mm.has_method("save_snapshot"):
		return mm.save_snapshot()
	return {}


func _missions_done() -> Array:
	var mm: Node = get_tree().get_first_node_in_group("mission_manager")
	if mm and mm.has_method("completed_ids"):
		return mm.completed_ids()
	return []


## Round 9 S3: snapshot the active delivery ({} when idle).
func _delivery_state() -> Dictionary:
	var d: Node = get_tree().get_first_node_in_group("delivery")
	if d and d.has_method("state"):
		return d.state()
	return {}


func load_game() -> bool:
	if not has_save():
		GameState.notify("No save file found")
		return false
	var f = FileAccess.open(GameState.SAVE_PATH, FileAccess.READ)
	if f == null:
		GameState.notify("Load failed: cannot open file")
		return false
	var parsed: Variant = JSON.parse_string(f.get_as_text())
	if not (parsed is Dictionary) or int(parsed.get("version", 0)) > SAVE_VERSION:
		GameState.notify("Load failed: incompatible save")
		return false
	# Optional-field tolerant apply
	GameState.money = int(parsed.get("money", 500))
	GameState.set_wanted(int(parsed.get("wanted", 0)))
	GameState.day_time = float(parsed.get("day_time", 9.0))
	GameState.set_raining(bool(parsed.get("raining", false)))
	GameState.collected.clear()
	if parsed.get("collected", []) is Array:
		# tolerant-load fix (P02 suite gate #31): index-after-default crashed
		# on saves lacking the key; the header contract promises tolerance.
		for id: Variant in (parsed.get("collected", []) as Array):
			GameState.collected[str(id)] = true
	if parsed.get("stats", {}) is Dictionary:
		# same tolerant-load fix as "collected" above (P02 gate #31)
		var saved_stats: Dictionary = parsed.get("stats", {})
		for k: String in saved_stats.keys():  # audit #10: iterate SAVED keys
			if GameState.stats.has(k):  # audit #10: guard unknown keys
				GameState.stats[k] = saved_stats[k]
	# --- migration chain: upgrade payload, then apply ---
	parsed = migrate(parsed, int(parsed.get("version", 0)))
	# --- P02 §13: spatial schema compatibility (all save generations) ---
	parsed = _sanitize_spatial(parsed)
	# payload defines the full persistent state (replace, not merge)
	GameState.owned = {}
	GameState.world_flags = {}
	if parsed.get("owned") is Array:
		for id in parsed["owned"]:
			if GameState.PROPERTIES.has(str(id)):
				GameState.owned[str(id)] = true
	if parsed.get("world_flags") is Dictionary:
		GameState.world_flags = parsed["world_flags"]
	# Round 9 S4: restore weapon ownership + ammo pools
	var wsave: Variant = parsed.get("weapons", {})
	if wsave is Dictionary and not (wsave as Dictionary).is_empty():
		var wd: Dictionary = wsave
		var pnode: Node = get_tree().get_first_node_in_group("player")
		if pnode and pnode.get("pistol") != null:
			var wpn: Node = pnode.pistol
			wpn.owned_weapons = {"pistol": true}
			if wd.get("owned", []) is Array:
				for wid: Variant in wd["owned"]:
					if wpn.WEAPONS.has(str(wid)):
						wpn.owned_weapons[str(wid)] = true
			if wd.get("ammo", {}) is Dictionary:
				for wid2: String in wd["ammo"].keys():
					if wpn.ammo.has(wid2) and wd["ammo"][wid2] is Array:
						wpn.ammo[wid2] = [int(wd["ammo"][wid2][0]), int(wd["ammo"][wid2][1])]
			if wd.get("current", "") != "" and wpn.owned_weapons.get(str(wd["current"]), false):
				wpn.weapon_id = str(wd["current"])
	# Round 9 S3: resume an in-flight delivery after the world settled
	# (tolerant-load fix, P02 gate #31: no raw index after a .get default)
	var saved_delivery: Dictionary = parsed.get("delivery", {})
	if not saved_delivery.is_empty():
		var dnode: Node = get_tree().get_first_node_in_group("delivery")
		if dnode and dnode.has_method("restore"):
			dnode.restore(saved_delivery)
	# v2.4: restore mission progression + active mission (deferred world settled)
	var mm: Node = get_tree().get_first_node_in_group("mission_manager")
	if mm and mm.has_method("restore"):
		mm.restore(parsed.get("mission", {}), parsed.get("missions_done", []))

	var player: Dictionary = parsed.get("player", {})
	var p = get_tree().get_first_node_in_group("player")
	if p and not player.is_empty():
		var pos: Array = player.get("pos", [0, 1, 0])
		p.restore_from_save(Vector3(pos[0], pos[1], pos[2]),
				float(player.get("health", 100)), float(player.get("yaw", 0.0)),
				int(player.get("mag", 12)), int(player.get("reserve", 48)))
	GameState.money_changed.emit(GameState.money)
	GameState.time_changed.emit(GameState.day_time)
	GameState.load_applied.emit()
	GameState.notify("Game loaded")
	return true
