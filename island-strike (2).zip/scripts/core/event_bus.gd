extends Node
## EventBus — centralized event bus + ring log (master plan §39/§41).
## One subscribable signal (event_logged), one structured ring buffer.
## GameState signals are relayed here with structured payloads:
##   WANTED_CHANGED / MONEY_CHANGED / TIME_CHANGED (hour steps) / WEATHER_CHANGED
##   CRIME (structured record with witnesses per master plan §9)
## Systems record domain events via record(): PLAYER_DIED, NPC_DIED,
## PLAYER_ENTERED_VEHICLE, PLAYER_EXITED_VEHICLE, VEHICLE_STOLEN,
## ITEM_PURCHASED, TRANSACTION, TRANSACTION_DENIED, MISSION_STARTED,
## MISSION_COMPLETED, DEBUG_CMD, WORLD_EVENT.

signal event_logged(kind: String, data: Dictionary)

const LOG_CAP: int = 120
const WITNESS_RADIUS: float = 28.0

var log: Array = []
var _last_hour: int = -1


func _ready() -> void:
	var gs: Node = get_parent().get_node_or_null("GameState")
	if gs == null:
		return
	gs.wanted_changed.connect(func(v: int) -> void:
		record("WANTED_CHANGED", {"level": v}))
	gs.money_changed.connect(func(v: int) -> void:
		record("MONEY_CHANGED", {"balance": v}))
	gs.weather_changed.connect(func(r: bool) -> void:
		record("WEATHER_CHANGED", {"raining": r}))
	gs.player_damaged.connect(func() -> void:
		record("PLAYER_DAMAGED", {}))
	gs.time_changed.connect(func(hours: float) -> void:
		var h: int = int(hours)
		if h != _last_hour:
			_last_hour = h
			record("TIME_CHANGED", {"hour": h}))
	gs.crime_committed.connect(_on_crime)


## Structured crime record (master plan §9): type/position/time/suspect/
## witnesses/severity. Witness pass is distance-only (cheap, deterministic
## enough for reporting); LOS refinement stays in the police perception layer.
func _on_crime(severity: int, pos: Vector3) -> void:
	var witnesses: Array = []
	var gs: Node = get_parent().get_node_or_null("GameState")
	var civs: Array = []
	if gs != null and gs.has_method("get_cached_group"):
		civs = gs.get_cached_group("civilians")
	elif get_tree() != null:
		civs = get_tree().get_nodes_in_group("civilians")
	var day_hours: float = 12.0
	if gs != null:
		day_hours = float(gs.get("day_time"))
	# untyped loop: the cached group can hold freed instances between ticks;
	# validity check MUST precede the type check (freed `is` errors in 4.5)
	for c in civs:
		if witnesses.size() >= 8:
			break
		if is_instance_valid(c) and c is Node3D:
			if (c as Node3D).global_position.distance_to(pos) <= WITNESS_RADIUS:
				witnesses.append(c.get_instance_id())
	record("CRIME", {
		"severity": severity,
		"pos": pos,
		"day_time": day_hours,
		"witness_count": witnesses.size(),
		"witnesses": witnesses,
	})


## Public recording API — every domain event funnels through here.
func record(kind: String, data: Dictionary) -> void:
	var entry: Dictionary = {
		"t": Time.get_ticks_msec() / 1000.0,
		"kind": kind,
		"data": data,
	}
	log.append(entry)
	if log.size() > LOG_CAP:
		log = log.slice(log.size() - LOG_CAP)
	event_logged.emit(kind, data)


func tail(n: int) -> Array:
	if log.size() <= n:
		return log.duplicate(true)
	return log.slice(log.size() - n).duplicate(true)


func count_kind(kind: String) -> int:
	var n: int = 0
	for e: Dictionary in log:
		if str(e.get("kind")) == kind:
			n += 1
	return n


func clear_log() -> void:
	log.clear()
