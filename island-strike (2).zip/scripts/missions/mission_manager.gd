extends Node
## MissionManager — the game's central mission orchestrator (Master Plan v2.4).
## COORDINATES ONLY: registry, availability, state machine, objective stepping,
## checkpoints, cleanup, persistence, rewards-via-Economy, EventBus routing.
## It does NOT own AI, physics, combat, economy math, or rendering — it uses
## the existing systems (Economy, EventBus, SaveSystem, npc scenes, wanted).
## Single active primary mission (v2.4 §48). Event listeners are connected
## ONCE here; objective logic reads instance state — restart can never
## duplicate listeners (lifetime rule §43).

const EconomyRes := preload("res://scripts/core/economy.gd")
const Defs := preload("res://scripts/missions/mission_defs.gd")
const GangScene := preload("res://scripts/npc/npc_gang.gd")
const CivScene := preload("res://scripts/npc/npc_civilian.gd")

const TICK_HZ: float = 10.0
## §7 transition table (plan's extended states STARTING/CHECKPOINT/RESTARTING/
## CLEANUP are modeled as policies/events on this reduced deterministic set —
## see DEVELOPMENT_REPORT v2.4.1). Every state change must pass _transition().
const VALID_TRANSITIONS: Dictionary = {
	"AVAILABLE": ["ACTIVE"],
	"ACTIVE": ["COMPLETING", "FAILED", "ACTIVE"],  # ACTIVE->ACTIVE = checkpoint restart
	"COMPLETING": ["COMPLETED", "FAILED"],
	"COMPLETED": ["AVAILABLE"],  # only reached for repeatable release (replay support)
	"FAILED": ["AVAILABLE"],     # retry allowed
}
const STATES: Dictionary = {
	"AVAILABLE": 0, "ACTIVE": 1, "COMPLETING": 2, "COMPLETED": 3, "FAILED": 4,
}

var definitions: Dictionary = {}   # OWNED deep copy of Defs.DEFINITIONS
var states: Dictionary = {}        # id -> STATES[int] (never stored in defs)
var active_id: String = ""
var inst: Dictionary = {}          # active mission instance (see _new_instance)
var completed: Array = []          # mission ids finished (repeat="once")
var failed_count: Dictionary = {}  # id -> times failed (stats)
var _tick_acc: float = 0.0
var _last_rejected: Dictionary = {}  # last rejected transition (audit)
var _zones: Dictionary = {}        # id -> start-zone Node3D
var _markers: Array = []           # active objective marker nodes
var _bus: Node = null


func _ready() -> void:
	add_to_group("mission_manager")
	definitions = Defs.DEFINITIONS.duplicate(true)
	for id: String in definitions:
		states[id] = STATES["AVAILABLE"]
	_build_start_zones()
	_bus = get_tree().root.get_node_or_null("EventBus")
	if _bus != null:
		# ONE subscription for the whole manager lifetime (§43/§44)
		_bus.event_logged.connect(_on_event)


## §7/§67.2: single guarded gateway for every state change. Invalid
## transitions are rejected (recorded in _last_rejected, never applied).
func _transition(id: String, to: String, reason: String) -> bool:
	var from: String = "AVAILABLE"
	var cur: int = int(states.get(id, 0))
	for k: String in STATES:
		if int(STATES[k]) == cur:
			from = k
			break
	if not (to in VALID_TRANSITIONS.get(from, [])):
		_last_rejected = {"id": id, "from": from, "to": to, "reason": reason}
		return false
	states[id] = STATES[to]
	return true


# ------------------------------------------------------------ availability
func is_available(id: String) -> bool:
	var d: Dictionary = definitions.get(id, {})
	if d.is_empty():
		return false
	if int(states.get(id, STATES["AVAILABLE"])) != STATES["AVAILABLE"]:
		return false
	if str(d.get("repeat", "once")) == "once" and id in completed:
		return false
	if active_id != "":
		return false  # single primary mission
	return true


func available_ids() -> Array:
	var out: Array = []
	for id: String in definitions:
		if is_available(id):
			out.append(id)
	return out


# ------------------------------------------------------------ start / end
## start_mission starts a mission by id. opts may override time_limit for tests.
## Returns "OK: ..." or "ERR: ...".
func start_mission(id: String, opts: Dictionary = {}) -> String:
	if not definitions.has(id):
		return "ERR: unknown mission %s" % id
	if not is_available(id):
		return "ERR: mission %s not available (active=%s)" % [id, active_id]
	var d: Dictionary = definitions[id]
	inst = _new_instance(id, d, opts)
	active_id = id
	if not _transition(id, "ACTIVE", "started"):
		active_id = ""
		inst = {}
		return "ERR: invalid transition (%s)" % str(_last_rejected)
	_enter_objective(0)
	GameState.notify("MISSION STARTED: %s" % str(d["name"]))
	if _bus != null:
		_bus.record("MISSION_STARTED", {"id": id})
	_zone_visible(id, false)
	return "OK: started %s" % id


func _new_instance(id: String, d: Dictionary, opts: Dictionary) -> Dictionary:
	return {
		"id": id,
		"objective_index": -1,
		"time_left": float(opts.get("time_limit", d.get("time_limit", 0.0))),
		"elapsed": 0.0,
		"actors": {},          # role -> instance_id (int)
		"checkpoint": 0,       # objective index to restart from
		"flags": {},           # mission-local variables (package carried etc.)
		"failure_reason": "",
	}


func _finish(success: bool, reason: String) -> String:
	if active_id == "" or inst.is_empty():
		return "ERR: no active mission"
	var id: String = active_id
	var d: Dictionary = definitions[id]
	if not _transition(id, "COMPLETING", reason if not success else "objectives complete"):
		return "ERR: invalid transition (%s)" % str(_last_rejected)
	if success:
		var reward: int = int(d.get("reward", 0))
		# §46 idempotency: reward paid exactly here, exactly once — the state
		# gate above plus immediate ACTIVE-clear makes re-entry impossible.
		if reward > 0:
			EconomyRes.earn(reward, "mission_reward:%s" % id)
			GameState.notify("MISSION COMPLETE: %s (+$%d)" % [str(d["name"]), reward])
		else:
			GameState.notify("MISSION COMPLETE: %s" % str(d["name"]))
		if str(d.get("repeat", "once")) == "once" and not (id in completed):
			completed.append(id)
		if _bus != null:
			_bus.record("MISSION_COMPLETED", {"id": id, "reward": reward})
		_transition(id, "COMPLETED", "reward paid")
	else:
		_transition(id, "FAILED", reason)
		failed_count[id] = int(failed_count.get(id, 0)) + 1
		GameState.notify("MISSION FAILED: %s — %s" % [str(d["name"]), reason])
		if _bus != null:
			_bus.record("MISSION_FAILED", {"id": id, "reason": reason})
	# release: repeatable COMPLETED -> AVAILABLE (explicit replay support);
	# once-missions stay terminal COMPLETED; FAILED always retries to AVAILABLE
	if success:
		if str(d.get("repeat", "once")) == "repeatable":
			_transition(id, "AVAILABLE", "repeatable release")
	else:
		_transition(id, "AVAILABLE", "retry allowed")
	_cleanup_actors()
	_clear_markers()
	_zone_visible(id, true)
	get_tree().call_group("hud", "set_mission_text", "")
	inst = {}
	active_id = ""
	return "OK: %s finished (%s)" % [id, "complete" if success else reason]


func abandon() -> String:
	if active_id == "":
		return "ERR: no active mission"
	var mid: String = active_id
	var out: String = _finish(false, "abandoned")
	if _bus != null:
		_bus.record("MISSION_ABANDONED", {"id": mid})
	return out


func fail(reason: String) -> String:
	return _finish(false, reason)


# ------------------------------------------------------------- objectives
func _objective() -> Dictionary:
	var objs: Array = definitions[active_id]["objectives"]
	var i: int = int(inst["objective_index"])
	if i < 0 or i >= objs.size():
		return {}
	return objs[i]


func _enter_objective(i: int) -> void:
	var objs: Array = definitions[active_id]["objectives"]
	if i >= objs.size():
		_finish(true, "done")
		return
	inst["objective_index"] = i
	var o: Dictionary = objs[i]
	_spawn_objective_actors(o)
	_place_marker(o)
	var label: String = "%d/%d %s" % [i + 1, objs.size(), str(o["text"])]
	GameState.notify("OBJECTIVE: " + label)
	get_tree().call_group("hud", "set_mission_text", label)
	if bool(o.get("checkpoint", false)):
		inst["checkpoint"] = i


func _complete_objective() -> void:
	_enter_objective(int(inst["objective_index"]) + 1)


## Spawn actors bound to this objective (ELIMINATE target / PROTECT vip).
## Mission owns the references (§16): ids recorded, cleanup guaranteed.
func _spawn_objective_actors(o: Dictionary) -> void:
	var kind: String = str(o.get("type", ""))
	var at: Vector3 = o.get("pos", Vector3.ZERO) if o.get("pos") != null else Vector3.ZERO
	if kind == "ELIMINATE":
		var territory: Rect2 = GameState.world_data.get("gang_territory",
				Rect2(at.x - 10, at.y - 10, 20, 20))
		var gang: CharacterBody3D = GangScene.create_in(territory)
		gang.position = at
		add_child(gang)
		inst["actors"]["target"] = gang.get_instance_id()
	elif kind == "PROTECT":
		var vip: CharacterBody3D = CivScene.create()
		vip.position = at
		add_child(vip)
		inst["actors"]["vip"] = vip.get_instance_id()


func _cleanup_actors() -> void:
	for role: String in inst.get("actors", {}).keys():
		var nid: int = int(inst["actors"][role])
		var node: Node = _node_by_id(nid)
		if node != null and is_instance_valid(node):
			node.queue_free()
	inst.get("actors", {}).clear()


func _node_by_id(id: int) -> Node:
	return instance_from_id(id) if id != 0 else null


# ------------------------------------------------------------ update tick
func _process(delta: float) -> void:
	_tick_acc += delta
	if _tick_acc < 1.0 / TICK_HZ:
		return
	_tick_acc = 0.0
	if active_id == "" or inst.is_empty():
		return
	inst["elapsed"] = float(inst["elapsed"]) + 0.1
	var limit: float = float(inst["time_left"])
	if limit > 0.0:
		inst["time_left"] = limit - 0.1
		if float(inst["time_left"]) <= 0.0:
			_finish(false, "time expired")
			return
	var o: Dictionary = _objective()
	if o.is_empty():
		return
	var p: Node = get_tree().get_first_node_in_group("player")
	if p == null or not (p is Node3D):
		return
	var ppos: Vector3 = (p as Node3D).global_position
	var kind: String = str(o.get("type", ""))
	match kind:
		"GO_TO", "DELIVER", "COLLECT", "INTERACT":
			var pos: Vector3 = o.get("pos", Vector3.ZERO)
			var radius: float = float(o.get("radius", 4.0))
			if ppos.distance_to(pos) <= radius:
				if kind == "INTERACT" or kind == "COLLECT":
					if not Input.is_action_pressed("interact"):
						return  # wait for the player to interact
				if kind == "DELIVER" and not bool(inst["flags"].get("carrying", false)):
					return
				if kind == "COLLECT":
					inst["flags"]["carrying"] = true
				_complete_objective()
		"ESCAPE":
			if GameState.wanted == 0:
				_complete_objective()
		"SURVIVE", "WAIT":
			if float(inst["elapsed"]) >= float(o.get("duration", 10.0)):
				_complete_objective()
		"ENTER_VEHICLE":
			pass  # event-driven via _on_event


# ------------------------------------------------------------ event route
func _on_event(kind: String, data: Dictionary) -> void:
	if active_id == "" or inst.is_empty():
		return

	match kind:
		"PLAYER_DIED":
			_finish(false, "you died")
		"NPC_DIED":
			var nid: int = int(data.get("node", 0))
			var o: Dictionary = _objective()
			if o.is_empty():
				return
			var okind: String = str(o.get("type", ""))
			if okind == "ELIMINATE" and nid == int(inst["actors"].get("target", 0)):
				_complete_objective()
			elif okind == "PROTECT" and nid == int(inst["actors"].get("vip", 0)):
				_finish(false, "the protected npc was killed")
		"PLAYER_ENTERED_VEHICLE":
			var o2: Dictionary = _objective()
			if str(o2.get("type", "")) == "ENTER_VEHICLE":
				_complete_objective()
		"WANTED_CHANGED":
			pass  # ESCAPE polls wanted at tick (cheap); no action needed


# ------------------------------------------------------- restart / markers
## Restart from the mission's last checkpoint: fresh actors, objective index
## restored, timers reset (v2.4 §19/§30). World/player state untouched.
func restart() -> String:
	if active_id == "" or inst.is_empty():
		return "ERR: no active mission"
	var id: String = active_id
	var d: Dictionary = definitions[id]
	var cp: int = int(inst["checkpoint"])
	var opts: Dictionary = {"time_limit": d.get("time_limit", 0.0)}
	_cleanup_actors()
	_clear_markers()
	inst = _new_instance(id, d, opts)
	if not _transition(id, "ACTIVE", "checkpoint restart"):
		return "ERR: invalid transition (%s)" % str(_last_rejected)
	_enter_objective(cp)
	GameState.notify("MISSION RESTARTED from checkpoint")
	return "OK: restarted %s at objective %d" % [id, cp]


func _build_start_zones() -> void:
	for id: String in definitions:
		var d: Dictionary = definitions[id]
		var z: Node3D = Node3D.new()
		z.name = "MissionZone_" + id
		z.position = d.get("start", Vector3.ZERO)
		var ring: MeshInstance3D = MeshInstance3D.new()
		var tm := TorusMesh.new()
		tm.inner_radius = 1.6
		tm.outer_radius = 2.0
		var mat: StandardMaterial3D = StandardMaterial3D.new()
		mat.albedo_color = Color(1.0, 0.8, 0.2)
		mat.emission_enabled = true
		mat.emission = Color(1.0, 0.75, 0.15)
		mat.emission_energy_multiplier = 1.2
		tm.material = mat
		ring.mesh = tm
		ring.position.y = 0.1
		z.add_child(ring)
		var area: Area3D = Area3D.new()
		area.collision_layer = 0
		area.collision_mask = 2
		var cs: CollisionShape3D = CollisionShape3D.new()
		var ss := SphereShape3D.new()
		ss.radius = 2.6
		cs.shape = ss
		cs.position.y = 1.0
		area.add_child(cs)
		z.add_child(area)
		# method callable + bind: no lambda captures (freed-capture-proof, §43)
		area.body_entered.connect(_on_zone_entered.bind(id))
		add_child(z)
		_zones[id] = z


func _on_zone_entered(_b: Node3D, mid: String) -> void:
	if is_available(mid):
		start_mission(mid)


func _zone_visible(id: String, vis: bool) -> void:
	var z: Node = _zones.get(id)
	if z != null and is_instance_valid(z):
		z.visible = vis
		z.get_child(1).set_deferred("monitoring", vis)


## Objective marker: glowing pillar at the objective position (§32).
func _place_marker(o: Dictionary) -> void:
	_clear_markers()
	var pos: Vector3 = o.get("pos", Vector3.ZERO)
	if pos == Vector3.ZERO:
		return
	var m: MeshInstance3D = MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.6
	cm.bottom_radius = 0.6
	cm.height = 12.0
	var mat: StandardMaterial3D = StandardMaterial3D.new()
	mat.albedo_color = Color(0.2, 0.9, 0.4, 0.5)
	mat.emission_enabled = true
	mat.emission = Color(0.2, 0.9, 0.4)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	cm.material = mat
	m.mesh = cm
	m.position = pos + Vector3(0, 6, 0)
	add_child(m)
	_markers.append(m)


func _clear_markers() -> void:
	for m: Node in _markers:
		if is_instance_valid(m):
			m.queue_free()
	_markers.clear()


# ------------------------------------------------------------ persistence
## Snapshot for SaveSystem (§39: ids and state only, no node references).
func save_snapshot() -> Dictionary:
	if active_id == "" or inst.is_empty():
		return {}
	var actors_out: Array = []
	for role: String in inst["actors"].keys():
		var n: Node = _node_by_id(int(inst["actors"][role]))
		if n != null and is_instance_valid(n) and n is Node3D:
			actors_out.append({"role": role, "kind": "actor",
					"pos": [(n as Node3D).global_position.x,
							(n as Node3D).global_position.y,
							(n as Node3D).global_position.z]})
	return {"id": active_id, "objective_index": int(inst["objective_index"]),
			"checkpoint": int(inst["checkpoint"]), "elapsed": float(inst["elapsed"]),
			"time_left": float(inst["time_left"]), "flags": inst["flags"],
			"actors": actors_out}


func completed_ids() -> Array:
	return completed.duplicate()


## Restore after a save/load. Deferred by SaveSystem (world settles first).
func restore(snap: Dictionary, done: Array) -> void:
	# REPLACE semantics (SaveSystem doctrine: the payload defines the full
	# persistent state). Merge kept stale progression on legacy saves (R17 fix).
	completed.clear()
	for id: String in definitions:
		states[id] = STATES["AVAILABLE"]
	for id: Variant in done:
		var sid: String = str(id)
		if definitions.has(sid) and not (sid in completed):
			completed.append(sid)
			if str(definitions[sid].get("repeat", "once")) != "repeatable":
				states[sid] = STATES["COMPLETED"]  # terminal for once-missions
	if snap.is_empty():
		# payload has no active mission: deterministically drop any in-memory one
		if active_id != "":
			_cleanup_actors()
			_clear_markers()
			_zone_visible(active_id, true)
			get_tree().call_group("hud", "set_mission_text", "")
			inst = {}
			active_id = ""
		return
	var id2: String = str(snap.get("id", ""))
	if not definitions.has(id2):
		return
	# resume overrides any in-memory active mission (payload is authoritative);
	# progression reset above already put every state on AVAILABLE
	if active_id != "" and active_id != id2:
		_cleanup_actors()
		_clear_markers()
	var d: Dictionary = definitions[id2]
	inst = _new_instance(id2, d, {})
	inst["objective_index"] = int(snap.get("objective_index", 0))
	inst["checkpoint"] = int(snap.get("checkpoint", 0))
	inst["elapsed"] = float(snap.get("elapsed", 0.0))
	inst["time_left"] = float(snap.get("time_left", 0.0))
	if snap.get("flags", {}) is Dictionary:
		inst["flags"] = snap["flags"]
	active_id = id2
	if not _transition(id2, "ACTIVE", "restored from save"):
		active_id = ""
		inst = {}
		return
	_zone_visible(id2, false)
	# _enter_objective spawns the bound actors fresh (no duplicate-instance
	# resurrection); saved positions are then re-applied to those actors
	_enter_objective(int(inst["objective_index"]))
	for a: Dictionary in snap.get("actors", []):
		var role: String = str(a.get("role", ""))
		var nid: int = int(inst["actors"].get(role, 0))
		var node: Node = _node_by_id(nid)
		if node != null and is_instance_valid(node) and node is Node3D:
			var parr: Array = a.get("pos", [0, 0, 0])
			(node as Node3D).global_position = Vector3(float(parr[0]),
					float(parr[1]), float(parr[2]))
	GameState.notify("Mission resumed: %s" % str(d["name"]))
