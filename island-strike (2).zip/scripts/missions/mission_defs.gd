extends Object
## Mission definitions — pure DATA (v2.4 §6/§49): adding a mission means
## adding an entry here, not editing the engine. Objectives reference world
## positions already established by locked content (bank/storefront row,
## harbor office, warehouse, gang territory, safehouse).
##
## Objective fields: type, text, pos, radius, [checkpoint], [duration].
## Types: GO_TO, INTERACT, COLLECT, DELIVER, ENTER_VEHICLE, ELIMINATE,
##        PROTECT, ESCAPE, SURVIVE, WAIT.

const DEFINITIONS: Dictionary = {
	"bank_run": {
		"name": "Bank Run",
		"brief": "Grab the ledger package from the downtown bank and run it to the harbor office.",
		"district": "Downtown",
		"start": Vector3(-281, 0.4, -172),
		"reward": 400,
		"repeat": "once",
		"time_limit": 0.0,  # untimed
		"objectives": [
			{"type": "GO_TO", "text": "Reach the downtown bank",
				"pos": Vector3(-281, 0.4, -202), "radius": 6.0, "checkpoint": true},
			{"type": "COLLECT", "text": "Collect the ledger package",
				"pos": Vector3(-281, 0.4, -202), "radius": 5.0},
			{"type": "GO_TO", "text": "Carry the package to the harbor office",
				"pos": Vector3(-560, 0.4, 230), "radius": 8.0, "checkpoint": true},
			{"type": "INTERACT", "text": "Hand over the package",
				"pos": Vector3(-560, 0.4, 230), "radius": 8.0},
		],
	},
	"dock_cleanup": {
		"name": "Dock Cleanup",
		"brief": "A Dockside Crew lieutenant is shaking down the docks. Remove him.",
		"district": "Industrial",
		"start": Vector3(370, 0.4, 240),
		"reward": 350,
		"repeat": "repeatable",
		"time_limit": 0.0,
		"objectives": [
			{"type": "GO_TO", "text": "Head to the industrial docks",
				"pos": Vector3(400, 0.4, 262), "radius": 10.0, "checkpoint": true},
			{"type": "ELIMINATE", "text": "Eliminate the crew lieutenant",
				"pos": Vector3(408, 0.4, 270), "radius": 6.0},
		],
	},
	"safe_passage": {
		"name": "Safe Passage",
		"brief": "Walk a nervous witness from the suburbs to the farmland safehouse.",
		"district": "Suburbs",
		"start": Vector3(-120, 0.4, -180),
		"reward": 450,
		"repeat": "once",
		"time_limit": 240.0,
		"objectives": [
			{"type": "PROTECT", "text": "Meet the witness at the suburbs corner",
				"pos": Vector3(-120, 0.4, -200), "radius": 8.0, "checkpoint": true},
			{"type": "GO_TO", "text": "Escort the witness to the safehouse road",
				"pos": Vector3(-165, 0.4, -232), "radius": 10.0},
		],
	},
	"getaway_car": {
		"name": "Getaway Car",
		"brief": "Boost any car near the industrial garage and leave it at the drop lane.",
		"district": "Industrial",
		"start": Vector3(350, 0.4, 230),
		"reward": 150,
		"repeat": "repeatable",
		"time_limit": 0.0,
		"objectives": [
			{"type": "ENTER_VEHICLE", "text": "Steal a car",
				"pos": Vector3.ZERO, "radius": 0.0, "checkpoint": true},
			{"type": "GO_TO", "text": "Park it at the drop lane",
				"pos": Vector3(300, 0.4, 200), "radius": 10.0},
		],
	},
	"warehouse_job": {
		"name": "Warehouse Job",
		"brief": "Hit the harbor warehouse, grab the goods, and lose the heat before the drop.",
		"district": "Industrial",
		"start": Vector3(330, 0.4, 220),
		"reward": 600,
		"repeat": "once",
		"time_limit": 300.0,
		"objectives": [
			{"type": "GO_TO", "text": "Enter the warehouse yard",
				"pos": Vector3(420, 0.4, 270), "radius": 14.0, "checkpoint": true},
			{"type": "COLLECT", "text": "Grab the goods",
				"pos": Vector3(420, 0.4, 270), "radius": 10.0},
			{"type": "ESCAPE", "text": "Lose the heat (wanted 0)",
				"pos": Vector3.ZERO, "radius": 0.0, "checkpoint": true},
			{"type": "GO_TO", "text": "Deliver the goods to the safehouse",
				"pos": Vector3(-165, 0.4, -240), "radius": 8.0},
		],
	},
}
