extends Node
class_name WorldSim
## Weather 2.0 + Slow Transitions — Realistic Environment
## Implements: CLEAR → PARTLY_CLOUDY → CLOUDY → DARK_CLOUDS → LIGHT_RAIN → RAIN → HEAVY_RAIN → STORM
## Transitions over MINUTES, not seconds, with smooth interpolation of
## cloud density, rain, fog, wind, lighting, wetness, thunder, puddles
## Don't instantly reset world to dry — puddles slowly disappear, ground dries

signal weather_changed(state: String)

const STATES := ["CLEAR", "PARTLY_CLOUDY", "CLOUDY", "DARK_CLOUDS", "LIGHT_RAIN", "RAIN", "HEAVY_RAIN", "STORM", "FOG"]
## Weighted chain — believable evolution, no instant desert↔storm
const CHAIN := {
	"CLEAR": [["CLEAR", 5], ["PARTLY_CLOUDY", 4], ["CLOUDY", 1]],
	"PARTLY_CLOUDY": [["CLEAR", 2], ["PARTLY_CLOUDY", 3], ["CLOUDY", 4], ["DARK_CLOUDS", 1]],
	"CLOUDY": [["PARTLY_CLOUDY", 3], ["CLOUDY", 2], ["DARK_CLOUDS", 3], ["FOG", 1], ["LIGHT_RAIN", 1]],
	"DARK_CLOUDS": [["CLOUDY", 2], ["DARK_CLOUDS", 2], ["LIGHT_RAIN", 4], ["RAIN", 2]],
	"LIGHT_RAIN": [["DARK_CLOUDS", 2], ["LIGHT_RAIN", 2], ["RAIN", 4], ["CLOUDY", 1]],
	"RAIN": [["LIGHT_RAIN", 2], ["RAIN", 3], ["HEAVY_RAIN", 3], ["CLOUDY", 2]],
	"HEAVY_RAIN": [["RAIN", 3], ["HEAVY_RAIN", 3], ["STORM", 2], ["CLOUDY", 1]],
	"STORM": [["HEAVY_RAIN", 4], ["STORM", 2], ["RAIN", 2]],
	"FOG": [["CLEAR", 2], ["CLOUDY", 3], ["FOG", 1], ["PARTLY_CLOUDY", 2]],
}

var state: String = "CLEAR"
var target_state: String = "CLEAR"
var state_t: float = 90.0
var transition_t: float = 0.0  # 0.0→1.0 lerp over 90s (slow)
var transition_duration: float = 90.0
var _game: Node

# Slow interpolation targets
var _target_fog: float = 0.0008
var _target_sun: float = 1.2
var _target_rain: float = 0.0
var _target_wet: float = 0.0
var _target_wind: float = 0.0
var _target_cloud: float = 0.0

static func create(game: Node) -> WorldSim:
	var ws: WorldSim = WorldSim.new()
	ws.name = "WorldSim"
	ws._game = game
	return ws

func _ready() -> void:
	var initial: String = "CLEAR"
	if GameState.raining:
		initial = "HEAVY_RAIN" if GameState.heavy_rain else "RAIN"
	set_state(initial, true)
	_apply_targets(initial)

func _process(delta: float) -> void:
	state_t -= delta
	
	# Slow transition lerp — over minutes, not seconds
	if state != target_state:
		transition_t = move_toward(transition_t, 1.0, delta / transition_duration)
		_lerp_weather(delta)
		if transition_t >= 1.0:
			state = target_state
			transition_t = 0.0
			# Apply final state
			GameState.set_raining(target_state in ["LIGHT_RAIN", "RAIN", "HEAVY_RAIN", "STORM"])
			GameState.heavy_rain = target_state in ["HEAVY_RAIN", "STORM"]
			if _game and _game.has_method("apply_weather"):
				_game.apply_weather(target_state)
	else:
		# In stable state, slowly evolve
		if state_t <= 0.0:
			_evolve()

func _lerp_weather(delta: float) -> void:
	# Smoothly interpolate fog, sun, rain, wetness, wind, lighting, thunder, puddles
	if _game == null:
		return
	# Lerp fog density
	var current_fog: float = _game.get("_wx_fog") if _game.get("_wx_fog") != null else 0.0008
	var new_fog = lerpf(current_fog, _target_fog, delta * 0.5)
	_game.set("_wx_fog", new_fog)
	# Lerp sun
	var current_sun: float = _game.get("_wx_sun") if _game.get("_wx_sun") != null else 1.2
	var new_sun = lerpf(current_sun, _target_sun, delta * 0.5)
	_game.set("_wx_sun", new_sun)
	# Lerp wetness (road darkens + sheens)
	var current_wet: float = _game.get("_wet") if _game.get("_wet") != null else 0.0
	var new_wet = lerpf(current_wet, _target_wet, delta * 0.3)
	_game.set("_wet", new_wet)
	# Rain particles amount lerp (not instant toggle)
	# Handled in game.gd _update_rain via _wet

func _apply_targets(s: String) -> void:
	# Set target values for lerp based on state
	match s:
		"CLEAR":
			_target_fog = 0.0008
			_target_sun = 1.2
			_target_rain = 0.0
			_target_wet = 0.0
			_target_wind = 0.1
			_target_cloud = 0.0
		"PARTLY_CLOUDY":
			_target_fog = 0.002
			_target_sun = 1.0
			_target_rain = 0.0
			_target_wet = 0.0
			_target_wind = 0.2
			_target_cloud = 0.3
		"CLOUDY":
			_target_fog = 0.0045
			_target_sun = 0.85
			_target_rain = 0.0
			_target_wet = 0.0
			_target_wind = 0.3
			_target_cloud = 0.6
		"DARK_CLOUDS":
			_target_fog = 0.006
			_target_sun = 0.65
			_target_rain = 0.0
			_target_wet = 0.1
			_target_wind = 0.5
			_target_cloud = 0.85
		"LIGHT_RAIN":
			_target_fog = 0.007
			_target_sun = 0.55
			_target_rain = 0.3
			_target_wet = 0.3
			_target_wind = 0.6
			_target_cloud = 0.9
		"RAIN":
			_target_fog = 0.008
			_target_sun = 0.45
			_target_rain = 0.7
			_target_wet = 0.6
			_target_wind = 0.7
			_target_cloud = 1.0
		"HEAVY_RAIN":
			_target_fog = 0.012
			_target_sun = 0.35
			_target_rain = 1.0
			_target_wet = 0.9
			_target_wind = 0.9
			_target_cloud = 1.0
		"STORM":
			_target_fog = 0.015
			_target_sun = 0.25
			_target_rain = 1.2
			_target_wet = 1.0
			_target_wind = 1.2
			_target_cloud = 1.0
		"FOG":
			_target_fog = 0.02
			_target_sun = 0.7
			_target_rain = 0.0
			_target_wet = 0.2
			_target_wind = 0.1
			_target_cloud = 0.5

func _evolve() -> void:
	var options: Array = CHAIN.get(state, [["CLEAR", 1]])
	var total: int = 0
	for o: Array in options:
		total += int(o[1])
	var roll = randi() % total
	for o: Array in options:
		roll -= int(o[1])
		if roll < 0:
			_set_target(String(o[0]))
			return
	_set_target("CLEAR")

func _set_target(s: String) -> void:
	if not STATES.has(s):
		return
	target_state = s
	transition_t = 0.0
	transition_duration = randf_range(60.0, 120.0)  # 1-2 minutes transition (slow)
	_apply_targets(s)
	state_t = randf_range(90.0, 180.0)  # stable state duration 1.5-3 minutes
	var labels: Dictionary = {
		"CLEAR": "Skies clearing.",
		"PARTLY_CLOUDY": "Partly cloudy.",
		"CLOUDY": "Clouds rolling in.",
		"DARK_CLOUDS": "Dark clouds gathering...",
		"LIGHT_RAIN": "Light rain starting...",
		"RAIN": "Rain moving in.",
		"HEAVY_RAIN": "HEAVY RAIN — roads are slick!",
		"STORM": "STORM! Take cover!",
		"FOG": "Fog bank rolling over the island.",
	}
	GameState.notify(labels.get(s, s))
	weather_changed.emit(s)
	# Don't instantly set raining — lerp will handle it, but set target for audio
	# Audio will follow via _lerp_weather

func cycle() -> void:
	var i = STATES.find(target_state)
	_set_target(STATES[(i + 1) % STATES.size()])

func set_state(s: String, silent := false) -> void:
	if not STATES.has(s):
		return
	state = s
	target_state = s
	transition_t = 1.0
	state_t = randf_range(75.0, 140.0)
	_apply_targets(s)
	GameState.set_raining(s in ["LIGHT_RAIN", "RAIN", "HEAVY_RAIN", "STORM"])
	GameState.heavy_rain = s in ["HEAVY_RAIN", "STORM"]
	if _game and _game.has_method("apply_weather"):
		_game.apply_weather(s)
	if not silent:
		var labels: Dictionary = {
			"CLEAR": "Skies clearing.", "PARTLY_CLOUDY": "Partly cloudy.",
			"CLOUDY": "Clouds rolling in.", "DARK_CLOUDS": "Dark clouds gathering...",
			"LIGHT_RAIN": "Light rain...", "RAIN": "Rain moving in.",
			"HEAVY_RAIN": "HEAVY RAIN — roads are slick!", "STORM": "STORM!",
			"FOG": "Fog bank rolling over the island.",
		}
		GameState.notify(labels.get(s, s))
	weather_changed.emit(s)

func day_phase() -> String:
	return GameState.day_phase()
