class_name WorldBoundsGuard
extends Node
## P03 §8/§20: hard actor containment. Every player/vehicle position is
## clamped inside the world circle each physics tick — the single RADIUS
## authority (WorldContract) minus a 3 m skin, so actors can never leave the
## playable disc (no void escapes, no out-of-world geometry loading).
## Deterministic clamp (radial projection), zero allocations per tick.

const SKIN_M := 3.0

var _limit: float = WorldContract.RADIUS_M - SKIN_M
var _actors: Array[Node3D] = []
var _last_scan: int = 0


func _physics_process(_d: float) -> void:
	# rescan cheaply every ~2 s so spawned vehicles are covered
	var now: int = Time.get_ticks_msec()
	if now - _last_scan > 2000:
		_last_scan = now
		_actors.clear()
		for g: String in ["player", "cars"]:
			for n: Node in get_tree().get_nodes_in_group(g):
				if n is Node3D:
					_actors.append(n)
	for a: Node3D in _actors:
		if not is_instance_valid(a):
			continue
		var gp: Vector3 = a.global_position
		var flat := Vector2(gp.x, gp.z)
		var r: float = flat.length()
		if r > _limit:
			flat = flat * (_limit / r)
			a.global_position = Vector3(flat.x, gp.y, flat.y)
			if a is CharacterBody3D:
				(a as CharacterBody3D).velocity.x = minf((a as CharacterBody3D).velocity.x, 0.0) \
						if gp.x > 0.0 else maxf((a as CharacterBody3D).velocity.x, 0.0)
				(a as CharacterBody3D).velocity.z = minf((a as CharacterBody3D).velocity.z, 0.0) \
						if gp.z > 0.0 else maxf((a as CharacterBody3D).velocity.z, 0.0)
