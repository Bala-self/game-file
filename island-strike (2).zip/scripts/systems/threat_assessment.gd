class_name ThreatAssessment
extends Node
## Threat Assessment System — separates "detected" from "wanted level"
## Central system for police behavior branching on threat, not just wanted

enum ThreatLevel { NONE, LOW, MEDIUM, HIGH, LETHAL }

static func assess(player: Node, police_pos: Vector3, wanted: int) -> int:
	if player == null or not is_instance_valid(player):
		return ThreatLevel.NONE
	if player.has_method("get") and player.get("health") != null and int(player.get("health")) <= 0:
		return ThreatLevel.NONE
	if wanted >= 4:
		return ThreatLevel.LETHAL
	
	var has_weapon: bool = false
	var is_aiming_at_police: bool = false
	var is_shooting: bool = false
	var speed: float = 0.0
	var is_in_vehicle: bool = false
	
	if player.has_method("get"):
		var pistol: Node = player.get("pistol")
		if pistol != null and pistol.has_method("get"):
			has_weapon = true
			# Check if aiming
			if player.get("aiming") != null and bool(player.get("aiming")):
				is_aiming_at_police = true
		var driving: Node = player.get("driving_car")
		if driving != null:
			is_in_vehicle = true
			if driving.has_method("get"):
				var vel: Vector3 = driving.get("velocity") if driving.get("velocity") != null else Vector3.ZERO
				speed = vel.length()
	
	if wanted >= 2 and has_weapon and is_aiming_at_police:
		return ThreatLevel.HIGH
	if wanted >= 3 and has_weapon:
		return ThreatLevel.HIGH
	if wanted >= 2 and has_weapon:
		return ThreatLevel.MEDIUM
	if wanted >= 1:
		return ThreatLevel.LOW
	return ThreatLevel.NONE

static func should_shoot(threat: int, wanted: int, has_los: bool, dist: float) -> bool:
	# Critical rule: No wanted star → no automatic shooting
	if wanted == 0:
		return false
	if not has_los:
		return false
	if threat == ThreatLevel.LETHAL:
		return true
	if threat == ThreatLevel.HIGH and wanted >= 2:
		return true
	if threat == ThreatLevel.MEDIUM and wanted >= 3 and dist < 30.0:
		return true
	if wanted >= 4:
		return true  # shoot on sight policy at 4+
	return false

static func should_arrest(threat: int, wanted: int, dist: float) -> bool:
	if wanted == 0:
		return false
	if threat == ThreatLevel.NONE or threat == ThreatLevel.LOW:
		if dist < 3.5 and wanted <= 2:
			return true
	return false
