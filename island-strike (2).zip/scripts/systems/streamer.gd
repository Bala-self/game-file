class_name Streamer
extends Node
## World streaming (Phase 6; Prompt 02 rebuild): sector-driven streaming over
## the authoritative circular world contract. Tiles are 125 m MICRO SECTORS
## from WorldContract (no fixed grid size, no rectangular island assumption):
## tile keys are world_to_micro_sector indices, and only circle-valid sectors
## stream — geometry outside the world circle falls into the always-on bucket.
## Static world geometry is bucketed by sector at registration; sectors around
## the player are ACTIVE (visible + collidable), the 1-ring neighborhood is
## NEAR (identical to ACTIVE — pre-activated so collision can never be missing
## at speed), everything farther is FAR (hidden, collision layer 0, processing
## off). Nothing is freed (memory is cheap at this scale; LOD culling comes
## with the sim-tier phase).
## Correctness contract: a sector can only lose collision when the player is
## >= 2 sectors (250 m) away; re-activation is instantaneous and applied
## before the next physics step (process_priority default runs _process first).
## Predictive activation hook (P02 §14): _tile_of() is the single
## position->sector authority, so velocity look-ahead can be added by feeding
## it a predicted position without touching the band machinery.

const TILE := WorldContract.MICRO_SECTOR_M  # 125 m streaming sector
## Never streamed: environment-scale nodes (ground, water, sky-lit slabs).
const MIN_AABB := 150.0
## Groups excluded (dynamic sims own their lifecycle).
const EXCLUDE_GROUPS := ["player", "cars", "civilians", "police", "gangs",
		"pickups", "street_lamps", "lighthouse_lights", "terrain_chunks"]

var _tiles: Dictionary = {}  # Vector2i -> {bodies: Array[Node], visuals: Array[Node]}
var _always: Array[Node] = []
var _player: Node3D
var _last_tile: Vector2i = Vector2i(9999, 9999)
## Round 11: activation budget — collision toggles are queued and drained at
## OPS_PER_FRAME per physics tick. The player's own tile applies instantly
## (correctness contract: never a live step without the floor underfoot);
## the rest spreads across frames so a band flip costs one small pair-burst
## instead of one 25 ms solver spike (measured, tools/perf_probe.gd).
var _pending: Array = []  # [{tile: Vector2i, on: bool}]
var _pending_tiles: Dictionary = {}
const OPS_PER_FRAME := 300  # bodies per physics tick


static func create(player: Node3D) -> Streamer:
	var s: Streamer = Streamer.new()
	s.name = "Streamer"
	s.add_to_group("streamer")
	s._player = player  # initial reference; _process re-resolves per frame
	return s


func _register(n: Node, aabb_size: float) -> void:
	for g: String in EXCLUDE_GROUPS:
		if n.is_in_group(g):
			return
	if aabb_size >= MIN_AABB:
		_always.append(n)
		return
	var p = (n as Node3D).global_position
	var t: Vector2i = _tile_of(p)
	if not WorldContract.micro_sector_is_valid(t):
		_always.append(n)  # outside the playable world circle
		return
	if not _tiles.has(t):
		_tiles[t] = {"bodies": [], "visuals": []}
	if n is CollisionObject3D:
		_tiles[t].bodies.append(n)
	else:
		_tiles[t].visuals.append(n)


## Walk the built world once and bucket static geometry by tile.
func scan(world_root: Node3D) -> void:
	for b: Node in world_root.find_children("*", "StaticBody3D", true, false):
		var cs = (b as CollisionObject3D).get_child_count()
		var size: float = 0.0
		for i in range(cs):
			var c: Node = b.get_child(i)
			if c is CollisionShape3D and c.shape != null \
					and c.shape is BoxShape3D:
				size = maxf(size, maxf((c.shape as BoxShape3D).size.x,
						(c.shape as BoxShape3D).size.z))
		_register(b, size)
	# visual-only world nodes: meshes not under a streamed static body
	for m: Node in world_root.find_children("*", "MeshInstance3D", true, false):
		var top = m
		var under_body: bool = false
		var walk: Node = m.get_parent()
		while walk != null and walk != m.get_tree().current_scene:
			if walk is StaticBody3D:
				under_body = true
				break
			walk = walk.get_parent()
		if under_body:
			continue  # toggled with its body
		if not (m.get_parent() is Node3D):
			continue
		var aabb: AABB = (m as MeshInstance3D).get_aabb()
		if maxf(aabb.size.x, aabb.size.z) >= MIN_AABB:
			continue
		# skip meshes that are children of an already-registered visual parent
		if m.get_parent() is MeshInstance3D:
			continue
		_register(m, maxf(aabb.size.x, aabb.size.z))
	_apply(_tile_of(_player.global_position), _last_tile)
	print("STREAMER: %d tiles registered, %d always-on" % [_tiles.size(), _always.size()])


## Apply collision + visibility for one tile (instant path and queue both
## land here, so a queued tile's meshes toggle the same tick it resolves).
func _set_tile_collision(t: Vector2i, set_on: bool) -> void:
	if not _tiles.has(t):
		return
	for b: Node in _tiles[t].bodies:
		if not is_instance_valid(b):
			continue
		var body = b as CollisionObject3D
		if not body.has_meta("orig_layer"):
			body.set_meta("orig_layer", body.collision_layer)
		body.collision_layer = (body.get_meta("orig_layer") as int) if set_on else 0
		if b is Node3D:
			(b as Node3D).visible = set_on


## Drain the activation queue: budget is counted in BODIES (the solver cost
## is per re-registered body, not per tile). Each tile's desired band is
## re-checked at pop time — a fast double-flip never applies a stale direction.
func _drain_activation_queue() -> void:
	var budget = OPS_PER_FRAME
	while budget > 0 and not _pending.is_empty():
		var op: Dictionary = _pending.pop_front()
		var t: Vector2i = op["tile"]
		# Deep fix: clean pending_tiles registry on drain — previously leaked
		_pending_tiles.erase(t)
		var want_on: bool = _band(t, _last_tile) == "ACTIVE"
		_set_tile_collision(t, want_on)
		if _tiles.has(t):
			budget -= (_tiles[t].bodies as Array).size()


func _tile_of(p: Vector3) -> Vector2i:
	return WorldContract.micro_sector_of(Vector2(p.x, p.z))


## Re-band in _physics_process: it runs BEFORE the physics server step, so a
## teleport/vehicle that crosses into a new tile gets collision applied in the
## same tick — never a live physics step with parked collision (smoke-caught:
## a _process re-band left a 1-tick fall-through window).
func _physics_process(_d: float) -> void:
	# Deep fix: use GameState cached player (0.5s cache) instead of raw group lookup
	# per-frame group lookup previously caused stale ref freeze — now handled via invalidate
	var p: Node3D = null
	var gs = get_tree().root.get_node_or_null("GameState")
	if gs and gs.has_method("get_player"):
		p = gs.get_player()
	else:
		p = get_tree().get_first_node_in_group("player") as Node3D
	if p == null:
		return
	var t = _tile_of(p.global_position)
	if t != _last_tile:
		var old = _last_tile
		_last_tile = t
		var t0: int = Time.get_ticks_usec()
		_apply(t, old)
		last_transition_ms = float(Time.get_ticks_usec() - t0) / 1000.0
		transition_count += 1
	_drain_activation_queue()


func _band(t: Vector2i, center: Vector2i) -> String:
	var dx: int = absi(t.x - center.x)
	var dy: int = absi(t.y - center.y)
	var ring = maxi(dx, dy)
	if ring <= 1:
		return "ACTIVE"   # player tile + 1-ring neighborhood: NEAR == ACTIVE
	return "FAR"


## Round 12 Phase 22: deactivate hysteresis — a tile activates at ring <= 1
## but only deactivates beyond ring 2, so pacing along a boundary cannot
## flip collision twice per second (and per-frame pair churn disappears).
func _desired_on(t: Vector2i, center: Vector2i, cur_on: bool) -> bool:
	var dx: int = absi(t.x - center.x)
	var dy: int = absi(t.y - center.y)
	var ring: int = maxi(dx, dy)
	if ring <= 1:
		return true
	if cur_on and ring <= 2:
		return true  # hold band (hysteresis)
	return false


func _apply(new_c: Vector2i, old_c: Vector2i) -> void:
	for t: Vector2i in _tiles.keys():
		var bucket: Dictionary = _tiles[t]
		var cur_on: bool = bucket.get("on", false)
		var set_on: bool = _desired_on(t, new_c, cur_on)
		if set_on == cur_on and old_c != Vector2i(9999, 9999):
			continue  # hysteresis: no state change
		var was: String = "ACTIVE" if cur_on else "FAR"
		var now: String = "ACTIVE" if set_on else "FAR"
		# Round 11: player tile collision NOW (contract); everything else —
		# including the initial world activation — queues (budgeted drain)
		if t == new_c:
			_set_tile_collision(t, set_on)
		elif not _pending_tiles.has(t) or _pending_tiles[t] != set_on:
			_pending_tiles[t] = set_on
			_pending.append({"tile": t, "on": set_on})
		for v: Node in bucket.visuals:
			if is_instance_valid(v) and v is Node3D:
				(v as Node3D).visible = set_on
		bucket["on"] = set_on


## P02 §26 metrics: transition cost + band counts (debug/test snapshots only).
var last_transition_ms: float = 0.0
var transition_count: int = 0


func sector_of_player() -> Vector2i:
	return _last_tile


func sector_id_of_player() -> String:
	return WorldContract.micro_id(_last_tile)


func active_count() -> int:
	var n := 0
	for t: Vector2i in _tiles.keys():
		if bool(_tiles[t].get("on", false)):
			n += 1
	return n


func far_count() -> int:
	return _tiles.size() - active_count()


func pending_count() -> int:
	return _pending.size()


func metrics() -> Dictionary:
	return {"active_sectors": active_count(), "far_sectors": far_count(),
			"registered_sectors": _tiles.size(), "always_on": _always.size(),
			"pending_ops": _pending.size(), "last_transition_ms": last_transition_ms,
			"transitions": transition_count,
			"player_sector": WorldContract.micro_id(_last_tile)}


## Test/QA hook: is world collision enabled at a world position right now?
func collision_enabled_at(p: Vector3) -> bool:
	return _band(_tile_of(p), _last_tile) == "ACTIVE"


## Round 12 QA hook: hysteresis contract — the player's own tile is always on.
func player_tile_contract_holds() -> bool:
	var t0: Vector2i = _tile_of(_player.global_position)
	return _desired_on(t0, _last_tile, false)
