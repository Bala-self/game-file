extends Node
class_name EventManager
## Data-driven world event director (v2.0): events are entries with weight,
## district filters and time filters; selection is district-aware, never
## right-on-top-of the player, and never the same event twice in a row.
## Implementations stay on the game node (scene access) — this node owns POLICY.

var _game: Node
var _last: String = ""
var cooldown: float = 0.0

## id, weight, districts (empty = anywhere), min_wanted (events that need calm streets use 99 gate on the game side)
const EVENTS := [
	{"id": "supply_drop", "weight": 3, "districts": []},
	{"id": "ambush", "weight": 2, "districts": ["Industrial", "Downtown", "Outskirts", "Roads/Water"]},
	{"id": "panic", "weight": 3, "districts": ["Downtown", "Suburbs", "Beachfront", "Park"]},
]


static func create(game: Node) -> EventManager:
	var em: EventManager = EventManager.new()
	em.name = "EventManager"
	em._game = game
	return em


func _process(delta: float) -> void:
	cooldown = maxf(0.0, cooldown - delta)


func _district_at(pos: Vector3) -> String:
	var pp: Vector2 = Vector2(pos.x, pos.z)
	for dname: String in GameState.world_data.get("districts", {}):
		if (GameState.world_data["districts"][dname] as Rect2).has_point(pp):
			return dname
	return "Roads/Water"


## District-aware weighted pick. Returns "" when nothing fits here.
func pick_event() -> String:
	var player = get_tree().get_first_node_in_group("player")
	if player == null:
		return ""
	var district = _district_at(player.global_position)
	var options: Array = []
	for e: Dictionary in EVENTS:
		if e["id"] == _last:
			continue  # never twice in a row
		var allowed: Array = e["districts"]
		if allowed.is_empty() or district in allowed:
			for i in range(int(e["weight"])):
				options.append(e["id"])
	if options.is_empty():
		return ""
	return options[randi() % options.size()]


## Policy-driven trigger used by the game director timer.
func trigger_random() -> bool:
	var ev = pick_event()
	if ev == "":
		return false
	_last = ev
	GameState.stats["events_seen"] = GameState.stats.get("events_seen", 0) + 1
	var first = not GameState.world_flags.has("ev_" + ev)
	GameState.world_flags["ev_" + ev] = true
	match ev:
		"supply_drop":
			_game._event_supply_drop(first)
		"ambush":
			_game._event_ambush(first)
		"panic":
			_game._event_panic(first)
	cooldown = 20.0
	return true
