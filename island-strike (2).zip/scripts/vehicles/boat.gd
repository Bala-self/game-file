extends CharacterBody3D
## Boat (audit #23 — first slice of the Phase 24 vehicle ecosystem): a
## drivable surface craft moored off the marina. Duck-types the vehicle
## interface the player camera already uses (get_seat_position / exit_player /
## velocity / global_basis), so the existing enter/exit flow drives it
## unchanged. Buoyancy is a fixed float line on the world-data water level
## plus a bob; durability/cover/wakes arrive with the full Phase 24 pass.

## Boat class configs (Round 9 S2 — Phase 24 ecosystem slice 2): data-driven
## like car.gd CLASSES. "fishing" = the original moored workboat; "speedboat" =
## sleek fast hull, no cabin. Add a row here and the class exists everywhere.
const CLASSES := {
	"fishing": {"top": 9.0, "w": 2.2, "l": 5.2, "cabin": true,
			"color": Color(0.82, 0.8, 0.74)},
	"speedboat": {"top": 15.0, "w": 1.9, "l": 4.6, "cabin": false,
			"color": Color(0.85, 0.25, 0.18)},
}

var driver: CharacterBody3D = null
var wrecked: bool = false  # interact-scan compat with the car enter flow
# cars-group scanners (repair, police, traffic) duck-type these:
var is_police_car: bool = false
var health: float = 100.0
var vehicle_class: String = "boat"
var boat_class: String = "fishing"
var traffic: bool = false
var engine_health: float = 100.0
var wheel_health: float = 100.0
var speed: float = 0.0
var _bob_t: float = 0.0
var horn_audio: AudioStreamPlayer3D = null
var wake: GPUParticles3D  # Round 10 E2: stern spray


static func create(b_class := "fishing") -> CharacterBody3D:
	var b = CharacterBody3D.new()
	b.name = "Boat"
	b.set_script(load("res://scripts/vehicles/boat.gd"))
	b.set("boat_class", b_class)
	return b


func _ready() -> void:
	add_to_group("cars")
	add_to_group("boats")
	var cfg: Dictionary = CLASSES.get(boat_class, CLASSES["fishing"])
	var hw: float = cfg["w"]
	var hl: float = cfg["l"]
	var hull = MeshInstance3D.new()
	var hm = BoxMesh.new()
	hm.size = Vector3(hw, 0.9, hl)
	var hull_mat = StandardMaterial3D.new()
	hull_mat.albedo_color = cfg["color"]
	hm.material = hull_mat
	hull.mesh = hm
	hull.position = Vector3(0, 0.15, 0)
	add_child(hull)
	if cfg["cabin"]:
		var cabin = MeshInstance3D.new()
		var cm = BoxMesh.new()
		cm.size = Vector3(1.7, 0.8, 1.8)
		var cabin_mat = StandardMaterial3D.new()
		cabin_mat.albedo_color = Color(0.35, 0.4, 0.45)
		cm.material = cabin_mat
		cabin.mesh = cm
		cabin.position = Vector3(0, 1.0, 0.6)
		add_child(cabin)
	else:
		# speedboat: low windshield instead of a cabin
		var shield = MeshInstance3D.new()
		var sm = BoxMesh.new()
		sm.size = Vector3(hw * 0.7, 0.5, 0.08)
		var shield_mat = StandardMaterial3D.new()
		shield_mat.albedo_color = Color(0.15, 0.2, 0.28, 0.85)
		shield_mat.metallic = 0.6
		shield_mat.roughness = 0.1
		sm.material = shield_mat
		shield.mesh = sm
		shield.position = Vector3(0, 0.95, 0.5)
		add_child(shield)
	var col = CollisionShape3D.new()
	var shape = BoxShape3D.new()
	shape.size = Vector3(hw, 1.4, hl)
	col.shape = shape
	col.position = Vector3(0, 0.4, 0)
	add_child(col)
	# Round 10 E2: wake spray at the stern when under way
	wake = GPUParticles3D.new()
	wake.amount = 26
	wake.lifetime = 0.9
	wake.emitting = false
	wake.position = Vector3(0, 0.35, -2.6)
	var wp = ParticleProcessMaterial.new()
	wp.direction = Vector3(0, 0.4, -1)
	wp.initial_velocity_min = 1.5
	wp.initial_velocity_max = 3.0
	wp.gravity = Vector3(0, -6.0, 0)
	wp.scale_min = 0.3
	wp.scale_max = 0.8
	wp.color = Color(0.92, 0.96, 0.97, 0.7)
	wake.process_material = wp
	var wq = QuadMesh.new()
	wq.size = Vector2(0.35, 0.35)
	wake.draw_pass_1 = wq
	add_child(wake)
	horn_audio = AudioStreamPlayer3D.new()
	horn_audio.stream = load("res://assets/audio/horn.wav")
	horn_audio.volume_db = -6.0
	horn_audio.max_distance = 60.0
	add_child(horn_audio)


func _physics_process(delta: float) -> void:
	_bob_t += delta
	var water = float(GameState.world_data.get("water_y", -1.3))
	global_position.y = water + 0.55 + sin(_bob_t * 1.6) * 0.05
	var throttle: float = 0.0
	var steer: float = 0.0
	if driver != null and not GameState.audio_shutdown:
		throttle = Input.get_axis("move_back", "move_forward")
		steer = Input.get_axis("move_left", "move_right")
		if Input.is_action_just_pressed("horn"):
			horn_audio.play()
	# rudder needs way on
	var turn = steer * 1.0 * delta * clampf(absf(speed) / 4.0, 0.0, 1.0) \
			* (-signf(speed) if speed < 0.0 else 1.0)
	rotation.y -= turn
	var top: float = CLASSES.get(boat_class, CLASSES["fishing"])["top"]
	speed = move_toward(speed, throttle * top,
			(4.5 if absf(throttle) > 0.1 else 6.0) * delta)
	var fwd = -global_basis.z
	velocity = Vector3(fwd.x, 0.0, fwd.z) * speed
	move_and_slide()
	if wake:
		wake.emitting = absf(speed) > 2.5
	if get_slide_collision_count() > 0:
		speed *= 0.4  # scraping the shore


func enter_player(p: CharacterBody3D) -> void:
	driver = p
	p.start_driving(self)
	GameState.stats.cars_entered += 1
	GameState.notify("Boat acquired")


func exit_player() -> void:
	if driver == null:
		return
	var p = driver
	driver = null
	var side = global_basis.x * 2.6
	p.exit_driving(global_position + side + Vector3(0, 0.4, 0))
	speed *= 0.5


## Vehicle-camera interface (player anchors the cab here while driving).
func get_seat_position() -> Vector3:
	return global_position + Vector3(0, 0.4, -0.6)


func engine_factor() -> float:
	return 1.0


func wheel_factor() -> float:
	return 1.0


## In the cars group for the enter scan; hull is durable until Phase 24.
@warning_ignore("unused_parameter")
func take_damage(_dmg: float, _from: Vector3, _source: Node = null) -> void:
	# Deep fix: hull durable until Phase 24 full pass — intentional no-op, not stuck
	pass
