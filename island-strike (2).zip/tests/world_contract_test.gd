extends SceneTree
## WorldContract suite (Reconstruction Prompt 01): the authoritative 3 km
## circular envelope must hold before Prompt 02 consumes it.
## Coverage per the locked QA method: normal, min/max boundary, invalid
## input, empty/out-of-range state, determinism, partition math, and a
## performance sanity gate. Prints WORLD_CONTRACT_RESULT: ALL PASS.

var fails := 0
var checks := 0


func _gate(cond: bool, msg: String) -> void:
	checks += 1
	if cond:
		print("WC PASS: %s" % msg)
	else:
		print("WC FAIL: %s" % msg)
		fails += 1


func _initialize() -> void:
	var WC := WorldContract

	# --- 1. validate() self-check (center, diameter, inclusive edge, AABB) ---
	var v: Dictionary = WC.validate()
	_gate(bool(v.get("ok", false)), "validate() self-check ok=%s" % str(v))

	# --- 2. normal cases ---
	_gate(WC.is_playable(Vector3.ZERO), "origin is playable")
	_gate(WC.is_playable(Vector3(1500, 0, -1500)), "(1500,-1500) inside circle")
	_gate(not WC.is_playable(Vector3(2500, 0, 2500)), "(2500,2500) dist=3535 outside")
	_gate(WC.is_playable(Vector3(-430, 0.6, -40)), "legacy player spawn inside circle")
	_gate(WC.dist_to_center(Vector3(300, 500, 400)) == 500.0,
			"dist_to_center ignores Y (3-4-5 triangle)")

	# --- 3. boundary cases (inclusive edge contract) ---
	_gate(WC.is_playable(Vector3(WC.RADIUS_M, 0, 0)), "exactly RADIUS is playable (inclusive)")
	_gate(not WC.is_playable(Vector3(WC.RADIUS_M + 0.01, 0, 0)), "RADIUS+0.01 not playable")
	_gate(WC.is_soft_boundary(Vector3(WC.RADIUS_M - 1.0, 0, 0)), "edge band is soft boundary")
	_gate(not WC.is_soft_boundary(Vector3.ZERO), "center is not soft boundary")
	_gate(not WC.is_soft_boundary(Vector3(WC.RADIUS_M + 5, 0, 0)),
			"outside point is not soft boundary (not playable at all)")
	_gate(WC.is_legal_road_area(Vector3(WC.ROAD_LIMIT_RADIUS_M, 0, 0)),
			"road limit radius inclusive")
	_gate(not WC.is_legal_road_area(Vector3(WC.ROAD_LIMIT_RADIUS_M + 1, 0, 0)),
			"beyond road limit rejected")
	_gate(WC.SOFT_RADIUS_M == WC.RADIUS_M - WC.SOFT_MARGIN_M, "soft radius derivation")

	# --- 4. invalid input ---
	_gate(not WC.is_playable(Vector3(NAN, 0, 0)), "NaN x rejected")
	_gate(not WC.is_playable(Vector3(0, 0, INF)), "INF z rejected")
	_gate(not WC.is_playable(Vector3(-INF, 0, -INF)), "-INF rejected")
	_gate(WC.classify_zone(Vector3(NAN, 0, 0)) == WC.ZONE_WATER, "NaN classified WATER")
	_gate(WC.clamp_to_playable(Vector2(NAN, INF)) == WC.CENTER_XZ, "NaN clamp -> center")

	# --- 5. clamp_to_playable behavior ---
	var far := Vector2(10000, 10000)
	var cl: Vector2 = WC.clamp_to_playable(far, 10.0)
	_gate(is_equal_approx(cl.length(), WC.RADIUS_M - 10.0), "far point clamped to inset radius")
	var inside := Vector2(10, -20)
	_gate(WC.clamp_to_playable(inside, 10.0) == inside, "interior point unchanged by clamp")

	# --- 6. zone classification ---
	_gate(WC.classify_zone(Vector3(0, 0, 0)) == WC.ZONE_CORE, "center is CORE_LAND")
	_gate(WC.classify_zone(Vector3(WC.LAND_RADIUS_M + 1, 0, 0)) == WC.ZONE_COAST,
			"just past land radius is COAST_BAND")
	_gate(WC.classify_zone(Vector3(WC.RADIUS_M + 1, 0, 0)) == WC.ZONE_WATER,
			"beyond envelope is WATER")

	# --- 7. sector math (determinism + bijection on valid set) ---
	var ids: Array[Vector2i] = WC.valid_sector_ids()
	_gate(ids.size() > 0 and ids.size() == WC.sector_count(), "sector list non-empty and consistent")
	var dup: Dictionary = {}
	var all_valid := true
	for s in ids:
		dup[s] = true
		if not WC.sector_is_valid(s):
			all_valid = false
	_gate(dup.size() == ids.size() and all_valid, "sector ids unique and all valid")
	_gate(WC.world_to_sector(Vector2(0, 0)) == Vector2i(0, 0), "origin maps to sector (0,0)")
	_gate(WC.world_to_sector(Vector2(-1, -1)) == Vector2i(-1, -1),
			"negative near-origin floors to (-1,-1)")
	# round-trip: every valid sector center maps back to its own sector
	var rt_ok := true
	for s in ids:
		if WC.world_to_sector(WC.sector_to_world(s)) != s:
			rt_ok = false
	_gate(rt_ok, "sector_to_world -> world_to_sector round-trip exact")
	# index: unique, dense 0..n-1, invalid -> -1
	var idx_ok := true
	var seen: Dictionary = {}
	for i in range(ids.size()):
		var ix: int = WC.sector_index(ids[i])
		if ix < 0 or ix >= ids.size() or seen.has(ix):
			idx_ok = false
		seen[ix] = true
	_gate(idx_ok, "sector_index dense and unique over valid set")
	_gate(WC.sector_index(Vector2i(99, 99)) == -1, "far invalid sector index -1")
	# determinism across calls
	_gate(WC.valid_sector_ids() == ids, "valid_sector_ids deterministic across calls")
	# every valid sector center is itself playable (envelope-closed property)
	var centers_ok := true
	for s in ids:
		if not WC.is_playable(Vector3(WC.sector_to_world(s).x, 0, WC.sector_to_world(s).y)):
			centers_ok = false
	_gate(centers_ok, "all valid sector centers playable")
	# circle area reference: pi*3^2 = 28.274 km^2
	_gate(is_equal_approx(WC.envelope_area_km2(), PI * 9.0), "envelope area 28.274 km^2")

	# --- 8. fine cell math ---
	_gate(WC.world_to_cell(Vector2(55, -55)) == Vector2i(0, -1), "cell flooring")
	_gate(WC.world_to_cell(WC.cell_to_world(Vector2i(3, -4))) == Vector2i(3, -4),
			"cell round-trip")
	_gate(WC.cell_is_valid(Vector2i(0, 0)) and not WC.cell_is_valid(Vector2i(50, 50)),
			"cell validity bounds")

	# --- 9. performance sanity gate (pure math; headless) ---
	var t0 := Time.get_ticks_usec()
	var acc := 0.0
	for i in range(100000):
		var p := Vector3(float(i % 7000) - 3500.0, 0.0, float(i % 5000) - 2500.0)
		if WC.is_playable(p):
			acc += 1.0
	var dt_ms: float = float(Time.get_ticks_usec() - t0) / 1000.0
	_gate(dt_ms < 500.0, "100k is_playable calls in %.1f ms (<500)" % dt_ms)
	_gate(acc > 0.0, "perf loop hit playable points (acc=%.0f)" % acc)

	# --- 10. no-duplication guard: this contract must not drift internally ---
	_gate(WC.DIAMETER_M == 2.0 * WC.RADIUS_M, "diameter == 2*radius")
	_gate(WC.LAND_RADIUS_M < WC.ROAD_LIMIT_RADIUS_M and WC.ROAD_LIMIT_RADIUS_M < WC.RADIUS_M,
			"band ordering LAND < ROAD_LIMIT < RADIUS")

	if fails == 0:
		print("WORLD_CONTRACT_RESULT: ALL PASS (%d/%d)" % [checks, checks])
		quit(0)
	else:
		print("WORLD_CONTRACT_RESULT: FAIL %d/%d" % [checks - fails, checks])
		quit(1)
