extends SceneTree
## Round 16 (v2.4) — Mission Framework gates (master plan §40–§47, §62–§67).
## Engine gate + 4-mission content gate + failure chaos + persistence +
## reward idempotency + cleanup/lifetime checks. Evidence-only verdicts.

const EconomyRes := preload("res://scripts/core/economy.gd")

var f: int = 0
var game: Node
var mm: Node
var GS: Node
var bus: Node
var passed: int = 0
var total: int = 0
var pre_kill_money: int = 0
var last_target_id: int = 0
var leak_baseline: int = 0
var leak_vips: Array = []
var restart_old_target: int = 0


func _initialize() -> void:
	game = load("res://scenes/game/game.tscn").instantiate()
	root.add_child(game)
	current_scene = game


func _check(cond: bool, label: String) -> void:
	total += 1
	if cond:
		passed += 1
	else:
		print("MISSION_FAIL: %s" % label)


func _player() -> Node3D:
	return get_first_node_in_group("player") as Node3D


func _tp(pos: Vector3) -> void:
	var p: Node3D = _player()
	p.global_position = pos
	if p is CharacterBody3D:
		(p as CharacterBody3D).velocity = Vector3.ZERO
	# force the 10 Hz mission tick on the next process: teleport checks are
	# deterministic regardless of headless frame pacing (R17 flake fix)
	if mm != null:
		mm._tick_acc = 1.0


func _wait(frames: int, step: int) -> bool:
	return f >= step + frames


func _process(_d: float) -> bool:
	f += 1
	if f >= 205 and f <= 385 and f % 10 == 0:
		var pl: Node = _player()
		if pl != null and "health" in pl:
			pl.set("health", 100)  # survive hostile turf during heist test
	if f == 40:
		mm = get_first_node_in_group("mission_manager")
		GS = root.get_node("GameState")
		bus = root.get_node_or_null("EventBus")
		_check(mm != null, "MissionManager present in tree")
		_check(bus != null, "EventBus present")
		_check(int(mm.definitions.size()) == 5, "5 mission definitions registered (%d)" % int(mm.definitions.size()))
		_check(int(mm.available_ids().size()) == 5, "all 5 available at start")
		_check(str(mm.start_mission("nope")).begins_with("ERR"), "unknown mission rejected")
		return false
	if f == 41:
		# ---- concurrency + duplicate start (§47) ----
		_check(str(mm.start_mission("bank_run")).begins_with("OK"), "bank_run started")
		_check(str(mm.start_mission("dock_cleanup")).begins_with("ERR"),
				"second mission rejected while one active")
		_check(str(mm.start_mission("bank_run")).begins_with("ERR"),
				"duplicate start of active mission rejected")
		return false
	if f == 45:
		# ---- bank_run end-to-end (Gate 02: one real mission) ----
		var p0: Node3D = _player()
		_check(str(mm.inst["id"]) == "bank_run" and int(mm.inst["objective_index"]) == 0,
				"bank_run at objective 1")
		_check(get_first_node_in_group("hud") != null, "hud present for mission text")
		var _hud: Node = get_first_node_in_group("hud")
		_check(_hud.has_meta("mission_label") and str((_hud.get_meta("mission_label") as Label).text) != "",
				"HUD mission text live during mission")
		_tp(Vector3(-281, 0.6, -202))  # bank step
		Input.action_press("interact")  # hold E for COLLECT/INTERACT objectives
		return false
	if f == 70:
		_check(int(mm.inst.get("objective_index", -1)) >= 1, "GO_TO bank completed")
		return false
	if f == 85:
		_check(int(mm.inst.get("objective_index", -1)) >= 2 and bool(mm.inst["flags"].get("carrying", false)),
				"COLLECT completed -> carrying package")
		_tp(Vector3(-560, 0.6, 230))  # harbor handover
		return false
	if f == 115:
		_check(mm.active_id == "" or int(mm.inst.get("objective_index", -1)) >= 3,
				"GO_TO harbor + handover advanced")
		return false
	if f == 130:
		_check(mm.active_id == "", "bank_run completed (active cleared)")
		_check("bank_run" in mm.completed, "bank_run recorded completed")
		_check(GS.money >= 400, "reward paid via Economy (money %d)" % int(GS.money))
		var found: bool = false
		for e: Dictionary in EconomyRes.transactions():
			if str(e["data"].get("reason")) == "mission_reward:bank_run":
				found = true
		_check(found, "reward in economy ledger with mission reason")
		_check(str(mm.start_mission("bank_run")).begins_with("ERR"),
				"once-mission locked after completion (§46)")
		return false
	if f == 131:
		_check(bus.count_kind("MISSION_COMPLETED") == 1,
				"MISSION_COMPLETED recorded on bus (bank_run)")
		# ---- dock_cleanup: eliminate via real combat damage (§26) ----
		_check(str(mm.start_mission("dock_cleanup")).begins_with("OK"), "dock_cleanup started")
		_tp(Vector3(400, 0.6, 262))
		return false
	if f == 150:
		_check(int(mm.inst["objective_index"]) == 1, "docks reached -> ELIMINATE active")
		var tid: int = int(mm.inst["actors"].get("target", 0))
		_check(tid != 0, "eliminate target spawned and bound")
		var target: Node = instance_from_id(tid)
		_check(target != null and is_instance_valid(target), "target alive in world")
		last_target_id = tid
		pre_kill_money = int(GS.money)
		# §55/§93: WRONG-TARGET death must NOT advance the objective
		bus.record("NPC_DIED", {"kind": "civilian", "pos": Vector3.ZERO,
				"node": _player().get_instance_id()})
		_check(mm.active_id == "dock_cleanup" and int(mm.inst["objective_index"]) == 1,
				"wrong-target death ignored (mission still active)")
		if target != null:
			target.take_damage(999, target.global_position, _player())
		return false
	if f == 153:
		_check(mm.active_id == "", "eliminate completed mission via NPC_DIED event")
		_check("dock_cleanup" not in mm.completed, "repeatable mission not locked")
		_check(int(GS.money) - pre_kill_money == 350,
				"reward exact: +350 paid once (%d)" % (int(GS.money) - pre_kill_money))
		# §55: duplicate completion signal after completion must be inert
		var done_before: int = mm.completed.size()
		bus.record("NPC_DIED", {"kind": "gang", "pos": Vector3.ZERO,
				"node": last_target_id})
		_check(mm.active_id == "" and mm.completed.size() == done_before
				and int(GS.money) - pre_kill_money == 350,
				"duplicate NPC_DIED after completion is inert")
		return false
	if f == 154:
		# repeatable: can start again (§24 families) — then abandon (§31)
		_check(str(mm.start_mission("dock_cleanup")).begins_with("OK"),
				"repeatable mission restartable")
		return false
	if f == 156:
		_check(str(mm.abandon()).begins_with("OK"), "abandon succeeds")
		_check(mm.active_id == "" and mm.is_available("dock_cleanup"),
				"abandoned mission returns to AVAILABLE")
		var found_ab: bool = false
		for e2: Dictionary in bus.tail(10):
			if str(e2["kind"]) == "MISSION_ABANDONED":
				found_ab = true
		_check(found_ab, "MISSION_ABANDONED on bus")
		return false
	if f == 157:
		# ---- safe_passage: PROTECT failure path (§29) ----
		_check(str(mm.start_mission("safe_passage")).begins_with("OK"), "safe_passage started")
		return false
	if f == 175:
		var vid: int = int(mm.inst["actors"].get("vip", 0))
		_check(vid != 0, "protected witness spawned")
		var vip: Node = instance_from_id(vid)
		if vip != null:
			vip.take_damage(999, vip.global_position, _player())
		return false
	if f == 178:
		_check(mm.active_id == "", "protect failure ended mission")
		_check(int(mm.failed_count.get("safe_passage", 0)) == 1, "failure counted")
		_check(mm.is_available("safe_passage"), "failed once-mission available again")
		return false
	if f == 179:
		# ---- PLAYER_DIED routing (§29) + timeout (§36) ----
		_check(str(mm.start_mission("safe_passage")).begins_with("OK"), "safe_passage restarted")
		return false
	if f == 181:
		bus.record("PLAYER_DIED", {"pos": Vector3.ZERO})
		return false
	if f == 184:
		_check(mm.active_id == "", "player death fails mission")
		var r1: String = str(mm.start_mission("safe_passage"))
		_check(r1.begins_with("OK"), "mission restartable after death-fail")
		mm.inst["time_left"] = 0.05
		return false
	if f == 200:
		_check(mm.active_id == "", "time expiry fails mission (§36)")
		_check(int(mm.failed_count.get("safe_passage", 0)) == 3, "failures tracked (3)")
		return false
	if f == 201:
		# ---- warehouse_job: mid-mission save/load (§20) + ESCAPE chain ----
		_check(str(mm.start_mission("warehouse_job")).begins_with("OK"), "warehouse_job started")
		_tp(Vector3(420, 0.6, 270))
		GS.set_wanted(2)  # heat BEFORE ESCAPE activates, so the gate is observable
		return false
	if f == 225:
		_check(int(mm.inst.get("objective_index", -1)) >= 1, "yard reached -> collect goods")
		return false
	if f == 240:
		_check(int(mm.inst.get("objective_index", -1)) == 2, "ESCAPE holds while wanted 2")
		return false
	if f == 255:
		_check(int(mm.inst.get("objective_index", -1)) == 2 and bool(mm.inst["flags"].get("carrying", false)),
				"goods collected -> ESCAPE objective")
		# ---- mid-mission save -> load -> objective preserved (§20) ----
		_check(GS.get_node("/root/SaveSystem").save_game(), "mid-mission save")
		var snap_before: int = int(mm.inst["objective_index"])
		GS.get_node("/root/SaveSystem").load_game()
		mm = get_first_node_in_group("mission_manager")
		_check(str(mm.active_id) == "warehouse_job", "mission resumed after load")
		_check(int(mm.inst.get("objective_index", -1)) == snap_before,
				"objective index preserved across save/load")
		GS.set_wanted(0)
		return false
	if f == 280:
		_check(int(mm.inst.get("objective_index", -1)) == 3, "wanted cleared -> ESCAPE completed")
		_tp(Vector3(-165, 0.6, -240))  # safehouse drop
		return false
	if f == 315:
		_check(mm.active_id == "", "warehouse_job completed")
		_check("warehouse_job" in mm.completed, "heist recorded completed")
		# ---- cleanup / lifetime (§43): no orphan bound actors ----
		var orphans: int = 0
		for role: String in ["target", "vip"]:
			var nid: int = int(mm.inst.get("actors", {}).get(role, 0))
			if nid != 0:
				var n: Node = instance_from_id(nid)
				if n != null and is_instance_valid(n):
					orphans += 1
		_check(orphans == 0, "no live bound actors after completion (cleared)")
		var _hud2: Node = get_first_node_in_group("hud")
		_check(str((_hud2.get_meta("mission_label") as Label).text) == "",
				"HUD mission text cleared on finish")
		return false
	if f == 318:
		# ---- §61 mission-layer measurements (headless wall-time, honest) ----
		var conns: Array = bus.event_logged.get_connections()
		var mm_conns: int = 0
		for c: Dictionary in conns:
			if c["callable"].get_object() == mm:
				mm_conns += 1
		_check(mm_conns == 1, "exactly ONE EventBus subscription for manager lifetime")
		var t0: int = Time.get_ticks_usec()
		_check(str(mm.start_mission("getaway_car")).begins_with("OK"),
				"getaway_car started (5th mission, data-only addition)")
		var start_us: int = Time.get_ticks_usec() - t0
		_check(start_us < 5000, "mission start overhead < 5 ms (%d us)" % start_us)
		t0 = Time.get_ticks_usec()
		for i: int in range(100):
			mm.save_snapshot()
		var snap_us: int = int((Time.get_ticks_usec() - t0) / 100.0)
		var snap_bytes: int = JSON.stringify(mm.save_snapshot()).length()
		print("MEASURED|mission_start_us=", start_us,
				"|snapshot_avg_us=", snap_us,
				"|snapshot_json_bytes=", snap_bytes,
				"|eventbus_connections=", conns.size(),
				"|manager_children=", mm.get_child_count())
		return false
	if f == 321:
		_check(int(mm.inst["objective_index"]) == 0, "getaway_car at ENTER_VEHICLE")
		bus.record("PLAYER_ENTERED_VEHICLE", {"node": 1, "vehicle": "test"})
		return false
	if f == 323:
		_check(int(mm.inst["objective_index"]) == 1,
				"PLAYER_ENTERED_VEHICLE completed ENTER_VEHICLE objective")
		pre_kill_money = int(GS.money)
		_tp(Vector3(300, 0.6, 200))  # drop lane
		return false
	if f == 327:
		_check(mm.active_id == "", "getaway_car completed")
		_check(int(GS.money) - pre_kill_money == 150, "getaway reward exact +150")
		return false
	if f == 330:
		# ---- §57/§93: checkpoint RESTART path (20-frame gaps: tick cadence) ----
		_check(str(mm.start_mission("dock_cleanup")).begins_with("OK"),
				"dock_cleanup started for restart test")
		_tp(Vector3(400, 0.6, 262))
		return false
	if f == 350:
		_check(int(mm.inst["objective_index"]) == 1, "docks reached again")
		restart_old_target = int(mm.inst["actors"].get("target", 0))
		_check(str(mm.restart()).begins_with("OK"), "restart() accepted")
		_check(int(mm.inst["objective_index"]) == 0,
				"restart restored checkpoint objective (GO_TO)")
		# §60: checkpoint-state save/load round trip
		_check(GS.get_node("/root/SaveSystem").save_game(), "checkpoint save")
		GS.get_node("/root/SaveSystem").load_game()
		mm = get_first_node_in_group("mission_manager")
		_check(str(mm.active_id) == "dock_cleanup" and int(mm.inst["objective_index"]) == 0,
				"post-restart state survives save/load")
		_tp(Vector3(400, 0.6, 262))
		return false
	if f == 353:
		_check(restart_old_target != 0
				and not is_instance_valid(instance_from_id(restart_old_target)),
				"old target freed on restart (deferred queue_free)")
		return false
	if f == 368:
		_check(int(mm.inst["objective_index"]) == 1, "docks reached after load")
		var tid2: int = int(mm.inst["actors"].get("target", 0))
		var tgt2: Node = instance_from_id(tid2)
		_check(tid2 != 0 and tid2 != restart_old_target,
				"fresh target bound after restart respawn")
		last_target_id = tid2
		if tgt2 != null:
			tgt2.take_damage(999, tgt2.global_position, _player())
		return false
	if f == 371:
		_check(mm.active_id == "", "dock_cleanup completed after restart+load cycle")
		return false
	if f == 374:
		# ---- §62 leak cycles: spawn/abandon repeated; asserts AFTER deferred
		# queue_free lands (same-frame validity checks are meaningless) ----
		leak_baseline = mm.get_child_count()
		leak_vips.clear()
		for cycle: int in range(3):
			_check(str(mm.start_mission("safe_passage")).begins_with("OK"),
					"leak cycle %d start" % cycle)
			var vip_id: int = int(mm.inst["actors"].get("vip", 0))
			_check(vip_id != 0, "leak cycle %d vip spawned" % cycle)
			leak_vips.append(vip_id)
			_check(str(mm.abandon()).begins_with("OK"), "leak cycle %d abandon" % cycle)
		return false
	if f == 378:
		for cycle2: int in range(leak_vips.size()):
			_check(not is_instance_valid(instance_from_id(int(leak_vips[cycle2]))),
					"leak cycle %d vip freed after deferral" % cycle2)
		_check(mm.get_child_count() == leak_baseline,
				"node count back to baseline (%d == %d)" % [mm.get_child_count(), leak_baseline])
		return false
	if f == 381:
		# ---- §44 EventBus regression: crime records unaffected ----
		_check(bus.count_kind("MISSION_COMPLETED") >= 2, "mission events on bus")
		bus.clear_log()
		GS.commit_crime(1, _player().global_position)
		var crime_ok: bool = false
		for e3: Dictionary in bus.tail(5):
			if str(e3["kind"]) == "CRIME":
				crime_ok = true
		_check(crime_ok, "CRIME records unaffected by mission layer")
		# ---- save/load persists completed set (reward exploit guard) ----
		_check(GS.get_node("/root/SaveSystem").save_game(), "final save")
		GS.get_node("/root/SaveSystem").load_game()
		mm = get_first_node_in_group("mission_manager")
		_check("bank_run" in mm.completed and "warehouse_job" in mm.completed,
				"completed missions persist across save/load")
		_check(not mm.is_available("bank_run"), "completed once-mission stays locked (§46)")
		_check(mm.is_available("dock_cleanup"), "availability state sane after load")
		return false
	if f == 384:
		# ---- §60: legacy save WITHOUT mission fields -> safe defaults ----
		var path: String = GS.SAVE_PATH
		var raw: String = ""
		var fr: FileAccess = FileAccess.open(path, FileAccess.READ)
		if fr != null:
			raw = fr.get_as_text()
			fr.close()
		var payload: Variant = JSON.parse_string(raw)
		_check(payload is Dictionary and payload.has("money"), "legacy payload parsed")
		(payload as Dictionary).erase("mission")
		(payload as Dictionary).erase("missions_done")
		var fw: FileAccess = FileAccess.open(path, FileAccess.WRITE)
		fw.store_string(JSON.stringify(payload))
		fw.close()
		_check(GS.get_node("/root/SaveSystem").load_game(), "legacy save loads")
		mm = get_first_node_in_group("mission_manager")
		_check(mm.active_id == "" and mm.completed.is_empty(),
				"legacy save -> safe default mission state")
		_check(mm.is_available("bank_run"), "mission progression reset with legacy save")
		# §7: invalid transition directly rejected
		mm.states["bank_run"] = mm.STATES["COMPLETED"]
		_check(not mm._transition("bank_run", "ACTIVE", "test"),
				"COMPLETED -> ACTIVE rejected by transition guard (§7)")
		_check(not mm._last_rejected.is_empty(), "rejected transition recorded")
		mm.states["bank_run"] = mm.STATES["AVAILABLE"]
		if passed == total:
			print("MISSION_RESULT: ALL PASS (%d/%d)" % [passed, total])
			quit(0)
		else:
			print("MISSION_RESULT: FAIL %d/%d" % [passed, total])
			quit(1)
		return false
	return false
