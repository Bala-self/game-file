extends SceneTree
## Round 14 STAGE 01 completion test — EventBus / Economy / DebugTools.
## Gates the master-plan §39 event bus, §19 economy ledger, §41 debug framework.

const EconomyRes := preload("res://scripts/core/economy.gd")
const DebugToolsRes := preload("res://scripts/core/debug_tools.gd")

var f: int = 0
var game: Node
var passed: int = 0
var total: int = 0
var money0: int = 0


func _initialize() -> void:
	game = load("res://scenes/game/game.tscn").instantiate()
	root.add_child(game)
	current_scene = game


func _check(cond: bool, label: String) -> void:
	total += 1
	if cond:
		passed += 1
	else:
		print("SYSTEM_FAIL: %s" % label)


func _process(_d: float) -> bool:
	f += 1
	if f != 40:
		return false
	var bus: Node = root.get_node_or_null("EventBus")
	var GS: Node = root.get_node("GameState")
	_check(bus != null, "EventBus autoload present")
	if bus == null:
		print("SYSTEM_RESULT: FAIL %d/%d" % [passed, total])
		quit(1)
		return false

	# ---- §39: ring buffer cap ----
	for i in range(200):
		bus.record("STRESS", {"i": i})
	_check(bus.log.size() <= 120, "ring buffer capped at 120 (%d)" % bus.log.size())
	bus.clear_log()

	# ---- §39: GameState relays ----
	var w0: int = GS.wanted
	GS.set_wanted(2)
	var found_wanted: bool = false
	for e: Dictionary in bus.tail(5):
		if str(e["kind"]) == "WANTED_CHANGED" and int(e["data"].get("level")) == 2:
			found_wanted = true
	_check(found_wanted, "WANTED_CHANGED relayed with level")
	GS.set_wanted(w0)

	# hour-step time relay (advance_time emits every frame; log only on hour change)
	bus.clear_log()
	GS.advance_time(1.2)
	var found_time: bool = false
	for e2: Dictionary in bus.tail(5):
		if str(e2["kind"]) == "TIME_CHANGED":
			found_time = true
	_check(found_time, "TIME_CHANGED relayed on hour step")
	bus.clear_log()
	GS.advance_time(0.05)
	_check(bus.count_kind("TIME_CHANGED") == 0, "no TIME_CHANGED spam within same hour")

	# ---- §9: structured crime record with witnesses ----
	var pnode: Node = get_first_node_in_group("player")
	_check(pnode != null, "player present for crime record")
	GS.commit_crime(2, (pnode as Node3D).global_position)
	var crime: Dictionary = {}
	for e3: Dictionary in bus.tail(5):
		if str(e3["kind"]) == "CRIME":
			crime = e3["data"]
	_check(not crime.is_empty(), "CRIME record exists")
	_check(int(crime.get("severity", -1)) == 2, "CRIME severity recorded")
	_check(crime.has("pos") and crime.has("day_time"), "CRIME pos+time recorded")
	_check(crime.has("witnesses") and crime["witnesses"] is Array,
			"CRIME witnesses array recorded")

	# ---- §19: Economy pay/charge/earn ledger ----
	money0 = GS.money
	var denied: bool = not EconomyRes.pay(money0 + 1000, "test_overdraft")
	_check(denied, "pay denies when insufficient")
	_check(GS.money == money0, "denied pay leaves money untouched")
	var paid: bool = EconomyRes.pay(100, "test_pay")
	_check(paid and GS.money == money0 - 100, "pay deducts exact amount")
	EconomyRes.earn(50, "test_earn")
	_check(GS.money == money0 - 50, "earn credits exact amount")
	var charged: int = EconomyRes.charge(100000, "test_clamp")
	_check(charged == money0 - 50 and GS.money == 0,
			"charge clamps at zero like legacy fines (charged %d)" % charged)
	# restore starting balance through the ledger
	EconomyRes.earn(money0, "test_restore")
	_check(GS.money == money0, "balance restored via earn")
	var txs: Array = EconomyRes.transactions()
	_check(txs.size() >= 5, "transaction ledger populated (%d)" % txs.size())
	var reasons: Array = []
	for e4: Dictionary in txs:
		reasons.append(str(e4["data"].get("reason")))
	_check("test_pay" in reasons and "test_clamp" in reasons,
			"ledger carries reasons")

	# ---- §41: DebugTools stats + commands ----
	var st: Dictionary = DebugToolsRes.stats()
	_check(st.has("fps") and int(st["fps"]) >= 0, "stats: fps present")
	_check(int(st.get("civilians", 0)) >= 10, "stats: civilian count (%d)" % int(st.get("civilians", 0)))
	_check(int(st.get("cars", 0)) >= 15, "stats: car count (%d)" % int(st.get("cars", 0)))
	_check(st.has("player_pos"), "stats: player position present")
	_check(DebugToolsRes.cmd("set_wanted", 3).begins_with("OK") and GS.wanted == 3,
			"cmd set_wanted")
	GS.set_wanted(w0)
	_check(DebugToolsRes.cmd("set_time", 12.0).begins_with("OK")
			and absf(GS.day_time - 12.0) < 0.01, "cmd set_time")
	var before: int = GS.money
	_check(DebugToolsRes.cmd("give_money", 250).begins_with("OK")
			and GS.money == before + 250, "cmd give_money")
	EconomyRes.charge(250, "test_debug_restore")
	var target: Vector3 = (pnode as Node3D).global_position + Vector3(3.0, 0.2, 0.0)
	_check(DebugToolsRes.cmd("teleport", target).begins_with("OK")
			and (pnode as Node3D).global_position.distance_to(target) < 0.5,
			"cmd teleport")
	_check(DebugToolsRes.cmd("give_weapon", "kestrel556").begins_with("OK"),
			"cmd give_weapon")
	var wpn: Node = pnode.get("pistol")
	_check(wpn != null and bool(wpn.get("owned_weapons").get("kestrel556", false)),
			"granted weapon owned")
	_check(DebugToolsRes.cmd("spawn_car", null).begins_with("OK"), "cmd spawn_car")
	_check(get_nodes_in_group("cars").size() >= 16, "spawned car in world")
	_check(DebugToolsRes.cmd("nonexistent_cmd", null).begins_with("ERR"),
			"unknown command errors safely")
	var dbg_cmds: int = bus.count_kind("DEBUG_CMD")
	_check(dbg_cmds >= 7, "commands logged on bus (%d)" % dbg_cmds)

	if passed == total:
		print("SYSTEM_RESULT: ALL PASS (%d/%d)" % [passed, total])
		quit(0)
	else:
		print("SYSTEM_RESULT: FAIL %d/%d" % [passed, total])
		quit(1)
	return false
