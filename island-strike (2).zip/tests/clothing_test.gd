extends SceneTree
## Deep clothing test — verifies 8 outfit types, jacket/hat/gender, deterministic seed, district-aware spawning

var f := 0
var game: Node

func _initialize() -> void:
	game = load("res://scenes/game/game.tscn").instantiate()
	root.add_child(game)
	current_scene = game

func _process(_d: float) -> bool:
	f += 1
	if f != 50:
		return false
	
	var rig_script = load("res://scripts/characters/character_rig.gd")
	var passed := 0
	var total := 0
	
	# Test 1: All outfit factories exist and return dict with required keys
	var outfit_funcs = ["player_outfit", "police_outfit", "gang_outfit", "commuter_outfit", "service_outfit", "military_outfit", "beach_outfit"]
	for fname in outfit_funcs:
		total += 1
		var outfit: Dictionary = rig_script.call(fname) if fname != "player_outfit" else rig_script.player_outfit()
		if outfit.has("skin") and outfit.has("hair") and outfit.has("shirt") and outfit.has("pants") and outfit.has("shoes") and outfit.has("jacket") and outfit.has("hat") and outfit.has("gender") and outfit.has("type"):
			passed += 1
		else:
			print("CLOTHING_FAIL: %s missing keys %s" % [fname, outfit.keys()])
	
	# Test 2: npc_outfit with shirt param
	total += 1
	var npc_out = rig_script.npc_outfit(Color(0.7,0.7,0.7))
	if npc_out.has("jacket") and npc_out.has("hat") and npc_out.has("gender"):
		passed += 1
	else:
		print("CLOTHING_FAIL: npc_outfit missing new keys")
	
	# Test 3: female_outfit
	total += 1
	var female_out = rig_script.female_outfit(Color(0.8,0.6,0.6))
	if female_out["gender"] == "female":
		passed += 1
	else:
		print("CLOTHING_FAIL: female_outfit gender != female")
	
	# Test 4: Deterministic seed — same counter should give same results across runs
	# Reset counter and check determinism
	total += 1
	rig_script._outfit_counter = 0
	var out1 = rig_script.npc_outfit(Color(0.7,0.7,0.7))
	rig_script._outfit_counter = 0
	var out2 = rig_script.npc_outfit(Color(0.7,0.7,0.7))
	if out1["skin"] == out2["skin"] and out1["pants"] == out2["pants"]:
		passed += 1
	else:
		print("CLOTHING_FAIL: deterministic seed broken")
	
	# Test 5: Police outfit specific colors
	total += 1
	var police = rig_script.police_outfit()
	if police["shirt"].is_equal_approx(Color(0.15, 0.20, 0.50)) and police["hat"] == true and police["type"] == "police":
		passed += 1
	else:
		print("CLOTHING_FAIL: police outfit incorrect %s" % police)
	
	# Test 6: Gang outfit has jacket chance
	total += 1
	var has_jacket_count := 0
	rig_script._outfit_counter = 100
	for i in range(20):
		var g = rig_script.gang_outfit()
		if g["jacket"]:
			has_jacket_count += 1
	if has_jacket_count > 0:
		passed += 1
	else:
		print("CLOTHING_FAIL: gang jacket never true")
	
	# Test 7: Beach outfit shorts color
	total += 1
	var beach = rig_script.beach_outfit()
	if beach["pants"].is_equal_approx(Color(0.85, 0.80, 0.60)) and beach["type"] == "beach":
		passed += 1
	else:
		print("CLOTHING_FAIL: beach pants not shorts color")
	
	# Test 8: Military outfit
	total += 1
	var mil = rig_script.military_outfit()
	if mil["type"] == "military" and mil["hat"] == true:
		passed += 1
	else:
		print("CLOTHING_FAIL: military")
	
	# Test 9: Service outfit
	total += 1
	var serv = rig_script.service_outfit()
	if serv["shirt"].is_equal_approx(Color(0.85, 0.65, 0.25)) and serv["type"] == "service":
		passed += 1
	else:
		print("CLOTHING_FAIL: service")
	
	# Test 10: CharacterRig.create with jacket/hat
	total += 1
	var test_outfit = {
		"skin": Color(0.85, 0.66, 0.52),
		"hair": Color(0.13, 0.09, 0.06),
		"shirt": Color(0.93, 0.93, 0.95),
		"pants": Color(0.16, 0.17, 0.19),
		"shoes": Color(0.88, 0.88, 0.90),
		"watch": true,
		"jacket": true,
		"hat": true,
		"gender": "male",
		"type": "police",
	}
	var rig = rig_script.create(test_outfit)
	if rig != null and rig.get_child_count() > 0:
		passed += 1
	else:
		print("CLOTHING_FAIL: rig create failed")
	
	# Test 11: Female rig smaller head
	total += 1
	var female_rig_outfit = {
		"skin": Color(0.75, 0.58, 0.44),
		"hair": Color(0.12, 0.08, 0.04),
		"shirt": Color(0.75, 0.60, 0.65),
		"pants": Color(0.055, 0.09, 0.16),
		"shoes": Color(0.88, 0.88, 0.90),
		"watch": false,
		"jacket": false,
		"hat": false,
		"gender": "female",
		"type": "civilian",
	}
	var frig = rig_script.create(female_rig_outfit)
	if frig != null:
		passed += 1
	else:
		print("CLOTHING_FAIL: female rig")
	
	# Test 12: GameState cached methods exist
	total += 1
	var gs = root.get_node("GameState")
	if gs.has_method("get_player") and gs.has_method("get_random_sidewalk_point") and gs.has_method("get_cached_group"):
		passed += 1
	else:
		print("CLOTHING_FAIL: GameState missing cached methods")
	
	# Test 13: WBKit utilities
	total += 1
	var wbkit = load("res://scripts/world/wb_kit.gd")
	if wbkit.has_method("random_sidewalk_point") and wbkit.has_method("district_at") and wbkit.has_method("is_beach_point"):
		passed += 1
	else:
		print("CLOTHING_FAIL: WBKit missing utilities")
	
	if passed == total:
		print("CLOTHING_RESULT: ALL PASS (%d/%d)" % [passed, total])
		quit(0)
	else:
		print("CLOTHING_RESULT: FAIL %d/%d" % [passed, total])
		quit(1)
	return false
