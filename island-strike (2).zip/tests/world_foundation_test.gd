extends SceneTree
## World Foundation suite (Reconstruction Prompt 02, §24): the 6 km circular
## world contract, sector model, streamer adaptation, save migration,
## terrain domain, and performance invariants.
## Prints WORLD_FOUNDATION_RESULT: ALL PASS. Never lowers an assertion to
## pass; every gate maps to the Prompt 02 §24 numbered list (noted as #n).

var fails := 0
var checks := 0
var world_root: Node3D
var player: CharacterBody3D
var strm: Streamer


func _gate(cond: bool, msg: String) -> void:
	checks += 1
	if cond:
		print("WF PASS: %s" % msg)
	else:
		print("WF FAIL: %s" % msg)
		fails += 1


func _body_at(pos: Vector3) -> StaticBody3D:
	var b := StaticBody3D.new()
	b.position = pos  # local == global (parent at origin); safe outside tree
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = Vector3(5, 1, 5)
	cs.shape = sh
	b.add_child(cs)
	return b


func _visual_at(pos: Vector3) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(2, 2, 2)
	m.mesh = bm
	m.position = pos
	return m


func _drain(n: int = 6) -> void:
	for i in range(n):
		strm._physics_process(0.016)


func _initialize() -> void:
	pass  # SceneTree is not active during _initialize; all work runs on frame 2


var _frames := 0


func _process(_d: float) -> bool:
	_frames += 1
	if _frames == 2:
		_run_all()
		_debug_section()
		if fails == 0:
			print("WORLD_FOUNDATION_RESULT: ALL PASS (%d/%d)" % [checks, checks])
			quit(0)
		else:
			print("WORLD_FOUNDATION_RESULT: FAIL %d/%d" % [checks - fails, checks])
			quit(1)
	return false


func _run_all() -> void:
	# --- test world scaffolding (light: no game.tscn build needed) ---
	world_root = Node3D.new()
	world_root.name = "WFWorld"
	root.add_child(world_root)
	current_scene = world_root
	player = CharacterBody3D.new()
	player.name = "WFPlayer"
	root.add_child(player)
	player.add_to_group("player")  # groups register only once inside the tree
	player.global_position = Vector3(100, 0.9, 100)
	# streamed content: player sector, 1-ring neighbor, far sector,
	# beyond-old-island-but-inside-circle, outside-world, + 2 visuals
	world_root.add_child(_body_at(Vector3(100, 0, 100)))     # S_0_0
	world_root.add_child(_body_at(Vector3(200, 0, 100)))     # S_1_0 (ring 1)
	world_root.add_child(_body_at(Vector3(600, 0, 600)))     # S_4_4 (far)
	world_root.add_child(_body_at(Vector3(500, 0, 100)))     # S_4_0 beyond old 450 m island, inside circle
	world_root.add_child(_body_at(Vector3(4000, 0, 4000)))   # outside world circle
	world_root.add_child(_visual_at(Vector3(110, 1, 110)))
	world_root.add_child(_visual_at(Vector3(610, 1, 610)))
	strm = Streamer.create(player)
	world_root.add_child(strm)
	strm.scan(world_root)
	_drain()

	_bounds_section()
	_sector_section()
	_schema_section()
	_streamer_section()
	_save_section()
	_terrain_section()
	_perf_section()


func _bounds_section() -> void:
	var WC := WorldContract
	# 1 center inside
	_gate(WC.is_playable(Vector3.ZERO), "#1 center inside")
	# 2 x=3000 on-boundary policy: inclusive
	_gate(WC.is_playable(Vector3(3000, 0, 0)), "#2 (3000,0) on boundary = inside (inclusive policy)")
	# 3/4 just outside
	_gate(not WC.is_playable(Vector3(3001, 0, 0)), "#3 (3001,0) outside")
	_gate(not WC.is_playable(Vector3(0, 0, 3001)), "#4 (0,3001) outside")
	# 5 diagonal near radial edge: 2121.3^2*2 = 8,999,759 <= 9,000,000
	_gate(WC.is_playable(Vector3(2121.3, 0, 2121.3)), "#5 (2121.3,2121.3) inside radial edge")
	_gate(not WC.is_playable(Vector3(2121.4, 0, 2121.4)), "#5b (2121.4,2121.4) just outside")
	# 6 square corner outside
	_gate(not WC.is_playable(Vector3(3000, 0, 3000)), "#6 corner (3000,3000) outside")
	_gate(not WC.is_playable(Vector3(-3000, 0, -3000)), "#6b corner (-3000,-3000) outside")
	# 7 negative axes
	_gate(WC.is_playable(Vector3(-3000, 0, 0)), "#7 (-3000,0) on boundary inside")
	_gate(not WC.is_playable(Vector3(-3001, 0, 0)), "#7b (-3001,0) outside")
	_gate(WC.is_playable(Vector3(0, 0, -3000)) and not WC.is_playable(Vector3(0, 0, -3001)),
			"#7c z-axis boundary symmetric")
	# 8 tolerance behavior: deterministic inclusivity, no jitter either side
	var a: bool = WC.is_playable(Vector3(3000.0, 0, 0))
	var b: bool = WC.is_playable(Vector3(3000.0, 0, 0))
	_gate(a == b and a, "#8 boundary evaluation deterministic (no inside/outside jitter)")
	_gate(WC.normalized_radius(Vector2(3000, 0)) == 1.0, "#8b normalized_radius = 1.0 at edge")
	_gate(WC.normalized_radius(Vector2(1500, 0)) == 0.5, "#8c normalized_radius = 0.5 mid")


func _sector_section() -> void:
	var WC := WorldContract
	# 9 center sector deterministic
	_gate(WC.micro_sector_of(Vector2(0, 0)) == Vector2i(0, 0), "#9 center -> S_0_0")
	# 10 same coordinate always same sector
	_gate(WC.micro_sector_of(Vector2(317.2, -88.4)) == WC.micro_sector_of(Vector2(317.2, -88.4)),
			"#10 coordinate -> sector deterministic")
	# 11 neighboring coordinates -> neighboring sectors
	var s1: Vector2i = WC.micro_sector_of(Vector2(124.0, 0))
	var s2: Vector2i = WC.micro_sector_of(Vector2(126.0, 0))
	_gate(s2 - s1 == Vector2i(1, 0), "#11 crossing 125 m line advances sector by 1")
	# 12 sector center reconstructs index
	var sc: Vector2 = WC.micro_sector_to_world(Vector2i(-7, 3))
	_gate(WC.micro_sector_of(sc) == Vector2i(-7, 3), "#12 sector center maps back to its index")
	# 13 macro contains micro
	var m: Vector2i = WC.macro_of_micro(Vector2i(5, -3))
	var mc: Vector2 = WC.sector_to_world(m)
	var mrec: Vector2 = WC.micro_sector_to_world(Vector2i(5, -3))
	_gate(absf(mrec.x - mc.x) <= WC.SECTOR_M * 0.5 + WC.MICRO_SECTOR_M
			and WC.micro_id(Vector2i(5, -3)) == "S_5_-3"
			and WC.macro_id(m) == "M_%d_%d" % [m.x, m.y], "#13 macro contains micro + ID format")
	# 14 edge coordinate deterministic + valid
	var edge: Vector2i = WC.micro_sector_of(Vector2(2999.0, 0))
	_gate(edge == Vector2i(23, 0) and WC.micro_sector_is_valid(edge),
			"#14 edge coord (2999,0) -> S_23_0 valid")
	# grid span sanity (P02 §5): 12x12 macro / 48x48 micro bounding square
	_gate(WC.MACRO_GRID_SPAN == 12 and WC.MICRO_GRID_SPAN == 48
			and WC.MACRO_GRID_SPAN * WC.SECTOR_M == WC.DIAMETER_M
			and WC.MICRO_GRID_SPAN * WC.MICRO_SECTOR_M == WC.DIAMETER_M,
			"#14b grid spans tile the 6000 m square exactly")
	# registry records carry the §6 contract fields
	var rec: Dictionary = WorldSectorRegistry.micro_record(Vector2i(0, 0))
	var has_all := true
	for k in ["id", "macro_id", "grid_x", "grid_z", "center_x", "center_z", "bounds",
			"circle_intersection", "region_id", "district_id", "biome_id", "density_class",
			"road_class", "terrain_class", "population_class", "traffic_class",
			"stream_state", "generation_seed", "revision", "version"]:
		if not rec.has(k):
			has_all = false
	_gate(has_all, "#13b micro record carries the full §6 data contract")
	var v: Dictionary = WorldSectorRegistry.validate()
	_gate(bool(v["ok"]), "#13c registry validate ok (%s)" % str(v["counts"]))
	# seeds deterministic + distinct per sector/subsystem
	_gate(WorldContract.micro_seed(Vector2i(3, 4)) == WorldContract.micro_seed(Vector2i(3, 4))
			and WorldContract.micro_seed(Vector2i(3, 4)) != WorldContract.micro_seed(Vector2i(4, 3))
			and WorldContract.subsystem_seed(Vector2i(3, 4), 0)
					!= WorldContract.subsystem_seed(Vector2i(3, 4), 1),
			"#13d seed chain deterministic and non-colliding")


func _schema_section() -> void:
	var sch: Dictionary = WorldContract.schema_dict()
	# 15 schema version present
	_gate(int(sch.get("schema_version", 0)) == WorldContract.SCHEMA_VERSION
			and int(sch.get("revision", 0)) == WorldContract.WORLD_REVISION,
			"#15 schema version + revision present")
	# 16 radius serialized
	_gate(float(sch.get("radius_m", 0)) == 3000.0, "#16 radius serialized (3000 m)")
	# 17 center serialized
	_gate((sch.get("center_xz_m", []) as Array) == [0.0, 0.0], "#17 center serialized (0,0)")
	# 18 seed serialized
	_gate(int(sch.get("seed", 0)) == 20260915, "#18 world seed serialized (20260915)")
	# 19 legacy world data migrates (WorldDataRes tolerates missing "world")
	var res := WorldDataRes.new()
	res.from_dict({"island": Rect2(-450, -350, 900, 700)})
	_gate((res.world as Dictionary).is_empty(), "#19a legacy dict -> empty world (tolerant)")
	res.from_dict({"world": sch})
	_gate(float(res.to_dict()["world"]["radius_m"]) == 3000.0, "#19b world survives round-trip")
	# committed typed resource carries the schema (regenerated this lock)
	var tres := load("res://assets/data/world.tres") as WorldDataRes
	_gate(tres != null and float((tres.world as Dictionary).get("radius_m", 0)) == 3000.0,
			"#19c assets/data/world.tres carries world schema")


func _streamer_section() -> void:
	# 20 initial player sector active
	_gate(strm.collision_enabled_at(Vector3(100, 0, 100)), "#20 player sector active")
	# 21 neighboring ring active
	_gate(strm.collision_enabled_at(Vector3(200, 0, 100)), "#21 1-ring neighbor active")
	# 22 far sector not active
	_gate(not strm.collision_enabled_at(Vector3(600, 0, 600)), "#22 far sector parked")
	# body-level truth: player-sector body has collision, far body layer 0
	var b0: StaticBody3D = world_root.get_child(0)
	var b2: StaticBody3D = world_root.get_child(2)
	_gate(b0.collision_layer != 0 and b2.collision_layer == 0,
			"#22b body collision layers match bands")
	# 24 player tile collision guarantee
	_gate(strm.player_tile_contract_holds(), "#24 player-tile contract holds")
	# 25/26 no duplicate activation / ownership: every body in exactly one bucket
	var seen := {}
	var total := 0
	for t: Vector2i in strm._tiles.keys():
		for b: Node in strm._tiles[t].bodies:
			seen[b.get_instance_id()] = true
			total += 1
	_gate(seen.size() == total, "#25/26 no duplicate sector ownership (%d bodies)" % total)
	# 23 hysteresis: 2 rings away keeps collision (hold band), 4 rings drops it
	player.global_position = Vector3(350, 0.9, 100)  # S_2_0: ring 2 from S_0_0
	_drain()
	_gate(b0.collision_layer != 0, "#23a hysteresis holds at ring 2")
	player.global_position = Vector3(600, 0.9, 600)  # S_4_4: ring 4
	_drain()
	_gate(b0.collision_layer == 0, "#23b drops beyond hysteresis ring")
	# 27 transition stability: oscillate across a sector boundary (x=250)
	var stable := true
	for i in range(6):
		player.global_position = Vector3(249.0 if i % 2 == 0 else 251.0, 0.9, 100)
		_drain()
		if not strm.collision_enabled_at(player.global_position):
			stable = false
	_gate(stable, "#27 boundary oscillation never loses player collision")
	# 28 traversal across OLD map boundary (x=450) works: S_4_0 registered + activates
	var crossed := strm._tiles.has(Vector2i(4, 0))
	player.global_position = Vector3(500, 0.9, 100)
	_drain()
	_gate(crossed and strm.collision_enabled_at(Vector3(500, 0, 100)),
			"#28 traversal beyond old 900x700 island works")
	# 29 traversal deep inside new world (beyond old boundary) works
	player.global_position = Vector3(2000, 0.9, -1500)
	_drain()
	_gate(strm.sector_of_player() == Vector2i(16, -12)
			and strm.collision_enabled_at(Vector3(2000, 0, -1500)),
			"#29 deep new-world position streams correctly")
	# 30 outside boundary rejected: (4000,4000) body went always-on, not sectored
	var out_rejected := not strm._tiles.has(Vector2i(32, 32))
	player.global_position = Vector3(100, 0.9, 100)
	_drain()
	_gate(out_rejected, "#30 outside-circle geometry rejected from sector grid")


func _save_section() -> void:
	player.remove_from_group("player")  # isolate save path from the dummy
	var SS: Node = root.get_node("/root/SaveSystem")
	var bus: Node = root.get_node("/root/EventBus")
	var backup: String = ""
	if FileAccess.file_exists(GameState.SAVE_PATH):
		backup = FileAccess.get_file_as_string(GameState.SAVE_PATH)
	var legacy: Dictionary = {"version": 3, "money": 123, "wanted": 0,
			"player": {"pos": [-430.0, 0.6, -40.0], "health": 100.0},
			"mission": {"active": "bank_run", "objective_index": 1},
			"missions_done": ["dock_cleanup"]}
	# 31 legacy save with old coordinates loads
	_write_save(legacy)
	var ok31: bool = SS.load_game()
	var clamped31 := _bus_has(bus, "WORLD_MIGRATED")
	_gate(ok31 and not clamped31, "#31 legacy old-world save loads, no clamp needed")
	# 34 mission state survives spatial migration untouched
	var san: Dictionary = SS._sanitize_spatial(legacy.duplicate(true))
	_gate((san["mission"] as Dictionary) == legacy["mission"]
			and (san["missions_done"] as Array) == legacy["missions_done"],
			"#34 mission state untouched by spatial migration")
	# 32 new save with large coordinates loads unchanged
	var big: Dictionary = legacy.duplicate(true)
	big["player"] = {"pos": [2500.0, 0.6, 100.0]}
	var san2: Dictionary = SS._sanitize_spatial(big.duplicate(true))
	_gate((san2["player"]["pos"] as Array) == [2500.0, 0.6, 100.0],
			"#32 large-coordinate position preserved")
	# 33 outside-new-world save clamps safely + records event
	var out: Dictionary = legacy.duplicate(true)
	out["player"] = {"pos": [4000.0, 0.6, 0.0]}
	var san3: Dictionary = SS._sanitize_spatial(out.duplicate(true))
	var p3: Array = san3["player"]["pos"]
	var v3 := Vector3(float(p3[0]), float(p3[1]), float(p3[2]))
	_gate(WorldContract.is_playable(v3) and absf(v3.x - 2990.0) < 0.001,
			"#33 outside position clamped to inset radius")
	_write_save(out)
	SS.load_game()
	_gate(_bus_has(bus, "WORLD_MIGRATED"), "#33b clamp recorded as migration event")
	# 35 duplicate migration does not duplicate anything (idempotent)
	var san4: Dictionary = SS._sanitize_spatial(san3.duplicate(true))
	_gate((san4["player"]["pos"] as Array) == (san3["player"]["pos"] as Array)
			and str(san4["mission"]) == str(san3["mission"]),
			"#35 double migration idempotent")
	# restore environment
	if backup != "":
		_write_raw(backup)
	elif FileAccess.file_exists(GameState.SAVE_PATH):
		DirAccess.remove_absolute(GameState.SAVE_PATH)


func _write_save(d: Dictionary) -> void:
	_write_raw(JSON.stringify(d))


func _write_raw(text: String) -> void:
	var f := FileAccess.open(GameState.SAVE_PATH, FileAccess.WRITE)
	f.store_string(text)
	f.close()


func _bus_has(bus: Node, kind: String) -> bool:
	for e: Variant in bus.tail(12):
		if str((e as Dictionary).get("kind", "")) == kind:
			return true
	return false


func _terrain_section() -> void:
	var WT := WorldTerrain
	WT.activate = false
	# 36 center deterministic
	_gate(WT.height_at(0.0, 0.0) == 0.0 and WT.height_at(0.0, 0.0) == WT.height_at(0.0, 0.0),
			"#36 height_at center deterministic (flat contract)")
	WT.activate = true
	WT.active_zone = Rect2(-400, -500, 800, 200)
	# 37 identical input -> identical result (mountain zone sample)
	var h1: float = WT.height_at(-300.0, -400.0)
	var h2: float = WT.height_at(-300.0, -400.0)
	_gate(h1 == h2 and h1 != 0.0, "#37 deterministic non-flat height (%.4f)" % h1)
	# 38 outside circle -> controlled result
	_gate(WT.height_at(4000.0, 0.0) == WT.OUT_OF_WORLD_Y
			and WT.height_at(-3500.0, 2000.0) == WT.OUT_OF_WORLD_Y,
			"#38 out-of-world height controlled (%.1f)" % WT.OUT_OF_WORLD_Y)
	# 39 chunk coordinate stable
	_gate(WT.chunk_sector_of(-300.0, -400.0) == WorldContract.micro_sector_of(Vector2(-300, -400))
			and WT.chunk_sector_of(-300.0, -400.0) == WT.chunk_sector_of(-300.0, -400.0),
			"#39 terrain chunk sector stable")
	# 40 chunk boundary continuity (125 m line at x=-250 inside active zone)
	var ha: float = WT.height_at(-250.0, -400.0)
	var hb: float = WT.height_at(-249.9, -400.0)
	_gate(absf(ha - hb) < 2.0, "#40 no discontinuity across chunk boundary (d=%.4f)" % absf(ha - hb))
	# zone clipping respects the world circle
	var clipped: Rect2 = WT.zone_clipped_to_world(Rect2(-5000, -100, 10000, 200))
	_gate(clipped.position.x >= -3000.0 and clipped.end.x <= 3000.0,
			"#40b zone_clipped_to_world bounds the domain")
	WT.activate = false
	WT.active_zone = Rect2()


func _perf_section() -> void:
	# 41 sector lookup bounded
	var t0 := Time.get_ticks_usec()
	var acc := 0
	for i in range(200000):
		if WorldContract.micro_sector_is_valid(
				WorldContract.micro_sector_of(Vector2(float(i % 6000) - 3000.0, float(i % 4000) - 2000.0))):
			acc += 1
	var dt: float = float(Time.get_ticks_usec() - t0) / 1000.0
	_gate(dt < 800.0, "#41 200k sector lookups in %.1f ms (<800)" % dt)
	# 42 records cached (no per-frame reconstruction)
	var r1: Dictionary = WorldSectorRegistry.micro_record(Vector2i(2, 3))
	var r2: Dictionary = WorldSectorRegistry.micro_record(Vector2i(2, 3))
	_gate(is_same(r1, r2), "#42 sector records cached (same instance)")
	# 43 no per-frame global scan: _physics_process touches only band math —
	# proven by timing 1000 idle ticks with a settled player
	player.global_position = Vector3(100, 0.9, 100)
	_drain()
	var t1 := Time.get_ticks_usec()
	for i in range(1000):
		strm._physics_process(0.016)
	var dt2: float = float(Time.get_ticks_usec() - t1) / 1000.0
	_gate(dt2 < 200.0, "#43 1000 settled ticks in %.1f ms (<200)" % dt2)
	# 44 activation queue bounded: worst-case jump queues each sector at most once
	player.global_position = Vector3(-2000, 0.9, 1500)
	strm._physics_process(0.016)
	_gate(strm.pending_count() <= strm._tiles.size(),
			"#44 activation queue bounded (%d <= %d)" % [strm.pending_count(), strm._tiles.size()])
	# 45 long traversal does not leak nodes
	player.global_position = Vector3(100, 0.9, 100)
	_drain()
	var n0: int = root.get_child_count() + world_root.get_child_count()
	for i in range(20):
		player.global_position = Vector3(float((i % 5) * 300 - 600), 0.9, float((i / 5) * 300 - 300))
		_drain(3)
	var n1: int = root.get_child_count() + world_root.get_child_count()
	_gate(n1 == n0, "#45 traversal leaks no nodes (%d -> %d)" % [n0, n1])
	# metrics snapshot shape (P02 §26)
	var met: Dictionary = strm.metrics()
	_gate(met.has("active_sectors") and met.has("far_sectors")
			and met.has("last_transition_ms") and met.has("player_sector"),
			"#26 streamer metrics snapshot complete")


func _debug_section() -> void:
	var r1: String = DebugTools.cmd("toggle_world_grid")
	var grid: Node = current_scene.get_node_or_null("WorldGridDebug")
	var verts := 0
	if grid != null:
		var mi: MeshInstance3D = grid.get_child(0)
		verts = (mi.mesh.surface_get_arrays(0)[Mesh.ARRAY_VERTEX] as PackedVector3Array).size()
	_gate(r1.begins_with("OK: world grid on") and grid != null and verts >= 200,
			"§25 world grid on: %d line verts; snapshot: %s" % [verts, r1.substr(0, 96)])
	var r2: String = DebugTools.cmd("toggle_world_grid")
	_gate(r2.begins_with("OK: world grid off")
			and current_scene.get_node_or_null("WorldGridDebug") == null, "§25 world grid toggles off")
