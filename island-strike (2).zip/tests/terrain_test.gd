extends SceneTree
## Terrain suite (Phase 7): flat-first contract, determinism, border falloff,
## patch-mesh/height agreement. TERRAIN_RESULT: ALL PASS

func _initialize() -> void:
	var fails := 0
	# 1. flat contract: height_at == 0 everywhere while activation is off
	WorldTerrain.activate = false
	var flat := true
	for x in range(-440, 441, 80):
		for z in range(-340, 341, 80):
			if WorldTerrain.height_at(float(x), float(z)) != 0.0:
				flat = false
	if not flat:
		print("TERRAIN FAIL: flat contract broken (activation is off)")
		fails += 1
	else:
		print("TERRAIN PASS: flat contract (height_at == 0 across island)")
	# 2. activation + determinism — use mountain zone (north), not farmland (flat in hybrid)
	WorldTerrain.activate = true
	WorldTerrain.active_zone = Rect2(-400, -500, 800, 200)
	var a := WorldTerrain.height_at(-300.0, -400.0)
	var b := WorldTerrain.height_at(-300.0, -400.0)
	if a != b or a == 0.0:
		print("TERRAIN FAIL: determinism/activation (a=%.4f b=%.4f)" % [a, b])
		fails += 1
	else:
		print("TERRAIN PASS: activated height deterministic (h=%.4f)" % a)
	# 3. border falloff: zone edge is 0 (no cliffs into flat world)
	var border := WorldTerrain.height_at(-400.0, -400.0)
	if border != 0.0:
		print("TERRAIN FAIL: zone border not flat (%.4f)" % border)
		fails += 1
	else:
		print("TERRAIN PASS: border falloff (edge == 0)")
	# 4. patch mesh agrees with height_at at sampled vertices
	var holder := Node3D.new()
	root.add_child(holder)
	var patch := WorldTerrain.build_patch(holder)
	var mesh: ArrayMesh = (patch as MeshInstance3D).mesh
	var verts: PackedVector3Array = mesh.surface_get_arrays(0)[Mesh.ARRAY_VERTEX]
	var ok := true
	for i in range(0, verts.size(), 37):
		var v := verts[i]
		if absf(v.y - WorldTerrain.height_at(patch.position.x + v.x,
				patch.position.z + v.z)) > 0.001:
			ok = false
	if not ok:
		print("TERRAIN FAIL: patch mesh disagrees with height_at")
		fails += 1
	else:
		print("TERRAIN PASS: patch mesh matches height_at (%d verts)" % verts.size())
	holder.queue_free()
	WorldTerrain.activate = false
	WorldTerrain.active_zone = Rect2()
	if fails == 0:
		print("TERRAIN_RESULT: ALL PASS")
		quit(0)
	else:
		print("TERRAIN_RESULT: FAIL (%d)" % fails)
		quit(1)
