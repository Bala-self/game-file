extends SceneTree
## P03 §34/§35 terrain reconstruction suite — entry point (static gates 1-38
## plus geometry-quality statistics). Live gates 39-55 run in-tree via
## terrain_live_node.gd against the real game scene.
## Run: godot --headless --path . -s res://tests/terrain_reconstruction_test.gd

const WT := preload("res://scripts/world/terrain.gd")
const TA := preload("res://scripts/world/terrain_authoring.gd")
const WBK := preload("res://scripts/world/wb_kit.gd")

var fails := 0
var passes := 0
var qa_notes := 0


func _check(ok: bool, label: String) -> void:
	if ok:
		passes += 1
		print("TRECON PASS: %s" % label)
	else:
		fails += 1
		print("TRECON FAIL: %s" % label)


func _qa(ok: bool, label: String) -> void:
	if ok:
		print("TRECON QA PASS: %s" % label)
	else:
		fails += 1
		print("TRECON QA FAIL: %s" % label)


func _initialize() -> void:
	Engine.max_fps = 60
	_world_domain()
	_determinism()
	_continuity()
	_elevation()
	_slope()
	_water()
	_classes()
	_sector_integration()
	_geometry_qa()
	# hand off to the live half (gates 39-55) with the running tally
	var game: Node = load("res://scenes/game/game.tscn").instantiate()
	root.add_child(game)
	current_scene = game
	var tester := Node.new()
	tester.set_script(load("res://tests/terrain_live_node.gd"))
	tester.set_meta("static_passes", passes)
	tester.set_meta("static_fails", fails)
	root.add_child(tester)


# ---------------------------------------------------------------- domain (1-6)
func _world_domain() -> void:
	_check(WorldContract.is_playable(Vector3(0, 0, 0)), "1 center valid")
	_check(WorldContract.is_playable(Vector3(WorldContract.RADIUS_M, 0, 0)),
			"2 radius boundary valid by contract")
	_check(not WorldContract.is_playable(Vector3(WorldContract.RADIUS_M + 1.0, 0, 0)),
			"3 outside radius invalid")
	_check(not WorldContract.is_playable(Vector3(3000, 0, 3000)), "4 corners invalid")
	_check(WT.height_at(3100.0, 0.0) == WT.OUT_OF_WORLD_Y
			and WT.OUT_OF_WORLD_Y == -3.0, "5 out-of-world height controlled (-3.0)")
	_check(WT.is_water_position(-900.0, 220.0) and not WT.is_water_position(0.0, 0.0)
			and WT.height_at(3100.0, 0.0) < TA.SEA_LEVEL_M,
			"6 water inside/outside follows contract")


# ------------------------------------------------------- determinism (7-10)
func _determinism() -> void:
	var pts := [Vector2(0, 0), Vector2(812, -1466), Vector2(-2210, 940),
			Vector2(1620, 950), Vector2(760, -1100), Vector2(-582, 226),
			Vector2(2450, -2280), Vector2(410, 2210), Vector2(-1750, -1750),
			Vector2(640, 60), Vector2(2999, 0), Vector2(-63, 646)]
	var ok := true
	for p: Vector2 in pts:
		if WT.height_at(p.x, p.y) != WT.height_at(p.x, p.y):
			ok = false
	_check(ok, "7 same coordinate = same height")
	var snap: PackedFloat64Array = PackedFloat64Array()
	for p: Vector2 in pts:
		snap.append(WT.height_at(p.x, p.y))
	var ok2 := true
	for i in range(1000):
		var p: Vector2 = pts[i % pts.size()]
		if WT.height_at(p.x, p.y) != snap[i % pts.size()]:
			ok2 = false
			break
	_check(ok2, "8 repeated 1000 queries identical")
	var before: String = str(WorldSectorRegistry.terrain_profile_for_sector(Vector2i(4, -6)))
	WorldSectorRegistry.invalidate()
	var after: String = str(WorldSectorRegistry.terrain_profile_for_sector(Vector2i(4, -6)))
	_check(before == after, "9 sector regeneration = same values")
	var rg: Dictionary = WT.resolve_to_ground(812.0, -1466.0)
	var json: String = JSON.stringify(rg)
	var back: Dictionary = JSON.parse_string(json)
	var same: bool = is_equal_approx(float(back["ground_y"]), float(rg["ground_y"])) \
			and String(back["surface"]) == String(rg["surface"]) \
			and WT.height_at(812.0, -1466.0) == float(rg["ground_y"])
	_check(same, "10 save/load round-trip = same terrain result")


# ---------------------------------------------------------- continuity (11-15)
func _continuity() -> void:
	# 11: chunk border columns sample identically from both sides (grid is
	# shared; this asserts the chunk math introduces no seam offsets)
	var ok := true
	for k in range(-4, 5):
		var xb: float = float(k) * TerrainChunks.CHUNK_M
		for zz in [-800.0, -33.0, 640.0, 1900.0]:
			var a: float = WT.height_at(xb - 0.001, zz)
			var b: float = WT.height_at(xb + 0.001, zz)
			if absf(a - b) > 0.01:
				ok = false
	_check(ok, "11 adjacent chunk border heights match")
	# 12: sector boundary transects stay under the discontinuity threshold
	var worst: float = 0.0
	for k in range(-6, 7):
		var xb: float = float(k) * 125.0
		var z: float = -2400.0
		while z <= 2400.0:
			worst = maxf(worst, absf(WT.height_at(xb, z + 2.0) - WT.height_at(xb, z)))
			z += 8.0
	_check(worst < 8.0, "12 sector boundary continuity (worst 2 m step = %.3f)" % worst)
	# 13: river bank transects smooth
	var rworst: float = 0.0
	for i in range(TA.RIVER_PTS.size()):
		var p: Vector2 = TA.RIVER_PTS[i]
		var w: float = WT._river_width_at(p.x, p.y)
		for s in range(0, 10):
			var d: float = float(s) * w * 0.3
			rworst = maxf(rworst, absf(WT.height_at(p.x + d + 2.0, p.y)
					- WT.height_at(p.x + d, p.y)))
	_check(rworst < 2.0, "13 river boundary smooth (worst 2 m step = %.3f)" % rworst)
	# 14: coastline deterministic + land-above / sea-below across the
	# transition (strict monotonicity would fail on legitimate detail noise;
	# the crossing direction and submersion are the contract)
	var le1: float = TA.land_end_r(90.0)
	var le2: float = TA.land_end_r(90.0)
	var h_land: float = WT.height_at(le1 - 150.0, 0.0)
	var h_sea: float = WT.height_at(minf(le1 + 350.0, 2960.0), 0.0)
	_check(le1 == le2 and h_land > TA.SEA_LEVEL_M + 0.5 and h_land - h_sea > 10.0,
			"14 coastline transition deterministic (land %.1f, offshore %.1f)" % [h_land, h_sea])
	# 15: platform blend continuous across r=700
	var bworst: float = 0.0
	for i in range(72):
		var a: float = TAU * float(i) / 72.0
		bworst = maxf(bworst, absf(WT.height_at(cos(a) * 705.0, sin(a) * 705.0)
				- WT.height_at(cos(a) * 695.0, sin(a) * 695.0)))
	_check(absf(WT.height_at(0.0, 695.0)) < 0.001 and bworst < 0.75,
			"15 flat zone blend continuous (10 m straddle = %.4f)" % bworst)


# ---------------------------------------------------------- elevation (16-21)
func _elevation() -> void:
	var hmin := 1e9
	var hmax := -1e9
	var hist := {"water": 0, "plain": 0, "hill": 0, "mountain": 0}
	var total := 0
	var spike_max := 0.0
	for gx in range(-75, 76, 2):
		for gz in range(-75, 76, 2):
			var x: float = float(gx) * 40.0
			var z: float = float(gz) * 40.0
			if not WorldContract.is_playable(Vector3(x, 0, z)):
				continue
			var h: float = WT.height_at(x, z)
			hmin = minf(hmin, h)
			hmax = maxf(hmax, h)
			total += 1
			if h < TA.SEA_LEVEL_M: hist["water"] = int(hist["water"]) + 1
			elif h < 60.0: hist["plain"] = int(hist["plain"]) + 1
			elif h < 150.0: hist["hill"] = int(hist["hill"]) + 1
			else: hist["mountain"] = int(hist["mountain"]) + 1
			var nb: float = 0.0
			for off: Vector2 in [Vector2(40, 0), Vector2(-40, 0), Vector2(0, 40),
					Vector2(0, -40), Vector2(40, 40), Vector2(-40, -40),
					Vector2(40, -40), Vector2(-40, 40)]:
				nb += WT.height_at(x + off.x, z + off.y)
			nb /= 8.0
			spike_max = maxf(spike_max, h - nb)
	_check(hmin >= TA.WORLD_MIN_HEIGHT_M - 0.001,
			"16 min height in contract (%.1f >= %.1f)" % [hmin, TA.WORLD_MIN_HEIGHT_M])
	_check(hmax <= TA.WORLD_MAX_HEIGHT_M + 0.001,
			"17 max height in contract (%.1f <= %.1f)" % [hmax, TA.WORLD_MAX_HEIGHT_M])
	var urban_sum := 0.0
	var urban_n := 0
	for gx in range(-17, 18):
		for gz in range(-17, 18):
			var x: float = float(gx) * 40.0
			var z: float = float(gz) * 40.0
			urban_sum += WT.height_at(x, z)
			urban_n += 1
	var mtn: float = WT.height_at(120.0, -2520.0)
	_check(urban_sum / float(urban_n) < 1.0 and mtn > 150.0,
			"18 urban lowland below mountain band (urban avg %.2f, peak %.1f)"
			% [urban_sum / float(urban_n), mtn])
	var hill_max := -1e9
	for i in range(64):
		var a: float = deg_to_rad(225.0 + 40.0 * float(i) / 63.0)
		for r: float in [900.0, 1300.0, 1700.0, 2000.0]:
			hill_max = maxf(hill_max, WT.height_at(cos(a) * r, sin(a) * r))
	_check(hmax > hill_max and hmax > 250.0,
			"19 peaks exceed hill band (peak %.1f > hills %.1f)" % [hmax, hill_max])
	var wf: float = float(hist["water"]) / float(total)
	var pf: float = float(hist["plain"]) / float(total)
	var mf: float = float(hist["mountain"]) / float(total)
	_check(wf > 0.15 and wf < 0.55 and pf > 0.30 and mf < 0.20,
			"20 height histogram reasonable (water %.0f%% plain %.0f%% mtn %.0f%%)"
			% [wf * 100.0, pf * 100.0, mf * 100.0])
	_check(spike_max < 40.0, "21 no absurd isolated spikes (max dev %.1f)" % spike_max)


# --------------------------------------------------------------- slope (22-25)
func _slope() -> void:
	var urban_worst := 0.0
	for gx in range(-11, 12, 2):
		for gz in range(-11, 12, 2):
			urban_worst = maxf(urban_worst,
					WT.grade_percent(float(gx) * 40.0, float(gz) * 40.0))
	_check(urban_worst <= 4.0, "22 urban build areas within grade target (%.2f%%)" % urban_worst)
	var viable := WT.is_road_viable(120.0, -300.0, "freeway") \
			and WT.is_road_viable(-200.0, 150.0, "arterial") \
			and not WT.is_road_viable(500.0, -2300.0, "freeway") \
			and WT.is_road_viable(2300.0, 900.0, "rural")
	_check(viable, "23 road-safe zones valid per class limits")
	var mtn_worst := 0.0
	for gx in range(-40, 40):
		var x: float = 120.0 + float(gx) * 40.0
		var z: float = -2520.0 + float(gx % 7) * 60.0
		mtn_worst = maxf(mtn_worst, WT.grade_percent(x, z))
	_check(mtn_worst > 20.0, "24 mountain slopes exceed urban limits (%.0f%%)" % mtn_worst)
	var ped_worst := 0.0
	for i in range(40):
		var a: float = TAU * float(i) / 40.0
		ped_worst = maxf(ped_worst, WT.grade_percent(cos(a) * 520.0, sin(a) * 520.0))
	_check(ped_worst <= 20.0, "25 pedestrian slopes within navigation contract (%.1f%%)" % ped_worst)


# --------------------------------------------------------------- water (26-30)
func _water() -> void:
	_check(TA.SEA_LEVEL_M == WBK.WATER_Y and TA.SEA_LEVEL_M == -1.3,
			"26 sea level constant single-source (%.2f)" % TA.SEA_LEVEL_M)
	var bed: PackedFloat64Array = WT.river_bed_levels()
	var mono := true
	for i in range(1, bed.size()):
		if bed[i] > bed[i - 1] - 0.9:
			mono = false
	var on_path := true
	for p: Vector2 in TA.RIVER_PTS:
		if WT._river_dist(p.x, p.y) > 0.01:
			on_path = false
	_check(mono and on_path, "27 river flows along defined path, monotonic bed")
	var inside := true
	for p: Vector2 in TA.RIVER_PTS:
		if not WorldContract.is_playable(Vector3(p.x, 0, p.y)):
			inside = false
	_check(inside, "28 river remains inside world")
	var b1: String = WT.surface_class_at(772.0, -1100.0)
	var b2: String = WT.surface_class_at(772.0, -1100.0)
	_check(b1 == b2 and b1 == "RIVERBANK", "29 river bank mask deterministic (%s)" % b1)
	var floats := false
	for i in range(TA.RIVER_PTS.size() - 1):
		var p: Vector2 = TA.RIVER_PTS[i]
		var wl: float = WT.water_level_at(p.x, p.y)
		var w: float = WT._river_width_at(p.x, p.y)
		if wl == -INF:
			floats = true
			continue
		if wl <= WT.height_at(p.x, p.y):
			floats = true  # water below its own bed
		var probe := Vector2(p.x + w * 3.0, p.y)
		if WT.has_inland_water(probe.x, probe.y):
			if absf(WT.water_level_at(probe.x, probe.y) - wl) > 3.5:
				floats = true  # inconsistent levels inside one water body
		elif wl > WT.height_at(probe.x, probe.y) + 0.6 \
				and WorldContract.is_playable(Vector3(probe.x, 0, probe.y)):
			floats = true  # water above the bank
	_check(not floats, "30 water never below bed or above banks")


# -------------------------------------------------------- classes (31-35)
func _classes() -> void:
	var known := ["WATER", "URBAN_LOWLAND", "SUBURBAN_HILL", "RURAL_GRASS", "FOREST",
			"FARM_FIELD", "MOUNTAIN", "FOOTHILL", "ROCK", "BEACH", "WETLAND",
			"CLIFF", "RIVERBANK", "INDUSTRIAL_FLAT", "PARKLAND", "COASTAL_URBAN"]
	var missing := 0
	var unknown := 0
	var found := {}
	for s: Vector2i in WorldContract.micro_sector_ids():
		if (s.x + s.y) % 4 != 0:
			continue
		var c: Vector2 = WorldContract.micro_sector_to_world(s)
		var cls: String = WorldSectorRegistry.terrain_class_at(c)
		if cls == "":
			missing += 1
		elif not known.has(cls):
			unknown += 1
		else:
			found[cls] = true
	_check(missing == 0, "31 every valid sector has a terrain class")
	_check(unknown == 0, "32 no unknown class in active world (%d classes seen)" % found.size())
	# 33: transitions not pathological: no A-B-A single-sample flicker along
	# long transects (raw flip counts are legitimate across water bodies)
	var seq: Array[String] = []
	var tx: float = -2800.0
	while tx <= 2800.0:
		seq.append(WT.surface_class_at(tx, 300.0))
		tx += 25.0
	var zig := 0
	for zi in range(1, seq.size() - 1):
		if seq[zi] != seq[zi - 1] and seq[zi + 1] == seq[zi - 1]:
			zig += 1
	_check(zig <= 2, "33 class transitions not pathological (%d zigzags / 5.6 km)" % zig)
	_check(WT.surface_class_at(0.0, 0.0) == "URBAN_LOWLAND"
			and WT.is_road_viable(0.0, 0.0, "local"), "34 flat/buildable regions mapped")
	_check(WT.surface_class_at(40.0, -2560.0) == "MOUNTAIN", "35 mountain region mapped")


# ------------------------------------------------- sector integration (36-38)
func _sector_integration() -> void:
	var s := Vector2i(16, -20)
	var p1: Dictionary = WorldSectorRegistry.terrain_profile_for_sector(s)
	var p2: Dictionary = WorldSectorRegistry.terrain_profile_for_sector(s)
	_check(str(p1) == str(p2) and p1.has("terrain_class") and p1.has("elevation_band"),
			"36 sector terrain profile deterministic")
	# 37: chunk vertex grids recompute identically (chunk derivation is pure)
	var csum := [0.0, 0.0]
	for pass_i in range(2):
		var acc := 0.0
		for ix in range(13):
			for iz in range(13):
				acc += WT.height_at(500.0 + float(ix) * 20.8333, 1000.0 + float(iz) * 20.8333)
		csum[pass_i] = acc
	_check(csum[0] == csum[1], "37 sector terrain chunk deterministic")
	var agree := true
	for v: Vector2 in [Vector2(0, 0), Vector2(1620, 950), Vector2(-2200, -1200),
			Vector2(812, -1466), Vector2(2100, 600)]:
		if WorldSectorRegistry.terrain_class_at(v) != WT.surface_class_at(v.x, v.y):
			agree = false
	_check(agree, "38 terrain class agrees with registry (delegation)")


# -------------------------------------------------------- §35 geometry QA
func _geometry_qa() -> void:
	# spike detector (median-free): deviation from 8-neighborhood at 20 m
	var spike := 0.0
	for gx in range(-70, 71, 3):
		for gz in range(-70, 71, 3):
			var x: float = float(gx) * 40.0
			var z: float = float(gz) * 40.0
			if not WorldContract.is_playable(Vector3(x, 0, z)):
				continue
			var nb := 0.0
			for off: Vector2 in [Vector2(20, 0), Vector2(-20, 0), Vector2(0, 20),
					Vector2(0, -20), Vector2(20, 20), Vector2(-20, -20),
					Vector2(20, -20), Vector2(-20, 20)]:
				nb += WT.height_at(x + off.x, z + off.y)
			spike = maxf(spike, absf(WT.height_at(x, z) - nb / 8.0))
	_qa(spike < 25.0, "QA no massive single-cell spikes (max %.1f m)" % spike)
	# checkerboard: sign flips of second differences along scan rows
	var flips := 0
	var steps := 0
	for gz in range(-60, 61, 15):
		var s0 := 0.0
		var x: float = -2400.0
		while x < 2360.0:
			var z: float = float(gz) * 40.0
			var d2: float = WT.height_at(x + 80.0, z) - 2.0 * WT.height_at(x + 40.0, z) \
					+ WT.height_at(x, z)
			if s0 != 0.0 and signf(d2) != s0 and absf(d2) > 0.05:
				flips += 1
			if absf(d2) > 0.05:
				s0 = signf(d2)
				steps += 1
			x += 40.0
	_qa(float(flips) / maxf(float(steps), 1.0) < 0.55,
			"QA no checkerboard noise (flip ratio %.2f)" % (float(flips) / maxf(float(steps), 1.0)))
	# repeating pattern: autocorrelation at the old 250 m chunk lag
	var num := 0.0
	var den := 0.0
	var mean := 0.0
	var n := 0
	for gx in range(-60, 61, 2):
		for gz in [-40, 0, 40]:
			var x: float = float(gx) * 40.0
			var z: float = float(gz) * 40.0
			mean += WT.height_at(x, z)
			n += 1
	mean /= float(n)
	for gx in range(-60, 55, 2):
		for gz in [-40, 0, 40]:
			var x: float = float(gx) * 40.0
			var z: float = float(gz) * 40.0
			num += (WT.height_at(x, z) - mean) * (WT.height_at(x + 250.0, z) - mean)
			den += pow(WT.height_at(x, z) - mean, 2.0)
	_qa(absf(num / maxf(den, 0.001)) < 0.97,
			"QA no repeating 250 m pattern (autocorr %.3f)" % (num / maxf(den, 0.001)))
	# rectangular imprint: old active_zone rect stays exactly flat
	var imprint := false
	var x: float = -400.0
	while x <= 400.0:
		var z: float = -500.0
		while z <= -300.0:
			if WT.height_at(x, z) != 0.0:
				imprint = true
			z += 25.0
		x += 25.0
	_qa(not imprint, "QA no rectangular active_zone imprint")
	# radial asymmetry: opposite bearings at r=1500 differ
	var asym := 0.0
	for i in range(12):
		var a: float = TAU * float(i) / 12.0
		asym = maxf(asym, absf(WT.height_at(cos(a) * 1500.0, sin(a) * 1500.0)
				- WT.height_at(-cos(a) * 1500.0, -sin(a) * 1500.0)))
	_qa(asym > 5.0, "QA no perfect radial symmetry (max opp delta %.1f)" % asym)
	# coastline smoothness: le() varies < 15 m per degree
	var lejump := 0.0
	for d in range(360):
		if absf(TA.angle_diff_deg(float(d), TA.BAY_CENTER_DEG)) < TA.BAY_HALF_WIDTH_DEG + 13.0:
			continue  # the bay mouth is an authored feature, not noise
		lejump = maxf(lejump, absf(TA.land_end_r(float(d)) - TA.land_end_r(float(d) + 1.0)))
	_qa(lejump < 15.0, "QA coastline not polygonal (max %.1f m/deg)" % lejump)
	# ridge/valley authored variety (data-level anomaly detector)
	var amps := {}
	for r: Dictionary in TA.RIDGES:
		amps[float(r["amp_m"])] = true
	for pk: Dictionary in TA.PEAKS:
		amps[float(pk["amp_m"])] = true
	var vw := {}
	for v: Dictionary in TA.VALLEYS:
		vw[str(v["width_m"]) + "/" + str(v["depth_m"])] = true
	_qa(amps.size() >= 6 and vw.size() == TA.VALLEYS.size(),
			"QA ridge/valley profiles not repeated (amps %d, valleys %d)" % [amps.size(), vw.size()])
	# height variance + slope distribution + curvature bounds
	var sum := 0.0
	var sum2 := 0.0
	var n2 := 0
	var extreme := 0
	var n3 := 0
	for vx in range(-70, 71, 3):
		for vz in range(-70, 71, 3):
			var px: float = float(vx) * 40.0
			var pz: float = float(vz) * 40.0
			if not WorldContract.is_playable(Vector3(px, 0, pz)):
				continue
			var ph: float = WT.height_at(px, pz)
			sum += ph
			sum2 += ph * ph
			n2 += 1
			var pg: float = WT.grade_percent(px, pz)
			n3 += 1
			if pg > 60.0:
				extreme += 1
	var var_h: float = sum2 / float(n2) - pow(sum / float(n2), 2.0)
	var ext_f: float = float(extreme) / float(n3)
	_qa(var_h > 400.0, "QA height variance meaningful (var %.0f)" % var_h)
	_qa(ext_f < 0.10, "QA slope distribution sane (extreme %.1f%%)" % (ext_f * 100.0))
	# waterline continuity: along r-sweeps, the sea crossing has no jumps
	var jump := 0.0
	for wi in range(72):
		var wa: float = TAU * float(wi) / 72.0
		var prev_h: float = WT.height_at(cos(wa) * 2400.0, sin(wa) * 2400.0)
		var wr: float = 2420.0
		while wr <= 2880.0:
			var wh: float = WT.height_at(cos(wa) * wr, sin(wa) * wr)
			if signf(wh - TA.SEA_LEVEL_M) != signf(prev_h - TA.SEA_LEVEL_M):
				jump = maxf(jump, absf(wh - prev_h))
			prev_h = wh
			wr += 20.0
	_qa(jump < 12.0, "QA waterline continuous (max crossing jump %.2f)" % jump)
	print("TRECON_STATIC: passes=%d fails=%d" % [passes, fails])
