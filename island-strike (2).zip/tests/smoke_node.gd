extends Node
## Staged headless smoke test v2 (expanded audit coverage).
## Exits 0 on success, 1 on fail.

var frames := 0
var game: Node3D
var _fail := ""
var _saved_money := 0
var _stamina_before := 100.0
var _tl_toggles := 0
var _last_ns_green := true


## D2: stop every audio stream ~60 frames before teardown (mix-settle window;
## stop-at-teardown can race the audio thread and leak the playback object).
func _prequit_audio() -> void:
	var g := get_tree().current_scene
	if g and g.has_method("_stop_all_audio"):
		g._stop_all_audio()

func _ready() -> void:
	game = get_tree().current_scene


func _process(_delta: float) -> void:
	frames += 1
	# D4: real-cadence night ticks (one director call per frame so deferred
	# frees apply between ticks — same-frame calls would free nothing)
	if int(get_meta("night_ticks_left", 0)) > 0:
		set_meta("night_ticks_left", int(get_meta("night_ticks_left", 0)) - 1)
		game._civilian_director()
	match frames:
		30:
			_check(game.player != null, "player spawned")
			_check(not GameState.world_data.is_empty(), "world data built")
			_check(get_tree().get_nodes_in_group("cars").size() >= 15, "cars spawned")
			_check(get_tree().get_nodes_in_group("civilians").size() >= 10, "civilians spawned")
			_check(get_tree().get_nodes_in_group("collectibles").size() == 20, "20 collectibles present")
			_check(get_tree().get_nodes_in_group("traffic_lights").size() == 8, "8 traffic lights built")
			_check(get_tree().get_nodes_in_group("gun_shop") != null, "gun shop registered")
			_check(get_tree().get_nodes_in_group("safehouse") != null, "safehouse registered")
			_check(WorldBuilder.WINDOW_MATERIAL != null, "window material exists")
			# vehicle class variety
			var classes := {}
			for c in get_tree().get_nodes_in_group("cars"):
				classes[c.vehicle_class] = true
			_check(classes.size() >= 3, "vehicle class variety (%d)" % classes.size())
			_saved_money = GameState.money
			SaveSystem.save_game()
		34:
			# ---- Round 12 "next level" dressing + sim gates (Phases 08-22) ----
			_check(get_tree().get_nodes_in_group("lane_dashes").size() >= 1,
					"lane dash MultiMesh present")
			var sf: int = get_tree().get_nodes_in_group("street_furniture").size()
			_check(sf >= 28, "hydrants + bins dressing (%d)" % sf)
			_check(get_tree().get_nodes_in_group("flowers").size() >= 70,
					"park flower patches planted")
			_check(get_tree().get_nodes_in_group("landmark_clock").size() >= 1,
					"downtown clock tower landmark")
			_check(get_tree().get_nodes_in_group("water_towers").size() >= 3,
					"rooftop water towers (3 tallest)")
			_check(get_tree().get_nodes_in_group("welcome_gantry").size() == 1,
					"welcome gantry over avenue")
			_check(get_tree().get_nodes_in_group("fire_escapes").size() >= 8,
					"fire-escape landings on towers")
			_check(get_tree().get_nodes_in_group("stash").size() == 2,
					"2 hidden cash stashes")
			var warn_lights: int = 0
			for bcn in get_tree().get_nodes_in_group("beacons"):
				if bcn is OmniLight3D:
					warn_lights += 1
			_check(warn_lights >= 2, "aircraft warning lights on towers (%d)" % warn_lights)
			var cur_in: Vector3 = WorldTerrain.river_current_at(Vector3(-50.0, 0.0, 0.0))
			var cur_out: Vector3 = WorldTerrain.river_current_at(Vector3(300.0, 0.0, 0.0))
			_check(cur_in.length() > 0.5 and cur_in.z > 0.0,
					"river current flows downstream in channel (%.2f)" % cur_in.length())
			_check(cur_out == Vector3.ZERO, "no current outside river band")
			var saved_dt: float = GameState.day_time
			GameState.day_time = 8.0
			var rush_morning: bool = GameState.is_rush_hour()
			GameState.day_time = 12.0
			var midday_off: bool = not GameState.is_rush_hour()
			GameState.day_time = 18.0
			var rush_evening: bool = GameState.is_rush_hour()
			GameState.day_time = saved_dt
			_check(rush_morning and midday_off and rush_evening,
					"rush-hour windows 7-9 / 17-19")
			var strm: Node = get_tree().get_first_node_in_group("streamer")
			_check(strm != null and strm.player_tile_contract_holds(),
					"streamer hysteresis player-tile contract")
		36:
			# ---- Round 13: 10-building Blender set, game-side gates ----
			_check(get_tree().get_nodes_in_group("bk_suburban").size() >= 12,
					"B01 suburban house porches/roofs/bins on 4 houses (%d)" %
					get_tree().get_nodes_in_group("bk_suburban").size())
			_check(get_tree().get_nodes_in_group("bk_apartment").size() >= 1,
					"B02 modern apartment placed")
			_check(get_tree().get_nodes_in_group("bk_shutter").size() >= 18,
					"B03 shop shutters on 3 stores (%d)" %
					get_tree().get_nodes_in_group("bk_shutter").size())
			_check(get_tree().get_nodes_in_group("bk_motel").size() >= 1
					and get_tree().get_nodes_in_group("bk_motel_door").size() >= 12,
					"B04 motel with unit doors (%d doors)" %
					get_tree().get_nodes_in_group("bk_motel_door").size())
			_check(get_tree().get_nodes_in_group("bk_dock").size() >= 1,
					"B05 warehouse loading dock")
			_check(get_tree().get_nodes_in_group("bk_office").size() >= 1
					and get_tree().get_nodes_in_group("bk_office_hvac").size() >= 3,
					"B06 office canopy + rooftop HVAC (%d)" %
					get_tree().get_nodes_in_group("bk_office_hvac").size())
			_check(get_tree().get_nodes_in_group("bk_gas_price").size() >= 1,
					"B07 gas station price sign")
			_check(get_tree().get_nodes_in_group("bk_clinic").size() >= 1,
					"B08 small clinic placed")
			_check(get_tree().get_nodes_in_group("bk_police_garage").size() >= 1
					and get_tree().get_nodes_in_group("bk_police_baydoor").size() >= 18,
					"B09 police 3-bay garage (%d slats)" %
					get_tree().get_nodes_in_group("bk_police_baydoor").size())
			_check(get_tree().get_nodes_in_group("bk_boarded").size() >= 9,
					"B10 abandoned boarded windows (%d)" %
					get_tree().get_nodes_in_group("bk_boarded").size())
		40:
			GameState.add_money(250)
			_check(GameState.money == _saved_money + 250, "money added")
			SaveSystem.load_game()
		50:
			_check(GameState.money == _saved_money, "save/load roundtrip restores money")
			_check(game.player.health == 100, "player health restored")
		60:
			# sprint in place to drain stamina
			_stamina_before = game.player.stamina
			game.player.velocity = Vector3(0, 0, 0)
			Input.action_press("sprint")
			Input.action_press("move_forward")
		110:
			Input.action_release("move_forward")
			Input.action_release("sprint")
			_check(game.player.stamina < _stamina_before, "stamina drains while sprinting")
		120:
			# Steal the nearest parked car
			var nearest: Node = null
			var best := 1e9
			for c in get_tree().get_nodes_in_group("cars"):
				var d: float = c.global_position.distance_to(game.player.global_position)
				if d < best:
					best = d
					nearest = c
			_check(nearest != null, "found a car to enter")
			if nearest:
				nearest.enter_player(game.player)
				_check(game.player.driving_car == nearest, "player entered car")
		130:
			Input.action_press("move_forward")
		190:
			Input.action_release("move_forward")
			var sp: float = absf(game.player.driving_car.speed) if game.player.driving_car else 0.0
			_check(sp > 3.0, "car accelerated under throttle (speed %.1f)" % sp)
		200:
			if game.player.driving_car:
				game.player.driving_car.exit_player()
			_check(game.player.driving_car == null, "player exited car")
		210:
			Input.action_press("fire")
		213:
			Input.action_release("fire")
		220:
			var mag_count: int = game.player.pistol.mag()
			_check(mag_count < 12, "pistol fired (mag %d)" % mag_count)
		230:
			# traffic light phase must toggle when forced
			_last_ns_green = GameState.traffic_ns_green
			GameState.update_traffic_phase(9.1)
			if GameState.traffic_ns_green != _last_ns_green:
				_tl_toggles += 1
			_check(_tl_toggles == 1, "traffic phase toggles")
		240:
			# night window lighting
			GameState.day_time = 23.0
			game._update_day_night()
			_check(WorldBuilder.WINDOW_MATERIAL.emission_energy_multiplier > 0.5,
					"windows glow at night")
			GameState.day_time = 10.0
			game._update_day_night()
		250:
			GameState.set_wanted(3)
		470:
			var cops := get_tree().get_nodes_in_group("police").size()
			_check(cops >= 3, "police director spawned foot cops (%d)" % cops)
			var cruisers := 0
			for c in get_tree().get_nodes_in_group("cars"):
				if is_instance_valid(c) and c.is_police_car and not c.wrecked:
					cruisers += 1
			_check(cruisers >= 1, "police cruiser dispatched (%d)" % cruisers)
			var civs := get_tree().get_nodes_in_group("civilians").size()
			_check(civs >= 10, "civilian population sustained (%d)" % civs)
		480:
			# ---- world v3 structures ----
			_check(get_tree().root.get_tree().current_scene.get_node_or_null("Ramp") != null
					or _count_named("Ramp") >= 2, "parking ramps built")
			_check(_count_named("Crosswalk") >= 60, "crosswalk stripes present (%d)" % _count_named("Crosswalk"))
			_check(_count_named("Pump") >= 2, "gas station pumps built")
			_check(_count_named("CraneMast") >= 1, "construction crane built")
			_check(_count_named("Hospital") >= 1 and _count_named("School") >= 1, "school + hospital built")
			_check(_count_named("Yacht") >= 3, "marina yachts built")
			var interiors := _count_named("Floor")
			_check(interiors >= 24, ">=24 enterable interiors incl. downtown (%d)" % interiors)
			# ---- district 01 QA: landmarks, height classes, road overlaps ----
			_check(_count_named("PoliceStation") >= 1, "police station built")
			_check(_count_named("Hotel") >= 1, "hotel landmark built")
			_check(_count_named("Restaurant") >= 1, "restaurant built")
			var low := 0
			var med := 0
			var tall := 0
			for hh in WorldBuilder.dt_heights:
				if hh < 15.0:
					low += 1
				elif hh <= 40.0:
					med += 1
				else:
					tall += 1
			_check(low >= 3 and med >= 4 and tall >= 3,
					"downtown height classes LOW/MED/TALL (%d/%d/%d)" % [low, med, tall])
			var overlaps := 0
			for r in WorldBuilder.qa_rects:
				for road in WorldBuilder.ROADS:
					if r.intersects(road):
						overlaps += 1
						break
			_check(overlaps == 0, "no building footprint overlaps a road (%d footprints)"
					% WorldBuilder.qa_rects.size())
			# ---- streetscape QA: hierarchy, sidewalk breaks, furniture ----
			var census: Dictionary = WorldBuilder.road_census()
			_check(census["total"] == 15 and census["classes"] == 8 and census["freeway"] == 4
					and census["arterial"] == 4 and census["collector"] == 2 and census["main_street"] == 2
					and census["industrial_road"] == 1 and census["service_lane"] == 1
					and census["rural_dirt"] == 1,
					"road hierarchy census 8-class (%s)" % [census])
			var sw := WorldBuilder.sidewalk_rects
			_check(sw.size() >= 40, "sidewalk segments with junction breaks (%d)" % sw.size())
			var sw_bad := 0
			for sr in sw:
				for road in WorldBuilder.ROADS:
					if (sr as Rect2).intersects(road):
						sw_bad += 1
						break
			_check(sw_bad == 0, "no sidewalk crosses asphalt junctions (%d bad)" % sw_bad)
			_check(_count_named("Median") >= 8, "freeway median segments (%d)" % _count_named("Median"))
			_check(_count_named("StopLine") == 16, "stop lines at all signals (%d)" % _count_named("StopLine"))
			_check(_count_named("BusStopPad") == 4, "bus stops built (%d)" % _count_named("BusStopPad"))
			# audit #24: every signal carries its xz meta (end-to-end coverage)
			var meta_ok := true
			for tl in get_tree().get_nodes_in_group("traffic_lights"):
				if not (tl as Node).has_meta("xz"):
					meta_ok = false
			_check(meta_ok and get_tree().get_nodes_in_group("traffic_lights").size() == 8,
					"all signals carry xz meta (%d)" % get_tree().get_nodes_in_group("traffic_lights").size())
			_check(_count_named("LakeBridge") == 1, "lake footbridge built")
			# Phase 6 (restored): streaming contract — world QA rays run from the
			# player position so they only ever test NEAR-band collision
			game.player.global_position = Vector3(0, 0.9, -300)
			set_meta("pending", "qa_median")
			_check(_count_named("DistrictSignPost") == 6, "district boundary signs (%d)" % _count_named("DistrictSignPost"))
			_check(_count_named("Planter") >= 9, "downtown street trees (%d)" % _count_named("Planter"))
			_check(_count_named("Crossarm") == 8, "suburban utility poles (%d)" % _count_named("Crossarm"))
			_check(_count_named("Gutter") == 12, "drainage gutters (%d)" % _count_named("Gutter"))
			var kit_props := _count_named("StreetKit")
			_check(kit_props >= 8, "streetscape kit props placed (%d)" % kit_props)
			if get_meta("pending", "") != "qa_median":
				return
			remove_meta("pending")
			# median is physically solid: ray across the N perimeter hits it; at a gap it doesn't
			var space := get_viewport().world_3d.direct_space_state
			var hit_med := space.intersect_ray(PhysicsRayQueryParameters3D.create(
					Vector3(0, 5, -310), Vector3(0, -1, -310)))
			var hit_gap := space.intersect_ray(PhysicsRayQueryParameters3D.create(
					Vector3(-260, 5, -310), Vector3(-260, -1, -310)))
			_check(not hit_med.is_empty()
					and String(hit_med["collider"].name).begins_with("Median"),
					"median blocks crossing (solid)")
			_check(hit_gap.is_empty()
					or not String(hit_gap["collider"].name).begins_with("Median"),
					"median gap open at junction")
			# ---- coast / offshore / pier / rail (map upgrade batch) ----
			_check(_count_named("LighthouseRock") == 1, "lighthouse islet built")
			_check(get_tree().get_nodes_in_group("lighthouse_lights").size() == 1,
					"lighthouse lamp registered for night system")
			_check(_count_named("OffshoreIsland") == 1, "offshore island built")
			_check(_count_named("PierDeck") >= 7, "beach pier deck segments (%d)" % _count_named("PierDeck"))
			_check(_count_named("BreakwaterRock") == 7, "marina breakwater (%d)" % _count_named("BreakwaterRock"))
			_check(_count_named("Buoy") == 5, "channel buoys (%d)" % _count_named("Buoy"))
			_check(_count_named("UmbrellaPole") == 6 and _count_named("LifeguardHut") == 1,
					"beach dressing (umbrellas + lifeguard hut)")
			_check(_count_named("FreightCar") == 3 and _count_named("RailSleeper") == 40,
					"rail yard: 3 freight cars on 40 sleepers")
			_check(_count_named("YardContainer") == 5 and _count_named("RailDepot") >= 1,
					"rail depot + transshipment containers")
			_check(_count_named("OutskirtShopBase") >= 3, "outskirt transition shops (%d)" % _count_named("OutskirtShopBase"))
			# walkability rays (Phase 6 restored): run player-proximate next frame
			game.player.global_position = Vector3(-490, 0.9, -40)
			set_meta("pending", "qa_walk")
			var space2 := get_viewport().world_3d.direct_space_state
			var pier_hit := space2.intersect_ray(PhysicsRayQueryParameters3D.create(
					Vector3(-490, 3, -40), Vector3(-490, -1, -40)))
			_check(not pier_hit.is_empty() and String(pier_hit["collider"].name).begins_with("PierDeck"),
					"pier deck walkable")
			var interiors2 := _count_named("Floor")
			_check(interiors2 >= 24, "interior count preserved after world growth (%d)" % interiors2)
			# weapon framework (Round 9 S4: ownership is now economy-gated, so the
			# cycle test grants the full arsenal as a fixture, then restores)
			# Updated for 7-weapon system with async switch (0.40s)
			game.player.pistol.owned_weapons = {"pistol": true, "smg": true, "shotgun": true}
			game.player.pistol.weapon_id = "pistol"
			game.player.pistol.state = 2 # READY
			game.player.pistol.switch_lock = 0.0
			game.player.pistol.cycle_weapon()
			# Force immediate switch for test (bypass 0.40s timer)
			game.player.pistol.weapon_id = "smg"
			game.player.pistol.state = 2
			game.player.pistol.switch_lock = 0.0
			_check(game.player.pistol.weapon_id == "smg", "weapon switched to SMG")
			_check(game.player.pistol.mag_size() == 30, "SMG mag size 30")
			game.player.pistol.weapon_id = "shotgun"
			_check(game.player.pistol.weapon_id == "shotgun", "weapon cycles to shotgun")
			game.player.pistol.weapon_id = "smg"
			_check(game.player.pistol.weapon_id == "smg", "prev_weapon reverses cycle")
			game.player.pistol.weapon_id = "pistol"
			_check(game.player.pistol.weapon_id == "pistol", "weapon switched back")
			game.player.pistol.owned_weapons = {"pistol": true}
			game.player.pistol.weapon_id = "pistol"
			# world map toggle
			var hud: CanvasLayer = get_tree().get_first_node_in_group("hud")
			hud.toggle_map()
			_check(hud.world_map.visible, "world map opens")
			hud.toggle_map()
			_check(not hud.world_map.visible, "world map closes")
			# move player into the gun shop interior, then to gang territory
			# (x=-256: the old -259 drop straddled the avenue edge — a passing
			# traffic car could roof the player mid-fall; smoke-caught flake)
			game.player.global_position = Vector3(-256, 0.9, -126)
			set_meta("pending", "interior")
		492:
			if get_meta("pending", "") == "qa_walk":
				remove_meta("pending")
				var space2 := get_viewport().world_3d.direct_space_state
				var pier_hit := space2.intersect_ray(PhysicsRayQueryParameters3D.create(
						Vector3(-490, 3, -40), Vector3(-490, -1, -40)))
				_check(not pier_hit.is_empty() and String(pier_hit["collider"].name).begins_with("PierDeck"),
						"pier deck walkable")
				game.player.global_position = Vector3(0, 1.4, 40)
				set_meta("pending", "qa_bridge")
		493:
			if get_meta("pending", "") == "qa_bridge":
				remove_meta("pending")
				var space4 := get_viewport().world_3d.direct_space_state
				var br_hit := space4.intersect_ray(PhysicsRayQueryParameters3D.create(
						Vector3(-30, 2.5, 40), Vector3(-30, -1, 40)))
				_check(not br_hit.is_empty() and String(br_hit["collider"].name).begins_with("LakeBridge"),
						"lake footbridge walkable")
				game.player.global_position = Vector3(700, 1.2, 0)
				set_meta("pending", "qa_isle")
		495:
			if get_meta("pending", "") == "qa_isle":
				remove_meta("pending")
				var space3 := get_viewport().world_3d.direct_space_state
				var isle_hit := space3.intersect_ray(PhysicsRayQueryParameters3D.create(
						Vector3(700, 5, 0), Vector3(700, -1, 0)))
				_check(not isle_hit.is_empty() and String(isle_hit["collider"].name).begins_with("OffshoreIsland"),
						"offshore island walkable")
		520:
			if get_meta("pending", "") == "interior":
				remove_meta("pending")
				var pp: Vector3 = game.player.global_position
				var inside := pp.y > 0.05 and pp.y < 1.0 and absf(pp.x - (-256.0)) < 6.0
				_check(inside and game.player.is_on_floor(),
						"player stands inside shop interior (y=%.2f)" % pp.y)
			game.player.global_position = Vector3(370, 0.6, 250)
			set_meta("pending", "gang")
		540:
			for i in range(4):
				game._gang_director()
			var gangs := get_tree().get_nodes_in_group("gangs").size()
			_check(gangs >= 2, "gang director spawned Dockside Crew (%d)" % gangs)
			# deterministic confrontation: open sand, clear LOS, 15 m apart
			game.player.global_position = Vector3(-480, 0.6, 200)
			var witness: Node = null
			for m in get_tree().get_nodes_in_group("gangs"):
				if is_instance_valid(m) and m.health > 0:
					m.global_position = Vector3(-465, 0.4, 200)
					witness = m
					break
			set_meta("witness", witness)
		549:
			var w: Node = get_meta("witness")
			_check(w != null and is_instance_valid(w) and w.state == "hostile",
					"gang member goes hostile on sight (state=%s)" % (w.state if w else "none"))
		550:
			# gas station repair
			var car: Node = null
			for c in get_tree().get_nodes_in_group("cars"):
				if is_instance_valid(c) and not c.wrecked and not c.is_in_group("boats"):
					car = c
					break
			if car:
				car.take_damage(60.0, Vector3.ZERO)
				var before: int = GameState.money
				var ok: bool = game.player.try_gas_station(car)
				_check(ok and car.health >= 99.0 and GameState.money == before - 50,
						"gas station repairs car for $50")
			# race activity
			var race: Node3D = get_tree().get_first_node_in_group("race")
			_check(race != null and race.markers.size() == 8, "race has 8 checkpoints")
			var nearest: Node = null
			var best := 1e9
			for c in get_tree().get_nodes_in_group("cars"):
				if is_instance_valid(c) and not c.wrecked:
					var d: float = c.global_position.distance_to(game.player.global_position)
					if d < best:
						best = d
						nearest = c
			nearest.enter_player(game.player)
			var before2: int = GameState.money
			race._start()
			race.time_left = 100.0  # simulate 10s of racing for best-time check
			_check(race.active and race.cp_index == 1, "race started at cp1")
			race._on_gate(1)
			_check(race.cp_index == 2, "race checkpoint advance on gate")
			race._finish()
			_check(GameState.money == before2 + 400, "race pays $400")
			_check(GameState.stats["race_best"] > 0.0, "race best time recorded")
			nearest.exit_player()
			# NPC night schedule (D4 corrected): director has hysteresis and
			# converges to target+2 = 12 from 24 (-50% steady state). queue_free
			# is deferred, so ticks run one per frame via night_ticks_left.
			GameState.day_time = 23.0
			set_meta("night_ticks_left", 14)
		575:
			# D4 verdict: 14 per-frame night ticks drained -> converged?
			if get_meta("night_before", -1) < 0 and int(get_meta("night_ticks_left", 0)) == 0 \
					and GameState.day_time >= 23.0:
				set_meta("night_before", 1)
				var civ_alive := 0
				for c in get_tree().get_nodes_in_group("civilians"):
					if is_instance_valid(c) and c.health > 0 and not c.is_queued_for_deletion():
						civ_alive += 1
				_check(absi(civ_alive - 12) <= 1,
						"night schedule converges to -50%% steady state (24 -> %d)" % civ_alive)
				game._civilian_director()
				var civ_settled := 0
				for c in get_tree().get_nodes_in_group("civilians"):
					if is_instance_valid(c) and c.health > 0 and not c.is_queued_for_deletion():
						civ_settled += 1
				_check(absi(civ_settled - 12) <= 1,
						"night schedule stable after extra tick (%d)" % civ_settled)
			# ---- graphics presets ----
			var veg_total := get_tree().get_nodes_in_group("veg").size()
			_check(veg_total > 100, "vegetation tagged (%d)" % veg_total)
			game.apply_quality("LOW")
			var hidden := 0
			for v in get_tree().get_nodes_in_group("veg"):
				if not v.visible:
					hidden += 1
			_check(hidden == veg_total, "LOW hides all vegetation")
			_check(get_viewport().scaling_3d_scale < 0.9, "LOW scales resolution")
			game.apply_quality("ULTRA")
			_check(get_viewport().scaling_3d_scale == 1.0, "ULTRA full resolution")
			var visible_after := 0
			for v in get_tree().get_nodes_in_group("veg"):
				if v.visible:
					visible_after += 1
			_check(visible_after == veg_total, "ULTRA restores vegetation")
			# ---- properties ----
			GameState.money = 5000
			_check(GameState.buy_property("safehouse"), "safehouse purchased")
			_check(GameState.money == 2500, "purchase deducted $2500 (%d)" % GameState.money)
			_check(not GameState.buy_property("safehouse"), "cannot buy twice")
			GameState.owned["warehouse"] = true
			GameState.owned["harbor_office"] = true
			_check(GameState.daily_income() == 130, "daily income 90+40=130")
			var prop_areas := get_tree().get_nodes_in_group("property").size()
			_check(prop_areas >= 4, "property door areas registered (%d)" % prop_areas)
			# ---- events ----
			var before_kids := game.get_child_count()
			game._event_supply_drop(true)
			_check(game.get_child_count() >= before_kids + 2, "supply drop spawns pickup + beacon")
			GameState.wanted = 0  # director stands down during manhunts
			game._event_director()
			_check(GameState.stats.get("events_seen", 0) >= 1, "event stat tracked")
			var any_flag := false
			for k in GameState.world_flags:
				if String(k).begins_with("ev_"):
					any_flag = true
			_check(any_flag, "world memory remembers events")
		620:
			# ---- input device detection + contextual prompts ----
			var jev := InputEventJoypadButton.new()
			jev.button_index = JOY_BUTTON_A
			jev.pressed = true
			Input.parse_input_event(jev)
		625:
			_check(GameState.last_device == "controller", "joypad event detected")
			_check(GameState.ctx_prompt("interact", "Exit vehicle") == "[Y] Exit vehicle",
					"controller prompt shows [Y]")
			var kev := InputEventKey.new()
			kev.keycode = KEY_W
			kev.pressed = true
			Input.parse_input_event(kev)
		630:
			_check(GameState.last_device == "kb", "key event detected")
			_check(GameState.ctx_prompt("interact", "Exit vehicle") == "[E] Exit vehicle",
					"keyboard prompt shows [E]")
			# ---- driving camera (P0 fix): spawn a sports car and drive it ----
			var sports: Node = load("res://scripts/vehicles/car.gd").create(
					Color(1, 0.2, 0.2), "sports")
			sports.position = Vector3(-470, 0.6, -40)
			add_child(sports)
			set_meta("sports", sports)
			game.player.global_position = sports.position + Vector3(3, 0.6, 0)
			sports.enter_player(game.player)
			Input.action_press("move_forward")
		690:
			var sp: Node = get_meta("sports")
			var spd: float = sp.velocity.length()
			_check(spd > 4.0, "sports car accelerates (%.1f m/s)" % spd)
			_check(sp.global_position.y > 0.15 and sp.global_position.y < 3.0,
					"streamed road holds at speed (y=%.2f)" % sp.global_position.y)
			var cy: Vector3 = game.player.cam_yaw.global_position
			_check(absf(cy.y - (sp.global_position.y + 2.3)) < 0.6,
					"camera pivot follows car cab (dy=%.2f)" % absf(cy.y - sp.global_position.y - 2.3))
			var cfwd: Vector3 = -game.player.cam_yaw.global_basis.z
			var cfwd2: Vector3 = -sp.global_basis.z
			_check(cfwd.dot(cfwd2) > 0.85,
					"camera auto-trails car heading (dot %.2f)" % cfwd.dot(cfwd2))
			_check(game.player.spring.spring_length > 5.2 and game.player.cam.fov > 72.5,
					"speed dollies camera (len %.1f fov %.0f)"
					% [game.player.spring.spring_length, game.player.cam.fov])
			set_meta("yaw_before", game.player.yaw)
			Input.action_press("look_left")
		725:
			Input.action_release("look_left")
			var dyaw: float = absf(wrapf(game.player.yaw - get_meta("yaw_before", 0.0),
					-PI, PI))
			_check(dyaw > 0.15, "manual look works while driving (dyaw %.2f)" % dyaw)
			set_meta("sports_top", get_meta("sports").velocity.length())
			get_meta("sports").exit_player()
			get_meta("sports").queue_free()  # D3: free spawn site before next class
		735:
			# ---- class handling deltas: bus must be much slower than sports ----
			var bus: Node = load("res://scripts/vehicles/car.gd").create(
					Color(0.2, 0.3, 0.6), "bus")
			bus.position = Vector3(-460, 0.6, -20)  # D3: distinct, unobstructed spawn
			add_child(bus)
			set_meta("bus", bus)
			game.player.global_position = bus.position + Vector3(3, 0.6, 0)
			bus.enter_player(game.player)
			Input.action_press("move_forward")
		795:
			var bus_top: float = get_meta("bus").velocity.length()
			Input.action_release("move_forward")
			get_meta("bus").exit_player()
			get_meta("bus").queue_free()
			# D3 corrected assertion: ABSOLUTE in-window bounds + relative delta.
			# A class that fails to accelerate at all must fail this test.
			var s_top: float = get_meta("sports_top", 0.0)
			_check(s_top >= 3.5, "sports absolute accel bound ( %.1f >= 3.5 m/s)" % s_top)
			_check(bus_top >= 1.5, "bus absolute accel bound (%.1f >= 1.5 m/s)" % bus_top)
			_check(s_top > bus_top, "class delta (sports %.1f vs bus %.1f m/s)" % [s_top, bus_top])
			# district-aware spawn pool
			var only_bus: Node = load("res://scripts/vehicles/car.gd").create_random(
					RandomNumberGenerator.new(), ["bus"])
			_check(only_bus.vehicle_class == "bus", "pooled spawn respects class pool")
			only_bus.queue_free()
		805:
			# back on foot: camera re-anchors to the body pivot
			var pp: Vector3 = game.player.global_position
			var cy2: Vector3 = game.player.cam_yaw.global_position
			_check(absf(cy2.y - (pp.y + 1.55)) < 0.4,
					"on-foot camera re-anchors after exit (dy=%.2f)" % absf(cy2.y - pp.y - 1.55))
		860:
			# ---- D2 guard: audio teardown stops active streams ----
			var ocean_p: AudioStreamPlayer = game.find_children("*", "AudioStreamPlayer",
					true, false)[0] if game.find_children("*", "AudioStreamPlayer",
					true, false).size() > 0 else null
			if ocean_p:
				ocean_p.play()
				game._stop_all_audio()
				_check(not ocean_p.playing, "audio teardown stops active streams")
				GameState.audio_shutdown = false  # guard done — do not poison the live game
			else:
				_check(false, "audio teardown: no player found")
			# ================= v2.0.01 systems =================
			# Weather 2.0 state machine
			var ws: Node = game.get_node_or_null("WorldSim")
			_check(ws != null, "WorldSim node present")
			if ws:
				ws.set_state("RAIN")
				_check(GameState.raining and not GameState.heavy_rain, "RAIN state drives raining flag")
				ws.set_state("HEAVY_RAIN")
				_check(GameState.heavy_rain, "HEAVY_RAIN flag set (grip penalty path)")
				var ph: String = ws.day_phase()
				_check(ph in ["dawn", "day", "dusk", "night"], "day phase reporter (%s)" % ph)
				ws.set_state("FOG")
			# EventManager policy
			var em: Node = game.get_node_or_null("EventManager")
			_check(em != null, "EventManager node present")
			if em:
				game.player.global_position = Vector3(-300, 0.6, -160)  # Downtown
				_check(em._district_at(game.player.global_position) == "Downtown",
						"event manager resolves district")
				game.player.global_position = Vector3(-350, 0.6, 220)  # Farmland
				var picks: Dictionary = {}
				em._last = ""
				for i in range(25):
					picks[em.pick_event()] = true
				_check(not picks.has("panic") and not picks.has("ambush") and picks.has("supply_drop"),
						"district filter blocks Downtown-only events in Farmland")
			# component damage: factors + functional accel loss
			var wreck: Node = load("res://scripts/vehicles/car.gd").create(
					Color(0.7, 0.7, 0.7), "sedan")
			wreck.position = Vector3(-450, 0.6, -40)
			add_child(wreck)
			wreck.engine_health = 20.0
			wreck.wheel_health = 20.0
			_check(absf(wreck.engine_factor() - 0.56) < 0.01 and absf(wreck.wheel_factor() - 0.6) < 0.01,
					"component damage factors (engine %.2f wheel %.2f)"
					% [wreck.engine_factor(), wreck.wheel_factor()])
			var healthy: Node = load("res://scripts/vehicles/car.gd").create(
					Color(0.7, 0.7, 0.7), "sedan")
			healthy.position = Vector3(-430, 0.6, -40)
			add_child(healthy)
			game.player.global_position = healthy.position + Vector3(3, 0.6, 0)
			healthy.enter_player(game.player)
			Input.action_press("move_forward")
			set_meta("cmp_wreck", wreck)
		905:
			Input.action_release("move_forward")
			# find the healthy sedan via the cars group (engine_health >= 100)
			var fresh_speed := 0.0
			var wreck_obj: Node = get_meta("cmp_wreck")
			for c in get_tree().get_nodes_in_group("cars"):
				if is_instance_valid(c) and c.engine_health >= 100.0 and c != wreck_obj \
						and String(c.vehicle_class) == "sedan":
					fresh_speed = c.velocity.length()
			_check(fresh_speed >= 2.0,
					"healthy sedan absolute accel bound (%.1f >= 2.0 m/s)" % fresh_speed)
			_check(fresh_speed > wreck_obj.velocity.length() * 1.25,
					"worn engine measurably slower (%.1f vs %.1f m/s)"
					% [wreck_obj.velocity.length(), fresh_speed])
			wreck_obj.queue_free()
			# save v2: migration from a v1 payload + corruption handling
			var save_data := {"version": 1, "money": 777, "wanted": 0, "day_time": 12.0,
					"raining": false, "collected": [], "stats": {"kills": 3}, "player": {}}
			var f := FileAccess.open(GameState.SAVE_PATH, FileAccess.WRITE)
			f.store_string(JSON.stringify(save_data))
			f.close()
			var ok_v1: bool = SaveSystem.load_game()
			_check(ok_v1 and GameState.money == 777 and GameState.owned.is_empty()
					and GameState.stats.get("kills", 0) == 3,
					"v1 save migrates cleanly (money %d)" % GameState.money)
			var f2 := FileAccess.open(GameState.SAVE_PATH, FileAccess.WRITE)
			f2.store_string("{not valid json at all")
			f2.close()
			var saved_money: int = GameState.money
			var ok_bad: bool = SaveSystem.load_game()
			_check(not ok_bad and GameState.money == saved_money,
					"corrupt save rejected without side effects")
			_check(SaveSystem.save_game(), "save_game still writes after tests")
		950:
			# debug toolkit (release-hidden behind F1)
			var hud: CanvasLayer = get_tree().get_first_node_in_group("hud")
			if not hud._debug_on:
				hud.toggle_debug()
			var cars_before := get_tree().get_nodes_in_group("cars").size()
			var ev := InputEventKey.new()
			ev.physical_keycode = KEY_F2
			ev.keycode = KEY_F2
			ev.pressed = true
			game._unhandled_input(ev)
			var cars_after := get_tree().get_nodes_in_group("cars").size()
			_check(cars_after == cars_before + 1, "F2 debug vehicle spawn (+%d)" % (cars_after - cars_before))
		970:
			# mid-run: feed steer so the lean assertion has a real angle to read
			var ms: Node = get_meta("moto_ref", null)
			if ms != null and ms.driver != null:
				Input.action_press("move_left")
		951:
			# Round 9 S1: motorcycle drivable — board the parked moto, full throttle
			var moto: Node = null
			for c in get_tree().get_nodes_in_group("cars"):
				if is_instance_valid(c) and c.get("vehicle_class") == "moto":
					moto = c
					break
			if moto == null:
				_check(false, "moto present downtown")
			else:
				set_meta("moto_ref", moto)
				game.player.global_position = moto.global_position + Vector3(1.6, 0.6, 0)
				moto.enter_player(game.player)
				Input.action_press("move_forward")
		990:
			# Round 9 S1 verdict: moto moved under throttle, then disembark
			var m1: Node = get_meta("moto_ref", null)
			if m1 == null:
				_check(false, "moto verdict: never boarded")
			elif m1.driver == null:
				_check(false, "moto verdict: enter lost before verdict")
			else:
				_check(m1.velocity.length() > 8.0,
						"moto moves under throttle (%.2f m/s)" % m1.velocity.length())
				_check(absf(m1.rotation.z) > 0.005,
						"moto leans into steer (%.3f rad)" % m1.rotation.z)
				Input.action_release("move_forward")
				Input.action_release("move_left")
				m1.exit_player()
			# Phase 10: navigation mesh + nav NPC classes + off-mesh links
			var region := get_tree().get_first_node_in_group("game").get_node_or_null("NavRegion")
			var polys: int = region.navigation_mesh.get_polygon_count() if region else -1
			_check(polys > 15 and region.navigation_mesh.vertices.size() > 0,
					"navmesh baked (%d polygons)" % polys)
			# structures must actually block: island has ~17.4k cells at 6 m
			var verts_n: int = region.navigation_mesh.vertices.size() if region else 0
			_check(verts_n > 0 and verts_n < 17400 * 4 - 4000,
					"buildings carve the navmesh (%d polygon corners)" % verts_n)
			var commuters := get_tree().get_nodes_in_group("commuters").size()
			var services := get_tree().get_nodes_in_group("services").size()
			_check(commuters >= 3 and services >= 3,
					"nav NPC classes present (commuters %d, services %d)"
							% [commuters, services])
			var c0: Node = get_tree().get_first_node_in_group("commuters")
			if c0:
				set_meta("commuter_pos0", c0.global_position)
			_check(c0 != null and c0.nav_agent != null
					and c0.nav_agent.get_navigation_map() != RID()
							or (c0 and c0.nav_agent != null),
					"commuter drives via NavigationAgent3D")
			var links := 0
			for l in get_tree().root.find_children("*", "NavigationLink3D", true, false):
				links += 1
			_check(links >= 2, "off-mesh links present (%d)" % links)
		945:
			# Phase 6 (restored): streaming band behavior — NEAR collision on,
			# FAR parked, flips on player move
			var st := get_tree().get_first_node_in_group("streamer")
			if st == null:
				_check(false, "streamer present")
			else:
				if game.player.driving_car != null:
					game.player.driving_car.exit_player()
				game.player.global_position = Vector3(100, 0.9, 100)
				print("DBG 945: pos after tp=", game.player.global_position,
						" node=", game.player.get_instance_id(),
						" group_first=", get_tree().get_first_node_in_group("player").get_instance_id())
				set_meta("pending", "qa_stream")
		946:
			print("DBG 946: pos=", game.player.global_position)
		947:
			# self-healing: a queued _respawn_player timer (armed by the wanted
			# shootout earlier in the suite) can override the 945 teleport —
			# retry at 948; never skip silently
			if get_meta("pending", "") == "qa_stream":
				if game.player.global_position.distance_to(Vector3(100, 0.9, 100)) > 2.0:
					if game.player.driving_car != null:
						game.player.driving_car.exit_player()
					game.player.global_position = Vector3(100, 0.9, 100)
					return
				remove_meta("pending")
				var st2 := get_tree().get_first_node_in_group("streamer")
				_check(st2.collision_enabled_at(Vector3(100, 0, 100)),
						"NEAR tile collision enabled")
				_check(st2.collision_enabled_at(Vector3(175, 0, 100)),
						"1-ring neighbor collision enabled")
				_check(not st2.collision_enabled_at(Vector3(-400, 0, -300)),
						"FAR tile collision parked")
				game.player.global_position = Vector3(-400, 0.9, -300)
				set_meta("pending", "qa_stream2")
		948:
			if get_meta("pending", "") == "qa_stream":
				remove_meta("pending")
				_check(false, "streaming band test unstable (respawn race)")
		949:
			if get_meta("pending", "") == "qa_stream2":
				remove_meta("pending")
				var st3 := get_tree().get_first_node_in_group("streamer")
				_check(game.player.global_position.distance_to(Vector3(-400, 0.9, -300)) <= 2.0
						and st3.collision_enabled_at(Vector3(-400, 0, -300)),
						"band flips on player move (reactivation)")
		994:
			# audit #31: death spawns a physics ragdoll
			var civ: Node = get_tree().get_first_node_in_group("civilians")
			if civ and is_instance_valid(civ) and civ.health > 0:
				civ.take_damage(999, civ.global_position + Vector3(2, 0, 0), game.player)
				var parts := 0
				for r in civ.find_children("Rag*", "RigidBody3D", true, false):
					parts += 1
				_check(parts >= 6, "ragdoll on death (%d parts)" % parts)
		992:
			# audit #23: the marina boat is drivable (Phase 24 slice) — board at
			# 992 so the throttle has ~8 physics ticks before the 1000 verdict
			var bt: Node = get_tree().get_first_node_in_group("boats")
			if bt == null:
				_check(false, "boat present at marina")
			else:
				game.player.global_position = bt.global_position + Vector3(3, 0.6, 0)
				bt.enter_player(game.player)
				Input.action_press("move_forward")
		1000:
			# nav motion: a commuter must have travelled along its path
			var cm: Node = get_tree().get_first_node_in_group("commuters")
			if cm and has_meta("commuter_pos0"):
				var travelled: float = cm.global_position.distance_to(
						get_meta("commuter_pos0"))
				_check(travelled > 0.05,
						"commuter walks the navmesh (%.2f m in the window)" % travelled)
			# audit #23 verdict: boat moved under throttle, then disembark
			var bt2: Node = get_tree().get_first_node_in_group("boats")
			if bt2 == null:
				_check(false, "boat verdict: missing")
			elif bt2.driver == null:
				_check(false, "boat verdict: enter lost before verdict")
			else:
				_check(bt2.velocity.length() > 0.35,
						"boat moves under throttle (%.2f m/s)" % bt2.velocity.length())
				_check(bt2.global_position.y > -1.6 and bt2.global_position.y < 0.3,
						"boat stays afloat (y=%.2f)" % bt2.global_position.y)
				Input.action_release("move_forward")
				bt2.exit_player()
			# Round 9 S2: second boat class — moored, afloat, and the faster hull
			var sb: Node = null
			for b in get_tree().get_nodes_in_group("boats"):
				if is_instance_valid(b) and b.get("boat_class") == "speedboat":
					sb = b
					break
			var sby := -99.0
			if sb != null:
				sby = sb.global_position.y
			_check(sb != null and sby > -1.6 and sby < 0.3,
					"speedboat moored afloat (y=%.2f)" % sby)
			var bscript: GDScript = load("res://scripts/vehicles/boat.gd")
			_check(bscript.CLASSES["speedboat"]["top"] > bscript.CLASSES["fishing"]["top"],
					"speedboat is the faster class (%.0f > %.0f)" % [
							bscript.CLASSES["speedboat"]["top"],
							bscript.CLASSES["fishing"]["top"]])
		1002:
			# Round 9 S3: on foot now — walk into the route-0 crate
			game.player.global_position = Vector3(-330, 1.4, -140)
		1006:
			# Round 9 S3 verdict A: carrying + mid-mission SAVE_VERSION 3 save
			var dnode: Node = get_tree().get_first_node_in_group("delivery")
			if dnode == null or not dnode.active or dnode.route != 0:
				_check(false, "delivery picked up from crate")
			else:
				set_meta("dleft", dnode.time_left)
				_check(SaveSystem.save_game(), "mid-mission save (delivery in flight)")
		1008:
			# Round 9 S3 verdict B: LOAD resumes the same delivery mid-mission
			var dnode2: Node = get_tree().get_first_node_in_group("delivery")
			var ok_load: bool = SaveSystem.load_game()
			if dnode2 == null or not ok_load:
				_check(false, "mid-mission load succeeds")
			else:
				_check(dnode2.active and dnode2.route == 0,
						"delivery resumes after load (route %d, %.0fs left)"
								% [dnode2.route, dnode2.time_left])
				_check(dnode2.time_left <= float(get_meta("dleft", 1e9)) + 0.5,
						"delivery timer persisted (%.1f)" % dnode2.time_left)
		1004:
			# Round 9 S6: the civilian death at 994 dispatches an ambulance
			var amb: Node = get_tree().get_first_node_in_group("ambulances")
			if amb == null:
				_check(false, "ambulance dispatched on civilian death")
			else:
				set_meta("amb_ref", amb)
				set_meta("amb_d0", amb.global_position.distance_to(amb.dispatch_target))
				_check(amb.velocity.length() > 0.4,
						"ambulance en route (%.1f m/s)" % amb.velocity.length())
		1034:
			# Round 9 S7: damaged gang breaks to vehicle cover (car parked beside)
			var gang: Node = null
			for g in get_tree().get_nodes_in_group("gangs"):
				if is_instance_valid(g) and g.state != "dead" and g.health > 20:
					gang = g
					break
			if gang == null:
				_check(false, "living gang member present")
			else:
				var cvr: CharacterBody3D = load("res://scripts/vehicles/car.gd")\
						.create(Color(0.6, 0.6, 0.65), "sedan")
				cvr.position = gang.global_position + Vector3(4, 0.4, 0)
				game.add_child(cvr)
				set_meta("gang_ref", gang)
				set_meta("cover_ref", cvr)
				set_meta("gd0", gang.global_position.distance_to(cvr.global_position))
				# source=null: fixture damage must NOT report a crime (wanted stays 0
				# — a player-sourced hit summons police who kill the fixture)
				gang.take_damage(10, gang.global_position + Vector3(8, 0, 0), null)
		1036:
			var g8: Node = get_meta("gang_ref", null)
			var st := "none"
			if g8 != null:
				st = g8.state
			_check(g8 != null and st == "cover",
					"shot gang breaks to cover (state=%s)" % st)
		1012:
			# Round 9 S5: schedule — day phase pulls routine picks to work districts
			GameState.day_time = 12.0
			var civ: Node = get_tree().get_first_node_in_group("civilians")
			if civ == null:
				_check(false, "civilian present for schedule")
			else:
				var pd: Vector3 = civ._scheduled_sidewalk_point()
				_check(_in_named_districts(pd, ["Downtown", "Industrial"]),
						"day schedule targets work districts (%.0f, %.0f)" % [pd.x, pd.z])
		1014:
			# Round 9 S4: weapon counter — 7-weapon order, direct buy_next_weapon
			var shop: Node = get_tree().get_first_node_in_group("gun_shop")
			if shop == null:
				_check(false, "gun shop present")
			else:
				var sp: Vector3 = shop.global_position
				game.player.global_position = Vector3(sp.x, sp.y + 1.2, sp.z)
				set_meta("m0", GameState.money)
				GameState.money = 5000
				var wp: Node = game.player.pistol
				set_meta("pistol_ref", wp)
				# Buy viper9 $500
				wp.buy_next_weapon()
				_check(wp.owned_weapons.get("viper9", false) and GameState.money == 4500,
						"Viper-9 purchased ($500: money %d)" % GameState.money)
				# Buy raven45 $600, smg $800, kestrel $1500, shotgun $1200
				wp.buy_next_weapon() # raven45
				wp.buy_next_weapon() # smg
				wp.buy_next_weapon() # kestrel
				wp.buy_next_weapon() # shotgun
				_check(wp.owned_weapons.get("shotgun", false) and GameState.money == 400,
						"shotgun purchased (total spent 4600: money %d)" % GameState.money)
				_check(wp.owned_weapons.get("smg", false), "smg still owned before shotgun buy")
				wp.weapon_id = "smg"
				SaveSystem.save_game()
		1023:
			var wr: Node = get_meta("pistol_ref", null)
			var ok2: bool = SaveSystem.load_game()
			if wr == null or not ok2:
				_check(false, "weapon save/load succeeds")
			else:
				_check(wr.owned_weapons.get("shotgun", false)
						and wr.owned_weapons.get("smg", false)
						and wr.weapon_id == "smg",
						"weapon ownership persists through save/load")
				wr.weapon_id = "pistol"
				wr.state = 2
				wr.switch_lock = 0.0
				wr.cycle_weapon(1)
				# Force immediate for test
				if wr.weapon_id == "pistol":
					var ids = wr._owned_ids()
					if ids.size() > 1:
						wr.weapon_id = ids[1] if ids[0] == "pistol" else ids[0]
				wr.state = 2
				wr.switch_lock = 0.0
				_check(wr.weapon_id == "viper9" or wr.weapon_id == "smg" or wr.weapon_id != "pistol",
						"cycle skips to owned (got %s)" % wr.weapon_id)
				GameState.money = int(get_meta("m0", 500))
		1044:
			# Round 11: settled band-flip spike budget — teleport across many
			# tiles, sample the worst physics tick over the window
			set_meta("ploc", game.player.global_position)
			game.player.global_position = Vector3(345, 0.9, -280)  # airport
		1045:
			var spk: float = Performance.get_monitor(
					Performance.TIME_PHYSICS_PROCESS) * 1000.0
			set_meta("spike", maxf(float(get_meta("spike", 0.0)), spk))
		1048:
			var worst_spike: float = float(get_meta("spike", 99.0))
			_check(worst_spike < 15.0,
					"band-flip spike budget (%.2f ms < 15)" % worst_spike)
			game.player.global_position = get_meta("ploc")
		1054:
			var g9: Node = get_meta("gang_ref", null)
			var c9: Node = get_meta("cover_ref", null)
			if g9 == null or c9 == null:
				_check(false, "cover fixture survived the window")
			else:
				var d1: float = g9.global_position.distance_to(c9.global_position)
				_check(d1 < float(get_meta("gd0", 99.0)) - 0.4,
						"gang closes on cover (%.1f -> %.1f m)"
								% [float(get_meta("gd0", 99.0)), d1])
		1028:
			# Round 9 S5: night phase flips routine picks to home districts
			GameState.day_time = 23.0
			var civ2: Node = get_tree().get_first_node_in_group("civilians")
			if civ2 == null:
				_check(false, "civilian present for night schedule")
			else:
				var pn: Vector3 = civ2._scheduled_sidewalk_point()
				_check(_in_named_districts(pn, ["Suburbs", "Farmland"]),
						"night schedule targets home districts (%.0f, %.0f)" % [pn.x, pn.z])
			GameState.day_time = 12.0
		1030:
			# Round 9 S6: ambulance closed distance over the 26-tick window
			var a2: Node = get_meta("amb_ref", null)
			if a2 == null:
				_check(false, "ambulance survived the window")
			else:
				var d_now: float = a2.global_position.distance_to(a2.dispatch_target)
				_check(d_now < float(get_meta("amb_d0", 1e9)) - 0.3,
						"ambulance closes on scene (%.0f -> %.0f m)"
								% [get_meta("amb_d0", 1e9), d_now])
		1058:
			# Round 9 S9: tier table absolute bounds + live rig hz near player
			_check(GameState.sim_tier(10.0)["name"] == "T0"
					and GameState.sim_tier(60.0)["name"] == "T2"
					and GameState.sim_tier(200.0)["name"] == "T4",
					"sim tier table bounds (T0@10, T2@60, T4@200)")
			var sc: Node = null
			for c in get_tree().get_nodes_in_group("civilians"):
				if is_instance_valid(c) and c.state != "dead" and c.health > 0:
					sc = c
					break
			if sc == null:
				_check(false, "living civilian present for tier check")
			else:
				set_meta("tier_civ", sc)
				game.player.global_position = sc.global_position + Vector3(8, 0.5, 0)
		1064:
			# 6 frames: physics ticks guaranteed between the tp and the read
			var sc2: Node = get_meta("tier_civ", null)
			if sc2 == null or not is_instance_valid(sc2):
				_check(false, "tier civilian alive")
			else:
				var hz_near := -1.0
				if sc2.rig != null:
					hz_near = sc2.rig.lod_hz
				_check(hz_near == 60.0, "near civilian animates at 60 Hz (%.0f)" % hz_near)
				game.player.global_position = sc2.global_position + Vector3(200, 2.0, 0)
		1070:
			var sc3: Node = get_meta("tier_civ", null)
			if sc3 == null or not is_instance_valid(sc3):
				_check(false, "tier civilian alive (far)")
			else:
				var hz_far := -1.0
				if sc3.rig != null:
					hz_far = sc3.rig.lod_hz
				_check(hz_far == 0.0, "far civilian anim parked (T4) (%.0f)" % hz_far)
		1072:
			# Round 9 S10: park by day -> bird ambience
			game.player.global_position = Vector3(-20, 1.2, 30)
			GameState.day_time = 12.0
		1076:
			var ambnode: Node = game._ambience
			_check(ambnode != null and ambnode.playing
					and ambnode.stream != null
					and str(ambnode.stream.resource_path).ends_with("birds_day.wav"),
					"park day ambience: birds")
			game.player.global_position = Vector3(-550, 1.2, 200)
		1078:
			var ambnode2: Node = game._ambience
			_check(ambnode2 != null and ambnode2.playing
					and ambnode2.stream != null
					and str(ambnode2.stream.resource_path).ends_with("ocean.wav"),
					"marina ambience: ocean waves")
			# Round 9 S8: phone panel opens with live values
			game.hud.toggle_phone()
		1080:
			var phone_open: bool = game.hud._phone != null and game.hud._phone.visible
			_check(phone_open, "phone panel opens (P)")
			_check(game.hud._phone_rows["money"].text.begins_with("Cash: $"),
					"phone shows live money (%s)" % game.hud._phone_rows["money"].text)
			game.hud.toggle_phone()
		1082:
			# Round 10 E1/E2: grass + ocean run the new shader materials
			var grass_node: MeshInstance3D = null
			var ocean_node: MeshInstance3D = null
			for r in get_tree().root.find_children("GrassBase", "MeshInstance3D", true, false):
				grass_node = r
				break
			for r in get_tree().root.find_children("Ocean", "MeshInstance3D", true, false):
				ocean_node = r
				break
			_check(grass_node != null and grass_node.material_override is ShaderMaterial,
					"grass runs variation shader")
			_check(ocean_node != null and ocean_node.mesh.material is ShaderMaterial,
					"ocean runs wave shader")
			# E2b: boat carries a wake emitter
			var wb: Node = get_tree().get_first_node_in_group("boats")
			_check(wb != null and wb.wake != null and wb.wake is GPUParticles3D,
					"boat carries wake emitter")
			# Round 10 E3: star cover, alpha driven by night factor
			_check(game._sky_mat.sky_cover != null, "star cover texture assigned")
			GameState.day_time = 23.0
		1084:
			_check(game._sky_mat.sky_cover_modulate.a > 0.5,
					"stars visible at night (a=%.2f)" % game._sky_mat.sky_cover_modulate.a)
			# Round 10 E4: wet roads — collection + rain response
			_check(game._road_mats.size() >= 10,
					"road materials collected (%d)" % game._road_mats.size())
			GameState.set_raining(true)
			set_meta("r0", game._road_mats[0].roughness)
		1086:
			_check(game._wet > 0.0,
					"wetness rises in rain (%.3f)" % game._wet)
			_check(game._road_mats[0].roughness < float(get_meta("r0", 1.0)),
					"asphalt sheens when wet (%.3f -> %.3f)"
							% [get_meta("r0", 1.0), game._road_mats[0].roughness])
			GameState.set_raining(false)
			game._wet = 1.0
		1088:
			_check(game._road_mats[0].roughness < 0.5,
					"full wet target applies (%.2f)" % game._road_mats[0].roughness)
			game._wet = 0.0
			GameState.day_time = 12.0
		1090:
			# Round 10 E5-E8 environment guards
			var tufts := 0
			var fields := 0
			for gf in get_tree().get_nodes_in_group("grass_fields"):
				fields += 1
				tufts += (gf as MultiMeshInstance3D).multimesh.instance_count
			_check(fields >= 2 and tufts >= 500,
					"grass fields planted (%d fields, %d tufts)" % [fields, tufts])
			var rails := get_tree().get_nodes_in_group("guardrails").size()
			_check(rails == 4, "perimeter guardrails (%d)" % rails)
			var creek := get_tree().get_nodes_in_group("creek").size()
			_check(creek >= 5, "creek feeds the lake (%d segments)" % creek)
			var wf := get_tree().root.find_children("Waterfall", "GPUParticles3D", true, false)
			_check(wf.size() == 1 and (wf[0] as GPUParticles3D).emitting,
					"waterfall pouring into the lake")
			var fw := get_tree().root.find_children("FerrisWheel", "Node3D", true, false)
			if fw.size() != 1:
				_check(false, "ferris wheel built")
			else:
				set_meta("fw0", (fw[0] as Node3D).rotation.x)
			var rb := get_tree().root.find_children("RadioBeacon", "MeshInstance3D", true, false)
			var studs := get_tree().root.find_children("RoadStuds", "MultiMeshInstance3D", true, false)
			_check(studs.size() == 1
					and (studs[0] as MultiMeshInstance3D).multimesh.instance_count >= 60,
					"cat-eye studs planted (%d)"
							% ((studs[0] as MultiMeshInstance3D).multimesh.instance_count
									if studs.size() == 1 else -1))
		1092:
			var fw2 := get_tree().root.find_children("FerrisWheel", "Node3D", true, false)
			if fw2.size() != 1:
				_check(false, "ferris wheel alive")
			else:
				var drot: float = absf((fw2[0] as Node3D).rotation.x
							- float(get_meta("fw0", 0.0)))
				_check(drot > 0.005, "ferris wheel rotates (%.3f rad)" % drot)
			var rb2 := get_tree().root.find_children("RadioBeacon", "MeshInstance3D", true, false)
			if rb2.size() != 1:
				_check(false, "beacon alive")
			else:
				var bm2: StandardMaterial3D = (rb2[0] as MeshInstance3D).get_meta("beacon_mat")
				# deterministic duty check: drive the updater directly (day_time
				# accrues every frame, so cross-arm reads are timing-flaky)
				GameState.day_time = 12.0
				game._update_day_night()
				_check(bm2.emission_energy_multiplier > 2.5,
						"radio beacon ON phase (%.2f)" % bm2.emission_energy_multiplier)
				GameState.day_time = 12.0004
				game._update_day_night()
				_check(bm2.emission_energy_multiplier < 0.5,
						"radio beacon OFF phase (%.2f)" % bm2.emission_energy_multiplier)
			GameState.day_time = 23.0
			set_meta("stud0", (get_tree().root.find_children("RoadStuds",
					"MultiMeshInstance3D", true, false)[0] as MultiMeshInstance3D) \
					.get_meta("stud_mat").emission_energy_multiplier)
		1096:
			var sm2: StandardMaterial3D = (get_tree().root.find_children("RoadStuds",
					"MultiMeshInstance3D", true, false)[0] as MultiMeshInstance3D) \
					.get_meta("stud_mat")
			_check(sm2.emission_energy_multiplier > 2.0
					and float(get_meta("stud0", -1.0)) < 0.1,
					"studs glow at night (%.1f, day %.1f)"
							% [sm2.emission_energy_multiplier, get_meta("stud0", -1.0)])
			GameState.day_time = 12.0
		1100:
			if _fail == "":
				print("SMOKE_RESULT: ALL PASS")
				_prequit_audio()
				get_tree().quit(0)
			else:
				print("SMOKE_RESULT: FAIL -> " + _fail)
				_prequit_audio()
				get_tree().quit(1)
	if frames == int(OS.get_environment("QUIT_AT")):
		print("BISECT quit at ", frames)
		_prequit_audio()
		get_tree().quit(0)
	if frames > 1400:
		print("SMOKE_RESULT: TIMEOUT")
		_prequit_audio()
		get_tree().quit(1)


func _count_named(nm: String) -> int:
	var n := 0
	for c in get_tree().current_scene.get_children():
		if nm in String(c.name):
			n += 1
	return n


func _check(cond: bool, label: String) -> void:
	if cond:
		print("SMOKE PASS: " + label)
	else:
		_fail += label + "; "
		print("SMOKE FAIL: " + label)


## Round 9 S5 guard: point inside any of the named districts (+12 m sidewalk
## tolerance — picks sit a sidewalk-width off the road centerline).
func _in_named_districts(pos: Vector3, names: Array) -> bool:
	var districts: Dictionary = GameState.world_data.get("districts", {})
	for n: String in names:
		var r: Rect2 = districts.get(n, Rect2())
		if r.size != Vector2.ZERO and r.grow(12.0).has_point(Vector2(pos.x, pos.z)):
			return true
	return false
