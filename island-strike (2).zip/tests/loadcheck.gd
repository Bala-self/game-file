extends SceneTree
func _initialize() -> void:
	var files := [
		"res://scripts/core/game_state.gd",
		"res://scripts/core/save_system.gd",
		"res://scripts/core/event_bus.gd",
		"res://scripts/core/economy.gd",
		"res://scripts/core/debug_tools.gd",
		"res://scripts/world/world_builder.gd",
		"res://scripts/characters/character_rig.gd",
		"res://scripts/player/player.gd",
		"res://scripts/weapons/pistol.gd",
		"res://scripts/vehicles/car.gd",
		"res://scripts/npc/person.gd",
		"res://scripts/npc/npc_civilian.gd",
		"res://scripts/npc/npc_police.gd",
		"res://scripts/world/pickup.gd",
		"res://scripts/world/collectible.gd",
		"res://scripts/ui/hud.gd",
		"res://scripts/ui/pause_menu.gd",
		"res://scripts/ui/settings_panel.gd",
		"res://scripts/main/main_menu.gd",
		"res://scripts/game/game.gd",
	]
	for f in files:
		var s = load(f)
		if s == null or not (s as Script).can_instantiate():
			# for scripts with only static funcs can_instantiate may be true anyway; check validity
			print("LOADFAIL: ", f)
		else:
			print("ok: ", f)
	quit(0)
