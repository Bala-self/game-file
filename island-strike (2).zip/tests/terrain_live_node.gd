extends Node
## P03 §34 live gates 39-55 (+ bounds-guard extra): run inside the real game
## scene. Staged by frame windows so streaming/physics settle between checks.

const WT := preload("res://scripts/world/terrain.gd")

var frames := 0
var fails: int = 0
var passes: int = 0
var game: Node3D
var _chunk_count0 := 0
var _nodes0 := 0
var _mem0 := 0
var _tp := 0
var _teleports: Array[Vector3] = [
	Vector3(2100, 0, 600), Vector3(-1400, 0, 2100), Vector3(60, 0, 2200),
	Vector3(1150, 0, -2450), Vector3(-2280, 0, -820), Vector3(3500, 0, 0),
]


func _check(ok: bool, label: String) -> void:
	if ok:
		passes += 1
		print("TRECON PASS: %s" % label)
	else:
		fails += 1
		print("TRECON FAIL: %s" % label)


func _ready() -> void:
	game = get_tree().current_scene
	passes = int(get_meta("static_passes", 0))
	fails = int(get_meta("static_fails", 0))


func _chunk_bodies() -> Array[Node]:
	return get_tree().get_nodes_in_group("terrain_chunks")


func _node_count() -> int:
	var n := 0
	var stack: Array[Node] = [get_tree().root]
	while stack.size() > 0:
		var cur: Node = stack.pop_back()
		n += 1
		for c: Node in cur.get_children():
			stack.append(c)
	return n


func _ground_at(x: float, z: float) -> Vector3:
	return Vector3(x, WT.resolve_to_ground(x, z)["ground_y"] + 1.2, z)


func _process(_d: float) -> void:
	frames += 1
	match frames:
		6: _initial_state()
		10: _spawn_and_legacy()
		14: _start_traversal()
		_: if frames > 14 and frames % 14 == 0:
			_teleport_step()


func _initial_state() -> void:
	# 39/40: chunk owner identity + uniqueness
	var seen := {}
	var bad_owner := 0
	var dup := 0
	for n: Node in _chunk_bodies():
		if n is StaticBody3D:
			_chunk_count0 += 1
			var nm: String = n.name
			if seen.has(nm):
				dup += 1
			seen[nm] = true
			var parts: PackedStringArray = nm.split("_")
			var gx: int = int(parts[2])
			var gz: int = int(parts[3])
			var want := Vector3(float(gx) * 250.0 + 125.0, 0.0, float(gz) * 250.0 + 125.0)
			if n.position.distance_to(want) > 0.01:
				bad_owner += 1
	_check(_chunk_count0 > 300 and bad_owner == 0,
			"39 chunk owner correct (%d bodies, %d misplaced)" % [_chunk_count0, bad_owner])
	_check(dup == 0, "40 no duplicate chunk owner (%d dups)" % dup)
	# 41: near terrain present from the start
	var pp: Vector3 = game.player.global_position
	var near := 0
	for n: Node in _chunk_bodies():
		if n is StaticBody3D and (n as Node3D).global_position.distance_to(pp) < 800.0:
			near += 1
	_check(near > 0 or not WT.is_water_position(pp.x, pp.z),
			"41 near terrain exists before traversal (%d near bodies)" % near)
	# 43: far terrain carries no collision
	var far_total := 0
	var far_hot := 0
	for n: Node in _chunk_bodies():
		if n is StaticBody3D:
			var b := n as StaticBody3D
			if b.global_position.distance_to(pp) > 750.0:
				far_total += 1
				if b.collision_layer != 0:
					far_hot += 1
	_check(far_total > 100 and far_hot == 0,
			"43 far terrain creates no full collision (%d far, %d hot)" % [far_total, far_hot])


func _spawn_and_legacy() -> void:
	# 42: active terrain collision under the player
	var pp: Vector3 = game.player.global_position
	var q := PhysicsRayQueryParameters3D.create(pp + Vector3(0, 14, 0),
			pp + Vector3(0, -14, 0))
	q.exclude = [game.player.get_rid()]
	var hit: Dictionary = get_viewport().world_3d.direct_space_state.intersect_ray(q)
	var ok := hit.has("collider") and hit["collider"] is StaticBody3D
	_check(ok, "42 active terrain collision present (%s)"
			% str(hit.get("collider").name if ok else "none"))
	# 46: legacy 900 x 700 heartland compatibility
	var sand := game.find_child("GroundSand", true, false)
	var shop := game.find_child("GunShop*", true, false)
	var flat_ok := true
	for gx in range(-6, 7):
		for gz in range(-5, 6):
			if absf(WT.height_at(float(gx) * 80.0, float(gz) * 80.0)) > 0.1:
				flat_ok = false
	_check(sand != null and shop != null and flat_ok,
			"46 legacy populated area compatible (sand=%s shop=%s flat=%s)"
			% [sand != null, shop != null, flat_ok])
	# 47: player spawn works — on land, above terrain, inside world
	var sp: Vector3 = game.player.global_position
	_check(WorldContract.is_playable(sp) and not WT.is_water_position(sp.x, sp.z)
			and sp.y >= WT.height_at(sp.x, sp.z) - 0.5,
			"47 player spawn works (%.0f, %.1f, %.0f)" % [sp.x, sp.y, sp.z])
	# 49: save positions survive (the save sanitizer's clamp keeps them in-world)
	var sane: Vector3 = WorldContract.clamp_position_to_world(Vector3(3500, 12.0, -3500))
	_check(WorldContract.is_playable(sane) and sane.length() <= 2991.0,
			"49 existing save positions survive (clamped to %.0f)" % sane.length())
	# 48: mission locations remain valid — every authored mission anchor must
	# sit inside the world contract on the new field (full objective logic is
	# covered by the 97-gate mission suite in the same CI run)
	var MD := load("res://scripts/missions/mission_defs.gd")
	var anchors := 0
	var bad_anchors := 0
	for key: String in MD.DEFINITIONS:
		var m: Dictionary = MD.DEFINITIONS[key]
		var pts: Array[Vector3] = [m["start"]]
		for o: Dictionary in m.get("objectives", []):
			if o.has("pos"):
				pts.append(o["pos"])
		for pt: Vector3 in pts:
			anchors += 1
			if not WorldContract.is_playable(pt):
				bad_anchors += 1
			elif absf(WT.height_at(pt.x, pt.z)) > 400.0:
				bad_anchors += 1
	_check(anchors > 10 and bad_anchors == 0,
			"48 mission locations remain valid (%d anchors, %d bad)" % [anchors, bad_anchors])
	# 51-54: measured budgets
	var st: Dictionary = WorldBuilder.terrain_stats
	_check(st.has("build_ms") and int(st["build_ms"]) < 6000,
			"51 terrain generation time measured (%d ms)" % int(st.get("build_ms", -1)))
	var t0: int = Time.get_ticks_usec()
	var acc := 0.0
	for i in range(20000):
		var x: float = float(i % 200) * 29.0 - 2900.0
		var z: float = float((i / 200) % 100) * 59.0 - 2900.0
		acc += WT.height_at(x, z)
	var us: int = Time.get_ticks_usec() - t0
	_check(us < 1200000 and acc != 12345.0,
			"52 terrain query throughput measured (20k in %d ms)" % (us / 1000))
	var total_nodes: int = _node_count()
	_nodes0 = total_nodes
	# budget: P02 baseline scene measured 9340 nodes; chunks add 3 nodes each
	# (body + collision shape + mesh) + 1 streamer. Ceiling = baseline + that.
	_check(_chunk_count0 == int(st.get("chunks", -1)) and total_nodes < 11500,
			"53 active terrain node count (%d chunk bodies, %d total)"
			% [_chunk_count0, total_nodes])
	var meshes := get_tree().root.find_children("*", "MeshInstance3D", true, false).size()
	# budget: P02 baseline measured 5177 MeshInstance3D; +1 per chunk
	_check(int(st.get("verts", 0)) == _chunk_count0 * 169
			and int(st.get("tris", 0)) < 160000 and meshes < 6100,
			"54 mesh/vertex budget (verts %d, tris %d, %d meshes)"
			% [int(st.get("verts", 0)), int(st.get("tris", 0)), meshes])
	_mem0 = int(Performance.get_monitor(Performance.MEMORY_STATIC))


func _start_traversal() -> void:
	_tp = 0
	_do_teleport()


func _do_teleport() -> void:
	if _tp >= _teleports.size():
		_finish()
		return
	var t: Vector3 = _teleports[_tp]
	game.player.global_position = _ground_at(t.x, t.z)


func _teleport_step() -> void:
	# fires 14 frames after each teleport: verify then hop again
	var pp: Vector3 = game.player.global_position
	var near_on := 0
	var near_tot := 0
	for n: Node in _chunk_bodies():
		if n is StaticBody3D:
			var b := n as StaticBody3D
			if b.global_position.distance_to(pp) < 650.0:
				near_tot += 1
				if b.collision_layer != 0:
					near_on += 1
	if near_tot == 0 or near_on == near_tot:
		pass  # per-hop streaming verified in aggregate below
	else:
		_check(false, "44/41 chunk collision streams on near player (hop %d: %d/%d)"
				% [_tp, near_on, near_tot])
	var cnt: int = _chunk_bodies().size()
	if cnt != _chunk_count0 * 2:
		_check(false, "44 activation duplicated terrain (%d vs %d)"
				% [cnt, _chunk_count0 * 2])
	# bounds guard extra gate: the final hop targets r=3500 (outside)
	if _tp == _teleports.size() - 1:
		_check(pp.length() <= 2997.5,
				"56 EXTRA bounds guard clamps actors (r=%.1f)" % pp.length())
	_tp += 1
	_do_teleport()


func _finish() -> void:
	var nodes: int = _node_count()
	var mem: int = int(Performance.get_monitor(Performance.MEMORY_STATIC))
	_check(_chunk_bodies().size() == _chunk_count0 * 2,
			"44 sector activation duplicates no terrain (%d nodes after 6 hops)"
			% _chunk_bodies().size())
	_check(absi(nodes - _nodes0) <= 20,
			"45 long traversal leaks no nodes (%d -> %d)" % [_nodes0, nodes])
	_check(mem - _mem0 < 6 * 1024 * 1024,
			"55 long traversal memory bounded (+%d KB)" % ((mem - _mem0) / 1024))
	print("TRECON_TALLY: passes=%d fails=%d" % [passes, fails])
	if fails == 0:
		print("TERRAIN_RECON_RESULT: ALL PASS (%d/%d)" % [passes, passes])
		get_tree().quit(0)
	else:
		print("TERRAIN_RECON_RESULT: FAIL (%d)" % fails)
		get_tree().quit(1)
