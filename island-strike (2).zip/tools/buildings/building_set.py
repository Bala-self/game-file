# ISLAND STRIKE — 10 Realistic Buildings, Blender 4.2 procedural set
# Run:  blender -b --factory-startup --python building_set.py -- --out <dir>
# Deterministic (seed 20260919). Exports building_01..10.glb + building_set.glb
# + building_set.blend. Structure per building:
#   BUILDING_NN_NAME/Architecture|Doors|Windows|Interior|Props/Collision/LOD
import bpy, bmesh, math, random, sys, argparse
from mathutils import Vector, Euler

SEED = 20260919
R = random.Random(SEED)
OUT = "."

# ---------------------------------------------------------------- materials
def mat(name, color, rough=0.85, metal=0.0, alpha=1.0, glass=False):
    m = bpy.data.materials.get(name)
    if m:
        return m
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    bsdf = m.node_tree.nodes.get("Principled BSDF")
    bsdf.inputs["Base Color"].default_value = (*color, 1.0)
    bsdf.inputs["Roughness"].default_value = rough
    bsdf.inputs["Metallic"].default_value = metal
    if alpha < 1.0:
        bsdf.inputs["Alpha"].default_value = alpha
        m.blend_method = "BLEND"
    if glass:
        for key in ("Transmission Weight", "Transmission"):
            if key in bsdf.inputs:
                bsdf.inputs[key].default_value = 1.0
                break
        bsdf.inputs["Roughness"].default_value = 0.08
    return m

MATS = {}
def build_materials():
    MATS["concrete_a"] = mat("Concrete_A", (0.62, 0.61, 0.58), 0.92)
    MATS["concrete_b"] = mat("Concrete_B", (0.55, 0.54, 0.52), 0.94)
    MATS["brick_a"]    = mat("Brick_A", (0.48, 0.26, 0.20), 0.90)
    MATS["brick_b"]    = mat("Brick_B", (0.38, 0.30, 0.26), 0.92)
    MATS["plaster_a"]  = mat("Plaster_A", (0.82, 0.80, 0.74), 0.88)
    MATS["plaster_b"]  = mat("Plaster_B", (0.74, 0.70, 0.62), 0.90)
    MATS["glass"]      = mat("Glass", (0.45, 0.62, 0.68), 0.08, 0.0, 0.35, True)
    MATS["glass_dark"] = mat("Glass_Dark", (0.16, 0.22, 0.28), 0.10, 0.0, 0.45, True)
    MATS["metal_dark"] = mat("Metal_Dark", (0.18, 0.19, 0.20), 0.45, 0.85)
    MATS["metal_roof"] = mat("Metal_Roof", (0.42, 0.45, 0.47), 0.55, 0.75)
    MATS["metal_white"]= mat("Metal_White", (0.85, 0.86, 0.87), 0.50, 0.60)
    MATS["asphalt"]    = mat("Asphalt", (0.16, 0.16, 0.17), 0.96)
    MATS["wood_door"]  = mat("Wood_Door", (0.34, 0.22, 0.13), 0.75)
    MATS["wood_dark"]  = mat("Wood_Dark", (0.22, 0.15, 0.10), 0.85)
    MATS["paint_white"]= mat("Paint_White", (0.88, 0.88, 0.86), 0.70)
    MATS["paint_red"]  = mat("Paint_Red", (0.65, 0.14, 0.12), 0.65)
    MATS["paint_blue"] = mat("Paint_Blue", (0.15, 0.30, 0.55), 0.65)
    MATS["dirt"]       = mat("Dirt_Accumulation", (0.23, 0.20, 0.16), 0.98)
    MATS["rust"]       = mat("Rust", (0.40, 0.22, 0.10), 0.95, 0.2)
    MATS["veg"]        = mat("Vegetation", (0.18, 0.34, 0.14), 0.95)
    MATS["rubble"]     = mat("Rubble", (0.42, 0.40, 0.36), 0.98)
    MATS["rubber"]     = mat("Rubber_Dark", (0.05, 0.05, 0.05), 0.95)
    MATS["sign_green"] = mat("Sign_Green", (0.12, 0.38, 0.20), 0.60)
    MATS["corridor"]   = mat("Corridor_Grey", (0.58, 0.58, 0.56), 0.90)

# ---------------------------------------------------------------- geometry
def C(parent, name):
    c = bpy.data.collections.new(name)
    parent.children.link(c)
    return c

def _bevel(obj, width=0.025, segs=1):
    m = obj.modifiers.new("Bevel", "BEVEL")
    m.width = width
    m.segments = segs
    m.limit_method = "ANGLE"
    m.angle_limit = math.radians(40)

def box(coll, name, size, loc, material, rot=(0, 0, 0), bevel=0.0):
    mesh = bpy.data.meshes.new(name)
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1.0)
    bm.to_mesh(mesh)
    bm.free()
    obj = bpy.data.objects.new(name, mesh)
    obj.scale = (size[0], size[1], size[2])
    obj.location = loc
    obj.rotation_euler = Euler(rot, "XYZ")
    if material:
        mesh.materials.append(material)
    coll.objects.link(obj)
    if bevel > 0:
        _bevel(obj, bevel, 1)
    return obj

def cyl(coll, name, r, depth, loc, material, rot=(0, 0, 0), verts=16):
    mesh = bpy.data.meshes.new(name)
    bm = bmesh.new()
    bmesh.ops.create_cone(bm, cap_ends=True, radius1=r, radius2=r, depth=depth, segments=verts)
    bm.to_mesh(mesh)
    bm.free()
    obj = bpy.data.objects.new(name, mesh)
    obj.location = loc
    obj.rotation_euler = Euler(rot, "XYZ")
    mesh.materials.append(material)
    coll.objects.link(obj)
    return obj

def prism(coll, name, w, d, h, loc, material):
    """Gable roof prism: ridge along X, width w (X) x depth d (Y) x height h."""
    mesh = bpy.data.meshes.new(name)
    x, y, z = w / 2, d / 2, 0.0
    verts = [(-x, -y, z), (x, -y, z), (x, y, z), (-x, y, z),
             (-x, 0, z + h), (x, 0, z + h)]
    faces = [(0, 1, 5, 4), (3, 2, 5, 4), (0, 4, 3), (1, 2, 5)]
    mesh.from_pydata(verts, [], faces)
    mesh.validate()
    obj = bpy.data.objects.new(name, mesh)
    obj.location = loc
    mesh.materials.append(material)
    coll.objects.link(obj)
    _bevel(obj, 0.02, 1)
    return obj

# modular wall with window/door openings (segments, so holes are real)
def wall(coll, name, length, height, thick, base, direction, material,
         openings=(), bevel=0.02):
    """direction 'x'|'y'; openings: (offset_along, width, top_height, sill_height).
    Builds segments below sill / above header / between openings."""
    parts = []
    out = []
    xs = [(0.0, length)]
    segs = []
    cur = 0.0
    for (off, w, top, sill) in sorted(openings):
        segs.append((cur, off))
        segs.append((off, off + w, sill, top))  # opening marker
        cur = off + w
    segs.append((cur, length))
    for s in segs:
        if len(s) == 2:
            a, b = s
            if b - a < 0.01:
                continue
            parts.append((a, b, 0.0, height, False))
        else:
            a, b, sill, top = s
            if sill > 0.01:
                parts.append((a, b, 0.0, sill, False))
            if top < height - 0.01:
                parts.append((a, b, top, height, False))
    for i, (a, b, z0, z1, _) in enumerate(parts):
        seg_len = b - a
        seg_h = z1 - z0
        cx = (a + b) / 2 - length / 2
        cz = (z0 + z1) / 2
        if direction == "x":
            loc = (base[0] + cx, base[1], base[2] + cz)
            size = (seg_len, thick, seg_h)
        else:
            loc = (base[0], base[1] + cx, base[2] + cz)
            size = (thick, seg_len, seg_h)
        parts_name = "%s_seg%d" % (name, i)
        created = box(coll, parts_name, size, loc, material, bevel=bevel)
        out.append(created)
    return out

def window(coll, name, w, h, loc, rot_y=0.0, frame_mat=None, glass_mat=None):
    frame_mat = frame_mat or MATS["paint_white"]
    glass_mat = glass_mat or MATS["glass"]
    g = C(coll, name)
    t = 0.06
    d = 0.10
    box(g, name + "_frameL", (t, d, h), (-w / 2 + t / 2, 0, 0), frame_mat, (0, rot_y, 0))
    box(g, name + "_frameR", (t, d, h), (w / 2 - t / 2, 0, 0), frame_mat, (0, rot_y, 0))
    box(g, name + "_frameT", (w, d, t), (0, 0, h / 2 - t / 2), frame_mat, (0, rot_y, 0))
    box(g, name + "_frameB", (w, d, t), (0, 0, -h / 2 + t / 2), frame_mat, (0, rot_y, 0))
    box(g, name + "_mullion", (0.04, d * 0.7, h), (0, 0, 0), frame_mat, (0, rot_y, 0))
    box(g, name + "_glass", (w - 2 * t, 0.02, h - 2 * t), (0, 0, 0), glass_mat, (0, rot_y, 0))
    return g

def door(coll, name, w, h, loc, rot_y=0.0, material=None):
    material = material or MATS["wood_door"]
    g = C(coll, name)
    box(g, name + "_slab", (w, 0.06, h), (0, 0, 0), material, (0, rot_y, 0))
    box(g, name + "_handle", (0.10, 0.10, 0.03), (w / 2 - 0.12, 0.05, -0.05), MATS["metal_dark"], (0, rot_y, 0))
    return g

def ribbed_panel(coll, name, w, h, loc, rot=(0, 0, 0), slats=8, material=None):
    material = material or MATS["metal_white"]
    g = C(coll, name)
    for i in range(slats):
        z = h / 2 - (i + 0.5) * h / slats
        box(g, "%s_slat%d" % (name, i), (w, 0.05, h / slats * 0.85),
            (0, 0, z), material, rot)
    return g

def ac_unit(coll, name, loc, rot=(0, 0, 0)):
    g = C(coll, name)
    box(g, name + "_body", (0.9, 0.9, 0.7), (0, 0, 0.35), MATS["metal_white"], rot)
    box(g, name + "_grill", (0.7, 0.06, 0.5), (0, -0.44, 0.38), MATS["metal_dark"], rot)
    box(g, name + "_pad", (1.1, 1.1, 0.08), (0, 0, 0.04), MATS["concrete_b"], rot)

def electrical_box(coll, name, loc, rot=(0, 0, 0)):
    box(coll, name, (0.5, 0.22, 0.7), loc, MATS["metal_dark"], rot)

def downpipe(coll, name, loc, height, rot=(0, 0, 0)):
    cyl(coll, name, 0.05, height, (loc[0], loc[1], loc[2] + height / 2), MATS["metal_white"], rot)

def gutter(coll, name, length, loc, rot=(0, 0, 0)):
    box(coll, name, (length, 0.12, 0.10), loc, MATS["metal_white"], rot)

def rooftop_hvac(coll, name, loc):
    g = C(coll, name)
    box(g, name + "_unit", (2.2, 1.4, 1.0), (0, 0, 0.5), MATS["metal_white"])
    box(g, name + "_fan", (0.9, 0.9, 0.25), (0.4, 0, 1.1), MATS["metal_dark"])

def antenna_mast(coll, name, loc, height=4.0):
    g = C(coll, name)
    cyl(g, name + "_mast", 0.05, height, (0, 0, height / 2), MATS["metal_dark"])
    box(g, name + "_dish", (0.7, 0.1, 0.5), (0.4, 0, height * 0.7), MATS["paint_white"], (0, 0.5, 0))

def dirt_skirt(coll, name, w, d, loc):
    box(coll, name, (w + 0.25, d + 0.25, 0.28), (loc[0], loc[1], 0.14), MATS["dirt"])

def collision_box(coll, name, size, loc, rot=(0, 0, 0)):
    obj = box(coll, name + "-colonly", size, loc, None, rot)
    obj.display_type = "WIRE"
    obj.hide_render = True
    return obj

def trash_bin(coll, name, loc):
    cyl(coll, name, 0.32, 0.85, (loc[0], loc[1], 0.43), MATS["metal_dark"], verts=12)

def bush(coll, name, loc, r=0.5):
    sph = bpy.data.meshes.new(name)
    bm = bmesh.new()
    bmesh.ops.create_uvsphere(bm, u_segments=10, v_segments=8, radius=r)
    bm.to_mesh(sph)
    bm.free()
    obj = bpy.data.objects.new(name, sph)
    obj.location = loc
    sph.materials.append(MATS["veg"])
    coll.objects.link(obj)

# ------------------------------------------------------------ building core
ROOT = None
def new_building(index, name):
    global ROOT
    top = C(bpy.context.scene.collection, "BUILDING_%02d_%s" % (index, name))
    arch = C(top, "Architecture")
    doors = C(top, "Doors")
    wins = C(top, "Windows")
    interior = C(top, "Interior")
    props = C(top, "Props")
    col = C(top, "Collision")
    lod = C(top, "LOD")
    return {"top": top, "arch": arch, "doors": doors, "wins": wins,
            "interior": interior, "props": props, "col": col, "lod": lod,
            "majors": []}

def finish_building(b, index, name, majors_box):
    """LOD1 = majors only (no windows/props), LOD2 = single bounding box."""
    lod1 = C(b["lod"], "LOD1")
    for i, (size, loc, material) in enumerate(majors_box):
        box(lod1, "%s_LOD1_%d" % (name, i), size, loc, material)
    lod2 = C(b["lod"], "LOD2")
    xs = [m[1][0] for m in majors_box]
    ys = [m[1][1] for m in majors_box]
    zs = [m[1][2] for m in majors_box]
    cx, cy = sum(xs) / len(xs), sum(ys) / len(ys)
    span_x = max(m[0][0] / 2 + abs(m[1][0] - cx) for m in majors_box) * 2
    span_y = max(m[0][1] / 2 + abs(m[1][1] - cy) for m in majors_box) * 2
    top_z = max(m[1][2] + m[0][2] / 2 for m in majors_box)
    box(lod2, "%s_LOD2" % name, (span_x, span_y, top_z), (cx, cy, top_z / 2),
        MATS["concrete_b"])

def weathered(kind):
    return MATS[R.choice([kind + "_a", kind + "_b"])]

# ------------------------------------------------------------ the 10 builds
def bld_01_suburban_house(b):
    W, D, H = 12.0, 10.0, 2.7
    wall_mat = weathered("plaster")
    dirt_skirt(b["arch"], "DirtSkirt", W, D, (0, 0))
    box(b["arch"], "Foundation", (W, D, 0.25), (0, 0, 0.125), MATS["concrete_a"])
    wall(b["arch"], "WallFront", W, H, 0.25, (0, D / 2, 0.25), "x", wall_mat,
         openings=[(-3.6, 1.4, 2.2, 0.9), (0.0, 1.0, 2.2, 0.0), (3.6, 1.4, 2.2, 0.9)])
    wall(b["arch"], "WallBack", W, H, 0.25, (0, -D / 2, 0.25), "x", wall_mat,
         openings=[(-2.5, 1.4, 2.2, 0.9), (2.5, 1.4, 2.2, 0.9)])
    wall(b["arch"], "WallLeft", D, H, 0.25, (-W / 2, 0, 0.25), "y", wall_mat,
         openings=[(0.0, 1.2, 2.2, 0.9)])
    wall(b["arch"], "WallRight", D, H, 0.25, (W / 2, 0, 0.25), "y", wall_mat,
         openings=[(0.0, 1.2, 2.2, 0.9)])
    prism(b["arch"], "GableRoof", W + 0.8, D / 2 + 0.35, 1.7, (0, D / 2 + 0.06, H + 0.25), MATS["brick_b"])
    prism(b["arch"], "GableRoofBack", W + 0.8, D / 2 + 0.35, 1.7, (0, -D / 2 - 0.06, H + 0.25), MATS["brick_b"])
    box(b["arch"], "RidgeCap", (W + 0.9, 0.3, 0.14), (0, 0, H + 2.0), MATS["metal_dark"])
    # porch
    box(b["arch"], "PorchSlab", (4.2, 2.0, 0.22), (0, D / 2 + 1.0, 0.11), MATS["concrete_a"])
    for px in (-1.8, 1.8):
        box(b["arch"], "PorchPost%d" % (1 if px < 0 else 2), (0.16, 0.16, 2.3),
            (px, D / 2 + 1.8, 0.25 + 1.15), MATS["paint_white"])
    box(b["arch"], "PorchRoof", (4.6, 2.4, 0.12), (0, D / 2 + 1.1, 2.75), MATS["brick_b"], rot=(0.12, 0, 0))
    # garage
    gx = W / 2 + 3.0
    box(b["arch"], "GarageVolume", (6.0, 6.0, 3.0), (gx, -0.5, 1.75), wall_mat)
    box(b["arch"], "GarageRoof", (6.4, 6.4, 0.2), (gx, -0.5, 3.3), MATS["brick_b"])
    ribbed_panel(b["doors"], "GarageDoor", 2.6, 2.2, (gx, 2.55, 1.35), slats=6)
    # windows + entry door
    for wx in (-3.6, 3.6):
        window(b["wins"], "WinFront%d" % int(wx), 1.4, 1.3, (wx, D / 2 + 0.1, 1.65))
    window(b["wins"], "WinLeft", 1.2, 1.3, (-W / 2 - 0.1, 0, 1.65), rot_y=math.pi / 2)
    window(b["wins"], "WinRight", 1.2, 1.3, (W / 2 + 0.1, 0, 1.65), rot_y=math.pi / 2)
    door(b["doors"], "EntryDoor", 1.0, 2.2, (0, D / 2 + 0.06, 1.35))
    # interior: living partition + kitchen counter
    box(b["interior"], "Partition", (0.12, D - 1.0, 2.45), (-1.5, 0, 0.25 + 1.225), MATS["plaster_a"])
    box(b["interior"], "KitchenCounter", (2.6, 0.6, 0.9), (3.6, -1.5, 0.25 + 0.45), MATS["wood_dark"])
    ac_unit(b["props"], "AC_Side", (W / 2 + 0.75, 2.5, 0.0), rot=(0, 0, math.pi / 2))
    electrical_box(b["props"], "ElecBox", (W / 2 + 0.15, -3.6, 1.3), rot=(0, 0, math.pi))
    downpipe(b["props"], "Downpipe", (-W / 2 - 0.18, D / 2 - 0.2, 0.25), H + 1.6)
    gutter(b["props"], "GutterFront", W + 0.6, (0, D / 2 + 0.32, H + 0.2))
    trash_bin(b["props"], "TrashBin", (gx + 2.0, 1.8, 0))
    b["majors"] = [((W, D, H + 0.25), (0, 0, (H + 0.25) / 2), wall_mat),
                   ((6.0, 6.0, 3.0), (gx, -0.5, 1.75), wall_mat),
                   ((4.6, 2.6, 0.3), (0, D / 2 + 1.1, 2.8), MATS["brick_b"])]
    collision_box(b["col"], "HouseMain", (W, D, H + 2.2), (0, 0, (H + 2.2) / 2))
    collision_box(b["col"], "Garage", (6.0, 6.0, 3.4), (gx, -0.5, 1.7))

def bld_02_modern_apartment(b):
    W, D, FLOORS, FH = 22.0, 16.0, 4, 3.0
    wall_mat = MATS["concrete_a"]
    dirt_skirt(b["arch"], "DirtSkirt", W, D, (0, 0))
    box(b["arch"], "GroundSlab", (W + 6, D + 6, 0.2), (0, 0, 0.1), MATS["concrete_b"])
    for f in range(FLOORS):
        z0 = f * FH
        box(b["arch"], "FloorSlab%d" % f, (W, D, 0.25), (0, 0, z0 + 0.125), MATS["concrete_b"])
        wall(b["arch"], "WallF%d" % f, W, FH - 0.25, 0.3, (0, D / 2, z0 + 0.25), "x", wall_mat)
        wall(b["arch"], "WallB%d" % f, W, FH - 0.25, 0.3, (0, -D / 2, z0 + 0.25), "x", wall_mat)
        box(b["arch"], "GlassBandF%d" % f, (W - 1.0, 0.08, FH - 1.3), (0, D / 2 + 0.02, z0 + 1.35), MATS["glass_dark"])
        box(b["arch"], "GlassBandB%d" % f, (W - 1.0, 0.08, FH - 1.3), (0, -D / 2 - 0.02, z0 + 1.35), MATS["glass_dark"])
        for bx in (-7.5, -2.5, 2.5, 7.5):
            box(b["arch"], "BalconySlab%d_%d" % (f, int(bx)), (3.0, 1.6, 0.15),
                (bx, D / 2 + 0.9, z0 + 0.3), MATS["concrete_b"])
            box(b["arch"], "BalconyRail%d_%d" % (f, int(bx)), (3.0, 0.06, 1.0),
                (bx, D / 2 + 1.65, z0 + 0.9), MATS["metal_dark"])
    box(b["arch"], "RoofSlab", (W, D, 0.3), (0, 0, FLOORS * FH + 0.15), MATS["concrete_b"])
    box(b["arch"], "RoofBulkhead", (4.0, 3.2, 2.2), (-6, 0, FLOORS * FH + 1.25), wall_mat)
    rooftop_hvac(b["props"], "RoofHVAC", (6.5, -2, FLOORS * FH + 0.3))
    ac_unit(b["props"], "AC_1", (-10.6, D / 2 - 1.2, 0.0))
    ac_unit(b["props"], "AC_2", (10.6, -D / 2 + 1.2, 0.0))
    # parking pad + wheel stops
    box(b["arch"], "ParkingPad", (16.0, 5.0, 0.06), (0, D / 2 + 5.5, 0.03), MATS["asphalt"])
    for wx in (-4.0, 4.0):
        box(b["props"], "WheelStop%d" % int(wx), (1.8, 0.15, 0.12),
            (wx, D / 2 + 4.4, 0.06), MATS["rubber"])
    for wx in (-9.5, 9.5):
        for f2 in range(FLOORS):
            window(b["wins"], "Win%d_%d" % (int(wx), f2), 1.5, 1.4,
                   (wx, D / 2 + 0.05, f2 * FH + 1.7))
    door(b["doors"], "LobbyDoor", 2.2, 2.4, (0, D / 2 + 0.08, 1.45), material=MATS["glass_dark"])
    b["majors"] = [((W, D, FLOORS * FH), (0, 0, FLOORS * FH / 2), wall_mat),
                   ((4.0, 3.2, 2.2), (-6, 0, FLOORS * FH + 1.25), wall_mat),
                   ((16.0, 5.0, 0.1), (0, D / 2 + 5.5, 0.05), MATS["asphalt"])]
    collision_box(b["col"], "ApartmentMain", (W, D, FLOORS * FH + 0.3), (0, 0, (FLOORS * FH) / 2))

def bld_03_small_shop(b):
    W, D, H = 10.0, 8.0, 3.6
    wall_mat = weathered("plaster")
    dirt_skirt(b["arch"], "DirtSkirt", W, D, (0, 0))
    box(b["arch"], "Slab", (W, D, 0.15), (0, 0, 0.075), MATS["concrete_a"])
    wall(b["arch"], "WallFront", W, H, 0.25, (0, D / 2, 0.15), "x", wall_mat,
         openings=[(-2.4, 4.0, 2.6, 0.5), (2.6, 1.1, 2.2, 0.0)])
    wall(b["arch"], "WallBack", W, H, 0.25, (0, -D / 2, 0.15), "x", wall_mat)
    wall(b["arch"], "WallLeft", D, H, 0.25, (-W / 2, 0, 0.15), "y", wall_mat)
    wall(b["arch"], "WallRight", D, H, 0.25, (W / 2, 0, 0.15), "y", wall_mat)
    box(b["arch"], "Parapet", (W + 0.3, D + 0.3, 0.5), (0, 0, H + 0.4), wall_mat)
    box(b["arch"], "RoofSlab", (W, D, 0.2), (0, 0, H + 0.15), MATS["concrete_b"])
    box(b["arch"], "SignBand", (W - 1.0, 0.12, 0.9), (0, D / 2 + 0.14, H - 0.6), MATS["paint_red"])
    box(b["arch"], "ShopfrontGlass", (4.0, 0.06, 2.1), (-2.4, D / 2 + 0.14, 1.6), MATS["glass"])
    ribbed_panel(b["doors"], "RollerShutter", 1.1, 2.2, (2.6, D / 2 + 0.18, 1.25), slats=7, material=MATS["metal_white"])
    box(b["interior"], "Counter", (3.0, 0.7, 1.0), (-1.0, -1.5, 0.65), MATS["wood_dark"])
    for sx in (-3.4, 3.4):
        for lvl in range(3):
            box(b["interior"], "Shelf%d_%d" % (int(sx), lvl), (1.0, 2.4, 0.05),
                (sx, 0, 0.6 + lvl * 0.6), MATS["metal_white"])
    ac_unit(b["props"], "AC_Rear", (2.5, -D / 2 - 0.8, 0.0))
    downpipe(b["props"], "Downpipe", (W / 2 + 0.18, D / 2 - 0.3, 0.15), H + 0.4)
    electrical_box(b["props"], "ElecBox", (-W / 2 - 0.14, 1.5, 1.4), rot=(0, 0, math.pi / 2))
    trash_bin(b["props"], "TrashBin", (-W / 2 - 0.9, -2.5, 0))
    door(b["doors"], "ShopDoor", 1.1, 2.2, (2.6, D / 2 + 0.08, 1.25))
    b["majors"] = [((W, D, H + 0.65), (0, 0, (H + 0.65) / 2), wall_mat),
                   ((W - 1.0, 0.3, 0.9), (0, D / 2, H - 0.6), MATS["paint_red"])]
    collision_box(b["col"], "ShopMain", (W, D, H + 0.6), (0, 0, (H + 0.6) / 2))

def bld_04_motel(b):
    W, D, H = 35.0, 14.0, 6.2
    wall_mat = weathered("plaster")
    dirt_skirt(b["arch"], "DirtSkirt", W, D, (0, 0))
    box(b["arch"], "Slab", (W + 14, D + 10, 0.12), (0, 0, 0.06), MATS["concrete_b"])
    box(b["arch"], "ParkingLot", (W + 12, 8.0, 0.05), (0, D / 2 + 6.0, 0.03), MATS["asphalt"])
    for i in range(8):
        sx = -14.0 + (i % 8) * 4.0
        box(b["props"], "StallStripe%d" % i, (0.12, 4.5, 0.02),
            (sx, D / 2 + 5.8, 0.06), MATS["paint_white"])
    for f in range(2):
        z0 = f * 3.1
        box(b["arch"], "Floor%d" % f, (W, D / 2 - 1.5, 0.25), (0, -D / 4, z0 + 0.125), MATS["concrete_b"])
        wall(b["arch"], "WallF%d" % f, W, 2.85, 0.25, (0, 0.5, z0 + 0.25), "x", wall_mat,
             openings=[(-14 + i * 4.0, 1.0, 2.35, 0.0) for i in range(8)])
        # external corridor
        box(b["arch"], "Walkway%d" % f, (W, 2.0, 0.18), (0, 1.6, z0 + 0.22), MATS["corridor"])
        box(b["arch"], "WalkRail%d" % f, (W, 0.06, 1.0), (0, 2.55, z0 + 0.85), MATS["metal_dark"])
        for i in range(8):
            door(b["doors"], "UnitDoor%d_%d" % (f, i), 0.95, 2.1,
                 (-14 + i * 4.0, 0.62, z0 + 1.3), material=MATS["wood_dark"])
            window(b["wins"], "UnitWin%d_%d" % (f, i), 1.2, 1.1,
                   (-14 + i * 4.0 + 1.5, 0.62, z0 + 1.7))
    box(b["arch"], "RoofSlab", (W, D / 2 + 0.5, 0.25), (0, -D / 4 + 0.5, H), MATS["concrete_b"])
    # exterior stair
    for s in range(9):
        box(b["arch"], "StairStep%d" % s, (1.4, 0.3, 0.18),
            (W / 2 - 1.0, 2.6 - 0.0, 0.15 + s * 0.33), MATS["concrete_b"])
    # sign pylon
    box(b["props"], "SignPole", (0.35, 0.35, 5.0), (-W / 2 - 3.0, D / 2 + 4.0, 2.5), MATS["metal_dark"])
    box(b["props"], "SignCabinet", (2.6, 0.5, 1.6), (-W / 2 - 3.0, D / 2 + 4.0, 5.6), MATS["paint_red"])
    ac_unit(b["props"], "AC_Rear", (5.0, -D / 2 - 0.7, 0.0))
    downpipe(b["props"], "Downpipe", (-W / 2 + 0.2, -D / 4 + 0.2, 0.15), H)
    b["majors"] = [((W, D / 2 + 1.0, H), (0, -D / 4 + 0.5, H / 2), wall_mat),
                   ((2.6, 0.6, 1.6), (-W / 2 - 3.0, D / 2 + 4.0, 5.6), MATS["paint_red"]),
                   ((W + 12, 8.0, 0.1), (0, D / 2 + 6.0, 0.05), MATS["asphalt"])]
    collision_box(b["col"], "MotelMain", (W, D / 2 + 1.0, H + 0.2), (0, -D / 4 + 0.5, (H + 0.2) / 2))

def bld_05_industrial_warehouse(b):
    W, D, H = 40.0, 25.0, 9.0
    wall_mat = MATS["metal_roof"]
    dirt_skirt(b["arch"], "DirtSkirt", W, D, (0, 0))
    box(b["arch"], "Slab", (W + 8, D + 8, 0.15), (0, 0, 0.075), MATS["concrete_b"])
    wall(b["arch"], "WallFront", W, H, 0.3, (0, D / 2, 0.15), "x", wall_mat,
         openings=[(-10.0, 5.0, 5.0, 0.0), (10.0, 5.0, 5.0, 0.0), (0.0, 1.2, 2.4, 0.0)])
    wall(b["arch"], "WallBack", W, H, 0.3, (0, -D / 2, 0.15), "x", wall_mat)
    wall(b["arch"], "WallLeft", D, H, 0.3, (-W / 2, 0, 0.15), "y", wall_mat)
    wall(b["arch"], "WallRight", D, H, 0.3, (W / 2, 0, 0.15), "y", wall_mat)
    box(b["arch"], "MetalRoof", (W + 0.6, D + 0.6, 0.25), (0, 0, H + 0.27), MATS["metal_roof"])
    for i in range(14):
        box(b["arch"], "RoofRib%d" % i, (0.12, D + 0.6, 0.1),
            (-W / 2 + 1.4 * i, 0, H + 0.45), MATS["metal_dark"])
    # loading dock
    box(b["arch"], "DockPad", (12.0, 4.0, 1.1), (-10.0, D / 2 + 2.2, 0.55), MATS["concrete_a"])
    for bx in (-14.4, -10.0, -5.6):
        box(b["props"], "DockBumper%d" % int(bx), (0.4, 0.3, 0.5),
            (bx, D / 2 + 3.9, 0.85), MATS["rubber"])
    ribbed_panel(b["doors"], "DockDoor", 3.0, 3.0, (-10.0, D / 2 + 0.2, 2.6), slats=6)
    ribbed_panel(b["doors"], "MainDoorL", 5.0, 5.0, (-10.0, D / 2 + 0.2, 2.65), slats=9)
    ribbed_panel(b["doors"], "MainDoorR", 5.0, 5.0, (10.0, D / 2 + 0.2, 2.65), slats=9)
    for vx in (-12.0, -4.0, 4.0, 12.0):
        box(b["props"], "RoofVent%d" % int(vx), (1.2, 1.2, 0.9),
            (vx, -3.0, H + 0.85), MATS["metal_dark"])
        box(b["props"], "VentCowl%d" % int(vx), (1.5, 1.5, 0.15),
            (vx, -3.0, H + 1.35), MATS["metal_white"])
    gutter(b["props"], "GutterFront", W, (0, D / 2 + 0.35, H + 0.15))
    for px in (-W / 2 + 0.3, W / 2 - 0.3):
        downpipe(b["props"], "Downpipe%d" % int(px), (px, D / 2 + 0.3, 0.15), H)
    electrical_box(b["props"], "ElecBox", (W / 2 + 0.2, -5.0, 1.5), rot=(0, 0, -math.pi / 2))
    door(b["doors"], "PersonnelDoor", 1.2, 2.4, (0, D / 2 + 0.1, 1.35))
    b["majors"] = [((W, D, H + 0.5), (0, 0, (H + 0.5) / 2), wall_mat),
                   ((12.0, 4.0, 1.1), (-10.0, D / 2 + 2.2, 0.55), MATS["concrete_a"])]
    collision_box(b["col"], "WarehouseMain", (W, D, H + 0.5), (0, 0, (H + 0.5) / 2))
    collision_box(b["col"], "Dock", (12.0, 4.0, 1.1), (-10.0, D / 2 + 2.2, 0.55))

def bld_06_office_building(b):
    W, D, FLOORS, FH = 30.0, 20.0, 3, 3.4
    wall_mat = MATS["concrete_a"]
    dirt_skirt(b["arch"], "DirtSkirt", W, D, (0, 0))
    box(b["arch"], "Plaza", (W + 8, D + 6, 0.12), (0, 0, 0.06), MATS["concrete_b"])
    for f in range(FLOORS):
        z0 = f * FH
        box(b["arch"], "Slab%d" % f, (W, D, 0.3), (0, 0, z0 + 0.15), MATS["concrete_b"])
        wall(b["arch"], "WallF%d" % f, W, FH - 0.3, 0.3, (0, D / 2, z0 + 0.3), "x", wall_mat)
        wall(b["arch"], "WallB%d" % f, W, FH - 0.3, 0.3, (0, -D / 2, z0 + 0.3), "x", wall_mat)
        box(b["arch"], "CurtainF%d" % f, (W - 2.0, 0.08, FH - 1.5), (0, D / 2 + 0.03, z0 + 1.6), MATS["glass_dark"])
        box(b["arch"], "CurtainB%d" % f, (W - 2.0, 0.08, FH - 1.5), (0, -D / 2 - 0.03, z0 + 1.6), MATS["glass"])
    box(b["arch"], "RoofSlab", (W, D, 0.3), (0, 0, FLOORS * FH + 0.15), MATS["concrete_b"])
    # double-height glass lobby entrance + canopy
    box(b["arch"], "LobbyGlass", (6.0, 0.08, 2 * FH - 1.0), (0, D / 2 + 0.05, 0.3 + FH - 0.2), MATS["glass"])
    box(b["arch"], "EntranceCanopy", (8.0, 3.0, 0.25), (0, D / 2 + 1.8, 3.4), MATS["metal_dark"])
    for px in (-3.4, 3.4):
        box(b["arch"], "CanopyRod%d" % int(px), (0.08, 0.08, 1.4),
            (px, D / 2 + 3.0, 4.1), MATS["metal_dark"])
    door(b["doors"], "RevolvingPairL", 1.1, 2.4, (-0.6, D / 2 + 0.1, 1.5), material=MATS["glass_dark"])
    door(b["doors"], "RevolvingPairR", 1.1, 2.4, (0.6, D / 2 + 0.1, 1.5), material=MATS["glass_dark"])
    box(b["interior"], "ReceptionDesk", (4.5, 1.0, 1.05), (0, D / 2 - 3.0, 0.15 + 0.52), MATS["wood_dark"])
    rooftop_hvac(b["props"], "Chiller1", (-8.0, -3.0, FLOORS * FH + 0.3))
    rooftop_hvac(b["props"], "Chiller2", (8.0, -3.0, FLOORS * FH + 0.3))
    antenna_mast(b["props"], "Antenna", (0.0, -6.0, FLOORS * FH + 0.3), 5.0)
    downpipe(b["props"], "Downpipe", (-W / 2 - 0.2, D / 2 - 1.0, 0.15), FLOORS * FH)
    b["majors"] = [((W, D, FLOORS * FH + 0.3), (0, 0, (FLOORS * FH + 0.3) / 2), wall_mat),
                   ((8.0, 3.0, 0.3), (0, D / 2 + 1.8, 3.4), MATS["metal_dark"])]
    collision_box(b["col"], "OfficeMain", (W, D, FLOORS * FH + 0.3), (0, 0, (FLOORS * FH + 0.3) / 2))

def bld_07_gas_station(b):
    W, D = 25.0, 18.0
    dirt_skirt(b["arch"], "DirtSkirt", 10, 8, (0, 8))
    box(b["arch"], "Apron", (W, D, 0.08), (0, 0, 0.04), MATS["asphalt"])
    box(b["arch"], "KioskSlab", (9.0, 7.0, 0.15), (0, 7.5, 0.075), MATS["concrete_a"])
    wall_mat = MATS["plaster_a"]
    wall(b["arch"], "KioskFront", 9.0, 3.2, 0.25, (0, 11.0, 0.15), "x", wall_mat,
         openings=[(-1.8, 3.2, 2.4, 0.6), (2.0, 1.1, 2.2, 0.0)])
    wall(b["arch"], "KioskBack", 9.0, 3.2, 0.25, (0, 4.0, 0.15), "x", wall_mat)
    wall(b["arch"], "KioskLeft", 7.0, 3.2, 0.25, (-4.5, 7.5, 0.15), "y", wall_mat)
    wall(b["arch"], "KioskRight", 7.0, 3.2, 0.25, (4.5, 7.5, 0.15), "y", wall_mat)
    box(b["arch"], "KioskRoof", (9.6, 7.6, 0.25), (0, 7.5, 3.5), MATS["concrete_b"])
    box(b["arch"], "KioskSign", (5.0, 0.12, 0.9), (0, 11.15, 2.9), MATS["paint_red"])
    # canopy on 4 columns
    for px in (-6.0, 6.0):
        for py in (-3.5, 1.5):
            box(b["arch"], "CanopyCol%d_%d" % (int(px), int(py)), (0.7, 0.7, 4.6),
                (px, py, 0.08 + 2.3), MATS["paint_white"])
    box(b["arch"], "CanopySlab", (16.0, 10.0, 0.6), (0, -1.0, 5.0), MATS["paint_red"])
    box(b["arch"], "CanopyFascia", (16.4, 0.25, 0.9), (0, 4.0, 4.6), MATS["paint_white"])
    # pump islands
    for px in (-3.0, 3.0):
        box(b["arch"], "Island%d" % int(px), (2.4, 1.6, 0.25), (px, -1.0, 0.2), MATS["concrete_a"])
        box(b["props"], "Pump%d" % int(px), (0.9, 0.6, 1.5), (px, -1.0, 1.05), MATS["paint_white"])
        box(b["props"], "PumpScreen%d" % int(px), (0.5, 0.08, 0.4), (px, -1.32, 1.35), MATS["glass_dark"])
    # price sign + tank covers
    box(b["props"], "PricePole", (0.3, 0.3, 4.0), (-W / 2 - 1.5, -D / 2 + 2.0, 2.0), MATS["metal_dark"])
    box(b["props"], "PriceBox", (2.2, 0.35, 2.6), (-W / 2 - 1.5, -D / 2 + 2.0, 5.2), MATS["paint_white"])
    for tx in (-2.0, 2.0):
        cyl(b["props"], "TankCover%d" % int(tx), 0.55, 0.12, (tx, -5.5, 0.06), MATS["metal_dark"], verts=14)
    door(b["doors"], "KioskDoor", 1.1, 2.2, (2.0, 11.08, 1.25))
    window(b["wins"], "KioskWindow", 3.2, 1.8, (-1.8, 11.1, 1.9))
    box(b["interior"], "KioskCounter", (3.4, 0.7, 1.0), (0.0, 9.5, 0.65), MATS["wood_dark"])
    b["majors"] = [((9.0, 7.0, 3.7), (0, 7.5, 1.85), wall_mat),
                   ((16.0, 10.0, 0.7), (0, -1.0, 5.0), MATS["paint_red"]),
                   ((W, D, 0.1), (0, 0, 0.05), MATS["asphalt"]),
                   ((2.2, 0.4, 2.6), (-W / 2 - 1.5, -D / 2 + 2.0, 5.2), MATS["paint_white"])]
    collision_box(b["col"], "Kiosk", (9.0, 7.0, 3.7), (0, 7.5, 1.85))
    for px in (-3.0, 3.0):
        collision_box(b["col"], "Island%d" % int(px), (2.4, 1.6, 1.6), (px, -1.0, 0.8))

def bld_08_small_clinic(b):
    W, D, H = 20.0, 15.0, 3.4
    wall_mat = MATS["plaster_a"]
    dirt_skirt(b["arch"], "DirtSkirt", W, D, (0, 0))
    box(b["arch"], "Slab", (W + 6, D + 5, 0.15), (0, 0, 0.075), MATS["concrete_a"])
    wall(b["arch"], "WallFront", W, H, 0.25, (0, D / 2, 0.15), "x", wall_mat,
         openings=[(-2.5, 2.0, 2.5, 0.0), (4.0, 1.6, 2.3, 0.9)])
    wall(b["arch"], "WallBack", W, H, 0.25, (0, -D / 2, 0.15), "x", wall_mat)
    wall(b["arch"], "WallLeft", D, H, 0.25, (-W / 2, 0, 0.15), "y", wall_mat)
    wall(b["arch"], "WallRight", D, H, 0.25, (W / 2, 0, 0.15), "y", wall_mat)
    box(b["arch"], "RoofSlab", (W, D, 0.3), (0, 0, H + 0.3), MATS["concrete_b"])
    box(b["arch"], "SignBand", (6.0, 0.12, 0.8), (0, D / 2 + 0.14, H - 0.4), MATS["paint_white"])
    box(b["arch"], "SignCrossV", (0.5, 0.08, 1.6), (3.2, D / 2 + 0.2, H - 0.4), MATS["paint_red"])
    box(b["arch"], "SignCrossH", (1.6, 0.08, 0.5), (3.2, D / 2 + 0.2, H - 0.4), MATS["paint_red"])
    # entrance ramp with rails
    box(b["arch"], "Ramp", (2.4, 4.0, 0.15), (-2.5, D / 2 + 2.2, 0.32), MATS["concrete_a"], rot=(0.22, 0, 0))
    for rx in (-3.7, -1.3):
        box(b["arch"], "RampRail%d" % int(rx), (0.07, 4.2, 0.9),
            (rx, D / 2 + 2.2, 0.85), MATS["metal_dark"])
    # emergency access pad + small canopy
    box(b["arch"], "EmergencyPad", (6.0, 5.0, 0.06), (W / 2 + 3.5, 0, 0.03), MATS["asphalt"])
    box(b["arch"], "EmergencyCanopy", (5.0, 3.0, 0.2), (W / 2 + 1.8, 0, 3.2), MATS["paint_white"])
    box(b["props"], "CanopyColA", (0.25, 0.25, 3.1), (W / 2 + 3.8, -1.2, 1.6), MATS["metal_dark"])
    box(b["props"], "CanopyColB", (0.25, 0.25, 3.1), (W / 2 + 3.8, 1.2, 1.6), MATS["metal_dark"])
    box(b["interior"], "ReceptionDesk", (4.0, 0.9, 1.05), (0, D / 2 - 2.5, 0.15 + 0.52), MATS["wood_dark"])
    for wx in (-8.0, 8.0):
        window(b["wins"], "WinSide%d" % int(wx), 1.6, 1.4,
               (wx, D / 2 + 0.05, 1.8))
    ac_unit(b["props"], "AC_Rear", (-4.0, -D / 2 - 0.8, 0.0))
    rooftop_hvac(b["props"], "RoofHVAC", (4.0, -2.0, H + 0.45))
    door(b["doors"], "MainDoor", 2.0, 2.5, (-2.5, D / 2 + 0.08, 1.4), material=MATS["glass_dark"])
    downpipe(b["props"], "Downpipe", (W / 2 + 0.18, -4.0, 0.15), H)
    b["majors"] = [((W, D, H + 0.45), (0, 0, (H + 0.45) / 2), wall_mat),
                   ((6.0, 5.0, 0.1), (W / 2 + 3.5, 0, 0.05), MATS["asphalt"]),
                   ((5.0, 3.0, 0.25), (W / 2 + 1.8, 0, 3.2), MATS["paint_white"])]
    collision_box(b["col"], "ClinicMain", (W, D, H + 0.45), (0, 0, (H + 0.45) / 2))

def bld_09_police_station(b):
    W, D, H = 28.0, 20.0, 7.0
    wall_mat = MATS["concrete_a"]
    dirt_skirt(b["arch"], "DirtSkirt", W, D, (0, 0))
    box(b["arch"], "Slab", (W + 4, D + 4, 0.15), (0, 0, 0.075), MATS["concrete_a"])
    wall(b["arch"], "WallFront", W, H, 0.3, (0, D / 2, 0.15), "x", wall_mat,
         openings=[(-9.0, 1.4, 2.6, 0.0), (0.0, 2.4, 2.6, 0.0), (9.5, 1.6, 2.3, 0.9)])
    wall(b["arch"], "WallBack", W, H, 0.3, (0, -D / 2, 0.15), "x", wall_mat)
    wall(b["arch"], "WallLeft", D, H, 0.3, (-W / 2, 0, 0.15), "y", wall_mat)
    wall(b["arch"], "WallRight", D, H, 0.3, (W / 2, 0, 0.15), "y", wall_mat)
    box(b["arch"], "RoofSlab", (W, D, 0.3), (0, 0, H + 0.3), MATS["concrete_b"])
    box(b["arch"], "RoofBulkhead", (5.0, 4.0, 2.2), (-8.0, -4.0, H + 1.4), wall_mat)
    # 3-bay garage on the left flank
    box(b["arch"], "GarageVolume", (12.0, 6.0, 4.6), (-W / 2 - 5.5, -3.0, 2.45), wall_mat)
    box(b["arch"], "GarageRoof", (12.4, 6.4, 0.25), (-W / 2 - 5.5, -3.0, 4.85), MATS["concrete_b"])
    for gy in (-5.6, -3.0, -0.4):
        ribbed_panel(b["doors"], "BayDoor%d" % int(gy * 10), 2.6, 3.4,
                     (-W / 2 - 11.6, gy, 2.0), rot=(0, 0, math.pi / 2), slats=7,
                     material=MATS["metal_white"])
    # entrance steps + canopy + blue band
    box(b["arch"], "Steps", (3.6, 1.2, 0.35), (0, D / 2 + 0.9, 0.17), MATS["concrete_b"])
    box(b["arch"], "EntranceCanopy", (4.5, 2.2, 0.22), (0, D / 2 + 1.4, 3.3), MATS["metal_dark"])
    box(b["arch"], "BlueBand", (W - 1.0, 0.1, 0.7), (0, D / 2 + 0.17, H - 1.2), MATS["paint_blue"])
    box(b["props"], "SignPanel", (3.2, 0.12, 0.8), (0, D / 2 + 0.25, H - 0.35), MATS["sign_green"])
    antenna_mast(b["props"], "CommsMast", (8.0, -6.0, H + 0.3), 5.5)
    rooftop_hvac(b["props"], "RoofHVAC", (4.0, -2.0, H + 0.45))
    door(b["doors"], "FrontDoor", 2.4, 2.6, (0, D / 2 + 0.08, 1.45), material=MATS["glass_dark"])
    window(b["wins"], "WindowR", 1.6, 1.4, (9.5, D / 2 + 0.05, 2.0))
    for wx in (-4.0, 4.0, 12.0):
        window(b["wins"], "WinUpper%d" % int(wx), 1.6, 1.4, (wx, D / 2 + 0.05, 5.4))
    downpipe(b["props"], "Downpipe", (-W / 2 - 0.18, 4.0, 0.15), H)
    b["majors"] = [((W, D, H + 0.45), (0, 0, (H + 0.45) / 2), wall_mat),
                   ((12.0, 6.0, 4.9), (-W / 2 - 5.5, -3.0, 2.45), wall_mat)]
    collision_box(b["col"], "StationMain", (W, D, H + 0.45), (0, 0, (H + 0.45) / 2))
    collision_box(b["col"], "GarageBays", (12.0, 6.0, 4.9), (-W / 2 - 5.5, -3.0, 2.45))

def bld_10_abandoned_building(b):
    W, D, H = 18.0, 12.0, 6.4
    wall_mat = MATS["brick_b"]
    dirt_skirt(b["arch"], "DirtSkirt", W, D, (0, 0))
    box(b["arch"], "Slab", (W, D, 0.12), (0, 0, 0.06), MATS["concrete_b"])
    wall(b["arch"], "WallFront", W, H, 0.3, (0, D / 2, 0.12), "x", wall_mat,
         openings=[(-6.0, 1.4, 2.2, 0.9), (-2.0, 1.2, 2.4, 0.0), (3.0, 1.4, 2.2, 0.9),
                   (-6.0, 1.4, 5.6, 4.0), (3.0, 1.4, 5.6, 4.0)])
    wall(b["arch"], "WallBack", W, H, 0.3, (0, -D / 2, 0.12), "x", wall_mat)
    wall(b["arch"], "WallLeft", D, H, 0.3, (-W / 2, 0, 0.12), "y", wall_mat,
         openings=[(0.0, 1.4, 5.2, 3.8)])
    wall(b["arch"], "WallRight", D, H, 0.3, (W / 2, 0, 0.12), "y", wall_mat)
    # damaged roofline: stepped collapsed edge
    box(b["arch"], "RoofMain", (W, D * 0.7, 0.2), (0, -D * 0.15, H + 0.2), MATS["concrete_b"])
    box(b["arch"], "RoofBrokenEdge", (W * 0.6, D * 0.35, 0.2), (2.0, D * 0.32, H - 0.7), MATS["concrete_b"])
    box(b["arch"], "RoofGap", (W * 0.4, D * 0.4, 0.1), (-3.5, D * 0.33, H - 1.6), MATS["wood_dark"])
    # boarded windows (planks over openings)
    for bx, bz, nb in [(-6.0, 1.55, 3), (-6.0, 4.8, 3), (3.0, 1.55, 2), (3.0, 4.8, 2)]:
        for i in range(nb):
            box(b["props"], "Board%d_%d" % (int(bx), i), (1.7, 0.05, 0.28),
                (bx, D / 2 + 0.2, bz - 0.4 + i * 0.42), MATS["wood_dark"],
                rot=(0, 0.12 * (1 if i % 2 == 0 else -1), 0))
    # broken glass remnants
    for gx, gz in [(-2.0, 1.2)]:
        box(b["wins"], "BrokenPane%d" % int(gx), (0.9, 0.03, 0.5), (gx, D / 2 + 0.16, gz + 0.5), MATS["glass"])
    # debris + vegetation
    for i in range(8):
        box(b["props"], "Rubble%d" % i,
            (R.uniform(0.3, 0.9), R.uniform(0.3, 0.8), R.uniform(0.2, 0.5)),
            (R.uniform(-W / 2, W / 2), D / 2 + R.uniform(0.5, 2.5), 0.2), MATS["rubble"])
    for i in range(6):
        bush(b["props"], "Overgrowth%d" % i,
             (R.uniform(-W / 2, W / 2), -D / 2 - R.uniform(0.3, 1.5), 0.35),
             R.uniform(0.35, 0.65))
    downpipe(b["props"], "BrokenDownpipe", (-W / 2 - 0.2, D / 2 - 0.5, 0.12), 3.2, rot=(0, 0.15, 0))
    door(b["doors"], "BustedDoor", 1.2, 2.4, (-2.0, D / 2 + 0.08, 1.2), material=MATS["wood_dark"])
    b["majors"] = [((W, D, H), (0, 0, H / 2), wall_mat),
                   ((W, D * 0.7, 0.2), (0, -D * 0.15, H + 0.2), MATS["concrete_b"])]
    collision_box(b["col"], "AbandonedMain", (W, D, H + 0.3), (0, 0, (H + 0.3) / 2))

BUILDINGS = [
    (1, "SUBURBAN_HOUSE", bld_01_suburban_house),
    (2, "MODERN_APARTMENT", bld_02_modern_apartment),
    (3, "SMALL_SHOP", bld_03_small_shop),
    (4, "MOTEL", bld_04_motel),
    (5, "INDUSTRIAL_WAREHOUSE", bld_05_industrial_warehouse),
    (6, "OFFICE_BUILDING", bld_06_office_building),
    (7, "GAS_STATION", bld_07_gas_station),
    (8, "SMALL_CLINIC", bld_08_small_clinic),
    (9, "POLICE_STATION", bld_09_police_station),
    (10, "ABANDONED_BUILDING", bld_10_abandoned_building),
]

# ---------------------------------------------------------------- main
def clear_scene():
    for ob in list(bpy.data.objects):
        bpy.data.objects.remove(ob, do_unlink=True)
    for c in list(bpy.data.collections):
        bpy.data.collections.remove(c)

def count_mesh_tris():
    tris = 0
    dg = bpy.context.evaluated_depsgraph_get()
    for ob in bpy.context.scene.objects:
        if ob.type != "MESH":
            continue
        me = ob.evaluated_get(dg).to_mesh()
        tris += len(me.loop_triangles) if me.loop_triangles else len(me.polygons)
        ob.evaluated_get(dg).to_mesh_clear()
    return tris

def export(path):
    bpy.ops.export_scene.gltf(filepath=path, export_format="GLB",
                              export_apply=True, export_yup=True)

def main():
    global OUT, R
    argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=".")
    args, _ = ap.parse_known_args(argv)
    OUT = args.out
    build_materials()
    objs_made = 0
    for (idx, name, fn) in BUILDINGS:
        clear_scene()
        R = random.Random(SEED + idx)
        b = new_building(idx, name)
        fn(b)
        finish_building(b, idx, name, b["majors"])
        n_objs = len(bpy.context.scene.objects)
        path = "%s/building_%02d.glb" % (OUT, idx)
        export(path)
        print("BUILDING_OK %02d %s objects=%d tris=%d -> %s" %
              (idx, name, n_objs, count_mesh_tris(), path))
        objs_made += n_objs
    # combined set + blend
    clear_scene()
    for (idx, name, fn) in BUILDINGS:
        R = random.Random(SEED + idx)
        b = new_building(idx, name)
        fn(b)
        finish_building(b, idx, name, b["majors"])
    export("%s/building_set.glb" % OUT)
    bpy.ops.wm.save_as_mainfile(filepath="%s/building_set.blend" % OUT)
    print("SET_OK objects=%d tris=%d" % (len(bpy.context.scene.objects), count_mesh_tris()))

main()
