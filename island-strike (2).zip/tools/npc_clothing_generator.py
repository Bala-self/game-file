"""
GAME HUMAN NPC GENERATOR — CLOTHING VARIANTS EDITION
=====================================================
Blender 4.x Python script — Island Strike NPC Clothing System

Enhances original game_human_npc_generator.py to support varied clothing for OTHER NPCs.

Original: Male + Female base
Enhanced: + 8 clothing archetypes for Island Strike districts:

    - CIVILIAN (default) — jeans + tee + sneakers
    - CIVILIAN_FEMALE — denim + top + sneakers
    - POLICE — police blue uniform + cap + black shoes
    - GANG — streetwear, hoodie/jacket + cap/beanie
    - COMMUTER — business casual shirt + jacket + watch
    - SERVICE — orange/brown workwear + hard hat
    - MILITARY — camo green + helmet + boots
    - BEACH — colorful tank + shorts + sandals + hat
    - PLAYER — white tee + charcoal trousers + white sneakers + watch

DESIGN GOALS
------------
- Realistic human proportions (male 1.78m, female 1.66m)
- Separate named body/clothing components for later replacement
- Armature with simple humanoid skeleton (root/spine/neck/head + limbs)
- Material slots: skin, hair, eyes, shoes, denim, shirt, jacket, hat, etc.
- Three detail presets: LOW / MEDIUM / HIGH
- Deterministic dimensions — same character regenerates consistently
- Clothing archetypes map directly to CharacterRig.gd outfit dicts in Godot:
  CharacterRig.npc_outfit, police_outfit, gang_outfit, commuter_outfit,
  service_outfit, military_outfit, beach_outfit, female_outfit, player_outfit

USAGE
-----
1. Open Blender 4.x
2. Scripting workspace
3. Open this file
4. Edit SETTINGS below if needed
5. Run

Output:
    GAME_CHARACTERS
        PLAYER
        CIVILIAN_MALE
        CIVILIAN_FEMALE
        POLICE
        GANG
        COMMUTER
        SERVICE
        MILITARY
        BEACH
        MALE_NPC (legacy)
        FEMALE_NPC (legacy)

For production: replace procedural meshes with sculpted/retopo/PBR 2K/4K,
keep naming/material/rig structure, export FBX/GLB.
"""

import bpy
import math
from mathutils import Vector

# ============================================================
# SETTINGS
# ============================================================

SETTINGS = {
    "detail": "MEDIUM",  # LOW / MEDIUM / HIGH
    "create_player": True,
    "create_civilian_male": True,
    "create_civilian_female": True,
    "create_police": True,
    "create_gang": True,
    "create_commuter": True,
    "create_service": True,
    "create_military": True,
    "create_beach": True,
    "create_male_legacy": False,
    "create_female_legacy": False,
    "create_rig": True,
    "create_clothes": True,
    "create_ground": True,
    "male_height": 1.78,
    "female_height": 1.66,
    "character_spacing": 2.8,
}

SEGMENTS = {
    "LOW": (12, 8),
    "MEDIUM": (20, 12),
    "HIGH": (32, 18),
}

# Clothing archetypes — maps to Godot CharacterRig outfit types
CLOTHING_ARCHETYPES = {
    "PLAYER": {
        "shirt_color": (0.93, 0.93, 0.95),
        "pants_color": (0.16, 0.17, 0.19),
        "shoes_color": (0.88, 0.88, 0.90),
        "jacket": False,
        "jacket_color": (0.2, 0.2, 0.22),
        "hat": False,
        "hat_color": (0.2, 0.2, 0.22),
        "gender": "male",
        "desc": "Player — white tee + charcoal trousers + white sneakers + watch",
    },
    "CIVILIAN_MALE": {
        "shirt_color": (0.70, 0.70, 0.70),
        "pants_color": (0.055, 0.09, 0.16),  # denim
        "shoes_color": (0.35, 0.33, 0.30),
        "jacket": False,
        "jacket_color": (0.15, 0.15, 0.18),
        "hat": False,
        "hat_color": (0.25, 0.25, 0.28),
        "gender": "male",
        "desc": "Civilian male — varied tee + denim + sneakers, 25% jacket 12% hat",
    },
    "CIVILIAN_FEMALE": {
        "shirt_color": (0.75, 0.60, 0.65),
        "pants_color": (0.055, 0.09, 0.16),
        "shoes_color": (0.88, 0.88, 0.90),
        "jacket": False,
        "jacket_color": (0.35, 0.30, 0.32),
        "hat": False,
        "hat_color": (0.25, 0.25, 0.28),
        "gender": "female",
        "desc": "Civilian female — top + denim + sneakers, longer hair",
    },
    "POLICE": {
        "shirt_color": (0.15, 0.20, 0.50),  # police blue
        "pants_color": (0.12, 0.15, 0.35),
        "shoes_color": (0.08, 0.08, 0.09),
        "jacket": False,
        "jacket_color": (0.12, 0.15, 0.35),
        "hat": True,
        "hat_color": (0.12, 0.15, 0.35),
        "gender": "male",
        "desc": "Police — blue uniform + cap + black shoes",
    },
    "GANG": {
        "shirt_color": (0.85, 0.15, 0.15),  # red or black/yellow
        "pants_color": (0.10, 0.10, 0.12),
        "shoes_color": (0.12, 0.12, 0.12),
        "jacket": True,
        "jacket_color": (0.15, 0.15, 0.18),
        "hat": True,
        "hat_color": (0.10, 0.10, 0.11),
        "gender": "male",
        "desc": "Gang — streetwear hoodie/jacket + cap/beanie, red/black",
    },
    "COMMUTER": {
        "shirt_color": (0.92, 0.92, 0.95),
        "pants_color": (0.20, 0.20, 0.22),
        "shoes_color": (0.15, 0.12, 0.10),
        "jacket": True,
        "jacket_color": (0.25, 0.28, 0.32),
        "hat": False,
        "hat_color": (0.25, 0.25, 0.28),
        "gender": "male",
        "desc": "Commuter — business casual shirt + jacket + watch",
    },
    "SERVICE": {
        "shirt_color": (0.85, 0.65, 0.25),  # workwear orange
        "pants_color": (0.30, 0.28, 0.25),
        "shoes_color": (0.35, 0.30, 0.25),
        "jacket": False,
        "jacket_color": (0.30, 0.28, 0.25),
        "hat": True,
        "hat_color": (0.85, 0.65, 0.25),
        "gender": "male",
        "desc": "Service — orange/brown workwear + hard hat",
    },
    "MILITARY": {
        "shirt_color": (0.35, 0.40, 0.30),  # camo green
        "pants_color": (0.30, 0.35, 0.25),
        "shoes_color": (0.15, 0.14, 0.12),
        "jacket": False,
        "jacket_color": (0.30, 0.35, 0.25),
        "hat": True,
        "hat_color": (0.30, 0.35, 0.25),
        "gender": "male",
        "desc": "Military — camo green + helmet + boots",
    },
    "BEACH": {
        "shirt_color": (0.90, 0.30, 0.25),  # colorful tank
        "pants_color": (0.85, 0.80, 0.60),  # shorts
        "shoes_color": (0.50, 0.40, 0.30),  # sandals
        "jacket": False,
        "jacket_color": (0.85, 0.80, 0.60),
        "hat": True,
        "hat_color": (0.90, 0.80, 0.40),
        "gender": "male",
        "desc": "Beach — colorful tank + shorts + sandals + hat",
    },
}

# ============================================================
# CLEANUP / COLLECTION HELPERS
# ============================================================

def remove_collection(name):
    col = bpy.data.collections.get(name)
    if not col:
        return
    for obj in list(col.objects):
        bpy.data.objects.remove(obj, do_unlink=True)
    bpy.data.collections.remove(col)

def make_collection(name, parent=None):
    existing = bpy.data.collections.get(name)
    if existing:
        return existing
    col = bpy.data.collections.new(name)
    if parent:
        parent.children.link(col)
    else:
        bpy.context.scene.collection.children.link(col)
    return col

ROOT = "GAME_CHARACTERS"
remove_collection(ROOT)
ROOT_COL = make_collection(ROOT)

# ============================================================
# MATERIALS
# ============================================================

def make_material(name, base_color, roughness=0.5, metallic=0.0):
    mat = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    if bsdf:
        bsdf.inputs["Base Color"].default_value = (*base_color, 1.0)
        bsdf.inputs["Roughness"].default_value = roughness
        bsdf.inputs["Metallic"].default_value = metallic
    return mat

MAT = {
    "SKIN": make_material("MAT_Skin", (0.58, 0.32, 0.20), 0.56),
    "SKIN_DARK": make_material("MAT_Skin_Dark", (0.36, 0.17, 0.09), 0.58),
    "SKIN_TAN": make_material("MAT_Skin_Tan", (0.78, 0.60, 0.48), 0.56),
    "HAIR": make_material("MAT_Hair", (0.025, 0.018, 0.012), 0.38),
    "HAIR_LIGHT": make_material("MAT_Hair_Light", (0.18, 0.12, 0.08), 0.45),
    "EYE": make_material("MAT_Eye", (0.035, 0.055, 0.040), 0.18),
    "WHITE": make_material("MAT_Shirt", (0.68, 0.68, 0.66), 0.62),
    "DENIM": make_material("MAT_Denim", (0.055, 0.09, 0.16), 0.72),
    "DARK": make_material("MAT_DarkCloth", (0.035, 0.04, 0.045), 0.78),
    "POLICE": make_material("MAT_Police", (0.15, 0.20, 0.50), 0.65),
    "POLICE_PANTS": make_material("MAT_Police_Pants", (0.12, 0.15, 0.35), 0.70),
    "GANG_RED": make_material("MAT_Gang_Red", (0.85, 0.15, 0.15), 0.72),
    "SERVICE": make_material("MAT_Service", (0.85, 0.65, 0.25), 0.70),
    "MILITARY": make_material("MAT_Military", (0.35, 0.40, 0.30), 0.75),
    "BEACH_TANK": make_material("MAT_Beach_Tank", (0.90, 0.30, 0.25), 0.65),
    "SHORTS": make_material("MAT_Shorts", (0.85, 0.80, 0.60), 0.80),
    "JACKET": make_material("MAT_Jacket", (0.15, 0.15, 0.18), 0.75),
    "HAT": make_material("MAT_Hat", (0.12, 0.15, 0.35), 0.65),
    "SHOE": make_material("MAT_Shoe", (0.035, 0.035, 0.03), 0.5),
    "SHOE_WHITE": make_material("MAT_Shoe_White", (0.88, 0.88, 0.90), 0.55),
    "RUBBER": make_material("MAT_Rubber", (0.015, 0.015, 0.012), 0.9),
    "GROUND": make_material("MAT_Ground", (0.10, 0.10, 0.10), 0.95),
}

# ============================================================
# GEOMETRY HELPERS
# ============================================================

def link_only_to(obj, collection):
    for c in list(obj.users_collection):
        c.objects.unlink(obj)
    collection.objects.link(obj)

def apply_transform(obj):
    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    obj.select_set(False)

def smooth(obj):
    if obj.type != "MESH":
        return
    for p in obj.data.polygons:
        p.use_smooth = True

def add_uv_sphere(name, loc, scale, material, collection, segments=None, rings=None):
    if segments is None or rings is None:
        segments, rings = SEGMENTS[SETTINGS["detail"]]
    bpy.ops.mesh.primitive_uv_sphere_add(segments=segments, ring_count=rings, location=loc)
    obj = bpy.context.object
    obj.name = name
    obj.scale = scale
    apply_transform(obj)
    smooth(obj)
    link_only_to(obj, collection)
    if material:
        obj.data.materials.append(material)
    return obj

def add_cylinder_between(name, a, b, radius_a, radius_b, material, collection, vertices=None):
    if vertices is None:
        vertices = SEGMENTS[SETTINGS["detail"]][0]
    a = Vector(a)
    b = Vector(b)
    direction = b - a
    length = direction.length
    midpoint = (a + b) * 0.5
    bpy.ops.mesh.primitive_cone_add(vertices=vertices, radius1=radius_a, radius2=radius_b, depth=length, location=midpoint)
    obj = bpy.context.object
    obj.name = name
    obj.rotation_mode = "QUATERNION"
    obj.rotation_quaternion = direction.to_track_quat("Z", "Y")
    smooth(obj)
    link_only_to(obj, collection)
    if material:
        obj.data.materials.append(material)
    return obj

def add_box(name, loc, scale, material, collection, bevel=0.04):
    bpy.ops.mesh.primitive_cube_add(location=loc)
    obj = bpy.context.object
    obj.name = name
    obj.scale = scale
    apply_transform(obj)
    bevel_mod = obj.modifiers.new("Bevel", "BEVEL")
    bevel_mod.width = bevel
    bevel_mod.segments = 2
    link_only_to(obj, collection)
    if material:
        obj.data.materials.append(material)
    return obj

def add_torus(name, loc, major_radius, minor_radius, material, collection):
    bpy.ops.mesh.primitive_torus_add(major_radius=major_radius, minor_radius=minor_radius, major_segments=24, minor_segments=8, location=loc)
    obj = bpy.context.object
    obj.name = name
    smooth(obj)
    link_only_to(obj, collection)
    if material:
        obj.data.materials.append(material)
    return obj

# ============================================================
# CHARACTER RIG
# ============================================================

def create_armature(name, c, height):
    arm_data = bpy.data.armatures.new(name + "_Armature")
    arm_obj = bpy.data.objects.new(name + "_Armature", arm_data)
    c.objects.link(arm_obj)
    bpy.context.view_layer.objects.active = arm_obj
    arm_obj.select_set(True)
    bpy.ops.object.mode_set(mode="EDIT")
    def bone(name, head, tail, parent=None):
        b = arm_data.edit_bones.new(name)
        b.head = head
        b.tail = tail
        if parent:
            b.parent = arm_data.edit_bones.get(parent)
            b.use_connect = False
        return b
    foot_z = 0.10
    ankle_z = 0.12 * height
    knee_z = 0.30 * height
    hip_z = 0.52 * height
    chest_z = 0.70 * height
    neck_z = 0.83 * height
    head_z = 0.90 * height
    top_z = height
    shoulder = 0.18
    hip = 0.11
    elbow_drop = 0.10
    bone("root", (0, 0, foot_z), (0, 0, hip_z))
    bone("spine", (0, 0, hip_z), (0, 0, chest_z), "root")
    bone("spine_02", (0, 0, chest_z), (0, 0, neck_z), "spine")
    bone("neck", (0, 0, neck_z), (0, 0, head_z), "spine_02")
    bone("head", (0, 0, head_z), (0, 0, top_z), "neck")
    for side, s in (("L", 1), ("R", -1)):
        bone(f"thigh_{side}", (s * hip, 0, hip_z), (s * hip * 1.15, 0, knee_z), "root")
        bone(f"calf_{side}", (s * hip * 1.15, 0, knee_z), (s * hip * 0.80, 0, ankle_z), f"thigh_{side}")
        bone(f"foot_{side}", (s * hip * 0.80, 0, ankle_z), (s * hip * 0.80, -0.20, foot_z), f"calf_{side}")
    for side, s in (("L", 1), ("R", -1)):
        shoulder_pos = (s * shoulder, 0, chest_z - 0.01)
        elbow = (s * (shoulder + 0.19), 0, chest_z - elbow_drop)
        wrist = (s * (shoulder + 0.28), 0, chest_z - 0.19)
        bone(f"upper_arm_{side}", shoulder_pos, elbow, "spine_02")
        bone(f"forearm_{side}", elbow, wrist, f"upper_arm_{side}")
        bone(f"hand_{side}", wrist, (wrist[0], -0.08, wrist[2]), f"forearm_{side}")
    bpy.ops.object.mode_set(mode="OBJECT")
    arm_obj.display_type = "WIRE"
    arm_obj.show_in_front = True
    arm_obj.hide_render = True
    arm_obj.select_set(False)
    return arm_obj

def parent_to_armature(obj, armature):
    if obj.type != "MESH":
        return
    bpy.ops.object.select_all(action="DESELECT")
    obj.select_set(True)
    armature.select_set(True)
    bpy.context.view_layer.objects.active = armature
    try:
        bpy.ops.object.parent_set(type="ARMATURE_AUTO")
    except RuntimeError:
        obj.parent = armature
    finally:
        bpy.ops.object.select_all(action="DESELECT")

# ============================================================
# BODY GENERATION
# ============================================================

def build_head(prefix, c, height, female=False, hat_mat=None, has_hat=False):
    head_scale = (0.105, 0.095, 0.135) if female else (0.115, 0.102, 0.14)
    head_z = height * 0.905
    skin_mat = MAT["SKIN_TAN"] if female else MAT["SKIN"]
    add_uv_sphere(prefix + "_HEAD", (0, 0, head_z), head_scale, skin_mat, c)
    neck_r = 0.055 if female else 0.060
    neck_bottom = height * 0.818
    neck_top = height * 0.875
    add_cylinder_between(prefix + "_NECK", (0, 0, neck_bottom), (0, 0, neck_top), neck_r, neck_r * 0.95, skin_mat, c)
    eye_z = height * 0.924
    eye_y = -0.091
    eye_x = 0.041 if female else 0.044
    for side, s in (("L", 1), ("R", -1)):
        add_uv_sphere(f"{prefix}_EYE_{side}", (s * eye_x, eye_y, eye_z), (0.016, 0.008, 0.012), MAT["EYE"], c)
        add_uv_sphere(f"{prefix}_EAR_{side}", (s * 0.104, -0.005, eye_z - 0.005), (0.010, 0.007, 0.018), skin_mat, c)
    add_uv_sphere(prefix + "_NOSE", (0, -0.102, height * 0.902), (0.020, 0.020, 0.035), skin_mat, c)
    # Hair
    hair_mat = MAT["HAIR_LIGHT"] if female else MAT["HAIR"]
    add_uv_sphere(prefix + "_HAIR_CAP", (0, 0.005, height * 0.946), (head_scale[0] * 1.02, head_scale[1] * 1.01, 0.085), hair_mat, c)
    if female:
        add_uv_sphere(prefix + "_HAIR_BACK", (0, 0.045, height * 0.885), (0.11, 0.08, 0.18), hair_mat, c)
    else:
        add_uv_sphere(prefix + "_HAIR_FRONT", (0, -0.045, height * 0.952), (0.11, 0.075, 0.035), hair_mat, c)
    # Hat
    if has_hat and hat_mat:
        add_box(prefix + "_HAT", (0, 0, height * 0.985), (0.12, 0.06, 0.13), hat_mat, c, bevel=0.02)
        # Brim for cap
        add_box(prefix + "_HAT_BRIM", (0, -0.09, height * 0.97), (0.12, 0.02, 0.08), hat_mat, c, bevel=0.01)

def build_body(prefix, c, height, clothing, female=False):
    if female:
        shoulder = 0.170
        chest_r = 0.145
        waist_r = 0.108
        hip_r = 0.145
        upper_arm = 0.040
        forearm = 0.033
        thigh_r = 0.065
        calf_r = 0.047
        shoe_len = 0.235
    else:
        shoulder = 0.205
        chest_r = 0.165
        waist_r = 0.125
        hip_r = 0.135
        upper_arm = 0.048
        forearm = 0.038
        thigh_r = 0.073
        calf_r = 0.052
        shoe_len = 0.255

    foot_z = 0.095
    ankle_z = height * 0.115
    knee_z = height * 0.315
    hip_z = height * 0.52
    waist_z = height * 0.62
    chest_z = height * 0.735
    shoulder_z = height * 0.805

    skin_mat = MAT["SKIN_TAN"] if female else MAT["SKIN"]
    shirt_mat = make_material(f"MAT_{prefix}_Shirt", clothing["shirt_color"], 0.62)
    pants_mat = make_material(f"MAT_{prefix}_Pants", clothing["pants_color"], 0.72)
    shoes_mat = make_material(f"MAT_{prefix}_Shoes", clothing["shoes_color"], 0.5)

    # Torso
    add_uv_sphere(prefix + "_PELVIS", (0, 0, hip_z), (hip_r, 0.095, 0.125), pants_mat, c)
    add_uv_sphere(prefix + "_ABDOMEN", (0, 0, waist_z), (waist_r, 0.085, 0.145), shirt_mat, c)
    add_uv_sphere(prefix + "_CHEST", (0, 0, chest_z), (chest_r, 0.095, 0.145), shirt_mat, c)

    for side, s in (("L", 1), ("R", -1)):
        add_uv_sphere(f"{prefix}_SHOULDER_{side}", (s * shoulder, 0, shoulder_z), (0.060, 0.065, 0.060), shirt_mat, c)

    # Legs
    for side, s in (("L", 1), ("R", -1)):
        hip = (s * hip_r * 0.56, 0, hip_z - 0.01)
        knee = (s * thigh_r * 0.54, 0, knee_z)
        ankle = (s * calf_r * 0.48, 0, ankle_z)
        add_cylinder_between(f"{prefix}_THIGH_{side}", hip, knee, thigh_r, thigh_r * 0.72, pants_mat, c)
        add_uv_sphere(f"{prefix}_KNEE_{side}", knee, (thigh_r * 0.73, thigh_r * 0.65, thigh_r * 0.70), pants_mat, c)
        add_cylinder_between(f"{prefix}_CALF_{side}", knee, ankle, calf_r * 1.12, calf_r, pants_mat, c)
        add_uv_sphere(f"{prefix}_FOOT_{side}", (s * calf_r * 0.48, -0.075, foot_z), (shoe_len * 0.52, 0.10, 0.055), skin_mat, c)

    # Arms
    for side, s in (("L", 1), ("R", -1)):
        shoulder_pos = (s * shoulder, 0, shoulder_z)
        elbow = (s * (shoulder + 0.165), 0, shoulder_z - 0.18)
        wrist = (s * (shoulder + 0.245), 0, shoulder_z - 0.37)
        add_cylinder_between(f"{prefix}_UPPER_ARM_{side}", shoulder_pos, elbow, upper_arm, upper_arm * 0.76, shirt_mat, c)
        add_uv_sphere(f"{prefix}_ELBOW_{side}", elbow, (upper_arm * 0.76, upper_arm * 0.67, upper_arm * 0.72), skin_mat, c)
        add_cylinder_between(f"{prefix}_FOREARM_{side}", elbow, wrist, forearm * 1.15, forearm, skin_mat, c)
        add_uv_sphere(f"{prefix}_HAND_{side}", (wrist[0], wrist[1] - 0.01, wrist[2] - 0.035), (0.040, 0.032, 0.065), skin_mat, c)

    hat_mat = make_material(f"MAT_{prefix}_Hat", clothing["hat_color"], 0.65) if clothing["hat"] else None
    build_head(prefix, c, height, female=female, hat_mat=hat_mat, has_hat=clothing["hat"])

# ============================================================
# CLOTHING
# ============================================================

def build_clothes(prefix, c, height, clothing, female=False):
    if not SETTINGS["create_clothes"]:
        return []
    objs = []
    shirt_mat = bpy.data.materials.get(f"MAT_{prefix}_Shirt")
    pants_mat = bpy.data.materials.get(f"MAT_{prefix}_Pants")
    shoes_mat = bpy.data.materials.get(f"MAT_{prefix}_Shoes")

    # Jacket
    if clothing["jacket"]:
        jacket_mat = make_material(f"MAT_{prefix}_Jacket", clothing["jacket_color"], 0.75)
        jacket = add_uv_sphere(prefix + "_CLOTH_JACKET", (0, 0.015, height * 0.735), (0.182, 0.112, 0.150), jacket_mat, c)
        objs.append(jacket)

    # Shoes
    for side, s in (("L", 1), ("R", -1)):
        shoe = add_box(f"{prefix}_SHOE_{side}", (s * 0.040, -0.09, 0.105), (0.075, 0.125, 0.040), shoes_mat, c, bevel=0.025)
        objs.append(shoe)

    # Belt
    add_torus(prefix + "_BELT", (0, -0.005, height * 0.555), 0.128 if not female else 0.138, 0.009, MAT["DARK"], c)
    # Watch for player/commuter
    if "PLAYER" in prefix or "COMMUTER" in prefix:
        side = -1
        add_torus(prefix + "_WATCH", (side * 0.250, -0.005, height * 0.60), 0.034, 0.007, MAT["DARK"], c)

    return objs

# ============================================================
# CHARACTER BUILD
# ============================================================

def build_character(name, height, clothing_key, female=False, x_offset=0):
    char_col = make_collection(name, ROOT_COL)
    prefix = name.upper()
    clothing = CLOTHING_ARCHETYPES.get(clothing_key, CLOTHING_ARCHETYPES["CIVILIAN_MALE"])

    build_body(prefix, char_col, height, clothing, female=female)
    build_clothes(prefix, char_col, height, clothing, female=female)

    if SETTINGS["create_rig"]:
        arm = create_armature(prefix, char_col, height)
        for obj in list(char_col.objects):
            if obj.type == "MESH" and "SHOE" not in obj.name and "BELT" not in obj.name and "WATCH" not in obj.name and "HAT" not in obj.name:
                parent_to_armature(obj, arm)

    for obj in list(char_col.objects):
        obj.location.x += x_offset

    return char_col

# ============================================================
# PRESENTATION
# ============================================================

def build_ground():
    if not SETTINGS["create_ground"]:
        return
    ground_col = make_collection("PRESENTATION", ROOT_COL)
    bpy.ops.mesh.primitive_plane_add(size=20, location=(0, 0, 0))
    plane = bpy.context.object
    plane.name = "CHARACTER_DISPLAY_GROUND"
    plane.data.materials.append(MAT["GROUND"])
    link_only_to(plane, ground_col)

def build_camera_and_lights():
    col = make_collection("PRESENTATION", ROOT_COL)
    bpy.ops.object.camera_add(location=(3.8, -6.2, 1.55), rotation=(math.radians(80), 0, math.radians(31)))
    cam = bpy.context.object
    cam.name = "NPC_REFERENCE_CAMERA"
    link_only_to(cam, col)
    bpy.context.scene.camera = cam
    target = Vector((0, 0, 0.88))
    direction = target - cam.location
    cam.rotation_euler = direction.to_track_quat("-Z", "Y").to_euler()
    bpy.ops.object.light_add(type="AREA", location=(0, -2.7, 3.4))
    key = bpy.context.object
    key.name = "KEY_LIGHT"
    key.data.energy = 900
    key.data.shape = "DISK"
    key.data.size = 3.0
    link_only_to(key, col)
    direction = target - key.location
    key.rotation_euler = direction.to_track_quat("-Z", "Y").to_euler()
    bpy.ops.object.light_add(type="AREA", location=(3.0, 1.0, 2.2))
    fill = bpy.context.object
    fill.name = "FILL_LIGHT"
    fill.data.energy = 500
    fill.data.size = 2.0
    link_only_to(fill, col)
    direction = target - fill.location
    fill.rotation_euler = direction.to_track_quat("-Z", "Y").to_euler()

def create_export_empty():
    col = make_collection("EXPORT", ROOT_COL)
    bpy.ops.object.empty_add(type="PLAIN_AXES", location=(0, 0, 0))
    empty = bpy.context.object
    empty.name = "GAME_EXPORT_ROOT"
    link_only_to(empty, col)
    return empty

# ============================================================
# MAIN
# ============================================================

def main():
    bpy.context.scene.unit_settings.system = "METRIC"
    bpy.context.scene.unit_settings.length_unit = "METERS"

    x = -SETTINGS["character_spacing"] * 4.5
    characters = []

    if SETTINGS["create_player"]:
        characters.append(("PLAYER", SETTINGS["male_height"], "PLAYER", False))
    if SETTINGS["create_civilian_male"]:
        characters.append(("CIVILIAN_MALE", SETTINGS["male_height"], "CIVILIAN_MALE", False))
    if SETTINGS["create_civilian_female"]:
        characters.append(("CIVILIAN_FEMALE", SETTINGS["female_height"], "CIVILIAN_FEMALE", True))
    if SETTINGS["create_police"]:
        characters.append(("POLICE", SETTINGS["male_height"], "POLICE", False))
    if SETTINGS["create_gang"]:
        characters.append(("GANG", SETTINGS["male_height"], "GANG", False))
    if SETTINGS["create_commuter"]:
        characters.append(("COMMUTER", SETTINGS["male_height"], "COMMUTER", False))
    if SETTINGS["create_service"]:
        characters.append(("SERVICE", SETTINGS["male_height"], "SERVICE", False))
    if SETTINGS["create_military"]:
        characters.append(("MILITARY", SETTINGS["male_height"], "MILITARY", False))
    if SETTINGS["create_beach"]:
        characters.append(("BEACH", SETTINGS["male_height"]*0.98, "BEACH", False))

    # Legacy
    if SETTINGS["create_male_legacy"]:
        characters.append(("MALE_NPC", SETTINGS["male_height"], "CIVILIAN_MALE", False))
    if SETTINGS["create_female_legacy"]:
        characters.append(("FEMALE_NPC", SETTINGS["female_height"], "CIVILIAN_FEMALE", True))

    for name, h, cloth_key, female in characters:
        build_character(name, h, cloth_key, female=female, x_offset=x)
        x += SETTINGS["character_spacing"]

    build_ground()
    build_camera_and_lights()
    create_export_empty()
    bpy.ops.object.select_all(action="DESELECT")

    print("="*60)
    print("GAME HUMAN NPC GENERATOR — CLOTHING VARIANTS COMPLETE")
    for name, h, cloth_key, female in characters:
        print(f"{name}: {h}m {cloth_key} female={female} — {CLOTHING_ARCHETYPES[cloth_key]['desc']}")
    print("Detail:", SETTINGS["detail"], "Rig:", SETTINGS["create_rig"])
    print("="*60)

if __name__ == "__main__":
    main()
