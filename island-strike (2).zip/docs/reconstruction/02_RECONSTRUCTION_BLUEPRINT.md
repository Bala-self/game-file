# ISLAND STRIKE — RECONSTRUCTION BLUEPRINT (Prompt 01 output for Prompt 02+)

**Date:** 2026-09-19 · **Companions:** `01_SOURCE_AUDIT.md`, `V2_4_1_EVIDENCE_RECONCILIATION.md`,
`gta_reference/*` (18 files), `../../data/reconstruction/*.json` (9 files),
`../../scripts/world/world_contract.gd` + `../../tests/world_contract_test.gd`.

---

## 1. Locked world contract (runtime authority)

`scripts/world/world_contract.gd` — the ONE authoritative spatial contract. Verified this session:
**WORLD_CONTRACT_RESULT: ALL PASS (41/41)** including boundary inclusivity, NaN/INF rejection,
sector bijection, determinism, and a 100k-query perf gate (20.1 ms).

| Field | Value |
|---|---|
| CENTER_XZ | (0, 0) — matches current island rect center (verified, not assumed) |
| RADIUS_M / DIAMETER_M | 3000 / 6000 (inclusive edge) |
| Envelope area | 28.274 km² (math circle) |
| LAND_RADIUS_M | 2700 (authored land) |
| SOFT_RADIUS_M | 2750 (warning band 250 m) |
| ROAD_LIMIT_RADIUS_M | 2900 (road graph cap; authored offshore exceptions must be flagged) |
| Zones | CORE_LAND / COAST_BAND / WATER (radial classification hook) |
| Sectors | 500 m macro (112 valid) + **125 m micro streaming sectors (1804 valid)** — P02 locked; verified |

**Prohibition:** no script may re-declare these constants. Legacy `wb_kit.ISLAND/SAND` remains the
*active build* contract until P02 migrates consumers one-by-one (safety procedure below).

## 2. Spatial partitioning specification (P02 consumes)

- **Logical sectors:** 500 m grid clipped by the circle; `Vector2i id = floor(pos/500)`; stable
  linear index via `WorldContract.sector_index` (sorted enumeration). Valid-sector set = 112.
- **Fine cells:** 125 m micro sectors (P02 locked; P01 designed 100 m — superseded), spawn/streaming ownership unit.
- **Simulation tiers attach to sectors:** ACTIVE (player sector + 8-neighborhood) → full sim;
  NEAR (next ring) → reduced; FAR → data-only. Render/collision LOD stays on the existing 75 m
  Streamer *inside* active sectors (two-level scheme; Streamer contract untouched in P01).
- **Sector registry schema (target spatial registry):**

```
sector_id: Vector2i
center_m: Vector2
primary_district: String (island_target_districts.json ids)
secondary_districts: Array[String]   (e.g. coast_band, suburbs fill)
terrain_type: String                 (flat_protected|rolling|mountain|sand|fields|dry_scrub|water|...)
road_density_0_1, ped_density_per_ha, traffic_veh_per_km, building_density_0_1,
activity_density_0_1, police_presence_0_3
service_points: Array[ServiceRef]    (island_target_services.json schema)
landmarks: Array[String]
interior_groups: Array[String]
spawn_tables: {peds: pool_id, traffic: pool_id, police: unit_set_id}
streaming_priority_0_100
performance_budget: {nodes_max, phys_ms_budget, draw_budget}
```

- **Save partitioning:** world flags stored per sector_id; ambient state is derived (seed+time),
  never saved (see dossier 14).

## 3. District & macro-biome plan / road hierarchy / landmarks / density / services

Authoritative machine-readable files (all validated JSON, this session):
`island_target_districts.json` (13 districts, wedge+radius geometry, priority resolution,
legacy-mapping column), `island_target_road_hierarchy.json` (7 classes, ring+radial+loops,
connectivity invariants, emergency dual-route rule), `island_target_landmarks.json` (20 anchors,
sightline rules), `island_target_density.json` (per-district ped/traffic/police + hour curves +
global sim budgets + T0–T4 alignment), `island_target_services.json` (15 categories, spacing
targets, P07 acceptance tests).

## 4. Safety procedure for locked contracts (unchanged, restated)

1. inspect the protecting test → 2. identify callers/consumers → 3. add new path →
4. migrate ONE consumer → 5. focused tests → 6. regression (full ci.sh) → 7. remove old path only
on evidence. Ownership stays: MissionManager=missions, EventBus=routing, Economy=money,
SaveSystem=persistence, GameState=shared state, WorldBuilder=build orchestration,
**WorldContract + sector registry = spatial truth (new)**.

## 5. QA matrix — test ownership per prompt

| Prompt | New suites (must ship green) | Existing suites that guard it |
|---|---|---|
| P01 | world_contract_test (41 gates) ✓ DONE | — |
| P02 | sector_registry_test; streaming_6km_stress | world_data_test (intentional regen), terrain_test, full ci |
| P03 | terrain_6km_determinism; coast_zone_test | terrain_test |
| P04 | road_graph_test (connectivity, dual-route, signals) | world_data_test |
| P05/P06 | skyline_sightline_test; district_metrics_test | smoke_test |
| P07 | service_spacing_test; landmark_registry_test | loadcheck |
| P08 | facade_contract_test; lod_budget_probe | stress_main |
| P09 | interior_registry_test; door_transition_stress | system_test |
| P10 | traffic_budget_probe; intersection_soak | stress_main |
| P11 | density_curve_test; witness_memory_test | system_test, stress_main |
| P12 | escalation_matrix_test; pursuit_path_test | system_test (threat gates), mission suite |
| P13 | weather regression (existing) + lighting_probe | system_test |
| P14 | walk suite extension; handling_determinism | walk_test, character_test |
| P15 | ballistics_table_regression; cover_snap_test | weapon_system_test |
| P16 | route_correctness_suite; reroute_latency_probe | world_data_test |
| P17 | mission suite EXTENDED (additive gates only) | mission_system_test (97 gates, never weakened) |
| P18 | save_migration_v3_v4_test; ledger_exploit_test | system_test |
| P19 | audio_budget_probe; ui_regression | smoke_test |
| P20 | full matrix + render QA + double CI | everything |

Every bug: reproduce → isolate → root-cause → fix at source → regression guard → focused re-run →
full ci.sh. Never patch symptoms; never weaken a gate.

## 6. Performance measurement plan (categories locked; numbers after baselines)

- **CPU:** world build time; sector activate/deactivate; physics ms by district; NPC think ms by
  tier; traffic update; nav query; mission tick; save/load. (Existing: `tools/perf_probe.gd`,
  CI gate phys ≤ 9 ms avg / worst frame < 13.5 ms — kept.)
- **GPU:** draw calls, visible meshes, shadow casters, transparents, particles, lights, material
  switches — via `render_probe.gd` on target HW (headless cannot; declared honestly, as the repo
  already does).
- **Memory:** nodes by sector, textures/meshes/anims/audio residency, peak RSS.
- **Gameplay counts:** peds/traffic/police/mission actors/nav agents/interiors vs the budgets in
  `island_target_density.json`.
- **P02-specific known risks to measure first:** NavGrid at 6 m over 28 km² ≈ 786k cells (vs
  ~17k today) → chunked bake + sector invalidation likely required; Streamer tile count scales
  ~40× → band-flip budget (OPS_PER_FRAME) must be re-tuned with measurement.
- Rule (project law, restated): budgets are set from measurement, never from wishful numbers;
  no gate is ever weakened to obtain PASS.

## 7. Save/data migration impact note

- Current SAVE_VERSION 3 w/ proven migration chain — pattern to reuse for v4 (P18: properties,
  garages, loadout; additive keys only).
- P02 map-contract change: saved world positions migrate via `WorldContract.clamp_to_playable`
  + nearest-legal-road snap; mid-mission saves abort to last checkpoint with notice (simpler,
  testable — flagged OPEN below).
- `tests/world_data_baseline.txt` DIFFs are contract alarms: regenerate only via `-- --generate`
  as an explicit reviewed act inside the prompt that intentionally changed the contract.

## 8. Open questions / VERIFY list (carried forward)

1. GTA V exact map area, coastline length, total road-km, vanilla density curves, day length
   official confirmation — all VERIFY (dossier 00/16 rules apply; never guess into data files).
2. Inland-water share of envelope (≤12% cap is a starting bound) — decide P03.
3. Tunnel count (candidate 2) — decide P03/P04.
4. Megatower final height (180–220 m) — decide P05 with skyline tests.
5. Helicopter/aircraft scope (P14) gates P12 air-response design — P12 must degrade to
   ground-only until decided.
6. Legacy `delivery.gd`/`race.gd`/`collectible.gd`: migrate into mission content vs keep as
   world toys — decide P17 with evidence.
7. Freight rail: decoration vs simulated trains — decide P10 by cost measurement.
8. Mid-mission save policy across contract change — confirm in P02 tests.
9. Sector sim-tier radii (ACTIVE/NEAR/FAR ring counts) — tune in P02 by measurement.

## 9. Prompt 01 acceptance gates — status

| Gate | Requirement | Status | Evidence |
|---|---|---|---|
| A — SOURCE AUDIT | full inventory, systems located | **PASS** | `01_SOURCE_AUDIT.md` (counts verified via find/grep this session) |
| B — VERSION RECONCILIATION | mismatch documented, no history rewrite | **PASS** | `V2_4_1_EVIDENCE_RECONCILIATION.md` (git HEAD 4f279a0 recorded; nothing rebased) |
| C — REFERENCE DOSSIER | sourced, taxonomy-marked | **PASS** | 18 files, 10 rated sources, FACT/OBSERVED/INFERRED/DECISION/VERIFY throughout |
| D — 3 KM WORLD CONTRACT | one authority, no duplicate constants | **PASS** | world_contract.gd + 41/41 test; legacy constants remain but are migration-scheduled, not duplicated from the new file |
| E — DATA SCHEMA | units + IDs everywhere | **PASS** | 9 JSON files, python-validated, unit-suffixed field names |
| F — DEPENDENCY CHAIN | P02 can consume without guessing | **PASS** | `island_reconstruction_dependencies.json` (inputs/outputs/tests per prompt) |
| G — REGRESSION SAFETY | no test weakened/deleted | **PASS** | baseline CI_RESULT: PASS (12 suites) before changes; world_contract_test added additively; full CI re-run after changes recorded in LAST_UPDATED.md |
| H — DOCUMENTATION | before/after + evidence + limits | **PASS** | this doc + audit + reconciliation; limitations stated (headless = no GPU numbers) |

**Prompt 01: LOCKED** (with the explicit caveat that GPU-side render QA is not measurable in this
headless environment — declared, not hidden, consistent with the repo's own honesty policy).
