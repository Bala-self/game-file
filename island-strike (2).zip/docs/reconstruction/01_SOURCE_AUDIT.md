# ISLAND STRIKE — FULL SOURCE AUDIT (Reconstruction Prompt 01)

**Date:** 2026-09-19 · **Method:** direct inspection of the uploaded archive + fresh headless CI run (Godot 4.5-stable).
**Companion docs:** `V2_4_1_EVIDENCE_RECONCILIATION.md` (version evidence), `02_RECONSTRUCTION_BLUEPRINT.md` (target spec).

Classification scale (each subsystem gets exactly one):
**[LT]** Locked & trusted (current source + test evidence) · **[II]** Implemented but incomplete vs the 6 km target · **[PP]** Placeholder/prototype · **[MI]** Missing · **[CF]** Conflicting evidence.

---

## 1. Inventory (verified counts, this session)

- Files: 230 excluding `.git/`; 860 including `.git/` (see reconciliation §1).
- Scripts: **79** `.gd` (+79 `.uid`); Scenes: **2** (`scenes/main/main_menu.tscn`, `scenes/game/game.tscn` — the world is assembled procedurally at runtime); Assets: **11** GLB building models, **13** WAV, 6 QA capture PNGs, 1 `.blend`; Tools: 3 Python generators, `ci.sh`, `perf_probe.gd`, `render_probe.gd`, `gen_world_tres.gd`, `lock_ledger.json`.
- Tests: 13 suites wired into `tools/ci.sh` (12 original + `world_contract_test` added by this prompt).

## 2. Project configuration

`project.godot`: Godot **4.3** feature flag (runs clean on 4.5-stable); main scene `main_menu.tscn`;
autoloads **GameState, SaveSystem, EventBus**; physics layers 1–5 = world/player/npc/vehicle/pickup;
gravity 9.8; viewport 1600×900; MSAA 3D = 1. Export presets: `export_presets.cfg` (Windows preset present).
No input map entries beyond engine defaults + in-code rebinding (settings_panel + rebind UI per git history). **[LT]**

## 3. World architecture

| Component | Facts verified in source | Class |
|---|---|---|
| `wb_kit.gd` (world contract, legacy) | `ISLAND = Rect2(-450,-350,900,700)` (900×700 m rect, centered on origin); `SAND = Rect2(-560,-450,1120,900)`; `WATER_Y = -1.3`; `ROAD_W = 14`; **14** road Rect2 + 1 dirt road; `TRAFFIC_LIGHTS`, `TRAFFIC_LOOP_A/B`, `COP_SPAWNS`, `COLLECTIBLE_SPOTS` (20), `PARKED_SPOTS`, `PLAYER_SPAWN = (-430,0.6,-40)`; `ROAD_CLASSES` + `ROAD_RULES` dicts (hierarchy seed); `DISTRICTS` dict | **[II]** — real, tested, but rectangular and ~1/36 of the target envelope; Prompt 02 replaces the envelope contract, migrates consumers |
| `world_builder.gd` | deterministic orchestrator, `rng.seed = 20260915`, explicit build order: ground→water→vegetation→mountain details→landmarks→creek→road protection→roads→sidewalks→medians→stop lines→bus stops→signs→street trees→utility poles→drains→coast→rail→districts→interiors | **[LT]** as orchestrator; geometry scale **[II]** |
| District modules (17 files in `world/districts/`) | roads, streetscape, env, downtown, suburbs, military, airport, industrial, farmland, park, beach, outskirts, rail, coast, interiors — modular kit pattern | **[LT]** architecture; content scale **[II]** |
| `terrain.gd` | seed 7717; `FLAT_DISTRICTS` protected flat; north-only mountain zone (`MOUNTAIN_AMPLITUDE 85`, `HILL_AMPLITUDE 28`, `AMPLITUDE 18`, `FREQ 1/130`); `height_at()` deterministic; river channel carved (lock ledger phase 08) | **[LT]** (TERRAIN_RESULT: ALL PASS) |
| `streamer.gd` | 12×12 grid × 75 m tiles over the island rect; ACTIVE/NEAR/FAR; 1-ring pre-activation; `OPS_PER_FRAME = 300` budgeted band flips; never frees; MIN_AABB 150 exclusion | **[II]** — correct design, sized for the 900 m world; extension plan in blueprint §4 (audit-first: it assumes a rectangular 12×12 domain) |
| `nav_grid.gd` | 6 m sampled grid, raycast walkability, greedy rect merge → NavigationMesh polys; off-mesh links (pier, parking levels); deterministic, no RNG | **[LT]** for current scale; resampling cost at 6 km must be measured before Prompt 04 **[II at scale]** |
| `building_kit.gd` + 10 authored GLBs + `building_set.glb` | kit-authored procedural buildings + small authored seed set (modern set, ~10 designs) | **[II]** — seed library, not 6 km city content (Prompt 08 owns expansion) |
| World data resource | `world_data_res.gd` + `tools/gen_world_tres.gd` + `tests/world_data_baseline.txt` (199-line canonical dump, contract-diff test) | **[LT]** — this is the project's existing spatial single-source-of-truth *mechanism*; Prompt 02 extends its schema rather than bypassing it |

## 4. Gameplay architecture

| Component | Facts verified | Class |
|---|---|---|
| `player.gd` + `character_rig.gd` | walk/sprint/crouch/jump/swim, camera-relative, spring-arm camera, shoulder aim, vehicle entry/exit; controller support; rig tests green | **[LT]** |
| `vehicles/car.gd` | data-driven `CLASSES`: sedan, sports, pickup, van, taxi, suv, bus, police, moto (**9** road classes) + `boat.gd` (speedboat) = 10 total; brake/reverse lights, body roll, horns, explosions w/ radial damage, surface grip + wet modifier, traffic-light obedience | **[LT]** core; ecosystem breadth **[II]** (Prompt 10) |
| NPC system | `person.gd` base + 7 subclasses (civilian, commuter, service, police, gang, military, beach); T0–T4 sim LOD tiers (lock ledger round 9); schedules; witness radius 28 m | **[LT]** core; density/schedule depth **[II]** (Prompt 11) |
| Wanted/police | `GameState.wanted` 0–5; witness→report→dispatch; npc_police states patrol/pursue/shoot/search/dismiss; `threat_assessment.gd` (NONE/LOW/MEDIUM/HIGH/LETHAL; wanted≥4 ⇒ LETHAL; verified `should_shoot: wanted==0 → false`) | **[LT]** foundation (LOCKED-VERIFIED in ledger); GTA-scale dispatch/roadblocks/air **[MI]** (Prompt 12) |
| Weapons | `weapon_data.gd`: **7** data-driven defs (pistol, viper9, raven45, smg, kestrel556, shotgun, mammoth12) w/ ballistics + ergonomics + `validate_all()`; `weapon_manager.gd`/`weapon_inventory.gd`; bloom heat, falloff, deploy timing, quick-swap | **[LT]** (WEAPON_RESULT 15/15); combat model breadth **[II]** (Prompt 15) |
| Missions | `mission_manager.gd` orchestrator: states, single-active, objective stepping @10 Hz, ONE EventBus subscription, checkpoints, save snapshot/restore, exactly-once rewards, start-zone auto-start; `mission_defs.gd`: **5** defs, archetypes GO_TO/INTERACT/COLLECT/DELIVER/ENTER_VEHICLE/ELIMINATE(+escape gate) | **[LT]** — locked foundation; activity universe **[II]** (Prompt 17) |
| `event_bus.gd` | single `event_logged(kind,data)` signal + 120-entry ring log; structured CRIME records with witnesses | **[LT]** |
| `economy.gd`, `save_system.gd`, `game_state.gd` | Economy = money owner; SAVE_VERSION **3** with per-version migration chain, atomic writes; GameState = shared state owner | **[LT]** |
| `event_manager.gd`, `world_sim.gd` | random events; weather: 9 states, weighted Markov-style chain, 90 s slow transitions, wetness/puddles persistence | **[LT]** weather core; seasonal/localized ambience **[II]** (Prompt 13) |

## 5. UI & player-facing

`hud.gd` (minimap, wanted stars, mission text/markers, speedometer), `pause_menu.gd`, `settings_panel.gd`
(rebind UI), phone panel (round 9 ledger), main menu scene. **[LT]** for current scope; map/GPS route line
**[MI]** (planned v2.5 per report roadmap; Prompt 16 owns it).

## 6. QA & release infrastructure

- `tools/ci.sh`: 12→**13** suites, expected-result strings, D1 error gate (script/engine errors fail the build),
  leak gate w/ upstream-#95484 classification, perf gate best-of-3 with noise detection (phys ≤ 9 ms avg,
  worst frame < 13.5 ms), and a **standing rule**: on PASS, refresh the single game zip via
  `/home/user/release-tools/make_game_zip.sh` (tool recreated this session at workspace root — see LAST_UPDATED.md).
- Fresh full run this session: **CI_RESULT: PASS**, worst frame **4.21 ms** (evidence table in the reconciliation doc §5).
- `lock_ledger.json`: Round 12 (26-phase upgrade) + round16 (v2.4.0 mission framework) locked entries.
- Render QA: 6 capture PNGs + `render_probe.gd` (GPU-side, not measurable headless — honestly declared in `PERFORMANCE_BASELINE.md`).
- **[LT]**

## 7. Where things live (quick map)

- World/spatial truth (today): `scripts/world/wb_kit.gd` + `world_data_res.gd` → Prompt 02 adds `WorldContract`-backed world data as the new spatial owner.
- World/spatial truth (target): `scripts/world/world_contract.gd` (**created by this prompt**, additive, 41-gate test green).
- Build orchestration: `scripts/world/world_builder.gd` → 17 district modules.
- Player: `scripts/player/player.gd`. Vehicles: `scripts/vehicles/`. NPCs: `scripts/npc/`. Missions: `scripts/missions/`. Core: `scripts/core/`. Systems: `scripts/systems/`. UI: `scripts/ui/`. Tests: `tests/`. Tools: `tools/`.

## 8. Conflicts & risks recorded

1. **[CF]** Version metadata (stamp v2.4.1 / report header v2.3.0 / git HEAD v2.0.14) — fully documented in the reconciliation doc; resolved by evidence ranking, history not rewritten.
2. `world_data_baseline.txt` will legitimately DIFF when Prompt 02 changes the world contract; the regeneration path is declared there (`-- --generate`) and must be an explicit, reviewed act.
3. The legacy `scripts/world/delivery.gd` predates the mission framework and is still live (ledger: "untouched, still functional"). Prompt 17 must decide migrate-or-retire with evidence; do not delete blindly.
4. Streamer/navgrid cost at 6 km scale is **unmeasured** — blueprint §6 assigns measurement before adoption.
