# V2.4.1 EVIDENCE RECONCILIATION

**Program:** Island Strike — GTA V Functional-Parity Reconstruction (Prompt 01/20)
**Audit date:** 2026-09-19
**Auditor environment:** fresh sandbox; Godot 4.5-stable (4.5.stable.official.876b29033) obtained and executed this session; `tools/ci.sh` re-run in full (see §6 — this is a NEW run, not inherited evidence).

This document records a real version/evidence mismatch in the supplied package **without rewriting
history**. No historical record was altered to make the evidence look clean.

---

## 1. Package stamp observed

`BUILD_STAMP.txt` (verbatim, before any change in this session):

```
ISLAND STRIKE game zip
Built: 2026-09-19 07:18 UTC
Files: 860
Source: v2.4.1 mission framework lock line
```

Note on the file count: `860` counts **every file including `.git/` internals**
(`find . -type f | wc -l` = 860). The working tree itself contains **230 files**
(`find . -path ./.git -prune -o -type f -print | wc -l`). Both numbers are true;
they answer different questions. The stamp does not say which it means — recorded
here so future audits do not treat this as a contradiction.

## 2. Source state observed (authoritative for implementation)

The working tree is a **v2.4.1 source line**:

- `scripts/missions/` (mission_manager.gd, mission_defs.gd) present, **untracked** by git.
- `mission_defs.gd` contains **5 mission definitions** (bank_run, dock_cleanup, safe_passage,
  getaway_car, warehouse_job) including the `ENTER_VEHICLE` objective archetype.
- `tests/mission_system_test.gd` present, untracked; ran green in this session at **97/97 gates**
  (the v2.4.0 lock ledger records 57 gates — the suite grew with the v2.4.1 hardening).
- Data-driven weapon layer (`weapon_data.gd`: 7 weapons), `economy.gd`, `event_bus.gd`,
  `threat_assessment.gd`, `building_kit.gd`, `debug_tools.gd` all present, untracked.
- 51 tracked files modified vs HEAD (player, NPCs, save system, game.gd, project.godot, …).
- 10 superseded root-level reports deleted in the working tree (AUDIT_0915.md, PROGRESS.md, …).

## 3. Git state observed (stale)

- `git rev-parse HEAD` = `4f279a0e64268e053a6a5ad9167d290408e57ac1`
- HEAD commit message: `v2.0.14 docs: Round 11 audit-first execution report (section 26 format)`
- Working tree vs HEAD: **10 deleted, 51 modified, 30 untracked** (untracked includes the entire
  mission framework, weapon data layer, lock ledger, docs/, GLB assets).
- Conclusion: **git history ends at the v2.0.14 line; v2.1→v2.4.1 exists only as working-tree state.**
  The zip is effectively a "working-tree snapshot release". This is recorded, not repaired.

## 4. Report state observed (stale)

- `docs/DEVELOPMENT_REPORT.md` header: `VERSION v2.3.0` / `PHASE Master Plan v2.1 Adoption …` / `STATUS LOCKED`.
- The same file's change-history section already contains a `## v2.4.0 — 2026-09-19` entry
  (Mission Framework). So the report's *history* is newer than its *header*.
- `README.md` still says "This is release **v1.0** of the project" — two documentation generations
  behind.
- `tools/lock_ledger.json` records `round16` (v2.4.0 Mission Framework, `CI_RESULT: PASS x2`,
  `next_phase: v2.5 GPS route line`) — newer than the report header, older than the stamp.

## 5. Test state observed (fresh, this session)

`bash tools/ci.sh` executed on 2026-09-19 in this environment (Godot 4.5-stable headless):

| Suite | Result (fresh run) |
|---|---|
| loadcheck | ok: res://scripts/game/game.gd |
| walk_test | WALK_RESULT: ALL PASS |
| character_test | CHARACTER_RESULT: ALL PASS |
| smoke_test | SMOKE_RESULT: ALL PASS |
| stress_main | STRESS_RESULT: PASS |
| menu_test | MENU_RESULT: OK |
| world_data_test | WORLD_DATA_RESULT: IDENTICAL (199 lines, tres in sync) |
| terrain_test | TERRAIN_RESULT: ALL PASS |
| clothing_test | CLOTHING_RESULT: ALL PASS (19/19) |
| weapon_system_test | WEAPON_RESULT: ALL PASS (15/15) |
| system_test | SYSTEM_RESULT: ALL PASS (32/32) |
| mission_system_test | MISSION_RESULT: ALL PASS (97/97) |
| perf_probe | PASS — worst frame 4.21 ms < 13.5 (attempt 1) |
| **Verdict** | **CI_RESULT: PASS** |

Leak gate: three suites hit the known upstream #95484 audio-teardown summary; verbose re-runs did
not reproduce (timing-masked) — allowed per the script's documented policy. No action taken.

## 6. Which evidence is authoritative

**Ranking for implementation decisions (highest first):**

1. **Actual working-tree source code** (what the game runs).
2. **Fresh test runs** (this document §5 — executed, not inherited).
3. `tools/lock_ledger.json` (structured, closest to current line: v2.4.0 round16).
4. `BUILD_STAMP.txt` (package-level claim; consistent with the source line, imprecise on file count).
5. `docs/DEVELOPMENT_REPORT.md` change history (mostly current up to v2.4.0; header stale).
6. Git history (v2.0.14 — oldest; useful for archaeology only).
7. `README.md` (v1.0-generation prose; describes the game loosely, not the current system inventory).

## 7. Artifacts classified as stale

| Artifact | State | Handling |
|---|---|---|
| `README.md` version prose ("release v1.0") | STALE | leave; regenerate at next verified lock |
| `docs/DEVELOPMENT_REPORT.md` header (v2.3.0) | STALE header, semi-current history | leave; regenerate at next verified lock |
| Git HEAD (v2.0.14) | STALE by ~4 minor lines | do not rewrite; commit forward |
| `BUILD_STAMP.txt` | describes the *previous* package | refreshed after this Prompt-01 lock (old content preserved verbatim in §1 above) |
| `PERFORMANCE_BASELINE.md` (v2.0 line) | stale baselines | re-baseline in Prompt 20, do not delete |

## 8. What must be regenerated after the next verified lock

- [ ] `docs/DEVELOPMENT_REPORT.md` — new versioned section + header bump, per the project's own documentation protocol.
- [ ] `README.md` — version prose and feature inventory.
- [ ] `BUILD_STAMP.txt` — refresh date/count/line (script: see `release-tools/make_game_zip.sh` at workspace root).
- [ ] Git — commit forward from HEAD (additive commits only; no history rewrite).
- [ ] `tests/world_data_baseline.txt` — regenerate **only** when Prompt 02 intentionally changes the world contract (it is a contract-diff test; a DIFF there is the alarm, not the failure).

**Do not** block reconstruction on this mismatch; **do not** claim the package ever had a perfectly
synchronized release history. This discrepancy stays visible.

**Addendum (Prompt 02 lock, 2026-09-19):** the v2.4.1 working-tree state was committed forward
(commits `b07cb79` + `69142a7`) exactly as found — content unaltered, nothing rebased, deleted
root reports stay deleted as the uploaded package had them. Git HEAD now equals the CI-verified
tree; the only standing drift is the one-line `BUILD_STAMP.txt` timestamp the packaging rule
rewrites on every verified update.
