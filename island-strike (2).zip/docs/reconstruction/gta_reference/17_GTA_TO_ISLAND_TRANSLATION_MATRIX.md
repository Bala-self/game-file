# 17 — GTA V → ISLAND STRIKE TRANSLATION MATRIX

Columns: **Now** = verified current state (this session) · **Gap** = missing vs target ·
**Depends** = prerequisite prompt · **Owner** = implementing prompt.

| # | GTA V pattern (reference label) | Island Strike target | Now | Gap | Depends | Owner |
|---|---|---|---|---|---|---|
| W1 | City↔countryside continuum on one landmass | 11–13 districts on 6 km circle, gradual transitions | 8 districts on 900×700 rect [LT/II] | envelope, district identities, transitions | P01✓ | P02/P05/P06 |
| W2 | Coastline as destination, not map edge | 2700–3000 m coast band, beaches/cliffs/marina | beach+coast modules exist [LT] | circular coast, cliffs, offshore islands | P02 | P03 |
| W3 | Mountains visible from city | Sentinel Ridge w/ skyline sightlines | north hill zone (amp 85) [LT] | scale, trails, viewpoints network | P02 | P03/P06 |
| W4 | Inland water (Alamo Sea/river) | lake + river drainage w/ bridges | carved river channel + lake/bridge (git round 10-11) [LT] | rescale to sector geography | P02 | P03 |
| R1 | Road graph w/ classes & rules | graph: freeway→alley w/ nav costs | 14 Rect2 roads + ROAD_CLASSES/RULES dicts [II] | full graph model, ramps, tunnels, markings | P02 | P04 |
| R2 | Traffic on graph, district mixes | 16–20 classes, pools per district, parking | 10 classes, traffic loops, lights [LT/II] | graph AI, pools, continuity | P04 | P10 |
| R3 | Trains/freight | freight rail corridor (sim stretch) | rail yard decoration [II] | simulate or freeze decision | P04 | P10 |
| P1 | Peds by district w/ schedules | archetype pools + schedules + density fields | 7 NPC classes, T0–T4 tiers, schedules seed [LT/II] | density fields, pools, groups | P02 | P11 |
| P2 | Crowd reactions & witness memory | witness memory + latency + district sensitivity | 28 m witness + crime records [LT] | memory, reporting nuance | P11 | P11/P12 |
| C1 | 5-star escalation w/ NOOSE/air | dispatch tables, roadblocks, search grid, air | wanted 0–5 + threat assessment + dispatch cruisers [LT] | tactical layer, roadblocks, heli | P04 | P12 |
| C2 | Jurisdictions (LSPD/Sheriff/Highway) | city/county/military zones | single police force [II] | jurisdiction zones + unit variants | P12 | P12 |
| M1 | Story missions + checkpoints | 8–12 mission story chain | MissionManager + 5 defs, 6 archetypes [LT] | content volume, new archetypes | — | P17 |
| M2 | Strangers & random events | location/time-weighted event scripts | event_manager seed [PP] | event library, reactions | P11 | P17 |
| M3 | Activities (races, ranges, golf-lite) | activity layer on mission engine | race.gd legacy toy [PP] | registry + rewards | P16 | P17 |
| S1 | Shops/services everywhere | service registry w/ spacing targets | a few service spots [II] | registry + interiors + interactions | P09 | P07/P09/P18 |
| S2 | Properties & garages persist | deeds, garage vehicles, save v4 | none [MI] | full feature | P09 | P18 |
| S3 | LSC vehicle customization | garage mod shop (visual+stats) | none [MI] | full feature | P09 | P18 |
| U1 | Map + GPS route line | graph routing + route line + reroute | minimap exists; GPS = declared v2.5 next phase [II] | routing engine, UI | P04 | P16 |
| U2 | Phone | phone panel w/ services | phone panel (round 9) [LT] | services integration | P16 | P19 |
| U3 | Radio stations | original procedural/CC0 audio | 13 WAV, district ambience [LT] | radio layer | — | P19 |
| E1 | Time/weather cross-system state | keep + localize | WorldSim 9-state chain [LT] | localized fog, season-lite | — | P13 |
| E2 | Streaming w/o loading screens | sector streaming + LOD + pools | 12×12 tile streamer [LT at 900 m] | sector tiers, budgets, nav chunks | P02 | P02/P04 |
| E3 | Save/persist player state | save v4 additive | save v3 + migration chain [LT] | properties/garages keys | P18 | P18 |
| X1 | Cover combat | snap-to cover + NPC tactics | hitscan combat, no cover [II] | cover system, loadouts | P08 | P15 |
| X2 | Drive-bys | window/lean drive-by | none [MI] | feature | P15 | P15 |
| X3 | Interiors at scale | interior registry + streaming | interiors module (few) [II] | registry, doors, persistence | P08 | P09 |

**P01-owned rows:** W1 (contract half) ✓, E2 (specification half) ✓ — all others are downstream.
No row may claim done without implementation + test + evidence per the program QA method.
