# 05 — BUILDINGS & LANDMARKS

## Evidence

- **DOCUMENTED FACT (wiki)** — Anchor landmarks include: Maze Bank Tower (tallest, downtown),
  FIB & IAA HQs, Union Depository, Mile High Club (under construction), Vinewood Sign, Galileo
  Observatory, Vinewood Bowl, Pleasure Pier (Del Perro), Kortz Center, Maze Bank Arena
  (La Puerta), LSIA terminals, Port of South LS cranes/containers, Fort Zancudo, Mount Chiliad
  w/ cable car, Alamo Sea, Land Act Dam, power plant/wind farms in Blaine County.
- **INFERRED DESIGN PATTERN** — Landmarks operate as navigation anchors at three ranges:
  skyline (km-scale silhouettes), district (100–300 m), street (door-level detail). Height
  hierarchy is deliberately readable — one dominant tower, a secondary cluster, a flat field.
  Construction sites ("Mile High Club") double as environmental storytelling + climb spaces.

## Island Strike decisions

- **ISLAND STRIKE DECISION (P07)** — Landmark registry (`island_target_landmarks.json`) with
  per-landmark: category, height class, visible-from range, district anchor role, interior hook,
  mission usage flags. Existing anchors (Island Tower 95 m, stadium, lighthouse, radar mast,
  harbor crane, windmill, ferris wheel) migrate and rescale; new anchors fill gaps:
  central megatower (≥180 m), port gantry cranes, airport control tower + terminal, refinery
  stack w/ warning lights, ridge chapel/observatory, radio masts, bridge(s), marina tower.
- **ISLAND STRIKE DECISION (P08)** — BuildingKit → modular pipeline: façade families × floor
  modules × roof sets × storefront slots × signage anchors × LOD tiers × collision tiers,
  district-rule-driven. The 10 authored GLBs become one façade family seed.
- **ISLAND STRIKE DECISION (P07)** — One construction site as dynamic landmark (cranes, fences,
  half-built floors) — GTA's "under construction" pattern, original design.

## Open questions

- **OPEN** — Final tower height (180–220 m) vs the current 95 m Island Tower: decide in P05 with
  skyline tests from 4 vantage points.
