# 13 — AUDIO & AMBIENCE

## Evidence

- **DOCUMENTED FACT (manual)** — Licensed radio stations play in vehicles; the manual presents
  radio as a documented feature. (We will NOT replicate licensed content.)
- **OBSERVED** — Ambient soundscape varies by location (beach waves, city traffic hum, desert
  wind, industrial machinery, birds rural) and by weather (rain, thunder) and time (night
  insects, day birds).
- **INFERRED DESIGN PATTERN** — Zone-based ambience layers crossfaded by player position +
  weather/time state; one-shot SFX pooled; music only for missions/radio.

## Island Strike decisions

- **ISLAND STRIKE DECISION (preserve)** — 13 procedural WAV assets + district ambience
  (round 9 ledger) already follow the zone pattern; keep.
- **ISLAND STRIKE DECISION (P19)** — Ambience zones keyed to P02 sectors: coast/waves,
  urban-hum (traffic density-weighted), industrial-machines, rural-birds/wind, mountain-wind,
  military-alarm (event), rain/thunder layers (weather-driven), night swap layer.
- **ISLAND STRIKE DECISION (P19)** — Budget: max 8 concurrent ambience buses; distance-attenuated
  point SFX pooled; audio teardown must keep passing the CI leak gate (known upstream #95484
  audio race is already allowlisted — do not weaken it).

## Open questions

- **OPEN** — Music generator vs authored CC0 loops for radio — P19 scope decision.
