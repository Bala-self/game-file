# 07 — POLICE & WANTED RESPONSE

## Evidence

- **DOCUMENTED FACT (gta.fandom, multiple sources)** — GTA V uses a **five-star** wanted scale
  (not six). Documented per-star behavior (story mode):
  - **★1**: police try to arrest on foot/vehicle; night helicopter spotlight tracking; arrest =
    respawn at nearest station, lose some cash + ammo; death penalty costs more than arrest.
    Officers hold fire unless threatened. Sight cones on radar.
  - **★2**: escalation triggers (running from prolonged pursuit, hitting civilians/cars,
    threatening with weapon, avoiding arrest in line of sight).
  - **★3**: shoot-to-kill; Police Maverick helicopter w/ NOOSE riflemen; spotlight at night;
    minimum ~4 police cars + helicopter on station; tactical repositioning for line of sight;
    aggressive ramming; roadblocks possible.
  - **★4**: NOOSE ground teams (rappelling from helicopters, landing deployments); armored
    riot vans; tear gas to flush cover; FIB involvement; up to ~3 Mavericks (2 deployed);
    minimum ~5 ground vehicles + 2 helicopters.
  - **★5**: maximal response; streets filled with police, civilian traffic nearly absent;
    multiple simultaneous roadblocks; indefinite ground units; up to 3 Mavericks.
- **DOCUMENTED FACT (wiki)** — Jurisdiction varies by location: LSPD in the city, Sheriff
  (LSCSO) in Blaine County, highway patrol on freeways; NOOSE is the tactical unit.
- **DOCUMENTED FACT (wiki)** — Heat decay: breaking line of sight and staying hidden drains the
  search; leaving the area works ("a few blocks distance" for low stars); respraying a vehicle
  at a mod shop instantly clears wanted level; railways are hard for police to follow.
- **DOCUMENTED FACT (wiki)** — Missions can force wanted levels (e.g., prologue bank exit = ★5).

## Island Strike decisions

- **ISLAND STRIKE DECISION (P12)** — Keep the existing wanted 0–5 + witness→report→dispatch +
  ThreatAssessment core (LOCKED). Expand: dispatch tables per star (unit types/counts by star,
  original), jurisdiction zones (city police / county sheriff / base military — Camp Halberd),
  patrol routes from the P04 graph, pursuit driving (existing), PIT/ram tactics at ★3+,
  roadblocks on graph edges (chokepoint scoring), search grid using P02 sectors, helicopter
  with spotlight at ★3+ night (existing lighthouse light tech as seed), arrest/bust flow
  (existing BUSTED), station respawn + penalty via Economy.
- **ISLAND STRIKE DECISION (P12)** — All counts/timings data-driven (`police_response.json` at
  implementation time); no numbers copied from GTA tables — original balance.
- **ISLAND STRIKE DECISION (P17)** — Missions may force-set wanted levels via the existing
  EventBus CRIME path (GTA mission pattern, original content).

## Open questions

- **OPEN** — Helicopter availability at current scale (no aircraft system yet — P14 decides
  flight scope; P12 must degrade gracefully to ground-only response until then).
