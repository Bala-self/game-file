# 00 — REFERENCE SCOPE & METHOD

**Purpose.** Collect publicly documented GTA V systems/design knowledge and convert it into
original Island Strike engineering requirements. Prompt 01 of 20.

## Evidence taxonomy (mandatory in every dossier file)

- **DOCUMENTED FACT** — stated by Rockstar (manual/site) or reproducible public record.
- **OBSERVED/MEASURED** — community measurement or reproducible in-game observation; may carry error.
- **INFERRED DESIGN PATTERN** — reasoned interpretation, clearly labeled.
- **ISLAND STRIKE DECISION** — what we will build, owned by a numbered prompt.
- **OPEN QUESTION / VERIFY** — unresolved; becomes a research task, never a guessed number.

## Legal boundary (hard rule)

No Rockstar proprietary code, RPF content, textures, models, animations, audio, map data,
mission scripts, or dialogue is copied. GTA V names appear here **only as reference labels**.
Island Strike ships 100% original implementations and assets. Target = comparable systemic
behavior, not duplication.

## Scale disclaimer

Island Strike's 3 km radius (28.27 km² envelope) is an explicit Island Strike design
requirement. It is NOT a measurement of GTA V and must never be presented as one.

## Source tiers

1. Official Rockstar manual / site (strongest, but light on systems detail).
2. Community wikis (gta.fandom.com, rockstargames.fandom.com, wikigta) — detailed mechanics, community-maintained, may contain errors/changes.
3. Forum measurements (GTAForums, Reddit) — useful for numbers, always labeled OBSERVED.
4. Technical analysis articles — inference-rich; treat as INFERRED unless they cite primaries.

Full source list with confidence ratings: `16_REFERENCE_DATA_SOURCES.md`.
