# 11 — TIME, WEATHER & ENVIRONMENT

## Evidence

- **DOCUMENTED FACT (manual)** — The game world has a full day/night cycle and changing weather
  the player lives through during normal play.
- **OBSERVED/MEASURED (community)** — One in-game day ≈ 48 real minutes (1 game minute = 2 real
  seconds) is the widely reproduced figure. Confidence: MEDIUM (community-measured, consistent).
- **OBSERVED** — Weather includes clear, cloudy, rain, thunderstorm, fog, and (Blaine/desert
  context) heat haze; rain wets surfaces, affects handling and visibility; lightning at storms.
- **INFERRED DESIGN PATTERN** — Time and weather are global world-state clocks that other
  systems read (traffic density, ped schedules, lighting, audio, handling) rather than owning.

## Island Strike decisions

- **ISLAND STRIKE DECISION (preserve)** — WorldSim's 9-state weighted chain with 90 s slow
  transitions + wetness/puddle persistence already implements the cross-system weather
  pattern; keep as locked core.
- **ISLAND STRIKE DECISION (P13)** — Add: wind affecting vegetation/water (partially exists),
  localized fog pockets (ridge/valley), season-lite palette drift, lightning strikes as world
  events, street-light response curve tied to GameState time, weather-sensitive traffic speed
  (wet modifier exists) and ped behavior (umbrellas? — cost check first).
- **ISLAND STRIKE DECISION (P13)** — Keep the current in-game day length; expose it in
  settings (players of open worlds expect control).

## Open questions

- **VERIFY** — Vanilla day length exactly 48 min across all platforms/versions — consistent
  community measurement, not official; safe to treat as MEDIUM.
