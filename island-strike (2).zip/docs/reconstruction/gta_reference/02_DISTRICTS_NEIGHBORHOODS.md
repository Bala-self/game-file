# 02 — DISTRICTS & NEIGHBORHOODS

## Evidence

- **DOCUMENTED FACT (community wiki, consistent across sources)** — Los Santos divides into
  major sections with named districts (gta.fandom "Los Santos (HD Universe)"):
  - **Downtown**: Pillbox Hill, Mission Row, Textile City, Legion Square — financial center,
    tallest high-rises (Maze Bank Tower, FIB, IAA, Union Depository, Mile High Club).
  - **Vinewood**: Downtown Vinewood, West/East Vinewood, Alta, Hawick, Mirror Park —
    entertainment industry, theaters, nightclubs; affluent.
  - **Vinewood Hills**: expensive hillside homes, Vinewood Sign, observatory.
  - **Rockford Hills** (+Burton): luxury shopping (Portola Drive), mansions.
  - **Vespucci**: beach, canals, marina (Puerto Del Sol) — recreation.
  - **West LS**: Little Seoul, Morningwood, Del Perro, Pacific Bluffs, Backlot City.
  - **South LS**: Davis, Strawberry, Rancho, Chamberlain Hills, Banning + Port of South LS
    (Banning, Elysian Island, Terminal) — industrial, lower income, gang presence.
  - **East LS**: La Mesa, Cypress Flats, El Burro Heights, Murrieta Heights + oil fields —
    industrial/gentrifying.
  - **La Puerta**: fishing/longshoring, Maze Bank Arena.
  - **Blaine County**: Sandy Shores, Paleto Bay, Grapeseed, Mount Chiliad, Alamo Sea,
    Grand Senora Desert, Fort Zancudo, LSIA-adjacent industrial.
- **INFERRED DESIGN PATTERN** — Districts are differentiated by building height/age, street
  width, vegetation, prop palette, NPC mix, traffic mix, and audio — not by signs alone.
  Socioeconomic gradient is spatially legible (hills = rich, flats/industrial = poor).

## Island Strike translation (target district plan → `data/reconstruction/island_target_districts.json`)

| GTA V pattern (reference label) | Island Strike original district |
|---|---|
| Downtown core (Pillbox/Mission Row) | **Harbor City Core** — high-rise financial spine + old town |
| Vinewood entertainment | **Neon Mile** — entertainment/nightlife corridor |
| Rockford Hills | **Crown Heights** — hillside affluent residential |
| Vespucci beach/canals | **Sunset Strand** — beach, boardwalk, canals, marina |
| Port/South LS industrial | **Ironworks** — container port, freight rail, warehouses |
| East LS oil/industry | **Refinery Flats** — plants, tank farms, worker housing |
| LSIA | **Palmetto International** — airport zone w/ approach corridors |
| Sandy Shores/Blaine rural | **Dustbowl** — desert/dry zone, small town |
| Grapeseed farmland | **Greenbelt** — farms, orchards, wind turbines |
| Mount Chiliad wilderness | **Sentinel Ridge** — mountains, trails, viewpoints, cabins |
| Fort Zancudo | **Camp Halberd** — restricted military (already exists, rescale) |

- **ISLAND STRIKE DECISION (P05/P06)** — 8 legacy districts migrate into ~11–13 target districts
  with explicit identities, palettes, density profiles, and transition bands. No district exists
  "because a sign says its name" — each needs geometry + population + traffic + audio identity.

## Open questions

- **OPEN** — Exact district polygon layout for the circular map: produced in P02 as the
  deterministic map database (sector→district assignment), reviewed in P05/P06.
