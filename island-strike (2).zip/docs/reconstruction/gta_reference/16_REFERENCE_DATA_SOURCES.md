# 16 — REFERENCE DATA SOURCES & CONFIDENCE

Consulted this session (2026-09-19). Tier: 1 = official, 2 = community wiki, 3 = forum/observed,
4 = analysis/inference-rich.

| # | Source | Tier | Used for | Confidence |
|---|---|---|---|---|
| 1 | Rockstar Games — GTA V: The Manual (official manual app/site listing) | 1 | player-facing structure: map/GPS, phone, services, activities, radio | HIGH for existence of features; LOW for numbers |
| 2 | gta.fandom.com — "Wanted Level in GTA V" | 2 | 5-star scale, per-star response, jurisdiction, decay rules | HIGH (multiple consistent articles) |
| 3 | Neoseeker GTA 5 Wiki — "Wanted Level" | 2 | cross-check per-star behavior (sight cones, arrest penalties) | MEDIUM |
| 4 | gta.fandom.com / rockstargames.fandom.com — "Los Santos (HD Universe)" + district pages (Vinewood, Rockford Hills, Downtown Vinewood) | 2 | district/neighborhood inventory, street-name classes, landmarks | HIGH for names/structure |
| 5 | GTAForums — "The most accurate GTA map comparison ever" | 3 | map-area measurements + rebuttal of the 49 sq mi figure | MEDIUM (methodology shown, community polygons) |
| 6 | Reddit r/GrandTheftAutoV — "Los Santos is only 3.4 square miles" thread (cites GTAForums mapping analysis) | 3 | dense-core vs county area split | MEDIUM |
| 7 | gtavlovers.com / u7buy.com map guides | 3/4 | area estimate spread (75.8–127 km²) — used only to show disagreement | LOW — context only |
| 8 | Medium — "GTA V as a Landmark of Open-World Design" (cites Denham & Spokes 2021; Chesher 2012; Dignum et al. 2009) | 4 | ped/traffic behavior by district, socioeconomic legibility | MEDIUM for patterns; academic citations not independently verified — VERIFY |
| 9 | DEV.to — "From 2D Streets to Living Worlds" | 4 | streaming/LOD reasoning framing | LOW — treated as INFERRED material only |
| 10 | GTA5-Mods — "Dynamic Population Density" (+ similar) | 3 | evidence that time-of-day density control is a community gap → vanilla tables unverifiable | Used only as a negative-evidence marker (VERIFY) |

## Rules applied

- No number entered `data/reconstruction/*.json` from a LOW-confidence source without a
  `confidence: LOW/VERIFY` field and `measurement_basis` note.
- Where sources disagreed (map area), the dossier records the disagreement, never a false
  average.
- Official manual content is described structurally (features exist); we never quote or
  redistribute manual text or assets.
