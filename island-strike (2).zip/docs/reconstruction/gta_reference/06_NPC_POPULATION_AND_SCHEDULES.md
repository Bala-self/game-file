# 06 — NPC POPULATION & SCHEDULES

## Evidence

- **DOCUMENTED FACT (manual)** — The world is populated by pedestrians with daily routines;
  the manual describes shops, activities, and crowds as player-facing structure.
- **OBSERVED** — Peds vary by district (business suits downtown, beach crowd at Vespucci,
  workers industrial, tourists Vinewood), react to player actions (fear/anger/curiosity),
  use phones, sit, jog, walk dogs, argue. Nightlife districts stay busy late; business
  districts empty at night. Police presence is heavier downtown/at night (attested by players;
  exact tables VERIFY).
- **INFERRED DESIGN PATTERN** — Population = archetype pools × density fields × time-of-day
  schedules × simulation tiers (full AI near player, simplified far, absent beyond). Density is
  authored per district, not uniform.

## Island Strike decisions

- **ISLAND STRIKE DECISION (P11)** — Extend `person.gd` + 7 subclasses into an archetype system:
  per-district pools (suit, tourist, worker, student, beachgoer, farmer, soldier-off-duty…),
  schedules (home→work→leisure→home with time windows), group spawning (couples, tourists
  clusters), non-repetitive selection (weighted shuffle w/ memory).
- **ISLAND STRIKE DECISION (P11)** — Density fields per sector from
  `island_target_density.json` (ped_density per district × hour curve), replacing the current
  single small active-count target. T0–T4 tiers (existing) stay; budgets attach per sector.
- **ISLAND STRIKE DECISION (P11/P12)** — Witness system (existing 28 m radius) gains memory +
  reporting latency + district-sensitivity (crowds report faster than empty streets).

## Open questions

- **VERIFY** — Vanilla ped counts per area (no official figures; community counts vary with
  platform/settings). Island Strike sets budgets by measurement, not by copying claims.
- **OPEN** — Interior-linked schedules (P11 needs P09 interior registry) — sequence dependency.
