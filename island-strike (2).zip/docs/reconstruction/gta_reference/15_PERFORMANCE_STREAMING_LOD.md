# 15 — PERFORMANCE, STREAMING & LOD

## Evidence

- **DOCUMENTED FACT** — GTA V is a streamed open world (loading screens only at session start /
  character switches in story mode) — observable fact of the shipped product.
- **INFERRED DESIGN PATTERN (technical analyses)** — Streamed worlds manage memory pressure via
  relevance tiers: near = full sim+render, mid = reduced sim/LOD render, far = data only;
  actors are pooled; physics gated by distance; interiors load on entry. Exact RAGE internals
  are not public — **VERIFY status for any specific claim.**
- **INFERRED DESIGN PATTERN** — Budget gates per subsystem (nodes, draw calls, memory) are
  what keep streaming from becoming frame-time chaos; measure, don't assume.

## Island Strike decisions

- **ISLAND STRIKE DECISION (preserve)** — The project's performance philosophy is already
  correct and locked: headless CI perf gates (phys ≤ 9 ms avg, worst frame < 13.5 ms,
  best-of-3 noise handling), STRESS suite, leak gates, node/mesh budgets
  (PERFORMANCE_BUDGET.md). Never weaken a test to get PASS.
- **ISLAND STRIKE DECISION (P02)** — Sector streaming extends the existing Streamer
  (75 m tiles, 1-ring pre-activation, OPS_PER_FRAME budget) rather than replacing it:
  500 m sectors own sim tiers; existing tiles keep owning render/collision LOD inside active
  sectors. Budget: sector activate ≤ 8 ms, deactivate ≤ 4 ms (to be measured and re-set after
  P02 baseline — these are starting hypotheses, not final numbers).
- **ISLAND STRIKE DECISION (P20)** — Full budget table re-baselined on target hardware
  (RTX 3050 4 GB / 1080p, per PERFORMANCE_BUDGET.md) with GPU-side captures.

## Open questions

- **VERIFY** — NavGrid rebuild cost at 6 km (6 m sampling over 28 km² ≈ 786k cells vs today's
  ~17k) — must be measured in P02/P04 before adopting; likely needs chunked bake + sector
  invalidation.
