# 01 — WORLD MACRO-GEOGRAPHY

## Evidence

- **DOCUMENTED FACT** — GTA V's setting is the city of **Los Santos** plus the surrounding
  countryside of **Blaine County** (state of San Andreas), a fictionalized Southern California.
  (Official manual / Rockstar site.)
- **OBSERVED/MEASURED** — No official area figure exists. Community measurements disagree by
  methodology: ~**75.8–81 km²** (land+water, tight bounds) up to ~**127 km² (49 sq mi)** for the
  full map bounds including water (GTAForums "most accurate map comparison" disputes the 49 sq mi
  figure as overstated). **Confidence: LOW — VERIFY.** Treat all as estimates.
- **OBSERVED/MEASURED** — The dense urban core of Los Santos measures roughly **3.4 sq mi
  (~8.8 km²)** by one community polygon; Los Santos County ~11 sq mi (~28.7 km²). (GTAForums
  mapping analysis via Reddit.) Confidence: MEDIUM (community polygons).
- **DOCUMENTED FACT** — The world contains ocean coastline west/south, an inland sea (Alamo Sea),
  a river, a mountain (Mount Chiliad) in the north, desert (Grand Senora), farmland, forest,
  an international airport (LSIA), a container port, and a military base (Fort Zancudo).
- **INFERRED DESIGN PATTERN** — The world reads as one continuous landmass because transitions
  are gradual and every macro-zone is anchored by a visible landmark (skyline, mountain, sea,
  airport towers). Zone identity changes over kilometers, not meters.

## Island Strike decisions

- **ISLAND STRIKE DECISION (P01)** — Target envelope: circular, center (0,0), radius 3000 m,
  diameter 6000 m, mathematical area **28.274 km²** — comparable in magnitude to community
  estimates of Los Santos County (~28.7 km²). The envelope is locked in
  `scripts/world/world_contract.gd` (single source of truth; 41-gate test).
- **ISLAND STRIKE DECISION (P02/P03)** — One continuous landmass; urban core offset toward one
  side, mountains on another, coast wrapping the circle. Macro-zones: downtown core, commercial
  ring, suburbs, industrial/port, airport, beach/coast resort, farmland, mountains/wilderness,
  military. Zone adjacency must mirror GTA's gradual transition principle.
- **ISLAND STRIKE DECISION (P03)** — Authored land out to `LAND_RADIUS_M = 2700`; 2700–3000 m
  ring is coast/beach/cliff/shallows; hard playable edge at 3000 m; ocean renders beyond.

## Open questions

- **VERIFY** — GTA V coastline length and road length: no trustworthy public measurements; do
  not invent numbers. Island Strike sets its own targets in `island_target_world.json` and
  measures its own build against them.
- **OPEN** — How much of the 3 km circle should be water/inland lake vs land? Decide in P03
  after terrain massing tests (candidate: ≤12% inland water of envelope area).
