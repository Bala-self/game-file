# 04 — TRANSPORT & TRAFFIC

## Evidence

- **DOCUMENTED FACT (manual/wiki)** — The world supports road vehicles (cars, bikes, buses,
  taxis, trucks, emergency), boats, helicopters, planes, and a freight rail system; the player
  can use all of them.
- **OBSERVED** — Traffic drives on the right, obeys signals, changes lanes, reacts to
  collisions/near-misses, and reroutes around blockage. Vehicle mix varies by district:
  luxury/sports cars concentrate in Vinewood & Rockford Hills; older/damaged vehicles dominate
  low-income districts; industrial zones produce trucks; buses run fixed corridors; taxis hail.
- **OBSERVED** — Traffic density varies by time of day and area (rush-hour effect is commonly
  reported; the strongest public time-of-day density material is community mods — treat exact
  vanilla schedules as **VERIFY**, but directional variance itself is well-attested).
- **INFERRED DESIGN PATTERN** — Traffic is spawned/despawned around the player from lane
  splines with class-weighted pools per zone; continuity is maintained so cars don't visibly
  pop (spawn behind sightlines).

## Island Strike decisions

- **ISLAND STRIKE DECISION (P10)** — Keep the data-driven `CLASSES` model (9 road classes +
  speedboat today). Expand to ~16–20 classes via data only (no hardcoded vehicles): add
  hatchback, coupe, muscle, supercar, work truck, semi+cargo trailer, box truck, ambulance,
  fire truck, moped, scooter, dirt bike, cruiser bike, luxury sedan, off-road SUV.
- **ISLAND STRIKE DECISION (P10)** — Spawn pools per district profile (JSON), lane-following on
  the P04 graph, intersection yield rules, overtaking, curbside parking (existing
  `PARKED_SPOTS` → graph-derived parking slots), despawn/respawn continuity with hysteresis.
- **ISLAND STRIKE DECISION (P10)** — Public transport: 2–3 bus routes on arterials; taxis with
  hail interaction (existing taxi class is the seed).
- **ISLAND STRIKE DECISION (P12)** — Emergency vehicles route on the same graph (dispatch owns
  origin selection: station → incident).

## Open questions

- **VERIFY** — Vanilla per-hour traffic density curves (community-mod material only).
- **OPEN** — Freight rail: keep as decoration (current) or simulate slow freight trains (P10
  stretch goal — decide by cost measurement).
