# 12 — MAP, GPS, UI, PHONE & CAMERA

## Evidence

- **DOCUMENTED FACT (manual)** — The manual documents the interactive map, GPS route guidance to
  waypoints, radar/minimap with blips, the in-game phone (contacts, internet, camera), and
  radio stations while driving.
- **OBSERVED** — Route lines follow the road graph, reroute when the player deviates, and
  distinguish highway vs street coloring; off-route guidance returns via nearest legal road.
  Blips: mission (yellow), property (green), shop (icons), wanted-related (blue/red cones).
- **INFERRED DESIGN PATTERN** — The map UI is a renderer over the same spatial data as gameplay
  (roads/districts/services); no parallel hand-drawn dataset.

## Island Strike decisions

- **ISLAND STRIKE DECISION (P16)** — Production GPS: A*/Dijkstra over the P04 graph, route line
  on minimap + world map, turn guidance, reroute hysteresis, off-road snapping, mission
  navigation via objective→nearest-node; minimap already exists (locked) — extend, don't
  replace. This was already the project's declared v2.5 next phase (lock ledger).
- **ISLAND STRIKE DECISION (P19)** — Phone panel (exists, round 9) grows: map shortcut, mission
  log, economy summary; camera app as light P19 stretch.
- **ISLAND STRIKE DECISION (P19)** — Radio: original procedural/CC0 ambient tracks per vehicle
  class zone; no licensed content, ever.

## Open questions

- **OPEN** — Full-screen world map zoom levels & district labels (P16 design task, needs P02
  sector data).
