# 14 — SAVE, PERSISTENCE & WORLD STATE

## Evidence

- **DOCUMENTED FACT (manual)** — Saving at safehouses + autosave; progress, money, properties,
  vehicles (garages), weapons persist.
- **OBSERVED** — World state persistence is partial by design: ambient world (traffic, peds)
  is not persisted; mission progress, wanted (session), owned assets, and time-of-day are.
- **INFERRED DESIGN PATTERN** — Persist what the player owns/changed meaningfully; regenerate
  ambient simulation deterministically from seed + time.

## Island Strike decisions

- **ISLAND STRIKE DECISION (preserve)** — SaveSystem (atomic writes, SAVE_VERSION 3,
  per-version migration chain) is the locked persistence owner.
- **ISLAND STRIKE DECISION (P02/P18)** — World-coordinate migration: when the map contract
  changes, saves store positions in world units; migration must clamp/relocate positions via
  `WorldContract.clamp_to_playable` and nearest-legal-road snap. Save v3 → v4 adds: owned
  properties, garage vehicles, weapon loadout, sector-scoped world flags. Additive keys only —
  the existing migration chain pattern is proven.
- **ISLAND STRIKE DECISION (P02)** — Determinism: world build seed stays fixed
  (20260915 today); sector registry is derived, not saved — saves store only deltas.

## Open questions

- **OPEN** — Mid-mission save across a map-contract change (P02 must define: abort-to-checkpoint
  vs coordinate remap; candidate: abort to last checkpoint with notice — simpler, testable).
