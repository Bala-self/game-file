# 10 — SHOPS, SERVICES, PROPERTIES & ECONOMY

## Evidence

- **DOCUMENTED FACT (manual)** — The manual presents shops (clothing, 24/7 convenience),
  weapon stores (Ammu-Nation), vehicle customization garages (Los Santos Customs), barber/
  tattoo services, bars/food, real-estate purchase, and the in-game phone/internet as
  player-facing services.
- **OBSERVED** — Services are distributed so the player rarely crosses the whole map for basic
  needs: convenience stores dot residential strips; Ammu-Nation and LSC exist in multiple
  locations; safehouses serve as save/wardrobe anchors.
- **INFERRED DESIGN PATTERN** — Each service = interior (or counter) + interaction contract +
  persistent state (owned items, vehicle mods, property ownership) + money sink/source.

## Island Strike decisions

- **ISLAND STRIKE DECISION (P07/P09/P18)** — Service registry (`island_target_services.json`):
  categories {gun_shop, clothing, convenience, food, barber, garage_mod, fuel, hospital,
  police_station, fire_station, safehouse, property_sale, impound, marina, airfield};
  per entry: district, sector_id, interior_group, interaction contract id, respawn rules.
- Spacing targets (original numbers, not copied): convenience ≤ 700 m in urban core, ≤ 1200 m
  suburbs; gun shop ≥ 1 per 2 km² urban; hospital ≥ 2; police stations ≥ 3 (one per
  jurisdiction); fuel along arterials/rural.
- **ISLAND STRIKE DECISION (P18)** — Economy (locked owner) extends: property deeds, garage
  ownership, weapon/vehicle purchase persistence (save v3 → v4 additive keys), exploit-resistant
  ledger (existing TRANSACTION events).

## Open questions

- **OPEN** — Hospital respawn vs current bust/death flow integration (P18 + P12 alignment).
