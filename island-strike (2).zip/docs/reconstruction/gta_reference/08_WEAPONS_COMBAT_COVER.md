# 08 — WEAPONS, COMBAT & COVER

## Evidence

- **DOCUMENTED FACT (manual/wiki)** — Weapon categories: melee, pistols, SMGs, rifles (incl.
  carbine/special carbine), shotguns, sniper, heavy (RPG/minigun), throwables (grenades,
  sticky bombs, molotovs), plus armor. Manual documents aiming, cover usage, and vehicle
  drive-bys as player verbs.
- **OBSERVED** — Cover is a snap-to system (stick to low walls/vehicles, blind-fire or
  aim-over-cover); NPCs use cover too; headshots matter; police/NPC accuracy scales with
  situation; drive-by from most vehicles.
- **INFERRED DESIGN PATTERN** — Data-driven weapon tables (damage/rate/spread/falloff per
  weapon) with shared ballistic resolution; per-weapon ergonomics (ADS zoom, move speed).

## Island Strike decisions

- **ISLAND STRIKE DECISION (locked, preserve)** — The 7-weapon data-driven architecture
  (`weapon_data.gd` w/ ballistics + ergonomics + `validate_all()`, WEAPON_RESULT 15/15) is the
  foundation. Prompts extend the data, not replace the layer.
- **ISLAND STRIKE DECISION (P15)** — Add: carbine/rifle expansion, sniper w/ scoped ballistics,
  throwables (grenade/sticky), melee combo layer, armor/vest system, NPC weapon loadouts by
  faction (police: pistol→carbine by star; gang: mixed; military: rifle), hit reactions,
  ragdoll on death (existing), damage model per body zone, pickups + ammo economy (existing).
- **ISLAND STRIKE DECISION (P15)** — Cover: snap-to via raycast-tagged cover props (streetscape
  kit already places walls/cars; add `cover_point` metadata in P08 building kit).
- **ISLAND STRIKE DECISION (P15)** — Drive-by from car/moto classes using existing window/lean
  anchors.

## Open questions

- **OPEN** — Projectile (physical) vs hitscan split: current is hitscan w/ falloff; snipers and
  throwables need real projectiles — budget physics cost first (P15 measurement gate).
