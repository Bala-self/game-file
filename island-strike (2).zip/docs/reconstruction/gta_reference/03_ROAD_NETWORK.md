# 03 — ROAD NETWORK

## Evidence

- **DOCUMENTED FACT (community wiki street lists)** — GTA V's network has explicit named
  classes: freeways (e.g., Los Santos Freeway, Great Ocean Highway, Senora Freeway), boulevards
  (Vespucci Blvd, Vinewood Blvd, Strawberry Ave, Portola Drive), local streets, alleys, and
  rural/dirt roads in Blaine County. Street names are listed per district on the wiki.
- **OBSERVED** — Hierarchy behavior in play: freeways carry high-speed through-traffic with
  on/off-ramps and no at-grade crossings; arterials have traffic lights and turn lanes;
  residential streets are narrow with parking; alleys serve as shortcuts/pursuit routes.
- **INFERRED DESIGN PATTERN** — The network is a connected graph: any two points are reachable
  without teleport logic; alternate routes exist at multiple scales (freeway vs surface); the
  rail corridor runs parallel-but-separate. Emergency response depends on this connectivity.

## Island Strike decisions

- **ISLAND STRIKE DECISION (P04)** — Replace rectangle-segment roads with an explicit **road
  graph**: nodes (intersections) + edges (segments) with attributes:
  `class ∈ {freeway, arterial, collector, local, alley, rural, service}`, `lanes_each_way`,
  `speed_limit_kmh`, `sidewalk(bool)`, `median(bool)`, `oneway`, `turn_restrictions`,
  `bridge/tunnel flag`, `nav_cost`. Schema: `data/reconstruction/island_target_road_hierarchy.json`.
- Current `wb_kit.ROAD_CLASSES`/`ROAD_RULES` dicts are the migration seed — extend, don't discard.
- **ISLAND STRIKE DECISION (P04)** — Target hierarchy for 6 km circle: 1 ring freeway (r≈2400),
  2–3 radials, 1 inner loop (r≈900), grid arterials in the core (≈400 m spacing), collectors
  (≈200 m), locals (≈100 m), alleys in old town/industrial only. Legal road area capped by
  `WorldContract.ROAD_LIMIT_RADIUS_M = 2900` (test-enforced).
- **ISLAND STRIKE DECISION (P16)** — The same graph powers GPS routing; visual roads without
  graph edges are forbidden (no fake roads).

## Open questions

- **VERIFY** — GTA V total road-km: no trustworthy public figure. Island Strike target set in
  its own data file (candidate 250–350 km total graph length) and verified by build measurement.
- **OPEN** — Tunnel count (candidate: 2 — downtown bypass + ridge pass). P03/P04 decision.
