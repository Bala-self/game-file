# 09 — MISSIONS, ACTIVITIES & RANDOM EVENTS

## Evidence

- **DOCUMENTED FACT (manual/wiki)** — Content layers: three-protagonist story missions; "Strangers
  & Freaks" side characters; random street events (muggings, accidents, chases); activities
  (golf, tennis, darts, shooting range, cinema, triathlon, stunt jumps, parachute); collectibles
  (spacecraft parts, letter scraps, nuclear waste); property/business income; races.
- **DOCUMENTED FACT (wiki)** — Some missions force wanted levels or scripted set-pieces; failure
  states restart at checkpoints.
- **INFERRED DESIGN PATTERN** — One mission engine, many content archetypes expressed as data
  (objectives, triggers, rewards, failure rules). Random events are lightweight spawn-and-react
  scripts tied to location/time, not full missions.

## Island Strike decisions

- **ISLAND STRIKE DECISION (locked, preserve)** — MissionManager stays the sole orchestration
  owner (states, single-active, checkpoints, exactly-once rewards, save/restore — 97/97 gates).
- **ISLAND STRIKE DECISION (P17)** — Content universe as data layered on the 6-archetype base:
  story chain (8–12 missions), contact jobs (repeatable, tiered), races (existing race.gd →
  graph routes), deliveries (existing), robberies w/ wanted gates (existing warehouse pattern),
  escorts (existing safe_passage), eliminations (existing), NEW archetypes via additive
  objective types only (e.g., FOLLOW, SURVIVE_TIMER, DEFEND_ZONE, PHOTO).
- **ISLAND STRIKE DECISION (P17)** — Random events via existing `event_manager.gd`: mugger,
  carjack-in-progress, stuck vehicle, street race invitation, medical emergency — location and
  time weighted, police/ped reaction through existing systems.
- **ISLAND STRIKE DECISION (P17)** — Collectibles: existing 20 packages scale to a
  registry-driven set (P18 progression hooks).

## Open questions

- **OPEN** — Legacy `scripts/world/delivery.gd` + `race.gd` + `collectible.gd` (pre-framework):
  migrate into MissionManager content or keep as world toys? Decide with evidence in P17.
