# P03 — MASTER TERRAIN RECONSTRUCTION (v2.5.1)

Prompt 03/20 lock document. Status: **LOCKED — CI_RESULT: PASS (16 slots),
TERRAIN_RECON_RESULT: ALL PASS (55/55)**, world_data IDENTICAL, mission 97/97 ×3.

---

## 1. Reference-data sources

Tiered in detail in `P03_TERRAIN_REFERENCE_PACK.md`. Summary:

| Tier | Source | Use |
|---|---|---|
| DOCUMENTED FACT | P01 dossier (docs/reconstruction/, rockstargames.fandom / gta.fandom citations) | GTA V world *structure*: coastal basin city, northern mountain county, countryside ring, district taxonomy |
| OBSERVED / MEDIUM | gtaforums "Height of Mt. Chiliad" thread citing gta.wikia | Chiliad ≈ 2619 ft ≈ 798 m in a ~76–127 km² world |
| DESIGN REFERENCE | standard geomorphology (ridge/valley forms, beach slopes 2–8°, alluvial plains, drainage basins, graded platforms) | shaping vocabulary only — no data copied |
| ISLAND STRIKE DECISION | this project | scale decisions (below), all authored coordinates |
| FORBIDDEN, honored | — | no proprietary Rockstar map data, no heightfield rips |

Scale decision: Island Strike is 28.3 km² (r=3000 m). Scaling the Chiliad
ratio down proportionally would give ~370–470 m; **ISLAND STRIKE DECISION:
ceiling 320 m contract / ~297 m built summit** — traversal time and camera
readability matter more than proportional realism at this world size.

## 2. Design interpretation

Intentional macro geography, not noise:

- **Central urban lowland** — engineered platform, exactly flat 0.0 for r ≤ 700 m
  (preserves the locked flat contract and every legacy prop at r ≤ 673).
- **Suburban ring** — 700→1150 m C1 handover into the regional field.
- **West/SW coast + beaches** — authored bay (bearing 183°±24°, shore r=760,
  depth −9) preserving the legacy beachfront/offshore-islet composition, plus
  the legacy marina as an engineered basin.
- **Eastern industrial flats** — port/heavy-industrial wedges at 4–10 m with
  the legacy offshore island kept genuinely offshore via the east harbor carve.
- **N/NW mountains** — Sentinel Ridge district wedge (265–315°): 2 ridges,
  6 peaks (summit ≈ 297 m), 2 valleys, foothill ramp 1250→2050 m.
- **NW hills / countryside / rural ring** — district-profile blend (see §4).

## 3. Old terrain limitations (why reconstruction, not stretch)

The P02-inherited `height_at` was a 900×700 m hybrid patch: gated behind
`activate` (runtime false — shipped world was flat), legacy noise constants
(SEED 7717, amplitude 18 m) sized for the old rectangle, mountains only as
hand-placed boxes in env, no coastline/river/slope semantics, no metadata
beyond 7 flat-district rects. Stretching it to 6 km (explicitly forbidden)
would have multiplied every constant and kept a rectangle imprint inside a
circular world. The legacy path is instead **preserved bit-identical** as a
locked sub-path (terrain_test h=21.3151 gate) and the new macro field is the
runtime truth everywhere else.

## 4. New master terrain specification

Single source of truth: `WorldTerrain.height_at(x, z)` →
`scripts/world/terrain.gd`. Dispatch order (contractual):

1. outside world circle → `OUT_OF_WORLD_Y` (−3.0);
2. legacy activated zone (`activate && active_zone`) → `_legacy_zone_height`
   — verbatim frozen formula (CI-locked value 21.3151);
3. legacy flat districts → exactly 0.0;
4. `_macro_height(x, z)` — the P03 field, composition:

```
regional blend (district wedges, JSON-shared with the registry)
  + mountain system (window × [ridges + peaks − valleys])
  + detail fbm (3 octaves from 240 m, decorrelated hash offsets 64+)
  + lake basin
  + river carve (monotonic bed + floodplain, blend-back edge)
  × coastal shaping (authored land-end, relief-scaled transition)
  × platform blend (smoothstep 700→1150, C1)
  + legacy-compat carves (marina basins, east harbor)
  → soft-knee ceiling (320) → clamp [−18, 320]
```

District relief: 13 wedges parsed from the SAME
`data/reconstruction/island_target_districts.json` the registry uses
(`WorldSectorRegistry.district_table()`), angular-Gaussian edges (14°),
radial ramp 900→1900 m, constant-weight default member (0.12) — no
thresholds, no hard wedge seams. Authored data lives in
`scripts/world/terrain_authoring.gd` (class `TerrainAuthoring`); adding a
ridge/peak/valley/river point is a data edit, not an engine edit.
No RNG anywhere — every value is a pure function of (x, z).

## 5. Elevation contract

| Constant | Value | Authority |
|---|---|---|
| `TerrainAuthoring.SEA_LEVEL_M` | −1.3 | single literal `= WBKit.WATER_Y` |
| `WORLD_MIN_HEIGHT_M` | −18 | clamp |
| `WORLD_MAX_HEIGHT_M` | 320 | clamp + soft knee (`MAX_KNEE_M` 35) |
| `PLATFORM_RADIUS_M` / `PLATFORM_BLEND_OUT_M` | 700 / 1150 | flat contract |
| `OUT_OF_WORLD_Y` | −3.0 | unchanged |

Built summit ≈ 297 m (Sentinel Peak, authored 160 m amp at (120, −2520) over
ridge/region base; the soft knee prevents a clamp-rim terrace).
Road grade limits (§13/P04 contract): freeway 4%, arterial 6%, collector 8%,
service 8%, local 10%, rural 12%, trail 20%.

## 6. Water contract

- Ocean: existing 6000×6000 shader plane at `WATER_Y` −1.3 (unchanged).
  Coastline = terrain ∩ water: wherever `height_at < −1.3` the ocean shows.
- `is_water_position`: h < SEA − 0.05. `water_depth_at`, `distance_to_water`
  (16 rays × 20 m, 600 m cap, −1 beyond).
- **Inland water** (river/lake) exists ABOVE sea level, so it needs its own
  surfaces: `has_inland_water`, `water_level_at` (river = bed + 0.9,
  lake = `LAKE_LEVEL_M` 4.0, ocean = −1.3, else −INF) and the visual meshes
  `RiverWater` / `LakeWater` (env `_build_inland_water`; no collision — P08).
- Water never sits below its bed or above its banks (gate 30).

## 7. River architecture

- Authored 9-point path (480, −2280) → (2050, 1850), north valleys to the SE
  sea; passes through the lake.
- **Monotonic bed**: built once from the pre-river field as
  `bed_i = min(field_i − 2.6, bed_{i−1} − 1.0)` — Phase F QA found the raw
  bed *rose* 5.2→13.7 m downstream (no continuous water surface possible on
  that); locked values: 174.9, 103.1, 20.1, 6.2, 5.2, 4.2, −0.1, −1.1, −18.5.
- Channel: cap to `bed + 2.6·smoothstep(0, w, d)`; floodplain terrace −1.1 m
  out to 2.6 w with blend-back 1.6 w→2.6 w (a bare min-cap left a 9 m bench
  cliff — Phase F fix).
- Width 8→26 m by **arc-length** u along the path (per-node lookups jumped up
  to 9 m at Voronoi boundaries — Phase F fix; `_river_project` is the single
  continuous projection used by width, bed and distance).
- Banks deterministic; `RIVER_BRIDGE_ANCHORS` (760, −1100), (1250, −150),
  (1700, 900) reserved for Prompt 04 crossings.
- Lake: (1620, 950) r 340, level 4.0, floor 2.5 — inflow rapid ≈ 1.1 m,
  outlet fall ≈ 3.2 m (both read as natural features, both continuous).

## 8. Mountain architecture

Window = registry `mountain_wild` wedge (265–315°) × foothill ramp
smoothstep(1250, 2050, r). Inside: 2 gaussian ridges (amp 85 σ 430;
amp 105 σ 380), 6 landmark peaks (max amp 160 σ 380), relief detail scaled by
district relief. Slopes exceed urban grade limits by design (measured to
430% on ridge walls; extreme >60% covers 1.6% of land cells).

## 9. Valley architecture

2 authored valleys (depth 55 σ 300; depth 40 σ 250) subtracted inside the
mountain window only (`max(ridges+peaks − valleys, 0)` — valleys never cut
the lowlands). Drainage reads: valley axes point at the river corridor; the
river itself is the drainage spine (monotonic bed, §7).

## 10. Terrain class taxonomy

`surface_class_at` (16 classes, deterministic from field state, **elevation
band takes precedence over district label** — the registry assigns the far NW
coast strip to beach_resort by priority, but a 297 m summit is MOUNTAIN
whatever the label):

WATER, URBAN_LOWLAND, SUBURBAN_HILL, RURAL_GRASS, FOREST, FARM_FIELD,
MOUNTAIN, FOOTHILL, ROCK, BEACH, WETLAND, CLIFF, RIVERBANK,
INDUSTRIAL_FLAT, PARKLAND, COASTAL_URBAN.

`coast_class_at` (shoreline, for P08): OPEN_WATER, MARSH, WETLAND,
RIVER_MOUTH, RIVERBANK, INLAND, ENGINEERED_SEAWALL, MARINA, CLIFF,
NATURAL_BEACH, ROCKY_SHORE. `elevation_band_at`: below_sea / coastal_0_10 /
lowland_10_60 / highland_60_150 / mountain_150_plus.

## 11. Sector integration

Registry owns **metadata only**; all terrain math stays in WorldTerrain
(no duplication): `district_table()`, `terrain_class_at`,
`terrain_profile_for_sector`, `water_state_for_sector`, `dominant_slope_class`,
`elevation_band` — thin delegations, verified by gate 38. `resolve_to_ground`
returns {x, z, ground_y, normal, slope_deg, sector, surface, water} for
spawns/saves (§40 of the prompt); save sanitization (P02) already clamps
positions to the inset circle (gate 49).

## 12. Chunk / LOD strategy

`scripts/world/terrain_chunks.gd` (`TerrainChunks`): 250 m chunks, 12×12
quads (169 verts, 20.83 m spacing), world-spaced vertices, per-chunk trimesh
body `TerrainBody_T_gx_gz` + vertex-colored mesh `TerrainChunk_T_gx_gz`
(single shared material). Built: **439 chunks, 74 k verts, ~115 k tris,
~2.5–3.1 s** (gate 51 budget 6 s). Skips: chunks entirely below SEA−2 (ocean
plane suffices) or entirely inside the legacy sand rect; vertices inside the
sand rect go to −0.25 (hidden underlay, no Z-fight with the sand skirt).
LOD: `visibility_range_end` 4200 m (max_h > 60) / 1700 m, FADE_SELF.
Chunk borders share grid vertices — seam-free by construction (gate 11).

## 13. Collision strategy

No far full-collision anywhere: chunk bodies are **excluded from the tile
streamer** (a 250 m body spans up to four 125 m sectors — tile ownership
would flicker) and are distance-streamed by `ChunkCollisionStreamer`
(collision ON inside 700 m of the player, layer 0 beyond — gates 42/43:
410 far bodies, 0 hot). `WorldBoundsGuard` (new, game.gd) clamps player +
vehicles to RADIUS−3 = 2997 m every physics tick — the P02 actor-containment
open item is closed (gate 56).

## 14. Test results

- `tests/terrain_reconstruction_test.gd` (+ `terrain_live_node.gd`):
  **TERRAIN_RECON_RESULT: ALL PASS (55/55)** — all §34 gates, plus 10 §35
  anomaly-detector QA lines (spikes, checkerboard, 250 m autocorrelation,
  active_zone imprint, radial symmetry, coastline smoothness, ridge/valley
  variety, height variance, slope distribution, waterline continuity) and
  1 extra bounds-guard gate.
- Locked suites unchanged: terrain_test ALL PASS (flat contract, 21.3151,
  patch agreement), foundation 63/63, contract 41/41, mission 97/97 ×3,
  smoke ALL PASS (incl. boat throttle — see §17 Phase F), world_data
  **IDENTICAL** (terrain is outside the world_data contract — compatibility
  PROVEN, baseline NOT regenerated, per prompt §48).
- **CI_RESULT: PASS — 16 slots** (terrain_reconstruction added).

Phase F defect log (each caught by a §34/§35 gate, fixed at source):
1. radial ramp inside blend weights cancelled out + wsum threshold → 0→70 m
   cliff in 5 m (gate 12); 2. wedge lo-side edge inverted (gate 12 trace);
3. river bed rising downstream (gate 27/30); 4. lake designed but never
   embodied (probe); 5. platform disc dried out the legacy marina → boats
   grounded (smoke boat gate); 6. east "offshore" island became connected
   (probe) → harbor carve; 7. floodplain min-cap bench cliff (gate 13);
8. hard 320 clamp terrace rim (gate 21); 9. fixed 110 m coast window made
   250 m vertical walls where mountains meet sea (gates 12/21 + waterline);
10. first soft-knee formula sign-inverted (gate 12 caught it immediately).

## 15. Performance (measured, budgets untouched)

| Metric | P02 lock | P03 measured | Budget |
|---|---|---|---|
| worst frame (perf_probe) | 4.44 ms | **6.25 ms** | < 13.5 (unchanged) |
| terrain chunk build | — | 2.5–3.1 s | < 6 s (gate 51) |
| 20 k height_at queries | — | 471 ms | < 1200 ms (gate 52) |
| scene nodes | 9 340 | **10 640** (+1 300 chunks) | < 11 500 (gate 53) |
| MeshInstance3D | 5 177 | **5 610** (+433) | < 6 100 (gate 54) |
| long-traversal memory | — | +116 KB / 6 hops | < 6 MB (gate 55) |
| world_data | 227 lines | IDENTICAL | unchanged |

Frame-time rose 4.44 → 6.25 ms (433 chunk meshes + inland water + heavier
height_at); the budget was NOT raised. If P04 pressure appears, the first
levers are chunk-mesh visibility tiers and height_at memoization at chunk
build — optimize before architecture.

## 16. Visual QA

Headless CI cannot measure GPU screenshots (standing policy — respected).
Capture procedure for a GPU machine (`--rendering-driver opengl3`, windowed,
`DebugTools.cmd("toggle_world_grid")` overlay showing world circle, sectors,
river centerline + snapshot elev/slope/wl/class/coast/chunks):

SHOT 01 full 6 km top-down (cam 0, 3200, 0 looking down) · 02 central urban
lowland (0, 60, 0) · 03 urban-to-hill transition (900, 80, −500) ·
04 foothill-to-mountain (800, 150, −1800) · 05 mountain valley (330, 120,
−2100) · 06 river corridor (1250, 40, −150 looking SE) · 07 coast+beach
(−700, 30, 300 west bay) · 08 coast-to-hill (2300, 60, 1300) · 09 industrial
flatland (1600, 40, −200) · 10 rural/farm (−400, 60, −1900) · 11 sector
boundary close-up (625, 20, 625) · 12 high-speed traversal (drive 4+ sectors
on the freeway, motion blur off).

## 17. Known limitations

- River/lake water surfaces are visual meshes without collision or flow
  simulation — P08 owns water interaction (boats currently buoy on the fixed
  ocean plane; the legacy marina boats work unchanged on the basin carve).
- Single ocean plane at −1.3: no tides, no depth shading beyond the shader.
- `palmetto_intl` (airport) wedge overlaps the west bay — those sectors
  report `water_state = water`; documented OPEN QUESTION for P08 (pier /
  reclaimed-flat decision), registry untouched.
- Terrain classes render as vertex colors (no texture splatting yet).
- Chunk meshes stay resident (visibility-culled, memory bounded per gate 55);
  mesh streaming can be added later without touching the field.
- The legacy activated-zone path remains for the locked determinism gate
  only; runtime never sets `activate`.

## 18. Next phase

**STOP after P03** (prompt directive). Prompt 04 = road network: grade limits
(§5 table) and `is_road_viable` / `nearest_low_grade_direction` are in place,
the 3 river bridge anchors are authored, and the monotonic river bed gives
deterministic crossing elevations.
