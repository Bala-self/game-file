# P03 TERRAIN REFERENCE PACK — source tiering

Companion to `P03_TERRAIN_RECONSTRUCTION.md` §1. Every external influence on
the terrain is tiered per the Prompt 01 evidence policy (DOCUMENTED FACT /
OBSERVED / INFERRED / ISLAND STRIKE DECISION / OPEN QUESTION). No proprietary
Rockstar map data, heightfield rips, or copyrighted assets were used.

## DOCUMENTED FACT (sourced in the P01 dossier)

- GTA V world structure: coastal basin metropolis (Los Santos), northern
  mountain wilderness (Blaine County / Mt. Chiliad), countryside and
  desert ring, airport adjacent to the urban coast, port/industrial
  waterfront, beach strip along the ocean bay.
  Sources: rockstargames.fandom.com, gta.fandom.com district taxonomies
  (citations archived in `GTA_V_WORLD_STRUCTURE.md`, P01).
- Map size has NO official figure; community estimates ≈ 75.8–127 km².
  (VERIFY/LOW confidence — used only as an order-of-magnitude ratio input.)

## OBSERVED / MEDIUM confidence

- Mt. Chiliad height ≈ 2619 ft ≈ 798 m (gtaforums "Height Of Mt. Chiliad in
  GTA V" thread citing gta.wikia; community-repeated). The GTA:SA-era Chiliad
  figure (≈ 526 m) is a DIFFERENT game and was discarded.

## INFERRED (engineering reasoning from the above)

- Mountain-to-world-size ratio: 798 m / ~100 km² → for Island Strike's
  28.3 km² a proportional peak would be ≈ 370–470 m.
- Real-world geomorphology vocabulary used for shaping (NOT data): gaussian
  ridgelines, V-shaped valleys pointing at drainage spines, alluvial
  floodplains widening downstream, beach face slopes 2–8°, cliff coasts at
  resistant rock, graded (engineered) urban platforms vs natural surrounds.

## ISLAND STRIKE DECISION (this project's authored choices)

- Ceiling: contract max 320 m, built summit ≈ 297 m (Sentinel Peak).
  Rationale: traversal time, camera readability, render silhouettes at
  6 km scale — over proportional scaling.
- Flat urban platform r ≤ 700 m with C1 blend to 1150 m (flat contract lock).
- Bay at bearing 183°±24°, shore r 760, max depth −9: preserves the legacy
  beachfront props (r ≤ 673) and offshore islet composition.
- District relief profiles (`TerrainAuthoring.TYPE_PROFILE`): downtown 0 m /
  historic 2 / entertainment 3 / port 4 / airport 5 / beach 6 / park 8 /
  heavy-industrial 10 / military 18 / farmland 35 / mountain base 55 /
  rural-dry 70 / affluent hills 80, each with its own relief amplitude.
- River: 9 authored control points, monotonic bed (≥ 1 m drop per reach),
  width 8→26 m, 3 bridge anchors held for P04.
- Lake (1620, 950) r 340, level 4.0 — river passes through it; inflow rapid
  and outlet fall accepted as natural features.
- Legacy-compatibility carves: west marina basins (both drivable boats) and
  east harbor (keeps the swim-destination island genuinely offshore).
- Chunk grid 250 m / 12×12 quads; collision stream radius 700 m;
  LOD visibility caps 1700/4200 m.

## OPEN QUESTIONS (carried forward, registry untouched)

- `palmetto_intl` (airport) wedge overlaps the west bay → some of its
  sectors report water. P08 decides: pier/reclaimed flats or leave as
  coastal water district.
- Whether inland water gains collision/flow simulation in P08 (boats,
  swimming) — surfaces are visual-only in P03 by design.

## Provenance hygiene

- All coordinates, profiles, ridges, peaks, valleys, river points, bay and
  coast parameters are ORIGINAL authored data in
  `scripts/world/terrain_authoring.gd` — editable without engine changes.
- Determinism: no RNG in the terrain field; the only seeded source (legacy
  `_hash2`, SEED 7717) is reused with decorrelated octave offsets ≥ 64.
