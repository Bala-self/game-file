# PROMPT 02 — SPATIAL MIGRATION INVENTORY

Every source of spatial truth located in Phase A, its status, and the test that proves the
migration state. Method: grep for Rect2 literals + dimension constants (450/350/900/700/1120/560/
410/317/303/267/75/12), then consumer tracing — comments were not accepted as evidence.

**Status legend:** MIGRATED (this prompt) · ADAPTER (legacy data preserved behind a query layer,
consumer migration owned by a later prompt) · INVENTORY (audit-only; behavior deliberately
unchanged per migration safety rule 2).

| # | File | Symbol | Current spatial assumption | New source of truth | Method | Test that proves it | Status |
|---|---|---|---|---|---|---|---|
| 1 | world/wb_kit.gd | `ISLAND`, `SAND` Rect2 | 900×700 rect is the world | `WorldContract` circle (gameplay authority); rects remain authored-content envelope | rects kept as data; playability now flows through WorldContract | foundation #1–8, #19c; world_data IDENTICAL | ADAPTER (rects retire as P03–P08 fill the circle) |
| 2 | world/wb_kit.gd | `ROADS`, `DIRT_ROADS`, `TRAFFIC_LIGHTS`, `COP_SPAWNS`, `COLLECTIBLE_SPOTS`, `PARKED_SPOTS`, `PLAYER_SPAWN`, `TRAFFIC_LOOP_A/B` | anchors inside the old rect | same values (all inside the 3 km circle — verified by tests); graph in P04 | none needed now; every coordinate is legal in the new world | foundation #28/#29 (beyond-rect streaming); world_data baseline | INVENTORY |
| 3 | world/world_builder.gd | `rng.seed = 20260915` literal | local seed constant | `WorldContract.WORLD_SEED` (same value) | seed authority unified; determinism unchanged | world_data IDENTICAL + terrain determinism | MIGRATED |
| 4 | world/world_builder.gd | `build()` return dict | 17 keys, no world metadata | + `"world": WorldContract.schema_dict()` (18 keys, schema v2) | additive key; baseline + tres intentionally regenerated | foundation #15–19; world_data_test | MIGRATED |
| 5 | world/world_data_res.gd | exports | no world schema field | `@export var world: Dictionary` + to_dict/from_dict | additive; tolerant of missing key | foundation #19a/b/c | MIGRATED |
| 6 | systems/streamer.gd | `TILE=75`, `GRID=12`, offset tile math, grid-bounds check | 12×12 tiles over the island rect | `WorldContract.MICRO_SECTOR_M` (125 m), unbounded sector dict, circle-validity filter | same band/hysteresis/player-tile contract; offshore geometry now sectors instead of always-on | foundation #20–30; smoke 945–949 band probes | MIGRATED |
| 7 | world/terrain.gd | `height_at` | rect/zone-limited domain | world-circle domain; `OUT_OF_WORLD_Y` outside; `chunk_sector_of`, `zone_clipped_to_world` helpers | guard fires only beyond 3 km — inner behavior bit-identical | foundation #36–40b; terrain_test (h=21.3151 unchanged) | MIGRATED |
| 8 | core/save_system.gd | `load_game` positions | any saved coord applied blindly | circle validation + clamp + `WORLD_MIGRATED` EventBus record; `"world"` marker on save | `_sanitize_spatial()`; idempotent; mission data untouched | foundation #31–35; mission suite 97/97; smoke legacy-save gate | MIGRATED |
| 9 | core/save_system.gd | `load_game` optional keys | `parsed["collected"/"stats"/"delivery"]` indexed after `.get` defaults | tolerant local-var reads | latent crash fixed at source (violated the file's own header contract) | foundation #31 is the regression guard | MIGRATED (bug fix) |
| 10 | ui/hud.gd | `_district_name()` | loops `world_data["districts"]` Rect2s | `WorldSectorRegistry.legacy_district_at_xz()` adapter (same data, one authority) | query layer introduced; NPC/HUD consumers move onto it incrementally | smoke district gate; menu_test | MIGRATED (adapter) |
| 11 | ui/hud.gd | `WorldMap.WORLD_MIN(-640,-460)`, `SCALE 0.52` | hard-coded world-size constants in UI | data-driven fit from `world_data["sand"]` + contract circle rendered from `WorldContract` | no world-size constant remains in any UI class | smoke (map scene builds/draws headless); foundation §25 overlay | MIGRATED |
| 12 | game/game.gd L88/L372/L521/L546/L732 | district Rect2 `.get(...)` fallbacks | districts are Rect2 | still Rect2 (adapter); sector districts arrive P05/P06 | untouched deliberately (rule 2: behavior stable via adapter) | smoke/world_data IDENTICAL | INVENTORY |
| 13 | game/game.gd L994–995 | traffic-light lane x-consts (−267, 53, −410) | light logic tied to legacy avenue coords | P04 road graph owns lanes | audit-only this prompt | smoke traffic-light gates | INVENTORY |
| 14 | npc/npc_civilian.gd L103 | hard-coded beach bounds | Rect2 thinking | registry adapter available; migrate with P06 districts | audit-only | civilian behavior gates in smoke | INVENTORY |
| 15 | npc/npc_police.gd L241 | hard-coded military bounds | Rect2 thinking | P06/P12 jurisdiction zones | audit-only | police gates in smoke/system | INVENTORY |
| 16 | npc/npc_gang.gd L9; npc/person.gd L269/L297 | territory default Rect2; district loops | Rect2 thinking | world_data adapter today; sectors P05/P06 | audit-only | smoke NPC gates | INVENTORY |
| 17 | systems/nav_grid.gd L100–101 | off-mesh link coords | legacy anchors | P04 nav rebuild; grid sampling cost flagged for P04 profiling (16,580 cells today) | audit-only | NAVMESH smoke gate (16580 cells, unchanged) | INVENTORY |
| 18 | world/districts/env.gd L103–116 | fog shader 560/450/900 falloff | world fog tuned to old extents | P03 environment rebuild | audit-only (visual) | render QA (GPU env) | INVENTORY |
| 19 | world/districts/coast.gd L221 + visibility 700/900 | offshore ring from rect corners; LOD ranges | old-map dressing | P03/P08 coast reconstruction | audit-only | smoke | INVENTORY |
| 20 | world/delivery.gd | route Vector3 list | legacy pre-framework toy | P17 migrate-or-retire decision | audit-only | smoke delivery gates | INVENTORY |
| 21 | missions/mission_defs.gd | objective positions (±560 m) | legacy-area anchors | all inside circle ⇒ valid; P16/P17 re-place on graph | none needed | mission suite 97/97 (untouched) | INVENTORY |
| 22 | world/terrain.gd | `active_zone: Rect2` | zone API is Rect2 | kept as API + `zone_clipped_to_world()`; P03 chunks sectors | additive helpers | foundation #40b | ADAPTER |
| 23 | game/player camera | no explicit `far` override found (Camera3D default ≈4000 m); `visibility_range_end` LOD set 280/330/480/760 (+800 terrain, 700/900 coast) | LOD tuned to small island | layered visibility concept owned by P19/P20; **not** blindly multiplied | audit-only | perf probe budgets unchanged | INVENTORY |
| 24 | tests/smoke_node.gd L767–771 | streamer probes at (100,100)/(175,100)/(−400,−300) | 75 m tile expectations | verified still-correct under 125 m sectors (sector math checked before rollout) | none changed | smoke 945–949 green in full CI | VERIFIED |

## Failure-mode sweep results (§29 checklist)

- 900×700 / max-x-450 / max-z-350 assumptions: items 1, 12, 14, 15, 24 above — all traced to consumers; none authoritative for playability anymore.
- streamer 12-sized arrays / 75 m math: eliminated (item 6); no `GRID` or `75.0` remains in streamer.gd (verified by post-patch assertion).
- minimap normalization by old width/height: eliminated (item 11); local minimap PPM is a zoom constant, not a world bound (documented, kept).
- save migrations rejecting larger coordinates: fixed + tested (items 8–9).
- mission positions clamped silently: none — sanitize only touches player pos, mission dict byte-identical (foundation #34).
- police spawn ring / traffic loops / collectibles constrained to old lists: data lives in wb_kit (item 2) — legal in new world; graph/density migration owned by P04/P10/P11.
- "island" naming meaning "world": `wb_kit.ISLAND` remains the legacy rect name; the world authority is `WorldContract` (single authority rule holds — no second origin, no duplicate radius constants introduced).
